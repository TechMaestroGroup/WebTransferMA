define("OpenBankingMA/OpenBankingUIModule/userfrmConsentDetailsController", ['FormControllerUtility', 'CommonUtilities'], function(FormControllerUtility, CommonUtilities) {
    return {
        /**
         * @function : init
         * @description : Sets the initial actions for form
         * @return : NA
         */
        init: function() {
            this.view.preShow = this.preShow;
            this.view.postShow = this.postShow;
            this.view.onDeviceBack = function() {};
            this.view.onBreakpointChange = this.onBreakpointChange;
            this.view.onHide = this.onHide;
        },
        /**
         * @function : onNavigate
         * @description : gets invoked as soon as the control comes to the form
         * @return : NA
         */
        onNavigate: function(navObj) {
            this.setConsentSegmentData(navObj)
        },
        /**
         * @function : preShow
         * @description : Gets invoked initially before rendering of UI
         * @return : NA
         */
        preShow: function() {
            this.view.btnReject.onClick = this.showRejectPopup;
            this.view.rejectPopup.flxCross.onClick = this.hideRejectPopup;
            this.view.lblLink.onTouchEnd = this.showInfoPopup;
            this.view.btnInfoPopupClose.onClick = this.hideInfoPopup;
            this.view.btnApprove.onClick = this.onApprove;
            this.view.rejectPopup.btnYes.onClick = this.onReject;
        },
        /**
         * @function : postShow
         * @description : Gets invoked initially after rendering of UI
         * @return : NA
         */
        postShow: function() {
            this.view.lblLink.cursorType = "pointer";
            this.setInfoPopupDetails();
        },
        /**
         * @function : setConsentSegmentData
         * @description : Sets the consent data to the segment
         * @return : NA
         */
        setConsentSegmentData: function(data) {
            let segData = [];
            let widgetMap = this.getWidgetMapData();
            this.view.segConsentDetails.widgetDataMap = widgetMap;
            let dataList = data ? data.consentDetails ? data.consentDetails : [] : [];
            this.setAISPConsentUI(dataList);
            var formatUtility = applicationManager.getFormatUtilManager();
            let currentBreakpoint = kony.application.getCurrentBreakpoint();
            if (applicationManager.consentTypeName === "global") {
                this.view.segConsentDetails.rowTemplate = "flxGlobalConsent";
            } else {
                this.view.segConsentDetails.rowTemplate = "flxDetailedConsent";
            }
            if (dataList && dataList.length > 0) {
                if (applicationManager.consentTypeName === "global") {
                    segData = dataList.map(entityData => {
                        return {
                            "lblName": {
                                "text": entityData.accountName
                            },
                            "lblID": {
                                "text": entityData.IBAN
                            },
                            "lblAccountType": entityData.accountType,
                            "lblBalance": entityData.availableBalance ? formatUtility.formatAmountandAppendCurrencySymbol(entityData.availableBalance, entityData.currencyCode) : "",
                            "flxSeparator": {
                                "width": currentBreakpoint <= 640 ? "89%" : "95%"
                            }
                        };
                    });
                } else {
                    segData = dataList.map(entityData => {
                        return {
                            "lblName": {
                                "text": entityData.accountName
                            },
                            "lblID": {
                                "text": entityData.IBAN
                            },
                            "lblAccountType": entityData.accountType,
                            "lblBalance": entityData.availableBalance ? formatUtility.formatAmountandAppendCurrencySymbol(entityData.availableBalance, entityData.currencyCode) : "",
                            "lblHeading": {
                                "text": kony.i18n.getLocalizedString("i18n.tppconsent.whatyouaresharing"),
                            },
                            "lblType1": {
                                "text": kony.i18n.getLocalizedString("i18n.tppconsent.accountInfo"),
                                "isVisible": (entityData.isAccountInfoRequired === 'true') ? true : false
                            },
                            "lblType2": {
                                "text": kony.i18n.getLocalizedString("i18n.AccountsDetails.Balance"),
                                "isVisible": (entityData.isBalanceRequired === 'true') ? true : false
                            },
                            "lblType3": {
                                "text": kony.i18n.getLocalizedString("i18n.konybb.Common.Transactions"),
                                "isVisible": (entityData.isTransactionsRequired === 'true') ? true : false
                            },
                            "lblType4": {
                                "text": kony.i18n.getLocalizedString("i18n.tppconsent.beneficiarieswithoutcolon"),
                                "isVisible": (entityData.isBeneficiaryInfoRequired === 'true') ? true : false
                            },
                            "flxSeparator": {
                                "width": currentBreakpoint <= 640 ? "89%" : "95%"
                            }
                        };
                    });
                }
            }
            this.view.segConsentDetails.setData(segData);
            applicationManager.getPresentationUtility().dismissLoadingScreen();
        },
        /**
         * @function : getWidgetMapData
         * @description : Invoked to get the widget map
         * @return {JSON}: widgetMap
         */
        getWidgetMapData: function() {
            return {
                "lblName": "lblName",
                "lblID": "lblID",
                "lblAccountType": "lblAccountType",
                "lblBalance": "lblBalance",
                "lblType1": "lblType1",
                "lblType2": "lblType2",
                "lblType3": "lblType3",
                "lblType4": "lblType4",
                "flxSeparator": "flxSeparator"
            }
        },
        /**
         * @function : setInfoPopupDetails
         * @description : Invoked to set the data to the info popup
         * @return : NA
         */
        setInfoPopupDetails: function() {
            let infoPopupData = this.getInfoPopupi18nData();
            let accountsData = infoPopupData.accountsData;
            let transactionsData = infoPopupData.transactionsData;
            let balanceData = infoPopupData.balanceData;
            let beneficiariesData = infoPopupData.beneficiariesData;
            const infoDetails = [{
                header: accountsData.header,
                subHeader: Array.isArray(accountsData.list) ? accountsData.list[0] + ":" : accountsData.list,
                list: this.getInfoPopupList(Array.isArray(accountsData.list) ? accountsData.list[1] : "")
            }, {
                header: transactionsData.header,
                subHeader: Array.isArray(transactionsData.list) ? transactionsData.list[0] + ":" : transactionsData.list,
                list: this.getInfoListForTransaction(Array.isArray(transactionsData.list) ? transactionsData.list[1] : "")
            }, {
                header: balanceData.header,
                subHeader: Array.isArray(balanceData.list) ? balanceData.list[0] + ":" : balanceData.list,
                list: this.getInfoPopupList(Array.isArray(balanceData.list) ? balanceData.list[1] : "")
            }, {
                header: beneficiariesData.header,
                subHeader: Array.isArray(beneficiariesData.list) ? beneficiariesData.list[0] + ":" : beneficiariesData.list,
                list: this.getInfoPopupList(Array.isArray(beneficiariesData.list) ? beneficiariesData.list[1] : "")
            }];
            for (var i = 0; i < infoDetails.length; i++) {
                var compInstance = com.temenos.infoPopup({
                    "clipBounds": false,
                    "id": "infoPopup" + i,
                    "isVisible": true,
                    "top": "16dp"
                });
                compInstance.setUIData(infoDetails[i]);
                this.view.flxInfoPopupComp.add(compInstance);
            }
        },
        /**
         * @function : getInfoPopupi18nData
         * @description : Invoked to get the i18n values for header and list of info popup
         * @return {JSON}: contains the accountsData, transactionsData, balanceData and beneficiariesData
         */
        getInfoPopupi18nData: function() {
            let i18n = kony.i18n.getLocalizedString;
            let accountsData = i18n("i18n.tppconsent.accountInfoMsg").includes(":") ? i18n("i18n.tppconsent.accountInfoMsg").split(":") : i18n("i18n.tppconsent.accountInfoMsg");
            let transactionsData = i18n("i18n.tppconsent.transInfo_list1").includes(":") ? i18n("i18n.tppconsent.transInfo_list1").split(":") : i18n("i18n.tppconsent.transInfo_list1");
            let balanceData = i18n("i18n.tppconsent.balanceInfo").includes(":") ? i18n("i18n.tppconsent.balanceInfo").split(":") : i18n("i18n.tppconsent.balanceInfo");
            let beneficiariesData = i18n("i18n.tppconsent.beneficiariesInfo").includes(":") ? i18n("i18n.tppconsent.beneficiariesInfo").split(":") : i18n("i18n.tppconsent.beneficiariesInfo");
            return {
                accountsData: {
                    header: i18n("i18n.tppconsent.accountInformation"),
                    list: accountsData
                },
                transactionsData: {
                    header: i18n("i18n.common.transactions"),
                    list: transactionsData
                },
                balanceData: {
                    header: i18n("i18n.tppconsent.balances"),
                    list: balanceData
                },
                beneficiariesData: {
                    header: i18n("i18n.tppconsent.beneficiaries"),
                    list: beneficiariesData
                }
            }
        },
        /**
         * @function : getInfoPopupList
         * @description : Invoked to get the list of info popup
         * @param {String} data it contains the list with comma separtor
         * @return {JSON}: list
         */
        getInfoPopupList: function(data, sep) {
            let separtor = sep ? sep : ","
            if (data) {
                let list = data.split(separtor).map(item => ({
                    lblName: item.trim()
                }));
                return list;
            } else {
                return "";
            }
        },
        /**
         * @function : getInfoListForTransaction
         * @description : Invoked to get the list of info popup for transaction list
         * @param {String} data it contains the list with comma separtor
         * @return {JSON}: finalList
         */
        getInfoListForTransaction: function(data) {
            let finalList = [];
            let transactionsData1 = data ? data : [];
            let transactionsData2 = kony.i18n.getLocalizedString("i18n.tppconsent.transInfo_list2");
            let list1 = this.getInfoPopupList(transactionsData1, ";");
            let list2 = this.getInfoPopupList(transactionsData2, ";");
            finalList = list1.concat(list2);
            return finalList;
        },
        /**
         * @function : onApprove
         * @description : This function is invoked on click of Approve button
         * @return : NA
         */
        onApprove: function() {
            let scope = this;
            let openBankingMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                "moduleName": "OpenBankingUIModule",
                "appName": "OpenBankingMA"
            });
            openBankingMod.presentationController.approveConsent(successCallback, errorCallback);

            function successCallback(response) {
                scope.navigateToAckScreen(response);
            }

            function errorCallback(response) {
                scope.navigateToAckScreen(response);
                kony.print("Approve conent error: " + response);
            }
        },
        /**
         * @function : onReject
         * @description : This function is invoked on click of Reject button
         * @return : NA
         */
        onReject: function() {
            let scope = this;
            this.view.flxRejectPopup.setVisibility(false);
            let openBankingMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                "moduleName": "OpenBankingUIModule",
                "appName": "OpenBankingMA"
            });
            openBankingMod.presentationController.denyConsent(successCallback, errorCallback);

            function successCallback(response) {
                scope.navigateToAckScreen(response);
            }

            function errorCallback(response) {
                scope.navigateToAckScreen(response);
                kony.print("Deny conent error: " + response);
            }
        },
        /**
         * @function : navigateToAckScreen
         * @description : This function is used to navigate to Acknowledgement screen
         * @param {Objecr} navData it contains the navigation data
         * @return : NA
         */
        navigateToAckScreen: function(navData) {
            var navMan = applicationManager.getNavigationManager();
            navMan.navigateTo({
                "appName": "OpenBankingMA",
                "friendlyName": "OpenBankingUIModule/frmAcknowledgement"
            }, false, navData);
        },
        /**
         * @function : setAISPConsentUI
         * @description : This function is invoked to set UI for AISP consent flow
         * @return : NA
         */
        setAISPConsentUI: function(dataList) {
            let thirdPartyWebsiteName = applicationManager.deeplinkAppName;
            this.view.rtxInfo.text = kony.i18n.getLocalizedString("i18n.login.authorise") + "<b> " + thirdPartyWebsiteName + "</b> " + kony.i18n.getLocalizedString("i18n.login.authoriseAcc");
            if (dataList && dataList.length > 0) {
                date = dataList[0].consentExpiryDate + " (" + dataList[0].consentDuration + " days),";
            } else {
                date = "(180 days),"
            }
            this.view.lblInfo.text = kony.i18n.getLocalizedString("i18n.common.AccessUntil") + " " + date + " " + kony.i18n.getLocalizedString("i18n.common.withdrawlimit"); //"Access will be until "+ date +" You can withdraw access at any time.";
        },
        /**
         * @function : updateFormUI
         * @description : updateFormUI - the entry point method for the form controller.
         * @param {Object} viewModel - it contains the set of view properties and keys.
         * @return : NA
         */
        updateFormUI: function(viewModel) {
            if (viewModel.isLoading === true) {
                FormControllerUtility.showProgressBar(this.view);
            } else if (viewModel.isLoading === false) {
                FormControllerUtility.hideProgressBar(this.view);
            }
        },
        /**
         * @function : showRejectPopup
         * @description - shows the reject popup
         * @return : NA
         */
        showRejectPopup: function() {
            this.view.rejectPopup.flxSeperator.setVisibility(false);
            this.view.rejectPopup.flxSeperator2.setVisibility(false);
            this.view.flxRejectPopup.setVisibility(true);
            this.view.rejectPopup.lblHeading.text = kony.i18n.getLocalizedString("i18.termsandconditions");
            this.view.rejectPopup.lblPopupMessage.text = kony.i18n.getLocalizedString("i18n.tppConsent.reject");
            this.view.rejectPopup.btnYes.text = kony.i18n.getLocalizedString("i18n.common.yes");
            this.view.rejectPopup.btnNo.text = kony.i18n.getLocalizedString("i18n.common.no");
            this.view.rejectPopup.btnNo.onClick = this.hideRejectPopup;
        },
        /**
         * @function : hideRejectPopup
         * @description - hides the reject popup
         * @return : NA
         */
        hideRejectPopup: function() {
            this.view.flxRejectPopup.setVisibility(false);
        },
        /**
         * @function : showInfoPopup
         * @description - shows the info popup
         * @return : NA
         */
        showInfoPopup: function() {
            this.view.flxInfoPopup.setVisibility(true);
        },
        /**
         * @function : hideInfoPopup
         * @description - hides the info popup
         * @return : NA
         */
        hideInfoPopup: function() {
            this.view.flxInfoPopup.setVisibility(false);
        }
    };
});
define("OpenBankingMA/OpenBankingUIModule/frmConsentDetailsControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for frmConsentDetails **/
    AS_Form_d4094691f9ae4ca5982c37b65cb92a66: function AS_Form_d4094691f9ae4ca5982c37b65cb92a66(eventobject) {
        var self = this;
        return self.init.call(this);
    }
});
define("OpenBankingMA/OpenBankingUIModule/frmConsentDetailsController", ["OpenBankingMA/OpenBankingUIModule/userfrmConsentDetailsController", "OpenBankingMA/OpenBankingUIModule/frmConsentDetailsControllerActions"], function() {
    var controller = require("OpenBankingMA/OpenBankingUIModule/userfrmConsentDetailsController");
    var controllerActions = ["OpenBankingMA/OpenBankingUIModule/frmConsentDetailsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
