define("ArrangementsMA/ServiceRequestsUIModule/frmServiceRequests", function() {
    return function(controller) {
        function addWidgetsfrmServiceRequests() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxf8f7f8BG",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblServiceHead = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "height": "30dp",
                "id": "lblServiceHead",
                "isVisible": true,
                "left": "6.60%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.ServiceRequest\")",
                "top": "30dp",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMainWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": 0,
                "width": "92.80%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxRequests = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxRequests",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequests.setDefaultUnit(kony.flex.DP);
            var flxRequestsDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRequestsDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestsDetails.setDefaultUnit(kony.flex.DP);
            var viewRequests = new com.InfinityOLB.ArrangementsMA.viewRequests({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "id": "viewRequests",
                "isVisible": true,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "90%",
                "zIndex": 1,
                "appName": "ArrangementsMA",
                "viewType": "viewRequests",
                "overrides": {
                    "viewRequests": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var viewRequests_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmServiceRequests"] && appConfig.componentMetadata["ArrangementsMA"]["frmServiceRequests"]["viewRequests"]) || {};
            viewRequests.serviceParameters = viewRequests_data.serviceParameters || {
                "ServiceOrder": {
                    "Service": "ServiceRequestManagement",
                    "Object": "ServiceRequest",
                    "Verb": "getDetails"
                }
            };
            viewRequests.filterValues = viewRequests_data.filterValues || "[{\"id\":\"All Service Requests\",\"text\":\"{i.i18n.serviceRequests.AllServiceRequests}\"},{\"id\":\"Add New Address\",\"text\":\"{i.i18n.ProfileManagement.AddNewAddress}\"},{\"id\":\"Order Cheque Book\",\"text\":\"{i.i18n.serviceRequests.OrderChequeBook}\"},{\"id\":\"Cancel Direct Debit\",\"text\":\"{i.i18n.serviceRequests.CancelDirectDebit}\"},{\"id\":\"Activate Credit Card\",\"text\":\"{i.i18n.serviceRequests.ActivateCreditCard}\"},{\"id\":\"Activate Debit Card\",\"text\":\"{i.i18n.serviceRequests.ActivateDebitCard}\"},{\"id\":\"Add New Phone Number\",\"text\":\"{i.i18n.ProfileManagement.AddNewPhoneNumber}\"},{\"id\":\"Add New Email\",\"text\":\"{i.i18n.ProfileManagement.AddNewEmail}\"}]";
            viewRequests.sknFilterValueText = viewRequests_data.sknFilterValueText || "{\"$.BREAKPTS.BP1\":\"ICSknLblSSP42424213px\",\"default\":\"ICSknLblSSP42424215px\"}";
            viewRequests.iconFilterRowExpanded = viewRequests_data.iconFilterRowExpanded || "{\"vizIcon\": \"P\",\"skin\":\"ICSknLblDropdownFontIcon003e7518px\"}";
            viewRequests.dataMapping = viewRequests_data.dataMapping || {
                "segments": {
                    "segServiceRequest": {
                        "segmentMasterData": "${Collection.ServiceRequest}",
                        "segmentUI": {
                            "lblColumn1": "${segmentMasterData.requestDate}",
                            "valueField1": "${segmentMasterData.serviceReqProcessedTime}",
                            "lblColumn2": "${segmentMasterData.subType_description}",
                            "valueField2": "${segmentMasterData.type_description}",
                            "lblColumn3": "${segmentMasterData.serviceReqId}",
                            "valueField3": "${segmentMasterData.accountName}",
                            "lblColumn4": "${segmentMasterData.serviceReqStatus}",
                            "valueField4": "${segmentMasterData.signatoryApprovalRequired}",
                            "lblField1": "Last Update Date",
                            "lblField2": "Request Category",
                            "lblField3": "Account ID",
                            "lblField4": "Signatory Approval:"
                        }
                    }
                },
                "columnProps": {
                    "default": {
                        "column1": {
                            "text": "${i18n{i18n.serviceRequests.RequestedDate}}",
                            "isSortable": true,
                            "sortField": "requestDate"
                        },
                        "column2": {
                            "text": "${i18n{i18n.serviceRequests.ServiceRequest}}",
                            "isSortable": true,
                            "sortField": "subType_description"
                        },
                        "column3": {
                            "text": "${i18n{i18n.serviceRequests.ReferenceN}}",
                            "isSortable": true,
                            "sortField": "serviceReqId"
                        },
                        "column4": {
                            "text": "${i18n{i18n.serviceRequests.Status}}",
                            "isSortable": true,
                            "sortField": "serviceReqStatus"
                        }
                    }
                },
                "filterFields": {
                    "field1": "serviceReqStatus",
                    "field2": "subtype"
                },
                "advancedSearch": {
                    "default": {
                        "advance1": {
                            "fieldKey": "type",
                            "fieldValue": "type_description",
                            "defaultValue": "All Request Categories",
                            "defaultKey": "all"
                        },
                        "advance4": {
                            "fieldKey": "subType",
                            "fieldValue": "subType_description",
                            "defaultValue": "All Service Requests",
                            "defaultKey": "all"
                        },
                        "advance2": {
                            "fieldKey": "serviceReqStatus",
                            "fieldValue": "serviceReqStatus",
                            "defaultValue": "All Status",
                            "defaultKey": "all"
                        }
                    }
                },
                "simpleSearch": {
                    "fieldKey": "subType",
                    "fieldValue": "subType_description",
                    "defaultValue": "All Subtypes",
                    "defaultKey": "all"
                },
                "keywordSearch": [{
                    "field": "serviceReqStatus"
                }, {
                    "field": "subType_description"
                }, {
                    "field": "serviceReqId"
                }, {
                    "field": "accountId"
                }]
            };
            viewRequests.filterHeading = viewRequests_data.filterHeading || "All Subtype";
            viewRequests.sknFilterRowSelected = viewRequests_data.sknFilterRowSelected || "ICSknFlxf7f7f7";
            viewRequests.iconFilterRowCollapsed = viewRequests_data.iconFilterRowCollapsed || "{\"vizIcon\": \"O\",\"skin\":\"sknLblFontTypeIcon1a98ff14pxOther\"}";
            viewRequests.dataFormatting = viewRequests_data.dataFormatting || {};
            viewRequests.selectedFilter = viewRequests_data.selectedFilter || "{\"id\":\"all\",\"text\":\"All Subtype\"}";
            viewRequests.sknFilterRowUnselected = viewRequests_data.sknFilterRowUnselected || "ICSknFlxffffff";
            viewRequests.iconRadioButtonSelected = viewRequests_data.iconRadioButtonSelected || "{\"vizIcon\": \"M\",\"skin\":\"ICSknLblRadioBtnSelectedFontIcon003e7520px\"}";
            viewRequests.conditionalMappingKey = viewRequests_data.conditionalMappingKey || "${Collection.ServiceRequest.subType_description}";
            viewRequests.sknFilterList = viewRequests_data.sknFilterList || "ICSknFlxffffffBordere3e3e31pxRadius3pxShadowBottom";
            viewRequests.iconRadioButtonUnselected = viewRequests_data.iconRadioButtonUnselected || "{\"vizIcon\": \"L\",\"skin\":\"ICSknLblRadioBtnUnelectedFontIcona0a0a020px\"}";
            viewRequests.conditionalMapping = viewRequests_data.conditionalMapping || {
                "segServiceRequest": {
                    "Cancel Dispute Transaction": {
                        "lblColumn4": "Requested Initiated"
                    }
                }
            };
            viewRequests.sknSearchAndFilterBackground = viewRequests_data.sknSearchAndFilterBackground || "{\"$.BREAKPTS.BP1\":\"ICSknFlxf7f7f7\",\"default\":\"ICSknFlxffffff\"}";
            viewRequests.sknFilterHeading = viewRequests_data.sknFilterHeading || "{\"$.BREAKPTS.BP1\":\"ICSknLblSSP72727213px\",\"default\":\"ICSknLblSSP72727215px\"}";
            viewRequests.isFilterEnabled = viewRequests_data.isFilterEnabled || true;
            viewRequests.BREAKPTS = viewRequests_data.BREAKPTS || {
                "BP1": "640",
                "BP2": "1024",
                "BP3": "1366",
                "BP4": "1380"
            };
            viewRequests.sknFilterRowHover = viewRequests_data.sknFilterRowHover || "ICSknFlxf7f7f7Hover";
            viewRequests.onError = controller.AS_UWI_be3271a8fc56401c9440a74f6971022e;
            viewRequests.showErrorMessage = controller.AS_UWI_b4d27738c04140cea11ae11ecf7e2d92;
            flxRequestsDetails.add(viewRequests);
            flxRequests.add(flxRequestsDetails);
            flxMainWrapper.add(flxDowntimeWarning, flxRequests);
            flxMain.add(lblServiceHead, flxMainWrapper);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "150dp",
                        "left": "0dp",
                        "maxHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%",
                        "zIndex": 2
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1100,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Service Requests",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblServiceHead": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxRequests": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRequestsDetails": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "viewRequests": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooternew"
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblServiceHead": {
                        "left": {
                            "type": "string",
                            "value": "2.70%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxRequests": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRequestsDetails": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "viewRequests": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0.70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooternew"
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblServiceHead": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "rtxDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxRequests": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxRequestsDetails": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "viewRequests": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooternew"
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "lblServiceHead": {
                        "left": {
                            "type": "string",
                            "value": "6.80%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxRequestsDetails": {
                        "left": {
                            "type": "string",
                            "value": "1.60%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "99.40%"
                        },
                        "segmentProps": []
                    },
                    "viewRequests": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "viewRequests": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                },
                "customfooternew": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "",
                    "height": "150dp",
                    "left": "0dp",
                    "maxHeight": "",
                    "maxWidth": "",
                    "minHeight": "",
                    "minWidth": "",
                    "right": "",
                    "top": "0dp",
                    "width": "100%",
                    "zIndex": 2
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmServiceRequests,
            "enabledForIdleTimeout": true,
            "id": "frmServiceRequests",
            "init": controller.AS_Form_ec831d0047024b6891b28ea0e4830b85,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_ecdb436b4aaf481f9fab7ba4ee759deb,
            "postShow": controller.AS_Form_i27852a29b2d4f97babce056eb1ef7a6,
            "preShow": function(eventobject) {
                controller.AS_Form_jd7f539d12ad459fbc5f3e46d38c6959(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "title": "Service Requests",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});