define(function() {
    return function(controller) {
        var QRCodeGenerator = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "QRCodeGenerator",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "postShow": controller.AS_FlexContainer_j31107a81f2545668b0edcf39ffd9623,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "QRCodeGenerator"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "QRCodeGenerator"), extendConfig({}, controller.args[2], "QRCodeGenerator"));
        QRCodeGenerator.setDefaultUnit(kony.flex.DP);
        var brwsrQRCode = new kony.ui.Browser(extendConfig({
            "detectTelNumber": true,
            "enableNativeCommunication": true,
            "enableZoom": false,
            "height": "100%",
            "htmlString": "",
            "id": "brwsrQRCode",
            "isVisible": true,
            "left": "0",
            "setAsContent": true,
            "onPageFinished": controller.AS_Browser_j610aa12afa44d85aaf4f79bbeec74e8,
            "top": "0",
            "width": "100%"
        }, controller.args[0], "brwsrQRCode"), extendConfig({}, controller.args[1], "brwsrQRCode"), extendConfig({}, controller.args[2], "brwsrQRCode"));
        QRCodeGenerator.add(brwsrQRCode);
        QRCodeGenerator.compInstData = {}
        return QRCodeGenerator;
    }
})