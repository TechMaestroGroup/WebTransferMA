define("AlertSettingsMA/SettingsNewAlertsUIModule/frmAlertCommunication", function() {
    return function(controller) {
        function addWidgetsfrmAlertCommunication() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblHeading",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknSupportedFileTypes",
                "text": "Settings",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "87.80%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.updateSettingAndPreferences\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Settings"
            });
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Dropdown"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "maxHeight": "700dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "262dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxAlertCommunication = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAlertCommunication",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "minHeight": "550dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "98%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertCommunication.setDefaultUnit(kony.flex.DP);
            var flxAlertCommunicationContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxAlertCommunicationContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "67dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "125dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertCommunicationContainer.setDefaultUnit(kony.flex.DP);
            var flxAlertsCommunication = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAlertsCommunication",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "minHeight": "700dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsCommunication.setDefaultUnit(kony.flex.DP);
            var flxAlertsCommContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "36dp",
                "clipBounds": false,
                "id": "flxAlertsCommContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsCommContainer.setDefaultUnit(kony.flex.DP);
            var flxAlertCommunicationHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxAlertCommunicationHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertCommunicationHeader.setDefaultUnit(kony.flex.DP);
            var flxAlertHeaderSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAlertHeaderSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3op60",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertHeaderSeperator.setDefaultUnit(kony.flex.DP);
            flxAlertHeaderSeperator.add();
            var lblAlertCommHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblAlertCommHeading",
                "isVisible": true,
                "left": "0px",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.alertSettings.Communication\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEditCommAlerts = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "42dp",
                "id": "btnEditCommAlerts",
                "isVisible": true,
                "right": "3px",
                "skin": "sknBtnSSP0273e315PxBg0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertCommunicationHeader.add(flxAlertHeaderSeperator, lblAlertCommHeading, btnEditCommAlerts);
            var flxErrorEditAlertComm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52dp",
                "id": "flxErrorEditAlertComm",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorEditAlertComm.setDefaultUnit(kony.flex.DP);
            var imgErrorAlertComm = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgErrorAlertComm",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorAlertComm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblErrorAlertComm",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknlblff000015px",
                "text": "Page level/transaction level errors appear here.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorEditAlertComm.add(imgErrorAlertComm, lblErrorAlertComm);
            var flxAlertCommWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAlertCommWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "100dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertCommWarning.setDefaultUnit(kony.flex.DP);
            var flxAlertsCommWarningWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20px",
                "clipBounds": true,
                "id": "flxAlertsCommWarningWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBordere3e3e3",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsCommWarningWrapper.setDefaultUnit(kony.flex.DP);
            var lblAlertsCommWarningImage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblAlertsCommWarningImage",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknlbl4a90e230OLBFontIconsPx",
                "text": "K",
                "top": "15px",
                "width": "32px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxAlertsCommWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20px",
                "id": "rtxAlertsCommWarning",
                "isVisible": true,
                "left": "50dp",
                "right": "5%",
                "skin": "sknRtx42424215px",
                "text": "You have selected the following contact details for alert communication.\n",
                "top": "20px",
                "width": "93%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertsCommWarningWrapper.add(lblAlertsCommWarningImage, rtxAlertsCommWarning);
            flxAlertCommWarning.add(flxAlertsCommWarningWrapper);
            var flxAlertCommBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAlertCommBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBordere3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertCommBody.setDefaultUnit(kony.flex.DP);
            var flxAlertComm1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAlertComm1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertComm1.setDefaultUnit(kony.flex.DP);
            var lblPhoneComm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPhoneComm",
                "isVisible": true,
                "left": "20px",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PhoneNumber\")",
                "top": "20px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPhoneCommValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "20px",
                "id": "lblPhoneCommValue",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Mobile - (+91) 8888888888",
                "top": "5px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCommPhoneDropDown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20px",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCommPhoneDropDown",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "30%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCommPhoneDropDown.setDefaultUnit(kony.flex.DP);
            var flxPhoneDropDown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPhoneDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFFFFFFmodbre3e3e33px",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneDropDown.setDefaultUnit(kony.flex.DP);
            var lblSelectPhoneNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSelectPhoneNumber",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknLblSSP42424215px",
                "text": "Mobile-(+91)9090909090",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCommDropDown1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "centerY": "55%",
                "clipBounds": true,
                "height": "10dp",
                "id": "flxCommDropDown1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10px",
                "skin": "slFbox",
                "width": "20px",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxCommDropDown1.setDefaultUnit(kony.flex.DP);
            var lblImgDropdown11 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "55%",
                "id": "lblImgDropdown11",
                "isVisible": true,
                "skin": "sknLblFontTypeIcon1a98ff12pxOther",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCommDropDown1.add(lblImgDropdown11);
            flxPhoneDropDown.add(lblSelectPhoneNumber, flxCommDropDown1);
            var flxPhoneNumbersSegment = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "5dp",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "250dp",
                "horizontalScrollIndicator": true,
                "id": "flxPhoneNumbersSegment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopysknFlxscrollffffffShadowdddcdc0c89e2b18399448",
                "top": "5dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 10
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumbersSegment.setDefaultUnit(kony.flex.DP);
            var segPhoneComm = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblContact": "joe.smith@temenos.com",
                    "lblPrimary": "Primary"
                }, {
                    "lblContact": "joe.smith@temenos.com",
                    "lblPrimary": "Primary"
                }, {
                    "lblContact": "joe.smith@temenos.com",
                    "lblPrimary": "Primary"
                }, {
                    "lblContact": "joe.smith@temenos.com",
                    "lblPrimary": "Primary"
                }, {
                    "lblContact": "joe.smith@temenos.com",
                    "lblPrimary": "Primary"
                }, {
                    "lblContact": "joe.smith@temenos.com",
                    "lblPrimary": "Primary"
                }, {
                    "lblContact": "joe.smith@temenos.com",
                    "lblPrimary": "Primary"
                }, {
                    "lblContact": "joe.smith@temenos.com",
                    "lblPrimary": "Primary"
                }, {
                    "lblContact": "joe.smith@temenos.com",
                    "lblPrimary": "Primary"
                }, {
                    "lblContact": "joe.smith@temenos.com",
                    "lblPrimary": "Primary"
                }],
                "groupCells": false,
                "id": "segPhoneComm",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AlertSettingsMA",
                    "friendlyName": "flxAlertCommunication"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAlertCommunication": "flxAlertCommunication",
                    "flxContactsList": "flxContactsList",
                    "flxPrimary": "flxPrimary",
                    "lblContact": "lblContact",
                    "lblPrimary": "lblPrimary"
                },
                "zIndex": 5,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhoneNumbersSegment.add(segPhoneComm);
            flxCommPhoneDropDown.add(flxPhoneDropDown, flxPhoneNumbersSegment);
            var flxAlertCommSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAlertCommSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3op60",
                "width": "94%",
                "zIndex": 5,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertCommSeperator.setDefaultUnit(kony.flex.DP);
            flxAlertCommSeperator.add();
            flxAlertComm1.add(lblPhoneComm, lblPhoneCommValue, flxCommPhoneDropDown, flxAlertCommSeperator);
            var flxAlertComm2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAlertComm2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertComm2.setDefaultUnit(kony.flex.DP);
            var lblEmailComm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEmailComm",
                "isVisible": true,
                "left": "20px",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.MFA.EmailID\")",
                "top": "20px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEmailCommValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "20px",
                "id": "lblEmailCommValue",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSPR42424215px",
                "text": "john.doe@kony.com",
                "top": "5px",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCommEmailDropDown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20px",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCommEmailDropDown",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "30%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCommEmailDropDown.setDefaultUnit(kony.flex.DP);
            var flxEmailDropDown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxEmailDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFFFFFFmodbre3e3e33px",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailDropDown.setDefaultUnit(kony.flex.DP);
            var lblSelectEmailNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSelectEmailNumber",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknLblSSPR42424215px",
                "text": "john.bailey007@gmail.com",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCommDropDown21 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "centerY": "55%",
                "clipBounds": true,
                "height": "10dp",
                "id": "flxCommDropDown21",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10px",
                "skin": "slFbox",
                "width": "20px",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxCommDropDown21.setDefaultUnit(kony.flex.DP);
            var lblImgDropdown21 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "55%",
                "id": "lblImgDropdown21",
                "isVisible": true,
                "skin": "sknLblFontTypeIcon1a98ff12pxOther",
                "text": "O",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCommDropDown21.add(lblImgDropdown21);
            flxEmailDropDown.add(lblSelectEmailNumber, flxCommDropDown21);
            var flxEmailsSegment = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "5dp",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "250dp",
                "horizontalScrollIndicator": true,
                "id": "flxEmailsSegment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopysknFlxscrollffffffShadowdddcdc0c89e2b18399448",
                "top": "5dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 10
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailsSegment.setDefaultUnit(kony.flex.DP);
            var segEmailComm = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segEmailComm",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AlertSettingsMA",
                    "friendlyName": "flxAlertCommunication"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAlertCommunication": "flxAlertCommunication",
                    "flxContactsList": "flxContactsList",
                    "flxPrimary": "flxPrimary",
                    "lblContact": "lblContact",
                    "lblPrimary": "lblPrimary"
                },
                "zIndex": 5,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEmailsSegment.add(segEmailComm);
            flxCommEmailDropDown.add(flxEmailDropDown, flxEmailsSegment);
            flxAlertComm2.add(lblEmailComm, lblEmailCommValue, flxCommEmailDropDown);
            flxAlertCommBody.add(flxAlertComm1, flxAlertComm2);
            flxAlertsCommContainer.add(flxAlertCommunicationHeader, flxErrorEditAlertComm, flxAlertCommWarning, flxAlertCommBody);
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var flxAlertsSeperator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAlertsSeperator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBordere3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsSeperator3.setDefaultUnit(kony.flex.DP);
            flxAlertsSeperator3.add();
            var btnAlertCommSave = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "65%",
                "height": "40dp",
                "id": "btnAlertCommSave",
                "isVisible": true,
                "right": 20,
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "top": "20dp",
                "width": "150px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnAlertCommCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "65%",
                "height": "40dp",
                "id": "btnAlertCommCancel",
                "isVisible": true,
                "left": "0",
                "right": "190px",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxButtons.add(flxAlertsSeperator3, btnAlertCommSave, btnAlertCommCancel);
            flxAlertsCommunication.add(flxAlertsCommContainer, flxButtons);
            flxAlertCommunicationContainer.add(flxAlertsCommunication);
            flxAlertCommunication.add(flxAlertCommunicationContainer);
            flxRight.add(flxAlertCommunication);
            flxContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxMainContainer.add(flxContainer);
            flxMain.add(lblHeading, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgCross": {
                        "height": "15dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmAlertCommunication": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Profile Settings",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxf8f7f8",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "minHeight": {
                            "type": "string",
                            "value": "510dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "minHeight": {
                            "type": "string",
                            "value": "540dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "maxHeight": {
                            "type": "string",
                            "value": "525dp"
                        },
                        "skin": "slFbox",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxRight": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "580dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxAlertCommunication": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "550dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "CopysknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAlertCommunicationContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "550dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsCommunication": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "minHeight": {
                            "type": "string",
                            "value": "550dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsCommContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "lblAlertCommHeading": {
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "btnEditCommAlerts": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknBtnSSP0273e313Px",
                        "segmentProps": []
                    },
                    "flxErrorEditAlertComm": {
                        "skin": "sknflxBordere3e3e3",
                        "segmentProps": []
                    },
                    "imgErrorAlertComm": {
                        "segmentProps": []
                    },
                    "flxAlertCommWarning": {
                        "segmentProps": []
                    },
                    "lblAlertsCommWarningImage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "12px"
                        },
                        "width": {
                            "type": "string",
                            "value": "32px"
                        },
                        "segmentProps": []
                    },
                    "rtxAlertsCommWarning": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknRtx42424213px",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertCommBody": {
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxAlertComm1": {
                        "zIndex": 25,
                        "segmentProps": []
                    },
                    "lblPhoneComm": {
                        "skin": "sknSSP72727213Px",
                        "segmentProps": []
                    },
                    "lblPhoneCommValue": {
                        "skin": "sknLblSSP42424213px",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxCommPhoneDropDown": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneDropDown": {
                        "blockedUISkin": "s2a94ef5bcb5484b89e960986af6399e",
                        "segmentProps": []
                    },
                    "lblSelectPhoneNumber": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknLblSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbersSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "segPhoneComm": {
                        "data": [{
                            "lblContact": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAlertCommunicationMobile"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxAlertCommunicationMobile": "flxAlertCommunicationMobile",
                            "flxContactsList": "flxContactsList",
                            "flxPrimary": "flxPrimary",
                            "lblContact": "lblContact",
                            "lblPrimary": "lblPrimary"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "flxAlertCommSeperator": {
                        "segmentProps": []
                    },
                    "flxAlertComm2": {
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "lblEmailComm": {
                        "skin": "sknSSP72727213Px",
                        "segmentProps": []
                    },
                    "lblEmailCommValue": {
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxCommEmailDropDown": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailDropDown": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectEmailNumber": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknLblSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailsSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "segEmailComm": {
                        "data": [],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAlertCommunicationMobile"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxAlertCommunicationMobile": "flxAlertCommunicationMobile",
                            "flxContactsList": "flxContactsList",
                            "flxPrimary": "flxPrimary",
                            "lblContact": "lblContact",
                            "lblPrimary": "lblPrimary"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "flxButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "btnAlertCommSave": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnAlertCommCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup.imgCross": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "segmentProps": []
                    },
                    "flxRight": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAlertCommunication": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertCommunicationContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsCommContainer": {
                        "height": {
                            "type": "string",
                            "value": "620dp"
                        },
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "flxErrorEditAlertComm": {
                        "skin": "sknflxBordere3e3e3",
                        "segmentProps": []
                    },
                    "imgErrorAlertComm": {
                        "segmentProps": []
                    },
                    "rtxAlertsCommWarning": {
                        "bottom": {
                            "type": "string",
                            "value": "10px"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertComm1": {
                        "zIndex": 25,
                        "segmentProps": []
                    },
                    "lblPhoneComm": {
                        "text": "Phone Number:",
                        "segmentProps": []
                    },
                    "flxCommPhoneDropDown": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbersSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertComm2": {
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "lblEmailComm": {
                        "segmentProps": []
                    },
                    "flxCommEmailDropDown": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailDropDown": {
                        "segmentProps": []
                    },
                    "lblSelectEmailNumber": {
                        "segmentProps": []
                    },
                    "flxEmailsSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "btnAlertCommSave": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnAlertCommCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "skin": "sknSupportedFileTypes",
                        "text": "Settings",
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "bbSKnFlxf1ab15",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "skin": "bbSKnFlxf1ab15",
                        "segmentProps": []
                    },
                    "flxAlertCommunication": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertCommunicationContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsCommContainer": {
                        "height": {
                            "type": "string",
                            "value": "620dp"
                        },
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "flxErrorEditAlertComm": {
                        "skin": "sknflxBordere3e3e3",
                        "segmentProps": []
                    },
                    "imgErrorAlertComm": {
                        "segmentProps": []
                    },
                    "rtxAlertsCommWarning": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertComm1": {
                        "zIndex": 25,
                        "segmentProps": []
                    },
                    "flxCommPhoneDropDown": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbersSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "segPhoneComm": {
                        "segmentProps": []
                    },
                    "flxAlertComm2": {
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "flxCommEmailDropDown": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectEmailNumber": {
                        "segmentProps": []
                    },
                    "flxEmailsSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "btnAlertCommSave": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnAlertCommCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmAlertCommunication": {
                        "segmentProps": []
                    },
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "1202dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "segmentProps": []
                    },
                    "flxAlertCommunication": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "860dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertCommunicationContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsCommContainer": {
                        "height": {
                            "type": "string",
                            "value": "620dp"
                        },
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "flxErrorEditAlertComm": {
                        "skin": "sknflxBordere3e3e3",
                        "segmentProps": []
                    },
                    "imgErrorAlertComm": {
                        "segmentProps": []
                    },
                    "rtxAlertsCommWarning": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertComm1": {
                        "zIndex": 25,
                        "segmentProps": []
                    },
                    "flxCommPhoneDropDown": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbersSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertComm2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "flxCommEmailDropDown": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailsSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "btnAlertCommSave": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnAlertCommCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "CustomPopup.imgCross": {
                    "height": "15dp"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmAlertCommunication,
            "enabledForIdleTimeout": true,
            "id": "frmAlertCommunication",
            "init": controller.AS_Form_b4513c639eb24f53938188776b46091c,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.alertSettings.alertComm\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AlertSettingsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});