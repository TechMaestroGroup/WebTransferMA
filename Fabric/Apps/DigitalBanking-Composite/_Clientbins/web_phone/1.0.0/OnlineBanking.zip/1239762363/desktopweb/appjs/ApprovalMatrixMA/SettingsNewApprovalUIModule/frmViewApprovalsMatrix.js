define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmViewApprovalsMatrix", function() {
    return function(controller) {
        function addWidgetsfrmViewApprovalsMatrix() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxMenuContainer": {
                        "width": "100%"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "84.50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var lblApprovalMatrixHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Foreign Exchange"
                },
                "id": "lblApprovalMatrixHeader",
                "isVisible": true,
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Settings.ApprovalMatrix.approvalMatrix\")",
                "top": "20dp",
                "width": "88%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxAckHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "58px",
                "id": "flxAckHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckHeader.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "96%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxImgContainer = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxImgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "32dp",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgContainer.setDefaultUnit(kony.flex.DP);
            var imgCheck = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgCheck",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "success_green_2.png",
                "top": "5dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgContainer.add(imgCheck);
            var lblSuccessMessage = new kony.ui.Label({
                "id": "lblSuccessMessage",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl000d19sspSemiBold24px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.Signatory.GroupDelete\")",
                "top": "33dp",
                "width": "88%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeft.add(flxImgContainer, lblSuccessMessage);
            var flxImgClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxImgClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "92%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "50dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "height": "100%",
                "id": "imgClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgClose.add(imgClose);
            flxAckHeader.add(flxLeft, flxImgClose);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "91.51%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxContractContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "80px",
                "id": "flxContractContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContractContainer.setDefaultUnit(kony.flex.DP);
            var flxAccountName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountName",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountName.setDefaultUnit(kony.flex.DP);
            var lblAccountNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.account\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNameValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Checking Account….6737",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountName.add(lblAccountNameHeader, lblAccountNameValue);
            var flxCustomerName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerName.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.customerName\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerHeaderValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerHeaderValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Kony India Pvt Limited-kalyani1SB",
                "width": "65%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerName.add(lblCustomerNameHeader, lblCustomerHeaderValue);
            var flxCustomerID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerID",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerID.setDefaultUnit(kony.flex.DP);
            var lblCustomerIDHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.lblCustomerID\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerIDValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "34256452388",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerID.add(lblCustomerIDHeader, lblCustomerIDValue);
            var flxContract = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxContract",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContract.setDefaultUnit(kony.flex.DP);
            var lblContractHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.contract\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblContractValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Corp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContract.add(lblContractHeader, lblContractValue);
            flxContractContainer.add(flxAccountName, flxCustomerName, flxCustomerID, flxContract);
            var flxApprovalMatrixContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxApprovalMatrixContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixContainer.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxHeaderContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.setDefaultUnit(kony.flex.DP);
            var lblCustomerLevelHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerLevelHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.customerLevellbl\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAccountLevelMatrix = new kony.ui.Button({
                "centerY": "50%",
                "height": "30dp",
                "id": "btnAccountLevelMatrix",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.accountLevelbtn\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.add(lblCustomerLevelHeader, lblHeaderSeparator, btnAccountLevelMatrix);
            var flxSwitchContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxSwitchContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwitchContainer.setDefaultUnit(kony.flex.DP);
            var flxSwitch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSwitch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwitch.setDefaultUnit(kony.flex.DP);
            var lblNoApprovalsRequire = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNoApprovalsRequire",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.approvalMatrix.NoApprovalsRequired\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var switchApprovals = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "switchApprovals",
                "isVisible": true,
                "left": "20dp",
                "right": 20,
                "skin": "slImage",
                "src": "includetoggle.png",
                "top": "10dp",
                "width": "35dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwitch.add(lblNoApprovalsRequire, switchApprovals);
            var lblSwitchHeaderSeperator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblSwitchHeaderSeperator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwitchSeparator = new kony.ui.Label({
                "bottom": "0dp",
                "height": "1dp",
                "id": "lblSwitchSeparator",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwitchContainer.add(flxSwitch, lblSwitchHeaderSeperator, lblSwitchSeparator);
            var flxFeaturesAndBackContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFeaturesAndBackContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeaturesAndBackContainer.setDefaultUnit(kony.flex.DP);
            var flxFeatuersContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFeatuersContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "90dp",
                "width": "30%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeatuersContainer.setDefaultUnit(kony.flex.DP);
            var lblFeaturesHeader = new kony.ui.Label({
                "id": "lblFeaturesHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.features\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFeatureSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblFeatureSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "5dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBoxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBoxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "20dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoxSearch.setDefaultUnit(kony.flex.DP);
            var flxSearchimg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSearchimg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15px",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "width": "17px",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchimg.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgSearch",
                "isVisible": true,
                "skin": "slImage",
                "src": "search.png",
                "width": "40dp",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchimg.add(imgSearch);
            var tbxSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxa0a0a0Ssp15px",
                "height": "100%",
                "id": "tbxSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "42px",
                "placeholder": "Search for keywords",
                "right": "40px",
                "secureTextEntry": false,
                "skin": "bbSknTbx949494SSP15pxItalic",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "bbSknTbx949494SSP15pxItalic"
            });
            flxBoxSearch.add(flxSearchimg, tbxSearch);
            var lblSearchSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblSearchSeparator",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "20dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Features = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "Features",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "top": "10dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFeatuersContainer.add(lblFeaturesHeader, lblFeatureSeparator, flxBoxSearch, lblSearchSeparator, Features);
            var flxBackContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBackContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainer.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "50dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "top": "0",
                "width": "175dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainer.add(lblBottomSeparator, btnBack);
            flxFeaturesAndBackContainer.add(flxFeatuersContainer, flxBackContainer);
            var flxApprovalRulesContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalRulesContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30.10%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "90dp",
                "width": "69.50%",
                "zIndex": 17,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalRulesContainer.setDefaultUnit(kony.flex.DP);
            var lblViewEditHeader = new kony.ui.Label({
                "id": "lblViewEditHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.viewPermissionlbl\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblViewEditHeaderSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblViewEditHeaderSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "45dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApprovalMatrixAccountWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalMatrixAccountWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "46dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixAccountWrapper.setDefaultUnit(kony.flex.DP);
            var segApprovalMatrix = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segApprovalMatrix",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixRow"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixSection"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnEditMatrix": "btnEditMatrix",
                    "flxApprovalMatrixRow": "flxApprovalMatrixRow",
                    "flxApprovalMatrixSection": "flxApprovalMatrixSection",
                    "flxHeaderLowerHalf": "flxHeaderLowerHalf",
                    "flxHeaderPending": "flxHeaderPending",
                    "flxHeaderUpperHalf": "flxHeaderUpperHalf",
                    "flxLimit1": "flxLimit1",
                    "flxNoRecords": "flxNoRecords",
                    "imgNoRecordsIcon": "imgNoRecordsIcon",
                    "imgWarning": "imgWarning",
                    "lblApprovalLimits": "lblApprovalLimits",
                    "lblApprovalLimitsValue": "lblApprovalLimitsValue",
                    "lblApprovalNumbers": "lblApprovalNumbers",
                    "lblApprovalRule": "lblApprovalRule",
                    "lblApprovalRuleValue": "lblApprovalRuleValue",
                    "lblApprovers": "lblApprovers",
                    "lblApproversValue": "lblApproversValue",
                    "lblFeatureAction": "lblFeatureAction",
                    "lblNoApprovalRulesDefined": "lblNoApprovalRulesDefined",
                    "lblNumOfApprovers": "lblNumOfApprovers",
                    "lblPending": "lblPending",
                    "lblSeparator1": "lblSeparator1",
                    "lblSeparator2": "lblSeparator2",
                    "lblSeparator3": "lblSeparator3"
                },
                "width": "100%",
                "zIndex": 2,
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoApprovalMatrixData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxNoApprovalMatrixData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "53dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoApprovalMatrixData.setDefaultUnit(kony.flex.DP);
            var lblNoApprovalMatrixData = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblNoApprovalMatrixData",
                "isVisible": true,
                "left": "151dp",
                "skin": "bbSknLbl424242SSP20PxBold",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoApprovalMatrixData.add(lblNoApprovalMatrixData);
            flxApprovalMatrixAccountWrapper.add(segApprovalMatrix, flxNoApprovalMatrixData);
            flxApprovalRulesContainer.add(lblViewEditHeader, lblViewEditHeaderSeparator, flxApprovalMatrixAccountWrapper);
            var lblFeatuesSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "id": "lblFeatuesSeparator",
                "isVisible": true,
                "left": "30%",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "89dp",
                "width": "1dp",
                "zIndex": 16
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixContainer.add(flxHeaderContainer, flxSwitchContainer, flxFeaturesAndBackContainer, flxApprovalRulesContainer, lblFeatuesSeparator);
            var flxSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxSignatoryGroups",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainerSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxHeaderContainerSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainerSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var lblCustomerLevelHeaderrSignatoryGroups = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerLevelHeaderrSignatoryGroups",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.SignatoryGroups.viewManage\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderSeparatorrSignatoryGroups = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderSeparatorrSignatoryGroups",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCreateNewGroup = new kony.ui.Button({
                "centerY": "50%",
                "height": "30dp",
                "id": "btnCreateNewGroup",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.SignaotryGoup.CreateNewGroup\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderContainerSignatoryGroups.add(lblCustomerLevelHeaderrSignatoryGroups, lblHeaderSeparatorrSignatoryGroups, btnCreateNewGroup);
            var flxSearchContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100dp",
                "id": "flxSearchContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchContainer.setDefaultUnit(kony.flex.DP);
            var flxBoxSearchSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxBoxSearchSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "width": "95%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoxSearchSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var flxSearchimgSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSearchimgSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15px",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "width": "17px",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchimgSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var imgSearchSignatoryGroups = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgSearchSignatoryGroups",
                "isVisible": true,
                "skin": "slImage",
                "src": "search.png",
                "width": "40dp",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchimgSignatoryGroups.add(imgSearchSignatoryGroups);
            var tbxSearchSignatoryGroups = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "height": "100%",
                "id": "tbxSearchSignatoryGroups",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0px",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"konybb.SignatoryGroups.SearchPlaceHolder\")",
                "right": "0px",
                "secureTextEntry": false,
                "skin": "bbSknTbx949494SSP15pxNormal",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [4, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "bbSknTbx949494SSP15pxNormal"
            });
            flxBoxSearchSignatoryGroups.add(flxSearchimgSignatoryGroups, tbxSearchSignatoryGroups);
            flxSearchContainer.add(flxBoxSearchSignatoryGroups);
            var flxSegSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSegSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var segSignatoryGroups = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgContractSort": "sorting.png",
                            "imgCustIDSort": "sorting.png",
                            "imgCustomerNameSort": "sorting.png",
                            "imgStatustSort": "sorting.png",
                            "lblActionHeader": "Action",
                            "lblBottomSepartor": "-",
                            "lblContractHeader": "Contract",
                            "lblCustomerIDHeader": "Customer ID",
                            "lblCustomerNameHeader": "Customer Name",
                            "lblStatusHeader": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Status\")",
                            "lblTopSeparator": "-"
                        },
                        [{
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }]
                    ],
                    [{
                            "imgContractSort": "sorting.png",
                            "imgCustIDSort": "sorting.png",
                            "imgCustomerNameSort": "sorting.png",
                            "imgStatustSort": "sorting.png",
                            "lblActionHeader": "Action",
                            "lblBottomSepartor": "-",
                            "lblContractHeader": "Contract",
                            "lblCustomerIDHeader": "Customer ID",
                            "lblCustomerNameHeader": "Customer Name",
                            "lblStatusHeader": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Status\")",
                            "lblTopSeparator": "-"
                        },
                        [{
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "imgStatustSort": "sorting.png",
                            "imgiconSym": "sorting.png",
                            "lblActiveAndPending": "Contract",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-",
                            "lblStatusIcon": "Status"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segSignatoryGroups",
                "isVisible": true,
                "left": "0dp",
                "minHeight": "250dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixContractRowStatus"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixContractHeaderStatus"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnAction": "btnAction",
                    "flxApprovalMatrixContractHeaderStatus": "flxApprovalMatrixContractHeaderStatus",
                    "flxApprovalMatrixContractRowStatus": "flxApprovalMatrixContractRowStatus",
                    "flxContract": "flxContract",
                    "flxCustID": "flxCustID",
                    "flxCustomerName": "flxCustomerName",
                    "flxHeadersContainer": "flxHeadersContainer",
                    "flxNoRecords": "flxNoRecords",
                    "flxStatus": "flxStatus",
                    "imgContractSort": "imgContractSort",
                    "imgCustIDSort": "imgCustIDSort",
                    "imgCustomerNameSort": "imgCustomerNameSort",
                    "imgStatustSort": "imgStatustSort",
                    "imgiconSym": "imgiconSym",
                    "lblActionHeader": "lblActionHeader",
                    "lblActiveAndPending": "lblActiveAndPending",
                    "lblBottomSepartor": "lblBottomSepartor",
                    "lblContract": "lblContract",
                    "lblContractHeader": "lblContractHeader",
                    "lblCustomerID": "lblCustomerID",
                    "lblCustomerIDHeader": "lblCustomerIDHeader",
                    "lblCustomerName": "lblCustomerName",
                    "lblCustomerNameHeader": "lblCustomerNameHeader",
                    "lblNoRecords": "lblNoRecords",
                    "lblRowSeparator": "lblRowSeparator",
                    "lblStatusHeader": "lblStatusHeader",
                    "lblStatusIcon": "lblStatusIcon",
                    "lblTopSeparator": "lblTopSeparator"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegSignatoryGroups.add(segSignatoryGroups);
            var flxNoRecords = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "400dp",
                "id": "flxNoRecords",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoRecords.setDefaultUnit(kony.flex.DP);
            var lblNoRecords = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "40%",
                "centerY": "50%",
                "height": "40dp",
                "id": "lblNoRecords",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoofRecords = new kony.ui.Label({
                "centerX": "54%",
                "centerY": "50%",
                "id": "lblNoofRecords",
                "isVisible": true,
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.userMgmt.errorsignatorygroup\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoRecords.add(lblNoRecords, lblNoofRecords);
            var flxBackContainerSignatoryGruops = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBackContainerSignatoryGruops",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainerSignatoryGruops.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparatorSignatoryGruops = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparatorSignatoryGruops",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBackSignatoryGruops = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "50dp",
                "id": "btnBackSignatoryGruops",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "top": "0",
                "width": "175dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainerSignatoryGruops.add(lblBottomSeparatorSignatoryGruops, btnBackSignatoryGruops);
            flxSignatoryGroups.add(flxHeaderContainerSignatoryGroups, flxSearchContainer, flxSegSignatoryGroups, flxNoRecords, flxBackContainerSignatoryGruops);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "centerX": "viz.val_cleared",
                        "left": "6dp",
                        "width": "103%"
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "left": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxContent.add(lblApprovalMatrixHeader, flxAckHeader, flxDowntimeWarning, flxContractContainer, flxApprovalMatrixContainer, flxSignatoryGroups, flxFooter);
            flxMain.add(flxContent);
            flxFormContent.add(flxMain);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxProfileDeletePopUp = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "102%",
                "id": "flxProfileDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxProfileDelete = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "268dp",
                "id": "flxProfileDelete",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDelete.setDefaultUnit(kony.flex.DP);
            var flxprofileDeleteHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxprofileDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofileDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Delete\")"
                },
                "id": "lblProfileDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Delete Picture",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxprofiledeleteClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxprofiledeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.setDefaultUnit(kony.flex.DP);
            var imgProfileDeleteClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgProfileDeleteClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.add(imgProfileDeleteClose);
            flxprofileDeleteHeader.add(lblProfileDeleteHeader, flxprofiledeleteClose);
            var flxProfileDeleteSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxProfileDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxProfileDeleteSeperator.add();
            var flxProfileDeleteContent = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "65dp",
                "id": "flxProfileDeleteContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteContent = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.deletePhoneNum\")"
                },
                "id": "lblProfileDeleteContent",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknlblUserName",
                "text": "Are you sure you want to remove your profile picture?",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.add(lblProfileDeleteContent);
            var flxWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "0%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var flxDisablWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxDisablWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20px",
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "20dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisablWarning.setDefaultUnit(kony.flex.DP);
            flxDisablWarning.add();
            flxWarning.add(flxDisablWarning);
            var flxProfileDeleteButtons = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": true,
                "height": "109px",
                "id": "flxProfileDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnDeletePopupNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.No\")"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupNo",
                "isVisible": true,
                "left": "35.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "28.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "No"
            });
            var btnDeletePopupYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.Yes\")"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupYes",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "28.44%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Yes"
            });
            flxProfileDeleteButtons.add(btnDeletePopupNo, btnDeletePopupYes);
            flxProfileDelete.add(flxprofileDeleteHeader, flxProfileDeleteSeperator, flxProfileDeleteContent, flxWarning, flxProfileDeleteButtons);
            flxProfileDeletePopUp.add(flxProfileDelete);
            flxDialogs.add(flxLogout, flxProfileDeletePopUp);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "segmentProps": []
                    },
                    "customfooternew.flxFooterMenu": {
                        "segmentProps": []
                    },
                    "customfooternew.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxContent": {
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "segmentProps": []
                    },
                    "flxAckHeader": {
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "left": {
                            "type": "string",
                            "value": "21px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "segmentProps": []
                    },
                    "flxCustomerID": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "flxContract": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "switchApprovals": {
                        "segmentProps": []
                    },
                    "flxSignatoryGroups": {
                        "segmentProps": []
                    },
                    "tbxSearchSignatoryGroups": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "segmentProps": [],
                        "instanceId": "customfooternew"
                    },
                    "customfooternew.flxFooterMenu": {
                        "segmentProps": []
                    },
                    "customfooternew.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteContent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Are you sure you want to remove your profile picture?",
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAccountName": {
                        "segmentProps": []
                    },
                    "flxCustomerID": {
                        "left": {
                            "type": "string",
                            "value": "1.50%"
                        },
                        "segmentProps": []
                    },
                    "flxContract": {
                        "left": {
                            "type": "string",
                            "value": "1.50%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMatrixContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSignatoryGroups": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBoxSearchSignatoryGroups": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.30%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooternew"
                    },
                    "customfooternew.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "height": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteContent": {
                        "height": {
                            "type": "string",
                            "value": "95%"
                        },
                        "text": "Are you sure you want to remove your profile picture?",
                        "top": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.flxMenuContainer": {
                    "width": "100%"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "Features": {
                    "top": "10dp"
                },
                "customfooternew": {
                    "centerX": "",
                    "left": "6dp",
                    "width": "103%"
                },
                "customfooternew.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooternew.lblCopyright": {
                    "left": ""
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmViewApprovalsMatrix,
            "enabledForIdleTimeout": true,
            "id": "frmViewApprovalsMatrix",
            "init": controller.AS_Form_h09e7e59d7d4406f8cdc2b6b5780d132,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_b64b03dd6c0246aa8017b604f795c84b,
            "preShow": function(eventobject) {
                controller.AS_Form_ab7154bb6c594bab8eaf45f7f43732fe(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ApprovalMatrixMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_e66f46ed11a94eb3b665bb7c0344a136,
            "retainScrollPosition": false
        }]
    }
});