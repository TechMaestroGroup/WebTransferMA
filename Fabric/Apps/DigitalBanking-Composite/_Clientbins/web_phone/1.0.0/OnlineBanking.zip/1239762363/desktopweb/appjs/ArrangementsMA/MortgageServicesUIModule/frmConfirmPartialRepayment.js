define("ArrangementsMA/MortgageServicesUIModule/frmConfirmPartialRepayment", function() {
    return function(controller) {
        function addWidgetsfrmConfirmPartialRepayment() {
            this.setDefaultUnit(kony.flex.DP);
            var confirmPartialRepayment = new com.InfinityOLB.Resources.confirmPartialRepayment({
                "height": "100%",
                "id": "confirmPartialRepayment",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "confirmPartialRepayment",
                "overrides": {
                    "confirmPartialRepayment": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var confirmPartialRepayment_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmConfirmPartialRepayment"] && appConfig.componentMetadata["ResourcesMA"]["frmConfirmPartialRepayment"]["confirmPartialRepayment"]) || {};
            confirmPartialRepayment.serviceParameters = confirmPartialRepayment_data.serviceParameters || {};
            confirmPartialRepayment.customPopupData = confirmPartialRepayment_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            confirmPartialRepayment.dataFormatting = confirmPartialRepayment_data.dataFormatting || {};
            confirmPartialRepayment.dataMapping = confirmPartialRepayment_data.dataMapping || {};
            confirmPartialRepayment.conditionalMappingKey = confirmPartialRepayment_data.conditionalMappingKey || "";
            confirmPartialRepayment.conditionalMapping = confirmPartialRepayment_data.conditionalMapping || {};
            confirmPartialRepayment.pageTitle = confirmPartialRepayment_data.pageTitle || "";
            confirmPartialRepayment.pageTitlei18n = confirmPartialRepayment_data.pageTitlei18n || "";
            confirmPartialRepayment.primaryLinks = confirmPartialRepayment_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            confirmPartialRepayment.flxMainWrapperzIndex = confirmPartialRepayment_data.flxMainWrapperzIndex || 2;
            confirmPartialRepayment.secondaryLinks = confirmPartialRepayment_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            confirmPartialRepayment.supplementaryLinks = confirmPartialRepayment_data.supplementaryLinks || [];
            confirmPartialRepayment.logoConfig = confirmPartialRepayment_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            confirmPartialRepayment.logoutConfig = confirmPartialRepayment_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            confirmPartialRepayment.profileConfig = confirmPartialRepayment_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profilePic",
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "subMenu": [{
                    "title": "profile settings",
                    "toolTip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.ProfileManagement.profilesettings}}"
                    },
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "presentationController": "enterProfileSettings",
                        "moduleName": "SettingsNewUIModule"
                    }
                }]
            };
            confirmPartialRepayment.activeMenuID = confirmPartialRepayment_data.activeMenuID || "";
            confirmPartialRepayment.activeSubMenuID = confirmPartialRepayment_data.activeSubMenuID || "";
            confirmPartialRepayment.backFlag = confirmPartialRepayment_data.backFlag || false;
            confirmPartialRepayment.hamburgerConfig = confirmPartialRepayment_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            confirmPartialRepayment.backProperties = confirmPartialRepayment_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            confirmPartialRepayment.breadCrumbProperties = confirmPartialRepayment_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            confirmPartialRepayment.genricMessage = confirmPartialRepayment_data.genricMessage || {};
            confirmPartialRepayment.sessionTimeOutData = confirmPartialRepayment_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            confirmPartialRepayment.footerProperties = confirmPartialRepayment_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            confirmPartialRepayment.copyRight = confirmPartialRepayment_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxContentMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContentMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentMain.setDefaultUnit(kony.flex.DP);
            var flxMortgageFacilityDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "240dp",
                "id": "flxMortgageFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "30dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityDetails.setDefaultUnit(kony.flex.DP);
            var flxMortgageFacilityHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxMortgageFacilityHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityHeader.setDefaultUnit(kony.flex.DP);
            var lblMortgageFacilityDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblMortgageFacilityDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.displayMortgageFacilityDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            var flxMortgageFacilityContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "190dp",
                "id": "flxMortgageFacilityContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": 50,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityContent.setDefaultUnit(kony.flex.DP);
            var lblMortgageFacilityName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMortgageFacilityName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.faciltyNameWithColon\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityNameValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFacilityNameValue",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Mortgage Facility Account - 1234 ",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNumberOfLoans = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNumberOfLoans",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.numberofloansWithColon\")",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoans = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblNoOfLoans",
                "isVisible": true,
                "left": "0",
                "text": "Number of Loans",
                "top": "0",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoansValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoOfLoansValue",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "3",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalance = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBalance",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.outstandingBalanceWithColon\")",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBalValue",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€150,054.00",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMaturityDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.amountPaidtoDate\")",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMaturityDateValue",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€50,054.00",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityContent.add(lblMortgageFacilityName, lblFacilityNameValue, lblNumberOfLoans, lblNoOfLoans, lblNoOfLoansValue, lblOutstandingBalance, lblOutstandingBalValue, lblMaturityDate, lblMaturityDateValue);
            flxMortgageFacilityHeader.add(lblMortgageFacilityDetails, flxSeperator, flxMortgageFacilityContent);
            flxMortgageFacilityDetails.add(flxMortgageFacilityHeader);
            var flxLoanDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "240dp",
                "id": "flxLoanDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanDetails.setDefaultUnit(kony.flex.DP);
            var flxLoanAccountsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLoanAccountsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccountsHeader.setDefaultUnit(kony.flex.DP);
            var lblLoanDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblLoanDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.loans.LoanDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLoanSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxLoanSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanSeperator.setDefaultUnit(kony.flex.DP);
            flxLoanSeperator.add();
            flxLoanAccountsHeader.add(lblLoanDetails, flxLoanSeperator);
            var flxLoanAccountName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxLoanAccountName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccountName.setDefaultUnit(kony.flex.DP);
            var lblLoanAccountName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "height": "20dp",
                "id": "lblLoanAccountName",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Primary Loan Account Name - 8760",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLoanDetailsSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxLoanDetailsSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "40dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanDetailsSeperator.setDefaultUnit(kony.flex.DP);
            flxLoanDetailsSeperator.add();
            flxLoanAccountName.add(lblLoanAccountName, flxLoanDetailsSeperator);
            var flxLoanDetailsContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoanDetailsContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "90dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanDetailsContent.setDefaultUnit(kony.flex.DP);
            var flxValueType = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxValueType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValueType.setDefaultUnit(kony.flex.DP);
            var lblCurrentVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblCurrentVal",
                "isVisible": true,
                "left": "250dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.CurrentValue\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblSimulatedVal",
                "isVisible": true,
                "left": "580dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.SimulatedValue\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValueType.add(lblCurrentVal, lblSimulatedVal);
            var flxInstallmentAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxInstallmentAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "45dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInstallmentAmount.setDefaultUnit(kony.flex.DP);
            var lblInstallementAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblInstallementAmount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.installmentAmountWithcolon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentInstallmentVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblCurrentInstallmentVal",
                "isVisible": true,
                "left": "250dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€3,000",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentInstallmentValDummy = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblCurrentInstallmentValDummy",
                "isVisible": true,
                "left": "0",
                "top": "0",
                "width": "1dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedInstallmentVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblSimulatedInstallmentVal",
                "isVisible": true,
                "left": "580dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€3,000",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedInstallmentValDummy = new kony.ui.Label({
                "height": "0dp",
                "id": "lblSimulatedInstallmentValDummy",
                "isVisible": true,
                "left": "0",
                "top": "0",
                "width": "1dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInstallmentAmount.add(lblInstallementAmount, lblCurrentInstallmentVal, lblCurrentInstallmentValDummy, lblSimulatedInstallmentVal, lblSimulatedInstallmentValDummy);
            var flxRepaymentDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxRepaymentDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "80dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRepaymentDate.setDefaultUnit(kony.flex.DP);
            var lblNextRepaymentDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNextRepaymentDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.nextRepaymentDateWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepaymentCurrentDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblRepaymentCurrentDate",
                "isVisible": true,
                "left": "250dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/01/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepaymentCurrentDateDummy = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "0dp",
                "id": "lblRepaymentCurrentDateDummy",
                "isVisible": true,
                "left": "0",
                "top": "0",
                "width": "1dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepaymentSimulatedDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblRepaymentSimulatedDate",
                "isVisible": true,
                "left": "580dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/01/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepaymentSimulatedDateDummy = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblRepaymentSimulatedDateDummy",
                "isVisible": true,
                "left": "0",
                "top": "0",
                "width": "1dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRepaymentDate.add(lblNextRepaymentDate, lblRepaymentCurrentDate, lblRepaymentCurrentDateDummy, lblRepaymentSimulatedDate, lblRepaymentSimulatedDateDummy);
            var flxMaturityDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxMaturityDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "110dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMaturityDate.setDefaultUnit(kony.flex.DP);
            var lblMaturity = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblMaturity",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.endDateWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityCurrentVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblMaturityCurrentVal",
                "isVisible": true,
                "left": "250dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/01/2031",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityCurrentValDummy = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "0dp",
                "id": "lblMaturityCurrentValDummy",
                "isVisible": true,
                "left": "0",
                "top": "0",
                "width": "1dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturitySimulatedVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblMaturitySimulatedVal",
                "isVisible": true,
                "left": "580dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "25/02/2030",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturitySimulatedValDummy = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "0dp",
                "id": "lblMaturitySimulatedValDummy",
                "isVisible": true,
                "left": "0",
                "top": "0dp",
                "width": "1dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMaturityDate.add(lblMaturity, lblMaturityCurrentVal, lblMaturityCurrentValDummy, lblMaturitySimulatedVal, lblMaturitySimulatedValDummy);
            var flxValueSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxValueSeperator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValueSeperator.setDefaultUnit(kony.flex.DP);
            flxValueSeperator.add();
            var flxSimulatedValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSimulatedValue",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulatedValue.setDefaultUnit(kony.flex.DP);
            var lblSimulatedValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedValue",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.SimulatedValue\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulatedValue.add(lblSimulatedValue);
            var flxSimulatedAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSimulatedAmount",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulatedAmount.setDefaultUnit(kony.flex.DP);
            var lblSimulatedAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedAmount",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.installmentAmountWithcolon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedAmountVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedAmountVal",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulatedAmount.add(lblSimulatedAmount, lblSimulatedAmountVal);
            var flxSimulatedDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSimulatedDate",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulatedDate.setDefaultUnit(kony.flex.DP);
            var lblSimulatedDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedDate",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.nextRepaymentDateWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedDateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedDateVal",
                "isVisible": true,
                "left": "0",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulatedDate.add(lblSimulatedDate, lblSimulatedDateVal);
            var flxSimulatedMaturityDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSimulatedMaturityDate",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulatedMaturityDate.setDefaultUnit(kony.flex.DP);
            var lblSimulatedMaturityDate = new kony.ui.Label({
                "id": "lblSimulatedMaturityDate",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.endDateWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedMaturityDateVal = new kony.ui.Label({
                "id": "lblSimulatedMaturityDateVal",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulatedMaturityDate.add(lblSimulatedMaturityDate, lblSimulatedMaturityDateVal);
            flxLoanDetailsContent.add(flxValueType, flxInstallmentAmount, flxRepaymentDate, flxMaturityDate, flxValueSeperator, flxSimulatedValue, flxSimulatedAmount, flxSimulatedDate, flxSimulatedMaturityDate);
            flxLoanDetails.add(flxLoanAccountsHeader, flxLoanAccountName, flxLoanDetailsContent);
            var flxPaymentDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetails.setDefaultUnit(kony.flex.DP);
            var flxPaymentDetailsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPaymentDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblPaymentDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblPaymentDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.PaymentDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaymentDetailsSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxPaymentDetailsSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsSeperator.setDefaultUnit(kony.flex.DP);
            flxPaymentDetailsSeperator.add();
            flxPaymentDetailsHeader.add(lblPaymentDetails, flxPaymentDetailsSeperator);
            var flxPaymentContentDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentContentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentContentDetails.setDefaultUnit(kony.flex.DP);
            var flxTotalRepaymentAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxTotalRepaymentAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalRepaymentAmount.setDefaultUnit(kony.flex.DP);
            var lblTotalRepaymentAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTotalRepaymentAmount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.totalRepaymentWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalRepaymentAmountVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTotalRepaymentAmountVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "€32,000",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalRepaymentAmount.add(lblTotalRepaymentAmount, lblTotalRepaymentAmountVal);
            var flxLoanAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxLoanAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccount.setDefaultUnit(kony.flex.DP);
            var lblLoanAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLoanAccount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.LoanAccount\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoanAccountVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLoanAccountVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "************0723",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShowIcons = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblShowIcons",
                "isVisible": true,
                "left": "358dp",
                "skin": "bbSknLblFontIcon",
                "text": "************0723",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoanAccount.add(lblLoanAccount, lblLoanAccountVal, lblShowIcons);
            var flxCreditValueDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxCreditValueDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreditValueDate.setDefaultUnit(kony.flex.DP);
            var lblCreditValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCreditValue",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.creditValueDateWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCreditValueDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCreditValueDate",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "07/14/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCreditValueDate.add(lblCreditValue, lblCreditValueDate);
            var flxTransactionFee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxTransactionFee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "85dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionFee.setDefaultUnit(kony.flex.DP);
            var lblTransactionFee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTransactionFee",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.TransactionfeeWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTransactionFeeVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTransactionFeeVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$5.00",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTransactionFee.add(lblTransactionFee, lblTransactionFeeVal);
            var flxExchangeRate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxExchangeRate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "top": "120dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExchangeRate.setDefaultUnit(kony.flex.DP);
            var lblExchangeRate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblExchangeRate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.exchangeRate\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExchangeRateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblExchangeRateVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "1.345",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExchangeRate.add(lblExchangeRate, lblExchangeRateVal);
            var flxAccountHolderName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxAccountHolderName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "155dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountHolderName.setDefaultUnit(kony.flex.DP);
            var lblAccountHolderName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountHolderName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.accountHolderNameWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountHolderNameVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountHolderNameVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Daisy Davis",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountHolderName.add(lblAccountHolderName, lblAccountHolderNameVal);
            var flxAccountNumber = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxAccountNumber",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "190dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountNumber.setDefaultUnit(kony.flex.DP);
            var lblAccountNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountNumber",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.accountNumWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountNumberVal",
                "isVisible": true,
                "left": "230dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "************0723",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxShowIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "View account number, your account number is currentl"
                },
                "clipBounds": false,
                "height": "70%",
                "id": "flxShowIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "top": "3px",
                "width": "2%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShowIcon.setDefaultUnit(kony.flex.DP);
            var lblShowIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblShowIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLblFontIcon",
                "text": "g",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxShowIcon.add(lblShowIcon);
            flxAccountNumber.add(lblAccountNumber, lblAccountNumberVal, flxShowIcon);
            var flxPayon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxPayon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "225dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayon.setDefaultUnit(kony.flex.DP);
            var lblPayon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayon",
                "isVisible": true,
                "left": "31dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.payOnWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayonDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayonDate",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "07/14/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayon.add(lblPayon, lblPayonDate);
            var flxNotes = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNotes",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "260dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNotes.setDefaultUnit(kony.flex.DP);
            var lblNotes = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNotes",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Notes\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNotesDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNotesDesc",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "The notes goes here",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNotes.add(lblNotes, lblNotesDesc);
            var flxSupportingDocuments = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSupportingDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "295dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocuments.setDefaultUnit(kony.flex.DP);
            var lblSupportingDocuments = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSupportingDocuments",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.supportingDocumentsWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segSupportingDocs = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgDoc": "",
                    "lblDocName": ""
                }],
                "groupCells": false,
                "id": "segSupportingDocs",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxSupportingDocs"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxContentDocs": "flxContentDocs",
                    "flxGap": "flxGap",
                    "flxImgDoc": "flxImgDoc",
                    "flxSupportingDocs": "flxSupportingDocs",
                    "imgDoc": "imgDoc",
                    "lblDocName": "lblDocName"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSupportingDocumentsVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSupportingDocumentsVal",
                "isVisible": false,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSupportingDocuments.add(lblSupportingDocuments, segSupportingDocs, lblSupportingDocumentsVal);
            var flxButtonSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxButtonSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "344dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtonSeperator.setDefaultUnit(kony.flex.DP);
            flxButtonSeperator.add();
            var flxModifyAndConfirm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100dp",
                "id": "flxModifyAndConfirm",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "365dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxModifyAndConfirm.setDefaultUnit(kony.flex.DP);
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnConfirm = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Confirm and pay repayment amount"
                },
                "height": "40dp",
                "id": "btnConfirm",
                "isVisible": true,
                "right": "50dp",
                "skin": "sknbtnSSPffffff15px0273e3bg",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ConfrimAndPay\")",
                "top": "0dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnModify = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Modify partial repayment details"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnModify",
                "isVisible": true,
                "right": "30dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Modify\")",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel partial repayment process"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "30dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(btnConfirm, btnModify, btnCancel);
            flxModifyAndConfirm.add(flxButtons);
            flxPaymentContentDetails.add(flxTotalRepaymentAmount, flxLoanAccount, flxCreditValueDate, flxTransactionFee, flxExchangeRate, flxAccountHolderName, flxAccountNumber, flxPayon, flxNotes, flxSupportingDocuments, flxButtonSeperator, flxModifyAndConfirm);
            flxPaymentDetails.add(flxPaymentDetailsHeader, flxPaymentContentDetails);
            flxContentMain.add(flxMortgageFacilityDetails, flxLoanDetails, flxPaymentDetails);
            confirmPartialRepayment.flxContentTCCenter.add(flxContentMain);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "confirmPartialRepayment": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxMortgageFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblMortgageFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "flxMortgageFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "lblMortgageFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblFacilityNameValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNumberOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNoOfLoansValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBalance": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBalValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityDate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "195dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityDateValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "flxLoanDetails": {
                        "height": {
                            "type": "string",
                            "value": "525dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsHeader"]
                    },
                    "lblLoanAccountName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountName"]
                    },
                    "flxLoanDetailsContent": {
                        "height": {
                            "type": "string",
                            "value": "435dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "flxValueType": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblCurrentVal": {
                        "i18n_text": "i18n.Accounts.CurrentPlan",
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Current Plan",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "lblSimulatedVal": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "flxInstallmentAmount": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblInstallementAmount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblCurrentInstallmentVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "text": "€3,000",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblSimulatedInstallmentVal": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "flxRepaymentDate": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblNextRepaymentDate": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentCurrentDate": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentSimulatedDate": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "flxMaturityDate": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblMaturity": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturityCurrentVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturitySimulatedVal": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "flxValueSeperator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": true,
                        "skin": "bbSknFlxSeperatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "214dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedValue": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "235dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedValue": {
                        "i18n_text": "i18n.Accounts.SimulatedValue",
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedValue"]
                    },
                    "flxSimulatedAmount": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedAmount": {
                        "i18n_text": "i18n.payments.installmentAmountWithcolon",
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "text": "Installment Amount:",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedAmount"]
                    },
                    "lblSimulatedAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "€3,000",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedAmount"]
                    },
                    "flxSimulatedDate": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "325dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedDate": {
                        "i18n_text": "i18n.payments.nextRepaymentDateWithColon",
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedDate"]
                    },
                    "lblSimulatedDateVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedDate"]
                    },
                    "flxSimulatedMaturityDate": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "375dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedMaturityDate": {
                        "i18n_text": "i18n.payments.endDateWithColon",
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "text": "End Date (Maturity Date):",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedMaturityDate"]
                    },
                    "lblSimulatedMaturityDateVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "31/01/2031",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedMaturityDate"]
                    },
                    "flxPaymentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentContentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails"]
                    },
                    "flxTotalRepaymentAmount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblTotalRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "lblTotalRepaymentAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "flxLoanAccount": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblLoanAccountVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblShowIcons": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "flxCreditValueDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblCreditValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "lblCreditValueDate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "flxTransactionFee": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblTransactionFee": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "lblTransactionFeeVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "flxExchangeRate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblExchangeRate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "lblExchangeRateVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "flxAccountHolderName": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountHolderName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "lblAccountHolderNameVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "flxAccountNumber": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblAccountNumberVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "flxShowIcon": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblShowIcon": {
                        "skin": "bbSknLblFontIcon",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber", "flxShowIcon"]
                    },
                    "flxPayon": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblPayon": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxPayon"]
                    },
                    "lblPayonDate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxPayon"]
                    },
                    "flxNotes": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblNotes": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "lblNotesDesc": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "flxSupportingDocuments": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblSupportingDocuments": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "lblSupportingDocumentsVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "flxButtonSeperator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "flxModifyAndConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "reverseLayoutDirection": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm"]
                    },
                    "btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    },
                    "btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    }
                },
                "1024": {
                    "flxContentMain": {
                        "width": {
                            "type": "string",
                            "value": "98.80%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter"]
                    },
                    "flxMortgageFacilityDetails": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxMortgageFacilityHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails"]
                    },
                    "lblMortgageFacilityDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "flxSeperator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "flxMortgageFacilityContent": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "lblMortgageFacilityName": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblFacilityNameValue": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNumberOfLoans": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNoOfLoansValue": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBalance": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBalValue": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityDateValue": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "flxLoanDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxLoanAccountsHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "lblLoanDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsHeader"]
                    },
                    "flxLoanSeperator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsHeader"]
                    },
                    "flxLoanAccountName": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "lblLoanAccountName": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountName"]
                    },
                    "flxLoanDetailsSeperator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountName"]
                    },
                    "flxLoanDetailsContent": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "flxValueType": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblCurrentVal": {
                        "left": {
                            "type": "string",
                            "value": "265dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "lblSimulatedVal": {
                        "left": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "flxInstallmentAmount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblInstallementAmount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblCurrentInstallmentVal": {
                        "left": {
                            "type": "string",
                            "value": "265dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblSimulatedInstallmentVal": {
                        "left": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "flxRepaymentDate": {
                        "top": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblNextRepaymentDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentCurrentDate": {
                        "left": {
                            "type": "string",
                            "value": "265dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentSimulatedDate": {
                        "left": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "flxMaturityDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblMaturity": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturityCurrentVal": {
                        "left": {
                            "type": "string",
                            "value": "265dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturitySimulatedVal": {
                        "left": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "flxValueSeperator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedValue": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedValue": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedValue"]
                    },
                    "flxSimulatedAmount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedAmount": {
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedAmount"]
                    },
                    "lblSimulatedAmountVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedAmount"]
                    },
                    "flxSimulatedDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedDate"]
                    },
                    "lblSimulatedDateVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedDate"]
                    },
                    "flxSimulatedMaturityDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedMaturityDate": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "tagName": "span"
                        },
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedMaturityDate"]
                    },
                    "lblSimulatedMaturityDateVal": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "tagName": "span"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedMaturityDate"]
                    },
                    "flxPaymentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxPaymentDetailsHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails"]
                    },
                    "lblPaymentDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentDetailsSeperator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentContentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails"]
                    },
                    "flxTotalRepaymentAmount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblTotalRepaymentAmount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "lblTotalRepaymentAmountVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "flxLoanAccount": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblLoanAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblLoanAccountVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblShowIcons": {
                        "left": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "skin": "bbSknLblFontIcon",
                        "text": "h",
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "flxCreditValueDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblCreditValue": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "lblCreditValueDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "flxTransactionFee": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblTransactionFee": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "lblTransactionFeeVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "flxExchangeRate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblExchangeRate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "lblExchangeRateVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "flxAccountHolderName": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountHolderName": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "lblAccountHolderNameVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "flxAccountNumber": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblAccountNumberVal": {
                        "left": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblShowIcon": {
                        "skin": "bbSknLblFontIcon",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber", "flxShowIcon"]
                    },
                    "flxPayon": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblPayon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxPayon"]
                    },
                    "lblPayonDate": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxPayon"]
                    },
                    "flxNotes": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblNotes": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "lblNotesDesc": {
                        "top": {
                            "type": "string",
                            "value": "-17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "52%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "flxSupportingDocuments": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblSupportingDocuments": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "segSupportingDocs": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "left": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "lblSupportingDocumentsVal": {
                        "top": {
                            "type": "string",
                            "value": "-17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "52%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "flxButtonSeperator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "flxModifyAndConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "flxButtons": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm"]
                    },
                    "btnConfirm": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    },
                    "btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    }
                },
                "1366": {
                    "confirmPartialRepayment": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxContentMain": {
                        "width": {
                            "type": "string",
                            "value": "101.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter"]
                    },
                    "flxMortgageFacilityDetails": {
                        "skin": "slFboxshadow1rad4px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblMortgageFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "flxSeperator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "lblMortgageFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNumberOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBalance": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "flxLoanDetails": {
                        "skin": "slFboxshadow1rad4px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsHeader"]
                    },
                    "flxLoanAccountName": {
                        "skin": "sknFlxfbfbfb",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "lblLoanAccountName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountName"]
                    },
                    "lblCurrentVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "lblInstallementAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblCurrentInstallmentVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "flxRepaymentDate": {
                        "top": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblNextRepaymentDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentCurrentDate": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblMaturity": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturityCurrentVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "flxPaymentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "slFboxshadow1rad4px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentContentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails"]
                    },
                    "flxTotalRepaymentAmount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblTotalRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblShowIcons": {
                        "left": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "text": "g",
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "flxCreditValueDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblCreditValue": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "flxTransactionFee": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblTransactionFee": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "flxExchangeRate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblExchangeRate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "flxAccountHolderName": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountHolderName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "flxAccountNumber": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountNumber": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblShowIcon": {
                        "skin": "bbSknLblFontIcon",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber", "flxShowIcon"]
                    },
                    "flxPayon": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblPayon": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxPayon"]
                    },
                    "flxNotes": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblNotes": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "lblNotesDesc": {
                        "top": {
                            "type": "string",
                            "value": "-19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "flxSupportingDocuments": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblSupportingDocuments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-31dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "lblSupportingDocumentsVal": {
                        "top": {
                            "type": "string",
                            "value": "-19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "flxButtonSeperator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "flxModifyAndConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "btnConfirm": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    },
                    "btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    }
                },
                "1380": {
                    "flxMortgageFacilityDetails": {
                        "skin": "slFboxshadow1rad4px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblMortgageFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "lblMortgageFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNumberOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBalance": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "flxLoanDetails": {
                        "skin": "slFboxshadow1rad4px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsHeader"]
                    },
                    "flxLoanAccountName": {
                        "skin": "sknFlxfbfbfb",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "lblLoanAccountName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountName"]
                    },
                    "lblCurrentVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "lblInstallementAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblCurrentInstallmentVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "flxRepaymentDate": {
                        "top": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblNextRepaymentDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentCurrentDate": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblMaturity": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturityCurrentVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "flxPaymentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "slFboxshadow1rad4px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentContentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails"]
                    },
                    "flxTotalRepaymentAmount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblTotalRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblShowIcons": {
                        "left": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "text": "g",
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "flxCreditValueDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblCreditValue": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "flxTransactionFee": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblTransactionFee": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "flxExchangeRate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblExchangeRate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "flxAccountHolderName": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountHolderName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "flxAccountNumber": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountNumber": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblShowIcon": {
                        "skin": "bbSknLblFontIcon",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber", "flxShowIcon"]
                    },
                    "flxPayon": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblPayon": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxPayon"]
                    },
                    "flxNotes": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblNotes": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "lblNotesDesc": {
                        "top": {
                            "type": "string",
                            "value": "-19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "flxSupportingDocuments": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblSupportingDocuments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "lblSupportingDocumentsVal": {
                        "top": {
                            "type": "string",
                            "value": "-19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "flxButtonSeperator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "flxModifyAndConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "btnConfirm": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    },
                    "btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxModifyAndConfirm", "flxButtons"]
                    }
                }
            }
            this.compInstData = {
                "confirmPartialRepayment": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(confirmPartialRepayment);
        };
        return [{
            "addWidgets": addWidgetsfrmConfirmPartialRepayment,
            "enabledForIdleTimeout": false,
            "id": "frmConfirmPartialRepayment",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_aa42914906094a59bafd82e69c557bde,
            "preShow": function(eventobject) {
                controller.AS_Form_gbbc53e75cf141f5975a799dc0a03b81(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});