define(function() {
    return {
        "properties": [],
        "apis": ["setData", "onToggleToRecommendStrategy"],
        "events": ["onToggle"]
    }
});