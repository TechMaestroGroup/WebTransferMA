define(function() {
    return function(controller) {
        var ActivateProfile = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "ActivateProfile",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_f638dca1126441fbb339b4fc0a8b7145(eventobject);
            },
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "onBreakpointHandler": onBreakpointHandler,
            "onBreakpointChange": controller.AS_FlexContainer_ge77170a074c459b956800ed1f85bc38,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "ActivateProfile"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "ActivateProfile"), extendConfig({}, controller.args[2], "ActivateProfile"));
        ActivateProfile.setDefaultUnit(kony.flex.DP);
        var flxActivateProfileQRScan = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "bottom": "0dp",
            "clipBounds": true,
            "id": "flxActivateProfileQRScan",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "74dp",
            "isModalContainer": false,
            "right": "74dp",
            "skin": "slFbox",
            "top": "46dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxActivateProfileQRScan"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxActivateProfileQRScan"), extendConfig({}, controller.args[2], "flxActivateProfileQRScan"));
        flxActivateProfileQRScan.setDefaultUnit(kony.flex.DP);
        var flxActivateText = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxActivateText",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxActivateText"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxActivateText"), extendConfig({}, controller.args[2], "flxActivateText"));
        flxActivateText.setDefaultUnit(kony.flex.DP);
        var lblActivateProfile = new kony.ui.Label(extendConfig({
            "id": "lblActivateProfile",
            "isVisible": true,
            "left": "0dp",
            "right": "0dp",
            "skin": "bbSknLbl424242SSP20Px",
            "text": "To activate your profile please download our infinity app.",
            "top": "0dp",
            "zIndex": 1
        }, controller.args[0], "lblActivateProfile"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblActivateProfile"), extendConfig({}, controller.args[2], "lblActivateProfile"));
        flxActivateText.add(lblActivateProfile);
        var flxAlertText = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxAlertText",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "35dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxAlertText"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxAlertText"), extendConfig({}, controller.args[2], "flxAlertText"));
        flxAlertText.setDefaultUnit(kony.flex.DP);
        var flxAlertTextInner = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxAlertTextInner",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxAlertTextInner"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxAlertTextInner"), extendConfig({}, controller.args[2], "flxAlertTextInner"));
        flxAlertTextInner.setDefaultUnit(kony.flex.DP);
        var imgBlueAlert = new kony.ui.Image2(extendConfig({
            "height": "20dp",
            "id": "imgBlueAlert",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "bluealert_2.png",
            "top": "0dp",
            "width": "20dp",
            "zIndex": 1
        }, controller.args[0], "imgBlueAlert"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgBlueAlert"), extendConfig({}, controller.args[2], "imgBlueAlert"));
        var lblBlueAlertText = new kony.ui.Label(extendConfig({
            "id": "lblBlueAlertText",
            "isVisible": true,
            "left": "12px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ActivateProfile.Description\")",
            "top": "0dp",
            "width": "318px",
            "zIndex": 1
        }, controller.args[0], "lblBlueAlertText"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblBlueAlertText"), extendConfig({}, controller.args[2], "lblBlueAlertText"));
        flxAlertTextInner.add(imgBlueAlert, lblBlueAlertText);
        flxAlertText.add(flxAlertTextInner);
        var flxQRScanner = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "206px",
            "id": "flxQRScanner",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "75px",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxQRScanner"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxQRScanner"), extendConfig({}, controller.args[2], "flxQRScanner"));
        flxQRScanner.setDefaultUnit(kony.flex.DP);
        var flxAppStoreQR = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxAppStoreQR",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "45%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxAppStoreQR"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxAppStoreQR"), extendConfig({}, controller.args[2], "flxAppStoreQR"));
        flxAppStoreQR.setDefaultUnit(kony.flex.DP);
        var flxAppStoreIcon = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "20%",
            "id": "flxAppStoreIcon",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxAppStoreIcon"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxAppStoreIcon"), extendConfig({}, controller.args[2], "flxAppStoreIcon"));
        flxAppStoreIcon.setDefaultUnit(kony.flex.DP);
        var ImgAppStoreIcon = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "height": "100%",
            "id": "ImgAppStoreIcon",
            "isVisible": true,
            "left": "5dp",
            "skin": "slImage",
            "src": "appstore_2x.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "ImgAppStoreIcon"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "ImgAppStoreIcon"), extendConfig({}, controller.args[2], "ImgAppStoreIcon"));
        flxAppStoreIcon.add(ImgAppStoreIcon);
        var QRCodeGenerator = new com.temenos.infinity.sca.uniken.QRCodeGenerator(extendConfig({
            "bottom": "0dp",
            "centerX": "50%",
            "height": "75%",
            "id": "QRCodeGenerator",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "5%",
            "width": "140dp",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA",
            "viewType": "QRCodeGenerator",
            "overrides": {
                "QRCodeGenerator": {
                    "right": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "QRCodeGenerator"), extendConfig({
            "paddingInPixel": false,
            "overrides": {}
        }, controller.args[1], "QRCodeGenerator"), extendConfig({
            "overrides": {}
        }, controller.args[2], "QRCodeGenerator"));
        var QRCodeGenerator_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesUnikenMA"] && appConfig.componentMetadata["ResourcesUnikenMA"]["com.temenos.infinity.sca.uniken.ActivateProfile"] && appConfig.componentMetadata["ResourcesUnikenMA"]["com.temenos.infinity.sca.uniken.ActivateProfile"]["QRCodeGenerator"]) || {};
        QRCodeGenerator.renderMode = QRCodeGenerator_data.renderMode || "Properties";
        QRCodeGenerator.codeText = QRCodeGenerator_data.codeText || "QRCode";
        QRCodeGenerator.codeWidth = QRCodeGenerator_data.codeWidth || 250;
        QRCodeGenerator.codeHeight = QRCodeGenerator_data.codeHeight || 250;
        QRCodeGenerator.colorDark = QRCodeGenerator_data.colorDark || "000000";
        QRCodeGenerator.colorLight = QRCodeGenerator_data.colorLight || "FFFFFF";
        QRCodeGenerator.correctLevel = QRCodeGenerator_data.correctLevel || 0;
        flxAppStoreQR.add(flxAppStoreIcon, QRCodeGenerator);
        var flxGoogleQR = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxGoogleQR",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "10%",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "45%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxGoogleQR"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxGoogleQR"), extendConfig({}, controller.args[2], "flxGoogleQR"));
        flxGoogleQR.setDefaultUnit(kony.flex.DP);
        var flxGoogleStoreIcon = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "20%",
            "id": "flxGoogleStoreIcon",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxGoogleStoreIcon"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxGoogleStoreIcon"), extendConfig({}, controller.args[2], "flxGoogleStoreIcon"));
        flxGoogleStoreIcon.setDefaultUnit(kony.flex.DP);
        var ImgGoogleStoreIcon = new kony.ui.Image2(extendConfig({
            "centerX": "50%",
            "height": "100%",
            "id": "ImgGoogleStoreIcon",
            "isVisible": true,
            "left": "0dp",
            "skin": "slImage",
            "src": "google_play_2x.png",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "ImgGoogleStoreIcon"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "ImgGoogleStoreIcon"), extendConfig({}, controller.args[2], "ImgGoogleStoreIcon"));
        flxGoogleStoreIcon.add(ImgGoogleStoreIcon);
        var QRCodeGenerator1 = new com.temenos.infinity.sca.uniken.QRCodeGenerator(extendConfig({
            "centerX": "50%",
            "height": "75%",
            "id": "QRCodeGenerator1",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "5%",
            "width": "140dp",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA",
            "viewType": "QRCodeGenerator1",
            "overrides": {
                "QRCodeGenerator": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "QRCodeGenerator1"), extendConfig({
            "paddingInPixel": false,
            "overrides": {}
        }, controller.args[1], "QRCodeGenerator1"), extendConfig({
            "overrides": {}
        }, controller.args[2], "QRCodeGenerator1"));
        var QRCodeGenerator1_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesUnikenMA"] && appConfig.componentMetadata["ResourcesUnikenMA"]["com.temenos.infinity.sca.uniken.ActivateProfile"] && appConfig.componentMetadata["ResourcesUnikenMA"]["com.temenos.infinity.sca.uniken.ActivateProfile"]["QRCodeGenerator1"]) || {};
        QRCodeGenerator1.renderMode = QRCodeGenerator1_data.renderMode || "Properties";
        QRCodeGenerator1.codeText = QRCodeGenerator1_data.codeText || "QRCode";
        QRCodeGenerator1.codeWidth = QRCodeGenerator1_data.codeWidth || 250;
        QRCodeGenerator1.codeHeight = QRCodeGenerator1_data.codeHeight || 250;
        QRCodeGenerator1.colorDark = QRCodeGenerator1_data.colorDark || "000000";
        QRCodeGenerator1.colorLight = QRCodeGenerator1_data.colorLight || "FFFFFF";
        QRCodeGenerator1.correctLevel = QRCodeGenerator1_data.correctLevel || 0;
        flxGoogleQR.add(flxGoogleStoreIcon, QRCodeGenerator1);
        flxQRScanner.add(flxAppStoreQR, flxGoogleQR);
        var lblCallUs = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.CallSupportTeam\")"
            },
            "bottom": "120px",
            "centerX": "50%",
            "id": "lblCallUs",
            "isVisible": true,
            "skin": "bbSknLbl424242SSP15Px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.CallSupportTeam\")",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblCallUs"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCallUs"), extendConfig({}, controller.args[2], "lblCallUs"));
        flxActivateProfileQRScan.add(flxActivateText, flxAlertText, flxQRScanner, lblCallUs);
        ActivateProfile.add(flxActivateProfileQRScan);
        ActivateProfile.breakpointResetData = {};
        ActivateProfile.breakpointData = {
            maxBreakpointWidth: 1400,
            "1400": {
                "ActivateProfile": {
                    "breakpoints": "{\"BP1\": \"640\", \"BP2\": \"1024\", \"BP3\": \"1400\" }",
                    "headingtext": "To activate your profile please download our infinity app.",
                    "segmentProps": [],
                    "isSrcCompTopFlex": true
                },
                "lblActivateProfile": {
                    "text": "To activate your profile please download our infinity app.",
                    "segmentProps": []
                }
            }
        }
        ActivateProfile.compInstData = {
            "QRCodeGenerator": {
                "right": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerY": ""
            },
            "QRCodeGenerator1": {
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerY": ""
            }
        }
        return ActivateProfile;
    }
})