define("PortfolioManagementMA/WealthPortfolioUIModule/frmContactAdvisor", function() {
    return function(controller) {
        function addWidgetsfrmContactAdvisor() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheadernew": {
                        "isVisible": true
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainContent = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxFormcontent = new kony.ui.FlexContainer({
                "bottom": 0,
                "centerX": "50%",
                "clipBounds": false,
                "height": "520dp",
                "id": "flxFormcontent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "95%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormcontent.setDefaultUnit(kony.flex.DP);
            var flxContactAdvisor = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "61dp",
                "id": "flxContactAdvisor",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "1366dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContactAdvisor.setDefaultUnit(kony.flex.DP);
            var lblContactAdvisor = new kony.ui.Label({
                "height": "25dp",
                "id": "lblContactAdvisor",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl424242SSPRegular20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.contactAdvisor\")",
                "top": "20dp",
                "width": "132dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContactAdvisor.add(lblContactAdvisor);
            var flxContent = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "460dp",
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxMessage = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "64dp",
                "id": "flxMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "396dp",
                "isModalContainer": false,
                "top": "21dp",
                "width": "408dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessage.setDefaultUnit(kony.flex.DP);
            var lblMessage = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblMessage",
                "isVisible": true,
                "left": "35%",
                "right": "35%",
                "skin": "sknlbl424242SSPRegular24px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.advisoryMessage\")",
                "top": "0",
                "width": "408dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMessage.add(lblMessage);
            var flxDetails = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "29dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetails.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "216dp",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var imgLeft = new kony.ui.Image2({
                "id": "imgLeft",
                "isVisible": true,
                "left": "232dp",
                "src": "contactadvisor.png",
                "top": "0dp",
                "width": "331dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeft.add(imgLeft);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxSendMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxSendMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "0",
                "width": "355dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSendMessage.setDefaultUnit(kony.flex.DP);
            var flxImgSendMessage = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "60dp",
                "id": "flxImgSendMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "68dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgSendMessage.setDefaultUnit(kony.flex.DP);
            var imgCombinedshapeSend = new kony.ui.Image2({
                "bottom": "0dp",
                "centerY": "50%",
                "height": "61dp",
                "id": "imgCombinedshapeSend",
                "isVisible": true,
                "left": "-1dp",
                "src": "combinedshape.png",
                "top": "-10dp",
                "width": "68dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSendMessage = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50dp",
                "id": "imgSendMessage",
                "isVisible": true,
                "left": "25%",
                "src": "mail.png",
                "top": "0",
                "width": "50dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgSendMessage.add(imgCombinedshapeSend, imgSendMessage);
            var flxLabelMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLabelMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "250dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLabelMessage.setDefaultUnit(kony.flex.DP);
            var lblSendMessage = new kony.ui.Label({
                "centerX": "30%",
                "centerY": "50%",
                "height": "19dp",
                "id": "lblSendMessage",
                "isVisible": true,
                "left": "12px",
                "skin": "sknLbl4176A4SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.sendUsAMessage\")",
                "top": "0",
                "width": "118dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLabelMessage.add(lblSendMessage);
            var flxBackSend = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxBackSend",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "37dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackSend.setDefaultUnit(kony.flex.DP);
            var imgBackSend = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "24dp",
                "id": "imgBackSend",
                "isVisible": true,
                "left": "0",
                "src": "right.png",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackSend.add(imgBackSend);
            flxSendMessage.add(flxImgSendMessage, flxLabelMessage, flxBackSend);
            var flxChat = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "60dp",
                "id": "flxChat",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "20dp",
                "width": "355dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChat.setDefaultUnit(kony.flex.DP);
            var flxImgChat = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "60dp",
                "id": "flxImgChat",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0",
                "width": "68dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgChat.setDefaultUnit(kony.flex.DP);
            var imgCombinedshapeChat = new kony.ui.Image2({
                "centerY": "50%",
                "height": "61dp",
                "id": "imgCombinedshapeChat",
                "isVisible": true,
                "left": "-1dp",
                "src": "combinedshape.png",
                "top": "-10dp",
                "width": "68dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgChat = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50dp",
                "id": "imgChat",
                "isVisible": true,
                "left": "25%",
                "src": "chat.png",
                "top": "0",
                "width": "50dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgChat.add(imgCombinedshapeChat, imgChat);
            var flxLabelChat = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLabelChat",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "250dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLabelChat.setDefaultUnit(kony.flex.DP);
            var lblChat = new kony.ui.Label({
                "centerX": "30%",
                "centerY": "50%",
                "height": "19dp",
                "id": "lblChat",
                "isVisible": true,
                "left": "14px",
                "skin": "sknlbl727272SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.liveChatWithUs\")",
                "top": "0",
                "width": "118dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLabelChat.add(lblChat);
            var flxBack2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxBack2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "37dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBack2.setDefaultUnit(kony.flex.DP);
            var imgBackChat = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "24dp",
                "id": "imgBackChat",
                "isVisible": true,
                "left": "0",
                "src": "right.png",
                "top": "0",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack2.add(imgBackChat);
            flxChat.add(flxImgChat, flxLabelChat, flxBack2);
            var flxCall = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "60dp",
                "id": "flxCall",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "20dp",
                "width": "355dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCall.setDefaultUnit(kony.flex.DP);
            var flxImgCall = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "60dp",
                "id": "flxImgCall",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0",
                "width": "68dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgCall.setDefaultUnit(kony.flex.DP);
            var imgCombinedshapeCall = new kony.ui.Image2({
                "centerY": "50%",
                "height": "61dp",
                "id": "imgCombinedshapeCall",
                "isVisible": true,
                "left": "-1dp",
                "src": "combinedshape.png",
                "top": "-10dp",
                "width": "68dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCall = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50dp",
                "id": "imgCall",
                "isVisible": true,
                "left": "25%",
                "src": "call.png",
                "top": "0",
                "width": "50dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgCall.add(imgCombinedshapeCall, imgCall);
            var flxLabelCall = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLabelCall",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "250dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLabelCall.setDefaultUnit(kony.flex.DP);
            var lblCall = new kony.ui.Label({
                "centerX": "45%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblCall",
                "isVisible": true,
                "left": "14px",
                "skin": "sknlbl727272SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.callUsOnWithColon\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPhoneNumber = new kony.ui.Label({
                "id": "lblPhoneNumber",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLabelCall.add(lblCall, lblPhoneNumber);
            flxCall.add(flxImgCall, flxLabelCall);
            flxRight.add(flxSendMessage, flxChat, flxCall);
            flxDetails.add(flxLeft, flxRight);
            var flxSeparator = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "ICSknFlxE9E9E91px",
                "top": "50dp",
                "width": "1160dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxClose = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "61dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "top": "2dp",
                "width": "1160dp",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClose.setDefaultUnit(kony.flex.DP);
            var btnClose = new kony.ui.Button({
                "bottom": 0,
                "focusSkin": "defBtnFocus",
                "height": "40dp",
                "id": "btnClose",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknIWBtnBgFFFFFFBorder1px003E7540px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.close\")",
                "top": "20dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(btnClose);
            flxContent.add(flxMessage, flxDetails, flxSeparator, flxClose);
            flxFormcontent.add(flxContactAdvisor, flxContent);
            flxMainContent.add(flxFormcontent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "70dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "130dp",
                "id": "customfooter",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnFaqs": {
                        "isVisible": true
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    },
                    "btnPrivacy": {
                        "isVisible": true
                    },
                    "btnTermsAndConditions": {
                        "isVisible": true
                    },
                    "customfooter": {
                        "centerX": "50%",
                        "height": "130dp",
                        "isVisible": false,
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "flxVBar2": {
                        "isVisible": true
                    },
                    "flxVBar3": {
                        "isVisible": true
                    },
                    "flxVBar4": {
                        "isVisible": true
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter, customfooternew);
            flxMain.add(flxMainContent, flxFooter);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "140%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0i94559a2949d45",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1200,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopupCancel = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "height": "268px",
                "id": "CustomPopupCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "250dp",
                "width": "43%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "top": "250dp",
                        "width": "43%"
                    },
                    "btnNo": {
                        "left": "5.48%",
                        "right": "viz.val_cleared"
                    },
                    "btnYes": {
                        "right": "4.89%"
                    },
                    "flxCross1": {
                        "height": "30dp",
                        "right": "16dp",
                        "width": "30dp",
                        "zIndex": 5
                    },
                    "imgCross": {
                        "centerX": "52%",
                        "height": "15dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.orders.popupHeader\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.orders.cancelOrder\")",
                        "width": "80%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(CustomPopupCancel);
            flxCancelPopup.add(flxPopup);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "lblSendMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblChat": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLabelCall": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblCall": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumber": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "skin": "sknlbl424242SSPReg15px",
                        "text": "+41 21 131 1582",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFormcontent": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContactAdvisor": {
                        "height": {
                            "type": "string",
                            "value": "61dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblContactAdvisor": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "sknlbl424242SSPRegular20px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "height": {
                            "type": "string",
                            "value": "633dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxMessage": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "top": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblMessage": {
                        "width": {
                            "type": "string",
                            "value": "408dp"
                        },
                        "segmentProps": []
                    },
                    "flxDetails": {
                        "height": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgLeft": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxSendMessage": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "305dp"
                        },
                        "segmentProps": []
                    },
                    "imgSendMessage": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxLabelMessage": {
                        "width": {
                            "type": "string",
                            "value": "205dp"
                        },
                        "segmentProps": []
                    },
                    "lblSendMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "flxBackSend": {
                        "width": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "flxChat": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "305dp"
                        },
                        "segmentProps": []
                    },
                    "imgChat": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxLabelChat": {
                        "width": {
                            "type": "string",
                            "value": "205dp"
                        },
                        "segmentProps": []
                    },
                    "lblChat": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "flxBack2": {
                        "width": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "flxCall": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "305dp"
                        },
                        "segmentProps": []
                    },
                    "imgCall": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxLabelCall": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "string",
                            "value": "237dp"
                        },
                        "segmentProps": []
                    },
                    "lblCall": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "width": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumber": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknlbl424242SSPReg15px",
                        "text": "+41 21 131 1582",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxClose": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnClose": {
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheadernew": {
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "customheadernew"
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "520dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFormcontent": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.70%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxContactAdvisor": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "61px"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblContactAdvisor": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "i18n_text": "i18n.wealth.contactAdvisor",
                        "skin": "sknlbl424242SSPRegular20px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "28px"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "height": {
                            "type": "string",
                            "value": "460px"
                        },
                        "segmentProps": []
                    },
                    "flxMessage": {
                        "height": {
                            "type": "string",
                            "value": "64px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblMessage": {
                        "i18n_text": "i18n.wealth.advisoryMessage",
                        "skin": "sknlbl424242SSPRegular24px",
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "408px"
                        },
                        "segmentProps": []
                    },
                    "flxDetails": {
                        "height": {
                            "type": "string",
                            "value": "220px"
                        },
                        "top": {
                            "type": "string",
                            "value": "29px"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "height": {
                            "type": "string",
                            "value": "216px"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgLeft": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxSendMessage": {
                        "left": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxImgSendMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "imgCombinedshapeSend": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "src": "combinedshape.png",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgSendMessage": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxLabelMessage": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblSendMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "i18n_text": "i18n.wealth.sendUsAMessage",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxBackSend": {
                        "width": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "imgBackSend": {
                        "segmentProps": []
                    },
                    "flxChat": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "left": {
                            "type": "string",
                            "value": "25px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxImgChat": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "imgCombinedshapeChat": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgChat": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxLabelChat": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblChat": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxBack2": {
                        "width": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "imgBackChat": {
                        "segmentProps": []
                    },
                    "flxCall": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "left": {
                            "type": "string",
                            "value": "25px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxImgCall": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "imgCombinedshapeCall": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgCall": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxLabelCall": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": []
                    },
                    "lblCall": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumber": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknlbl424242SSPReg15px",
                        "text": "+41 21 131 1582",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxClose": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "61px"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "reverseLayoutDirection": true,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnClose": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "i18n_text": "kony.mb.common.close",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "24px"
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "130dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopupCancel": {
                    "centerX": "50%",
                    "centerY": "",
                    "top": "250dp",
                    "width": "43%"
                },
                "CustomPopupCancel.btnNo": {
                    "left": "5.48%",
                    "right": ""
                },
                "CustomPopupCancel.btnYes": {
                    "right": "4.89%"
                },
                "CustomPopupCancel.flxCross1": {
                    "height": "30dp",
                    "right": "16dp",
                    "width": "30dp",
                    "zIndex": 5
                },
                "CustomPopupCancel.imgCross": {
                    "centerX": "52%",
                    "height": "15dp"
                },
                "CustomPopupCancel.lblPopupMessage": {
                    "width": "80%"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                }
            }
            this.add(flxHeader, flxMain, flxCancelPopup, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmContactAdvisor,
            "enabledForIdleTimeout": true,
            "id": "frmContactAdvisor",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "PortfolioManagementMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});