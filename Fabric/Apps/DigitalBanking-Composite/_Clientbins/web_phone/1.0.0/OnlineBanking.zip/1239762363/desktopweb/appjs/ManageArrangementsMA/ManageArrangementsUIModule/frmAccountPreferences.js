define("ManageArrangementsMA/ManageArrangementsUIModule/frmAccountPreferences", function() {
    return function(controller) {
        function addWidgetsfrmAccountPreferences() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Settingscapson\")",
                    "tagName": "h1"
                },
                "id": "lblHeading",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Settingscapson\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "27dp",
                "width": "87.80%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.updateSettingAndPreferences\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Settings"
            });
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Dropdown",
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxAccountSettings = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccountSettings",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "550dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettings.setDefaultUnit(kony.flex.DP);
            var flxAccountsWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountsWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsWrapper.setDefaultUnit(kony.flex.DP);
            var flxAccountsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxAccountsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsHeader.setDefaultUnit(kony.flex.DP);
            var flxAccountsHeaderSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAccountsHeaderSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsHeaderSeperator.setDefaultUnit(kony.flex.DP);
            flxAccountsHeaderSeperator.add();
            var lblAccountsHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.topmenu.accounts\")",
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblAccountsHeader",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.topmenu.accounts\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountsHeader.add(flxAccountsHeaderSeperator, lblAccountsHeader);
            var flxDowntimeWarning1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "169px",
                "id": "flxDowntimeWarning1",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.29%",
                "isModalContainer": false,
                "skin": "sknFlxffffffBorder3px",
                "top": "20dp",
                "width": "95.18%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning1.setDefaultUnit(kony.flex.DP);
            var imgWarning1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.payments.displayError\")"
                },
                "height": "35dp",
                "id": "imgWarning1",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "11dp",
                "width": "35dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "error"
            });
            var lblWarning1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.StopPayment.PleaseNote\")",
                    "tagName": "span"
                },
                "id": "lblWarning1",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP46464615pxbold",
                "text": "Please note the following points:",
                "top": 14,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning1.add(imgWarning1, lblWarning1);
            var flxAccounts = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "610dp",
                "horizontalScrollIndicator": true,
                "id": "flxAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccounts.setDefaultUnit(kony.flex.DP);
            var segAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "ul"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segAccounts",
                "isVisible": true,
                "left": "0%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountListItemHeaderPM"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btn": "btn",
                    "btnEdit": "btnEdit",
                    "flxAccountHolder": "flxAccountHolder",
                    "flxAccountHolderKey": "flxAccountHolderKey",
                    "flxAccountHolderValue": "flxAccountHolderValue",
                    "flxAccountListItemHeaderPM": "flxAccountListItemHeaderPM",
                    "flxAccountListItemWrapper": "flxAccountListItemWrapper",
                    "flxAccountName": "flxAccountName",
                    "flxAccountNumber": "flxAccountNumber",
                    "flxAccountNumberKey": "flxAccountNumberKey",
                    "flxAccountNumberValue": "flxAccountNumberValue",
                    "flxAccountRow": "flxAccountRow",
                    "flxAccountType": "flxAccountType",
                    "flxAccountTypeKey": "flxAccountTypeKey",
                    "flxAccountTypeValue": "flxAccountTypeValue",
                    "flxContent": "flxContent",
                    "flxEStatement": "flxEStatement",
                    "flxEStatementCheckBox": "flxEStatementCheckBox",
                    "flxFavoriteCheckBox": "flxFavoriteCheckBox",
                    "flxIdentifier": "flxIdentifier",
                    "flxLeft": "flxLeft",
                    "flxMarkAsFavorite": "flxMarkAsFavorite",
                    "flxMenu": "flxMenu",
                    "flxMenuorg": "flxMenuorg",
                    "flxMoveDown": "flxMoveDown",
                    "flxMoveDownorg": "flxMoveDownorg",
                    "flxMoveUp": "flxMoveUp",
                    "flxMoveorg": "flxMoveorg",
                    "flxRight": "flxRight",
                    "imgEStatementCheckBox": "imgEStatementCheckBox",
                    "imgFavoriteCheckBox": "imgFavoriteCheckBox",
                    "imgMoveDown": "imgMoveDown",
                    "imgMoveDownorg": "imgMoveDownorg",
                    "imgMoveUp": "imgMoveUp",
                    "imgMoveUporg": "imgMoveUporg",
                    "lblAccountHolderColon": "lblAccountHolderColon",
                    "lblAccountHolderKey": "lblAccountHolderKey",
                    "lblAccountHolderValue": "lblAccountHolderValue",
                    "lblAccountName": "lblAccountName",
                    "lblAccountNumberColon": "lblAccountNumberColon",
                    "lblAccountNumberKey": "lblAccountNumberKey",
                    "lblAccountNumberValue": "lblAccountNumberValue",
                    "lblAccountTypeColon": "lblAccountTypeColon",
                    "lblAccountTypeKey": "lblAccountTypeKey",
                    "lblAccountTypeValue": "lblAccountTypeValue",
                    "lblEStatement": "lblEStatement",
                    "lblEstatementCheckBoxIcon": "lblEstatementCheckBoxIcon",
                    "lblMarkAsFavorite": "lblMarkAsFavorite",
                    "lblMarkAsFavouriteAccountCheckBoxIcon": "lblMarkAsFavouriteAccountCheckBoxIcon",
                    "lblMove": "lblMove",
                    "lblMoveDownIcon": "lblMoveDownIcon",
                    "lblMoveDownIconorg": "lblMoveDownIconorg",
                    "lblMoveUpIcon": "lblMoveUpIcon",
                    "lblMoveUpIconorg": "lblMoveUpIconorg",
                    "lblMoveorg": "lblMoveorg",
                    "lblSepeartorlast": "lblSepeartorlast",
                    "lblSeperator": "lblSeperator",
                    "lblSeperator2": "lblSeperator2",
                    "lblTransactionHeader": "lblTransactionHeader",
                    "lblsepeartorfirst": "lblsepeartorfirst",
                    "lblseperator3": "lblseperator3"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSpacing = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxAccounts.add(segAccounts, flxSpacing);
            var flxCheckingAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCheckingAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckingAccounts.setDefaultUnit(kony.flex.DP);
            var segCheckingAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "ul"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segCheckingAccounts",
                "isVisible": true,
                "left": "0%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountPreferencesHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "20dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btn": "btn",
                    "btnEdit": "btnEdit",
                    "flxAccountHolder": "flxAccountHolder",
                    "flxAccountHolderKey": "flxAccountHolderKey",
                    "flxAccountHolderValue": "flxAccountHolderValue",
                    "flxAccountListItemWrapper": "flxAccountListItemWrapper",
                    "flxAccountName": "flxAccountName",
                    "flxAccountNumber": "flxAccountNumber",
                    "flxAccountNumberKey": "flxAccountNumberKey",
                    "flxAccountNumberValue": "flxAccountNumberValue",
                    "flxAccountPreferencesHeader": "flxAccountPreferencesHeader",
                    "flxAccountRow": "flxAccountRow",
                    "flxAccountType": "flxAccountType",
                    "flxAccountTypeKey": "flxAccountTypeKey",
                    "flxAccountTypeValue": "flxAccountTypeValue",
                    "flxContent": "flxContent",
                    "flxEStatement": "flxEStatement",
                    "flxEStatementCheckBox": "flxEStatementCheckBox",
                    "flxFavoriteCheckBox": "flxFavoriteCheckBox",
                    "flxIdentifier": "flxIdentifier",
                    "flxLeft": "flxLeft",
                    "flxMarkAsFavorite": "flxMarkAsFavorite",
                    "flxMenu": "flxMenu",
                    "flxMenudup": "flxMenudup",
                    "flxMoveDown": "flxMoveDown",
                    "flxMoveDowndup": "flxMoveDowndup",
                    "flxMoveUp": "flxMoveUp",
                    "flxMoveUpdup": "flxMoveUpdup",
                    "flxRight": "flxRight",
                    "imgEStatementCheckBox": "imgEStatementCheckBox",
                    "imgFavoriteCheckBox": "imgFavoriteCheckBox",
                    "imgMoveDown": "imgMoveDown",
                    "imgMoveDowndup": "imgMoveDowndup",
                    "imgMoveUp": "imgMoveUp",
                    "imgMoveUpdup": "imgMoveUpdup",
                    "lblAccountHolderColon": "lblAccountHolderColon",
                    "lblAccountHolderKey": "lblAccountHolderKey",
                    "lblAccountHolderValue": "lblAccountHolderValue",
                    "lblAccountName": "lblAccountName",
                    "lblAccountNumberColon": "lblAccountNumberColon",
                    "lblAccountNumberKey": "lblAccountNumberKey",
                    "lblAccountNumberValue": "lblAccountNumberValue",
                    "lblAccountPreferencesHeader": "lblAccountPreferencesHeader",
                    "lblAccountTypeColon": "lblAccountTypeColon",
                    "lblAccountTypeKey": "lblAccountTypeKey",
                    "lblAccountTypeValue": "lblAccountTypeValue",
                    "lblEStatement": "lblEStatement",
                    "lblEstatementCheckBoxIcon": "lblEstatementCheckBoxIcon",
                    "lblMarkAsFavorite": "lblMarkAsFavorite",
                    "lblMarkAsFavouriteAccountCheckBoxIcon": "lblMarkAsFavouriteAccountCheckBoxIcon",
                    "lblMove": "lblMove",
                    "lblMoveDownIcon": "lblMoveDownIcon",
                    "lblMoveDownIcondup": "lblMoveDownIcondup",
                    "lblMoveUpIcon": "lblMoveUpIcon",
                    "lblMoveUpIcondup": "lblMoveUpIcondup",
                    "lblMovedup": "lblMovedup",
                    "lblSepeartorlast": "lblSepeartorlast",
                    "lblSeperator": "lblSeperator",
                    "lblSeperator2": "lblSeperator2",
                    "lblsepeartorfirst": "lblsepeartorfirst",
                    "lblseperator3": "lblseperator3"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckingAccounts.add(segCheckingAccounts);
            var flxLoansAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLoansAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoansAccounts.setDefaultUnit(kony.flex.DP);
            var segLoansAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "ul"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segLoansAccounts",
                "isVisible": true,
                "left": "0%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountPreferencesHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "20dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btn": "btn",
                    "btnEdit": "btnEdit",
                    "flxAccountHolder": "flxAccountHolder",
                    "flxAccountHolderKey": "flxAccountHolderKey",
                    "flxAccountHolderValue": "flxAccountHolderValue",
                    "flxAccountListItemWrapper": "flxAccountListItemWrapper",
                    "flxAccountName": "flxAccountName",
                    "flxAccountNumber": "flxAccountNumber",
                    "flxAccountNumberKey": "flxAccountNumberKey",
                    "flxAccountNumberValue": "flxAccountNumberValue",
                    "flxAccountPreferencesHeader": "flxAccountPreferencesHeader",
                    "flxAccountRow": "flxAccountRow",
                    "flxAccountType": "flxAccountType",
                    "flxAccountTypeKey": "flxAccountTypeKey",
                    "flxAccountTypeValue": "flxAccountTypeValue",
                    "flxContent": "flxContent",
                    "flxEStatement": "flxEStatement",
                    "flxEStatementCheckBox": "flxEStatementCheckBox",
                    "flxFavoriteCheckBox": "flxFavoriteCheckBox",
                    "flxIdentifier": "flxIdentifier",
                    "flxLeft": "flxLeft",
                    "flxMarkAsFavorite": "flxMarkAsFavorite",
                    "flxMenu": "flxMenu",
                    "flxMenudup": "flxMenudup",
                    "flxMoveDown": "flxMoveDown",
                    "flxMoveDowndup": "flxMoveDowndup",
                    "flxMoveUp": "flxMoveUp",
                    "flxMoveUpdup": "flxMoveUpdup",
                    "flxRight": "flxRight",
                    "imgEStatementCheckBox": "imgEStatementCheckBox",
                    "imgFavoriteCheckBox": "imgFavoriteCheckBox",
                    "imgMoveDown": "imgMoveDown",
                    "imgMoveDowndup": "imgMoveDowndup",
                    "imgMoveUp": "imgMoveUp",
                    "imgMoveUpdup": "imgMoveUpdup",
                    "lblAccountHolderColon": "lblAccountHolderColon",
                    "lblAccountHolderKey": "lblAccountHolderKey",
                    "lblAccountHolderValue": "lblAccountHolderValue",
                    "lblAccountName": "lblAccountName",
                    "lblAccountNumberColon": "lblAccountNumberColon",
                    "lblAccountNumberKey": "lblAccountNumberKey",
                    "lblAccountNumberValue": "lblAccountNumberValue",
                    "lblAccountPreferencesHeader": "lblAccountPreferencesHeader",
                    "lblAccountTypeColon": "lblAccountTypeColon",
                    "lblAccountTypeKey": "lblAccountTypeKey",
                    "lblAccountTypeValue": "lblAccountTypeValue",
                    "lblEStatement": "lblEStatement",
                    "lblEstatementCheckBoxIcon": "lblEstatementCheckBoxIcon",
                    "lblMarkAsFavorite": "lblMarkAsFavorite",
                    "lblMarkAsFavouriteAccountCheckBoxIcon": "lblMarkAsFavouriteAccountCheckBoxIcon",
                    "lblMove": "lblMove",
                    "lblMoveDownIcon": "lblMoveDownIcon",
                    "lblMoveDownIcondup": "lblMoveDownIcondup",
                    "lblMoveUpIcon": "lblMoveUpIcon",
                    "lblMoveUpIcondup": "lblMoveUpIcondup",
                    "lblMovedup": "lblMovedup",
                    "lblSepeartorlast": "lblSepeartorlast",
                    "lblSeperator": "lblSeperator",
                    "lblSeperator2": "lblSeperator2",
                    "lblsepeartorfirst": "lblsepeartorfirst",
                    "lblseperator3": "lblseperator3"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoansAccounts.add(segLoansAccounts);
            var flxDepositsAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDepositsAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDepositsAccounts.setDefaultUnit(kony.flex.DP);
            var segDepositsAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "ul"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segDepositsAccounts",
                "isVisible": true,
                "left": "0%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountPreferencesHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "20dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btn": "btn",
                    "btnEdit": "btnEdit",
                    "flxAccountHolder": "flxAccountHolder",
                    "flxAccountHolderKey": "flxAccountHolderKey",
                    "flxAccountHolderValue": "flxAccountHolderValue",
                    "flxAccountListItemWrapper": "flxAccountListItemWrapper",
                    "flxAccountName": "flxAccountName",
                    "flxAccountNumber": "flxAccountNumber",
                    "flxAccountNumberKey": "flxAccountNumberKey",
                    "flxAccountNumberValue": "flxAccountNumberValue",
                    "flxAccountPreferencesHeader": "flxAccountPreferencesHeader",
                    "flxAccountRow": "flxAccountRow",
                    "flxAccountType": "flxAccountType",
                    "flxAccountTypeKey": "flxAccountTypeKey",
                    "flxAccountTypeValue": "flxAccountTypeValue",
                    "flxContent": "flxContent",
                    "flxEStatement": "flxEStatement",
                    "flxEStatementCheckBox": "flxEStatementCheckBox",
                    "flxFavoriteCheckBox": "flxFavoriteCheckBox",
                    "flxIdentifier": "flxIdentifier",
                    "flxLeft": "flxLeft",
                    "flxMarkAsFavorite": "flxMarkAsFavorite",
                    "flxMenu": "flxMenu",
                    "flxMenudup": "flxMenudup",
                    "flxMoveDown": "flxMoveDown",
                    "flxMoveDowndup": "flxMoveDowndup",
                    "flxMoveUp": "flxMoveUp",
                    "flxMoveUpdup": "flxMoveUpdup",
                    "flxRight": "flxRight",
                    "imgEStatementCheckBox": "imgEStatementCheckBox",
                    "imgFavoriteCheckBox": "imgFavoriteCheckBox",
                    "imgMoveDown": "imgMoveDown",
                    "imgMoveDowndup": "imgMoveDowndup",
                    "imgMoveUp": "imgMoveUp",
                    "imgMoveUpdup": "imgMoveUpdup",
                    "lblAccountHolderColon": "lblAccountHolderColon",
                    "lblAccountHolderKey": "lblAccountHolderKey",
                    "lblAccountHolderValue": "lblAccountHolderValue",
                    "lblAccountName": "lblAccountName",
                    "lblAccountNumberColon": "lblAccountNumberColon",
                    "lblAccountNumberKey": "lblAccountNumberKey",
                    "lblAccountNumberValue": "lblAccountNumberValue",
                    "lblAccountPreferencesHeader": "lblAccountPreferencesHeader",
                    "lblAccountTypeColon": "lblAccountTypeColon",
                    "lblAccountTypeKey": "lblAccountTypeKey",
                    "lblAccountTypeValue": "lblAccountTypeValue",
                    "lblEStatement": "lblEStatement",
                    "lblEstatementCheckBoxIcon": "lblEstatementCheckBoxIcon",
                    "lblMarkAsFavorite": "lblMarkAsFavorite",
                    "lblMarkAsFavouriteAccountCheckBoxIcon": "lblMarkAsFavouriteAccountCheckBoxIcon",
                    "lblMove": "lblMove",
                    "lblMoveDownIcon": "lblMoveDownIcon",
                    "lblMoveDownIcondup": "lblMoveDownIcondup",
                    "lblMoveUpIcon": "lblMoveUpIcon",
                    "lblMoveUpIcondup": "lblMoveUpIcondup",
                    "lblMovedup": "lblMovedup",
                    "lblSepeartorlast": "lblSepeartorlast",
                    "lblSeperator": "lblSeperator",
                    "lblSeperator2": "lblSeperator2",
                    "lblsepeartorfirst": "lblsepeartorfirst",
                    "lblseperator3": "lblseperator3"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDepositsAccounts.add(segDepositsAccounts);
            var flxCreditAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": true,
                "id": "flxCreditAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreditAccounts.setDefaultUnit(kony.flex.DP);
            var segCreditAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "ul"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segCreditAccounts",
                "isVisible": true,
                "left": "0%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountPreferencesHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "20dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btn": "btn",
                    "btnEdit": "btnEdit",
                    "flxAccountHolder": "flxAccountHolder",
                    "flxAccountHolderKey": "flxAccountHolderKey",
                    "flxAccountHolderValue": "flxAccountHolderValue",
                    "flxAccountListItemWrapper": "flxAccountListItemWrapper",
                    "flxAccountName": "flxAccountName",
                    "flxAccountNumber": "flxAccountNumber",
                    "flxAccountNumberKey": "flxAccountNumberKey",
                    "flxAccountNumberValue": "flxAccountNumberValue",
                    "flxAccountPreferencesHeader": "flxAccountPreferencesHeader",
                    "flxAccountRow": "flxAccountRow",
                    "flxAccountType": "flxAccountType",
                    "flxAccountTypeKey": "flxAccountTypeKey",
                    "flxAccountTypeValue": "flxAccountTypeValue",
                    "flxContent": "flxContent",
                    "flxEStatement": "flxEStatement",
                    "flxEStatementCheckBox": "flxEStatementCheckBox",
                    "flxFavoriteCheckBox": "flxFavoriteCheckBox",
                    "flxIdentifier": "flxIdentifier",
                    "flxLeft": "flxLeft",
                    "flxMarkAsFavorite": "flxMarkAsFavorite",
                    "flxMenu": "flxMenu",
                    "flxMenudup": "flxMenudup",
                    "flxMoveDown": "flxMoveDown",
                    "flxMoveDowndup": "flxMoveDowndup",
                    "flxMoveUp": "flxMoveUp",
                    "flxMoveUpdup": "flxMoveUpdup",
                    "flxRight": "flxRight",
                    "imgEStatementCheckBox": "imgEStatementCheckBox",
                    "imgFavoriteCheckBox": "imgFavoriteCheckBox",
                    "imgMoveDown": "imgMoveDown",
                    "imgMoveDowndup": "imgMoveDowndup",
                    "imgMoveUp": "imgMoveUp",
                    "imgMoveUpdup": "imgMoveUpdup",
                    "lblAccountHolderColon": "lblAccountHolderColon",
                    "lblAccountHolderKey": "lblAccountHolderKey",
                    "lblAccountHolderValue": "lblAccountHolderValue",
                    "lblAccountName": "lblAccountName",
                    "lblAccountNumberColon": "lblAccountNumberColon",
                    "lblAccountNumberKey": "lblAccountNumberKey",
                    "lblAccountNumberValue": "lblAccountNumberValue",
                    "lblAccountPreferencesHeader": "lblAccountPreferencesHeader",
                    "lblAccountTypeColon": "lblAccountTypeColon",
                    "lblAccountTypeKey": "lblAccountTypeKey",
                    "lblAccountTypeValue": "lblAccountTypeValue",
                    "lblEStatement": "lblEStatement",
                    "lblEstatementCheckBoxIcon": "lblEstatementCheckBoxIcon",
                    "lblMarkAsFavorite": "lblMarkAsFavorite",
                    "lblMarkAsFavouriteAccountCheckBoxIcon": "lblMarkAsFavouriteAccountCheckBoxIcon",
                    "lblMove": "lblMove",
                    "lblMoveDownIcon": "lblMoveDownIcon",
                    "lblMoveDownIcondup": "lblMoveDownIcondup",
                    "lblMoveUpIcon": "lblMoveUpIcon",
                    "lblMoveUpIcondup": "lblMoveUpIcondup",
                    "lblMovedup": "lblMovedup",
                    "lblSepeartorlast": "lblSepeartorlast",
                    "lblSeperator": "lblSeperator",
                    "lblSeperator2": "lblSeperator2",
                    "lblsepeartorfirst": "lblsepeartorfirst",
                    "lblseperator3": "lblseperator3"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCreditAccounts.add(segCreditAccounts);
            flxAccountsWrapper.add(flxAccountsHeader, flxDowntimeWarning1, flxAccounts, flxCheckingAccounts, flxLoansAccounts, flxDepositsAccounts, flxCreditAccounts);
            flxAccountSettings.add(flxAccountsWrapper);
            flxRight.add(flxAccountSettings);
            flxContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxMainContainer.add(flxContainer);
            flxMain.add(lblHeading, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxProfileDeletePopUp = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "102%",
                "id": "flxProfileDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxProfileDelete = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "268dp",
                "id": "flxProfileDelete",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDelete.setDefaultUnit(kony.flex.DP);
            var flxprofileDeleteHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxprofileDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofileDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Delete\")",
                    "tagName": "span"
                },
                "id": "lblProfileDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Delete Picture",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxprofiledeleteClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxprofiledeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.setDefaultUnit(kony.flex.DP);
            var imgProfileDeleteClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgProfileDeleteClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.add(imgProfileDeleteClose);
            flxprofileDeleteHeader.add(lblProfileDeleteHeader, flxprofiledeleteClose);
            var flxProfileDeleteSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxProfileDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxProfileDeleteSeperator.add();
            var flxProfileDeleteContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "65dp",
                "id": "flxProfileDeleteContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteContent = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.deletePhoneNum\")",
                    "tagName": "span"
                },
                "id": "lblProfileDeleteContent",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknlblUserName",
                "text": "Are you sure you want to remove your profile picture?",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.add(lblProfileDeleteContent);
            var flxWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "0%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var flxDisablWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxDisablWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20px",
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "20dp",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisablWarning.setDefaultUnit(kony.flex.DP);
            flxDisablWarning.add();
            flxWarning.add(flxDisablWarning);
            var flxProfileDeleteButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": 0,
                "clipBounds": true,
                "height": "109px",
                "id": "flxProfileDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnDeletePopupNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.No\")"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupNo",
                "isVisible": true,
                "left": "35.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "28.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "No"
            });
            var btnDeletePopupYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.Yes\")"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupYes",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "28.44%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Yes"
            });
            flxProfileDeleteButtons.add(btnDeletePopupNo, btnDeletePopupYes);
            flxProfileDelete.add(flxprofileDeleteHeader, flxProfileDeleteSeperator, flxProfileDeleteContent, flxWarning, flxProfileDeleteButtons);
            flxProfileDeletePopUp.add(flxProfileDelete);
            var flxLogout = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ManageArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxProfileDeletePopUp, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmAccountPreferences": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Profile Settings",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "540dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettings": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc3",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAccountsWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning1": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknflxBordere3e3e3",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgWarning1": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarning1": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "skin": "sknLblSSP33333313px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccounts": {
                        "height": {
                            "type": "string",
                            "value": "610dp"
                        },
                        "segmentProps": []
                    },
                    "flxSpacing": {
                        "height": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "maxHeight": {
                            "type": "string",
                            "value": "702dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "702dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "702dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "702dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "33.33%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "maxHeight": {
                            "type": "string",
                            "value": "702dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "66.67%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettings": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning1": {
                        "height": {
                            "type": "string",
                            "value": "69px"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknflxBordere3e3e3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgWarning1": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarning1": {
                        "left": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "skin": "sknLblSSP33333313px",
                        "top": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": []
                    },
                    "flxAccounts": {
                        "height": {
                            "type": "string",
                            "value": "610dp"
                        },
                        "segmentProps": []
                    },
                    "flxSpacing": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteContent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Are you sure you want to remove your profile picture?",
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "49%"
                        },
                        "top": {
                            "type": "number",
                            "value": "27"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "height": {
                            "type": "string",
                            "value": "702dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "660dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": "75%"
                        },
                        "skin": "slFboxffffff",
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettings": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning1": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknflxBordere3e3e3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgWarning1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarning1": {
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "skin": "sknLblSSP33333313px",
                        "text": "No accounts available for this user",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccounts": {
                        "height": {
                            "type": "string",
                            "value": "610dp"
                        },
                        "segmentProps": []
                    },
                    "flxSpacing": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmAccountPreferences": {
                        "segmentProps": []
                    },
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "i18n_text": "i18n.ProfileManagement.Settingscapson",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1202dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "702dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "702dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettings": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "860dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning1": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknflxBordere3e3e3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgWarning1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarning1": {
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "skin": "sknLblSSP33333313px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccounts": {
                        "height": {
                            "type": "string",
                            "value": "610dp"
                        },
                        "segmentProps": []
                    },
                    "flxSpacing": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxprofileDeleteHeader": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmAccountPreferences,
            "enabledForIdleTimeout": true,
            "id": "frmAccountPreferences",
            "init": controller.AS_Form_h43479b84eff4144a10a75f42eae70c6,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountPreferences\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ManageArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});