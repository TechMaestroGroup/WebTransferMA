define("FinanceManagementMA/PersonalFinanceManagementUIModule/frmPersonalFinanceManagement", function() {
    return function(controller) {
        function addWidgetsfrmPersonalFinanceManagement() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customhamburger.imgKony": {
                        "src": "kony_logo_white.png"
                    },
                    "customheader": {
                        "height": "121px"
                    },
                    "flxBottomContainer": {
                        "isVisible": true
                    },
                    "flxHamburger": {
                        "isVisible": false,
                        "left": "-50%"
                    },
                    "flxHeaderMain": {
                        "height": "120px",
                        "width": "1366dp"
                    },
                    "flxSeperatorHor2": {
                        "top": "120dp"
                    },
                    "flxTopmenu": {
                        "top": "70dp",
                        "width": "1366dp"
                    },
                    "headermenu": {
                        "isVisible": true
                    },
                    "imgKony": {
                        "isVisible": true,
                        "src": "kony_logo.png"
                    },
                    "topmenu.flxFeedback": {
                        "isVisible": true
                    },
                    "topmenu.flxHelp": {
                        "isVisible": true
                    },
                    "topmenu.flxSeperator1": {
                        "isVisible": true
                    },
                    "topmenu.flxTransfersAndPay": {
                        "isVisible": true
                    },
                    "topmenu.flxaccounts": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var breadcrumb = new com.InfinityOLB.Resources.breadcrumb({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "53dp",
                "id": "breadcrumb",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "breadcrumb": {
                        "height": "53dp",
                        "isVisible": true,
                        "top": "0dp"
                    },
                    "btnBreadcrumb1": {
                        "text": "ACCOUNTS"
                    },
                    "btnBreadcrumb2": {
                        "centerY": "51%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.PersonalFinanceManagement\")",
                        "left": "2.46%"
                    },
                    "flxBottomBorder": {
                        "bottom": "0dp"
                    },
                    "flxBreadcrumbcontainer": {
                        "centerX": "50%",
                        "height": "50dp",
                        "top": "1dp",
                        "width": "1366dp"
                    },
                    "flxTopBorder": {
                        "isVisible": true,
                        "top": "0dp"
                    },
                    "imgBreadcrumb2": {
                        "isVisible": false
                    },
                    "lblBreadcrumb2": {
                        "isVisible": false,
                        "text": "CATEGORIZED MONTHLY SPENDING"
                    },
                    "lblBreadcrumb3": {
                        "isVisible": false,
                        "text": "CATEGORIZED MONTHLY SPENDING"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            breadcrumb.btnBreadcrumb1.onClick = controller.AS_Button_fb5a0d943cbd487ea26c5488b18a8748;
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknRtx424242SSP17Px",
                "text": "There is some error in the server.\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxPFMContainers = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "40dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxPFMContainers",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "87.84%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPFMContainers.setDefaultUnit(kony.flex.DP);
            var CommonHeader = new com.InfinityOLB.Resources.CommonAll.CommonHeader({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "CommonHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CommonHeader": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "btnRequest": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.ViewUncategorizedTransactions\")"
                    },
                    "flxHeader": {
                        "height": "50dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.PersonalFinanceManagement\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxPFMContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "40dp",
                "clipBounds": false,
                "id": "flxPFMContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPFMContainer.setDefaultUnit(kony.flex.DP);
            var flxPFMContainer1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPFMContainer1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPFMContainer1.setDefaultUnit(kony.flex.DP);
            var flxPFMOverallSpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "500dp",
                "id": "flxPFMOverallSpending",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                "top": "30dp",
                "width": "46.85%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPFMOverallSpending.setDefaultUnit(kony.flex.DP);
            var flxHeaderOverallSpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxHeaderOverallSpending",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7Borderf7f7f71pxRadius3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderOverallSpending.setDefaultUnit(kony.flex.DP);
            var imgOverallSpendingIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "I",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "imgOverallSpendingIcon",
                "isVisible": true,
                "left": "5.32%",
                "skin": "sknLblFontTypeIconPFM",
                "text": "I",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderOverallSpending = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblHeaderOverallSpending",
                "isVisible": true,
                "left": "11%",
                "skin": "sknLblSSP46464615px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.OverallSpending\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxToggle = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxToggle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "sknFocusBorder293275",
                "top": "0dp",
                "width": "80dp",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxToggle.setDefaultUnit(kony.flex.DP);
            var flxChartView = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Overall Spending Chart View Toggle"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxChartView",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skbflx293276",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChartView.setDefaultUnit(kony.flex.DP);
            var lblChartIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblChartIcon",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblFontType3Selected",
                "text": "L",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChartView.add(lblChartIcon);
            var flxTableView = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Overall Spending Table View Toggle"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxTableView",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTableView.setDefaultUnit(kony.flex.DP);
            var lblTableIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblTableIcon",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblFontType3Unselected",
                "text": "J",
                "top": "0",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTableView.add(lblTableIcon);
            flxToggle.add(flxChartView, flxTableView);
            flxHeaderOverallSpending.add(imgOverallSpendingIcon, lblHeaderOverallSpending, flxToggle);
            var flxSeparatorOverallSpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorOverallSpending",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorOverallSpending.setDefaultUnit(kony.flex.DP);
            flxSeparatorOverallSpending.add();
            var flxOverallSpendingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "449dp",
                "id": "flxOverallSpendingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverallSpendingWrapper.setDefaultUnit(kony.flex.DP);
            var lblSelectPeriod = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSelectPeriod",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.SelectPeriod\")",
                "top": "31dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lstSelectPeriod = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblSelectPeriod",
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lstSelectPeriod",
                "isVisible": true,
                "left": "34%",
                "masterData": [
                    ["lb1", "2018"],
                    ["lb2", "2017"],
                    ["lb3", "2016"]
                ],
                "skin": "sknlbxalto33333315pxBordere3e3e32pxRadius",
                "top": "20dp",
                "width": "60%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknbtnhoverlst",
                "multiSelect": false
            });
            var flxChart = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "370dp",
                "id": "flxChart",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "80dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxChart.setDefaultUnit(kony.flex.DP);
            flxChart.add();
            var flxOverallSpendingSeg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxOverallSpendingSeg",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "80dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxOverallSpendingSeg.setDefaultUnit(kony.flex.DP);
            var segOverall = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "table"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "lblAssets": "Label",
                            "lblCol1": "Label",
                            "lblCol2": "Label",
                            "lblCol3": "Label",
                            "lblSeperator": "-",
                            "lblSeperator1": "-",
                            "lblTotal": "Label"
                        },
                        [{
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }]
                    ],
                    [{
                            "lblAssets": "Label",
                            "lblCol1": "Label",
                            "lblCol2": "Label",
                            "lblCol3": "Label",
                            "lblSeperator": "-",
                            "lblSeperator1": "-",
                            "lblTotal": "Label"
                        },
                        [{
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segOverall",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "FinanceManagementMA",
                    "friendlyName": "flxPFMSpendingTable"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "FinanceManagementMA",
                    "friendlyName": "flxPFMSpendingHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxGroup": "flxGroup",
                    "flxPFMSpendingHeader": "flxPFMSpendingHeader",
                    "flxPFMSpendingTable": "flxPFMSpendingTable",
                    "flxRow": "flxRow",
                    "lblAssets": "lblAssets",
                    "lblAssetsDummy": "lblAssetsDummy",
                    "lblCol1": "lblCol1",
                    "lblCol2": "lblCol2",
                    "lblCol3": "lblCol3",
                    "lblSeperator": "lblSeperator",
                    "lblSeperator1": "lblSeperator1",
                    "lblTotal": "lblTotal",
                    "lblTotalDummy": "lblTotalDummy",
                    "lblUsed": "lblUsed",
                    "lblUsedDummy": "lblUsedDummy"
                },
                "width": "100%",
                "appName": "FinanceManagementMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOverallSpendingSeg.add(segOverall);
            var flxNoTransactions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "200dp",
                "id": "flxNoTransactions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "60dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "90dp",
                "width": "80%",
                "zIndex": 5,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoTransactions.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.NAO.Info\")"
                },
                "height": "30dp",
                "id": "imgInfo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "1.50%",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "13dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverallSpending = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOverallSpending",
                "isVisible": true,
                "left": "43dp",
                "skin": "sknLabel42424224pxlight",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.OverallSpendingDataUnavailable\")",
                "top": "11dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblImg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "75%",
                "height": "120dp",
                "id": "lblImg",
                "isVisible": true,
                "left": "53dp",
                "skin": "sknLblFontTypeIconPFM100px",
                "text": "I",
                "top": "21dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoTransactions.add(imgInfo, lblOverallSpending, lblImg);
            flxOverallSpendingWrapper.add(lblSelectPeriod, lstSelectPeriod, flxChart, flxOverallSpendingSeg, flxNoTransactions);
            var flxSeperatorOverallSpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorOverallSpending",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorOverallSpending.setDefaultUnit(kony.flex.DP);
            flxSeperatorOverallSpending.add();
            flxPFMOverallSpending.add(flxHeaderOverallSpending, flxSeparatorOverallSpending, flxOverallSpendingWrapper, flxSeperatorOverallSpending);
            var flxPFMContainerMySpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "500dp",
                "id": "flxPFMContainerMySpending",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.30%",
                "isModalContainer": false,
                "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                "top": "5dp",
                "width": "48.50%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPFMContainerMySpending.setDefaultUnit(kony.flex.DP);
            var flxHeaderMySpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxHeaderMySpending",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7Borderf7f7f71pxRadius3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderMySpending.setDefaultUnit(kony.flex.DP);
            var imgMySpendingIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "K"
                },
                "centerY": "50%",
                "id": "imgMySpendingIcon",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLblFontTypeIcon",
                "text": "K",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderMySpending = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblHeaderMySpending",
                "isVisible": true,
                "left": "11%",
                "skin": "sknLblSSP46464615px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.MySpending\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxToggleMySpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxToggleMySpending",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "sknFocusBorder293275",
                "top": "0dp",
                "width": "80dp",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxToggleMySpending.setDefaultUnit(kony.flex.DP);
            var flxChartViewMySpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "My Spending Chart View Toggle"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxChartViewMySpending",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skbflx293276",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChartViewMySpending.setDefaultUnit(kony.flex.DP);
            var lblChartIconMySpending = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblChartIconMySpending",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblFontType3Selected",
                "text": "L",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChartViewMySpending.add(lblChartIconMySpending);
            var flxTableViewMySpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "My Spending Table View Toggle"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxTableViewMySpending",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTableViewMySpending.setDefaultUnit(kony.flex.DP);
            var lblTableIconMySpending = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblTableIconMySpending",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblFontType3Unselected",
                "text": "J",
                "top": "0",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTableViewMySpending.add(lblTableIconMySpending);
            flxToggleMySpending.add(flxChartViewMySpending, flxTableViewMySpending);
            flxHeaderMySpending.add(imgMySpendingIcon, lblHeaderMySpending, flxToggleMySpending);
            var flxSeparatorMySpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorMySpending",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorMySpending.setDefaultUnit(kony.flex.DP);
            flxSeparatorMySpending.add();
            var flxMySpendingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "449dp",
                "id": "flxMySpendingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMySpendingWrapper.setDefaultUnit(kony.flex.DP);
            var lblLastMonthSpending = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLastMonthSpending",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.SelectMonth\")",
                "top": "32dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lstSelectMonth = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblLastMonthSpending",
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lstSelectMonth",
                "isVisible": true,
                "left": "34%",
                "masterData": [
                    ["lb1", "December 2018"],
                    ["lb2", "November 2018"],
                    ["lb3", "September 2018"]
                ],
                "skin": "sknlbxalto33333315pxBordere3e3e32pxRadius",
                "top": "20dp",
                "width": "60%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknbtnhoverlst",
                "multiSelect": false
            });
            var lblOverallSpendingMySpending = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOverallSpendingMySpending",
                "isVisible": true,
                "left": "31dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.OverallSpending\")",
                "top": "88dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverallSpendingAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblOverallSpendingAmount",
                "isVisible": true,
                "left": "42%",
                "skin": "sknlblSSP42424220px",
                "text": "$3000.00",
                "top": "84dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDonutChart = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "320dp",
                "id": "flxDonutChart",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "130dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxDonutChart.setDefaultUnit(kony.flex.DP);
            flxDonutChart.add();
            var flxMonthlySeg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "320dp",
                "id": "flxMonthlySeg",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "130dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxMonthlySeg.setDefaultUnit(kony.flex.DP);
            var segMonthly = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "table"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "lblAssets": "Label",
                            "lblCol1": "Label",
                            "lblCol2": "Label",
                            "lblCol3": "Label",
                            "lblSeperator": "-",
                            "lblSeperator1": "-",
                            "lblTotal": "Label"
                        },
                        [{
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }]
                    ],
                    [{
                            "lblAssets": "Label",
                            "lblCol1": "Label",
                            "lblCol2": "Label",
                            "lblCol3": "Label",
                            "lblSeperator": "-",
                            "lblSeperator1": "-",
                            "lblTotal": "Label"
                        },
                        [{
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": "Label"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segMonthly",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "FinanceManagementMA",
                    "friendlyName": "flxPFMSpendingTable"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "FinanceManagementMA",
                    "friendlyName": "flxPFMSpendingHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxGroup": "flxGroup",
                    "flxPFMSpendingHeader": "flxPFMSpendingHeader",
                    "flxPFMSpendingTable": "flxPFMSpendingTable",
                    "flxRow": "flxRow",
                    "lblAssets": "lblAssets",
                    "lblAssetsDummy": "lblAssetsDummy",
                    "lblCol1": "lblCol1",
                    "lblCol2": "lblCol2",
                    "lblCol3": "lblCol3",
                    "lblSeperator": "lblSeperator",
                    "lblSeperator1": "lblSeperator1",
                    "lblTotal": "lblTotal",
                    "lblTotalDummy": "lblTotalDummy",
                    "lblUsed": "lblUsed",
                    "lblUsedDummy": "lblUsedDummy"
                },
                "width": "100%",
                "appName": "FinanceManagementMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMonthlySeg.add(segMonthly);
            var flxNoTransactionsMySpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "200dp",
                "id": "flxNoTransactionsMySpending",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "60dp",
                "minHeight": "300dp",
                "minWidth": "300dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "90dp",
                "width": "80%",
                "zIndex": 5,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoTransactionsMySpending.setDefaultUnit(kony.flex.DP);
            var flxNoTransactionInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxNoTransactionInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoTransactionInfo.setDefaultUnit(kony.flex.DP);
            var imgInfoMySpending = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "30dp",
                "id": "imgInfoMySpending",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "1.50%",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "13dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMySpending = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMySpending",
                "isVisible": true,
                "left": "44dp",
                "skin": "sknLabel42424224pxlight",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.MonthlySpendingDataUnavailable\")",
                "top": "11dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoTransactionInfo.add(imgInfoMySpending, lblMySpending);
            var lblImgMySpending = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "75%",
                "height": "120dp",
                "id": "lblImgMySpending",
                "isVisible": true,
                "left": "53dp",
                "skin": "sknLblFontTypeIcon100pxPFM",
                "text": "K",
                "top": "20dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoTransactionsMySpending.add(flxNoTransactionInfo, lblImgMySpending);
            flxMySpendingWrapper.add(lblLastMonthSpending, lstSelectMonth, lblOverallSpendingMySpending, lblOverallSpendingAmount, flxDonutChart, flxMonthlySeg, flxNoTransactionsMySpending);
            var flxSeperatorMySpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorMySpending",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorMySpending.setDefaultUnit(kony.flex.DP);
            flxSeperatorMySpending.add();
            flxPFMContainerMySpending.add(flxHeaderMySpending, flxSeparatorMySpending, flxMySpendingWrapper, flxSeperatorMySpending);
            flxPFMContainer1.add(flxPFMOverallSpending, flxPFMContainerMySpending);
            var flxPFMContainer2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxPFMContainer2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPFMContainer2.setDefaultUnit(kony.flex.DP);
            var flxPFMAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "clipBounds": false,
                "height": "600dp",
                "id": "flxPFMAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                "top": "20dp",
                "width": "46.85%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPFMAccounts.setDefaultUnit(kony.flex.DP);
            var flxHeaderAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxHeaderAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7Borderf7f7f71pxRadius3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderAccounts.setDefaultUnit(kony.flex.DP);
            var imgMySpendingIconAccounts = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a"
                },
                "centerY": "50%",
                "id": "imgMySpendingIconAccounts",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLblFontTypeIcon",
                "text": "a",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderAccounts = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.topmenu.accounts\")",
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblHeaderAccounts",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblSSP46464615px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.topmenu.accounts\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderAccounts.add(imgMySpendingIconAccounts, lblHeaderAccounts);
            var flxSeparatorAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorAccounts.setDefaultUnit(kony.flex.DP);
            flxSeparatorAccounts.add();
            var flxMySpendingWrapperAccounts = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "549dp",
                "horizontalScrollIndicator": true,
                "id": "flxMySpendingWrapperAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxMySpendingWrapperAccounts.setDefaultUnit(kony.flex.DP);
            var segAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblAccountName": "Checking Account Nick Name",
                    "lblAccountNumber": "Account Number  XXXXXXXXXXXX",
                    "lblAvailableBalanceDummy": "Label",
                    "lblAvailableBalanceTitle": "Available Balance",
                    "lblAvailableBalanceValue": "$9000000.00",
                    "lblCreditDummy": "Label",
                    "lblCreditKey": "Total Credit",
                    "lblCreditValue": "+$3200.00",
                    "lblDebitDummy": "Label",
                    "lblDebitKey": "Total Debit",
                    "lblDebitValue": "-$1200.00",
                    "lblIdentifier": "a",
                    "lblSeparator": "A",
                    "lblSepeartor2": "a",
                    "lblSeperator3": "a"
                }, {
                    "lblAccountName": "Checking Account Nick Name",
                    "lblAccountNumber": "Account Number  XXXXXXXXXXXX",
                    "lblAvailableBalanceDummy": "Label",
                    "lblAvailableBalanceTitle": "Available Balance",
                    "lblAvailableBalanceValue": "$9000000.00",
                    "lblCreditDummy": "Label",
                    "lblCreditKey": "Total Credit",
                    "lblCreditValue": "+$3200.00",
                    "lblDebitDummy": "Label",
                    "lblDebitKey": "Total Debit",
                    "lblDebitValue": "-$1200.00",
                    "lblIdentifier": "a",
                    "lblSeparator": "A",
                    "lblSepeartor2": "a",
                    "lblSeperator3": "a"
                }, {
                    "lblAccountName": "Checking Account Nick Name",
                    "lblAccountNumber": "Account Number  XXXXXXXXXXXX",
                    "lblAvailableBalanceDummy": "Label",
                    "lblAvailableBalanceTitle": "Available Balance",
                    "lblAvailableBalanceValue": "$9000000.00",
                    "lblCreditDummy": "Label",
                    "lblCreditKey": "Total Credit",
                    "lblCreditValue": "+$3200.00",
                    "lblDebitDummy": "Label",
                    "lblDebitKey": "Total Debit",
                    "lblDebitValue": "-$1200.00",
                    "lblIdentifier": "a",
                    "lblSeparator": "A",
                    "lblSepeartor2": "a",
                    "lblSeperator3": "a"
                }, {
                    "lblAccountName": "Checking Account Nick Name",
                    "lblAccountNumber": "Account Number  XXXXXXXXXXXX",
                    "lblAvailableBalanceDummy": "Label",
                    "lblAvailableBalanceTitle": "Available Balance",
                    "lblAvailableBalanceValue": "$9000000.00",
                    "lblCreditDummy": "Label",
                    "lblCreditKey": "Total Credit",
                    "lblCreditValue": "+$3200.00",
                    "lblDebitDummy": "Label",
                    "lblDebitKey": "Total Debit",
                    "lblDebitValue": "-$1200.00",
                    "lblIdentifier": "a",
                    "lblSeparator": "A",
                    "lblSepeartor2": "a",
                    "lblSeperator3": "a"
                }, {
                    "lblAccountName": "Checking Account Nick Name",
                    "lblAccountNumber": "Account Number  XXXXXXXXXXXX",
                    "lblAvailableBalanceDummy": "Label",
                    "lblAvailableBalanceTitle": "Available Balance",
                    "lblAvailableBalanceValue": "$9000000.00",
                    "lblCreditDummy": "Label",
                    "lblCreditKey": "Total Credit",
                    "lblCreditValue": "+$3200.00",
                    "lblDebitDummy": "Label",
                    "lblDebitKey": "Total Debit",
                    "lblDebitValue": "-$1200.00",
                    "lblIdentifier": "a",
                    "lblSeparator": "A",
                    "lblSepeartor2": "a",
                    "lblSeperator3": "a"
                }, {
                    "lblAccountName": "Checking Account Nick Name",
                    "lblAccountNumber": "Account Number  XXXXXXXXXXXX",
                    "lblAvailableBalanceDummy": "Label",
                    "lblAvailableBalanceTitle": "Available Balance",
                    "lblAvailableBalanceValue": "$9000000.00",
                    "lblCreditDummy": "Label",
                    "lblCreditKey": "Total Credit",
                    "lblCreditValue": "+$3200.00",
                    "lblDebitDummy": "Label",
                    "lblDebitKey": "Total Debit",
                    "lblDebitValue": "-$1200.00",
                    "lblIdentifier": "a",
                    "lblSeparator": "A",
                    "lblSepeartor2": "a",
                    "lblSeperator3": "a"
                }, {
                    "lblAccountName": "Checking Account Nick Name",
                    "lblAccountNumber": "Account Number  XXXXXXXXXXXX",
                    "lblAvailableBalanceDummy": "Label",
                    "lblAvailableBalanceTitle": "Available Balance",
                    "lblAvailableBalanceValue": "$9000000.00",
                    "lblCreditDummy": "Label",
                    "lblCreditKey": "Total Credit",
                    "lblCreditValue": "+$3200.00",
                    "lblDebitDummy": "Label",
                    "lblDebitKey": "Total Debit",
                    "lblDebitValue": "-$1200.00",
                    "lblIdentifier": "a",
                    "lblSeparator": "A",
                    "lblSepeartor2": "a",
                    "lblSeperator3": "a"
                }, {
                    "lblAccountName": "Checking Account Nick Name",
                    "lblAccountNumber": "Account Number  XXXXXXXXXXXX",
                    "lblAvailableBalanceDummy": "Label",
                    "lblAvailableBalanceTitle": "Available Balance",
                    "lblAvailableBalanceValue": "$9000000.00",
                    "lblCreditDummy": "Label",
                    "lblCreditKey": "Total Credit",
                    "lblCreditValue": "+$3200.00",
                    "lblDebitDummy": "Label",
                    "lblDebitKey": "Total Debit",
                    "lblDebitValue": "-$1200.00",
                    "lblIdentifier": "a",
                    "lblSeparator": "A",
                    "lblSepeartor2": "a",
                    "lblSeperator3": "a"
                }, {
                    "lblAccountName": "Checking Account Nick Name",
                    "lblAccountNumber": "Account Number  XXXXXXXXXXXX",
                    "lblAvailableBalanceDummy": "Label",
                    "lblAvailableBalanceTitle": "Available Balance",
                    "lblAvailableBalanceValue": "$9000000.00",
                    "lblCreditDummy": "Label",
                    "lblCreditKey": "Total Credit",
                    "lblCreditValue": "+$3200.00",
                    "lblDebitDummy": "Label",
                    "lblDebitKey": "Total Debit",
                    "lblDebitValue": "-$1200.00",
                    "lblIdentifier": "a",
                    "lblSeparator": "A",
                    "lblSepeartor2": "a",
                    "lblSeperator3": "a"
                }, {
                    "lblAccountName": "Checking Account Nick Name",
                    "lblAccountNumber": "Account Number  XXXXXXXXXXXX",
                    "lblAvailableBalanceDummy": "Label",
                    "lblAvailableBalanceTitle": "Available Balance",
                    "lblAvailableBalanceValue": "$9000000.00",
                    "lblCreditDummy": "Label",
                    "lblCreditKey": "Total Credit",
                    "lblCreditValue": "+$3200.00",
                    "lblDebitDummy": "Label",
                    "lblDebitKey": "Total Debit",
                    "lblDebitValue": "-$1200.00",
                    "lblIdentifier": "a",
                    "lblSeparator": "A",
                    "lblSepeartor2": "a",
                    "lblSeperator3": "a"
                }],
                "groupCells": false,
                "id": "segAccounts",
                "isVisible": true,
                "left": "30dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "FinanceManagementMA",
                    "friendlyName": "flxPFMAccounts"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flPFMAccountListItemWrapper": "flPFMAccountListItemWrapper",
                    "flxAccountName": "flxAccountName",
                    "flxAvailableBalance": "flxAvailableBalance",
                    "flxContent": "flxContent",
                    "flxCredit": "flxCredit",
                    "flxDebit": "flxDebit",
                    "flxPFMAccounts": "flxPFMAccounts",
                    "lblAccountName": "lblAccountName",
                    "lblAccountNumber": "lblAccountNumber",
                    "lblAvailableBalanceDummy": "lblAvailableBalanceDummy",
                    "lblAvailableBalanceTitle": "lblAvailableBalanceTitle",
                    "lblAvailableBalanceValue": "lblAvailableBalanceValue",
                    "lblCreditDummy": "lblCreditDummy",
                    "lblCreditKey": "lblCreditKey",
                    "lblCreditValue": "lblCreditValue",
                    "lblDebitDummy": "lblDebitDummy",
                    "lblDebitKey": "lblDebitKey",
                    "lblDebitValue": "lblDebitValue",
                    "lblIdentifier": "lblIdentifier",
                    "lblSeparator": "lblSeparator",
                    "lblSepeartor2": "lblSepeartor2",
                    "lblSeperator3": "lblSeperator3"
                },
                "width": "92%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMySpendingWrapperAccounts.add(segAccounts);
            var flxAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "549dp",
                "id": "flxAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccounts.setDefaultUnit(kony.flex.DP);
            var flxNoAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "200dp",
                "id": "flxNoAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "60dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "90dp",
                "width": "80%",
                "zIndex": 5,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAccounts.setDefaultUnit(kony.flex.DP);
            var imgInfoAccounts = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "30dp",
                "id": "imgInfoAccounts",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "6.5%",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "13dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoAccounts = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoAccounts",
                "isVisible": true,
                "left": "72dp",
                "skin": "sknLabel42424224pxlight",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pfm.nopfmAccounts\")",
                "top": "11dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblimgAccounts = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a",
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "75%",
                "height": "120dp",
                "id": "lblimgAccounts",
                "isVisible": true,
                "left": "53dp",
                "skin": "sknLblFontTypeIcon100pxd3d3d3",
                "text": "a",
                "top": "21dp",
                "width": "105dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoAccounts.add(imgInfoAccounts, lblNoAccounts, lblimgAccounts);
            flxAccounts.add(flxNoAccounts);
            var flxSeperator2Accounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator2Accounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2Accounts.setDefaultUnit(kony.flex.DP);
            flxSeperator2Accounts.add();
            flxPFMAccounts.add(flxHeaderAccounts, flxSeparatorAccounts, flxMySpendingWrapperAccounts, flxAccounts, flxSeperator2Accounts);
            var flxPFMBudget2018 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "clipBounds": false,
                "height": "600dp",
                "id": "flxPFMBudget2018",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                "top": "20dp",
                "width": "46.85%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPFMBudget2018.setDefaultUnit(kony.flex.DP);
            var flxHeaderBudget = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxHeaderBudget",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7Borderf7f7f71pxRadius3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderBudget.setDefaultUnit(kony.flex.DP);
            var imgMySpendingIconBudget = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "J",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "imgMySpendingIconBudget",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLblFontTypeIconPFM",
                "text": "J",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderBudget = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblHeaderBudget",
                "isVisible": true,
                "left": "11%",
                "skin": "sknLblSSP46464615px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.Budget2018\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxToggleBudget = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxToggleBudget",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "sknFocusBorder293275",
                "top": "0dp",
                "width": "80dp",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxToggleBudget.setDefaultUnit(kony.flex.DP);
            var flxChartViewBudget = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Budget Chart View Toggle"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxChartViewBudget",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skbflx293276",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChartViewBudget.setDefaultUnit(kony.flex.DP);
            var lblChartIconBudget = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblChartIconBudget",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblFontType3Selected",
                "text": "L",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxChartViewBudget.add(lblChartIconBudget);
            var flxTableViewBudget = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Budget Table View Toggle "
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxTableViewBudget",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTableViewBudget.setDefaultUnit(kony.flex.DP);
            var lblTableIconBudget = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblTableIconBudget",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblFontType3Unselected",
                "text": "J",
                "top": "0",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTableViewBudget.add(lblTableIconBudget);
            flxToggleBudget.add(flxChartViewBudget, flxTableViewBudget);
            flxHeaderBudget.add(imgMySpendingIconBudget, lblHeaderBudget, flxToggleBudget);
            var flxSeparatorBudget = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorBudget",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBudget.setDefaultUnit(kony.flex.DP);
            flxSeparatorBudget.add();
            var flxBudgetMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "549dp",
                "id": "flxBudgetMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "Copysknflxffffff",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBudgetMain.setDefaultUnit(kony.flex.DP);
            var lstSelectMonthBudget = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lstSelectMonthBudget",
                "isVisible": false,
                "left": "34%",
                "masterData": [
                    ["lb1", "December 2018"],
                    ["lb2", "November 2018"],
                    ["lb3", "September 2018"]
                ],
                "skin": "sknlbxalto33333315pxBordere3e3e32pxRadius",
                "top": "20dp",
                "width": "60%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknbtnhoverlst",
                "multiSelect": false
            });
            var lblLastMonthSpendingBudget = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLastMonthSpendingBudget",
                "isVisible": false,
                "left": "30dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.SelectMonth\")",
                "top": "32dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBudget2018WrapperdataUnavailable = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "85%",
                "id": "flxBudget2018WrapperdataUnavailable",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "60dp",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "90dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBudget2018WrapperdataUnavailable.setDefaultUnit(kony.flex.DP);
            var imgInfoBudget2018 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.NAO.Info\")"
                },
                "height": "30dp",
                "id": "imgInfoBudget2018",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "6.5%",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "13dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBudget2018 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblBudget2018",
                "isVisible": true,
                "left": "72dp",
                "skin": "sknLabel42424224pxlight",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.NoBudgetCreatedFor2018\")",
                "top": "11dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblImgBudget2018 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "J"
                },
                "centerX": "50%",
                "centerY": "75%",
                "height": "120dp",
                "id": "lblImgBudget2018",
                "isVisible": true,
                "left": "53dp",
                "skin": "sknLblFontTypeIconPFM100px",
                "text": "J",
                "top": "21dp",
                "width": "105dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBudget2018WrapperdataUnavailable.add(imgInfoBudget2018, lblBudget2018, lblImgBudget2018);
            var flxMySpendingWrapperBudget = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "85%",
                "id": "flxMySpendingWrapperBudget",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "50dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMySpendingWrapperBudget.setDefaultUnit(kony.flex.DP);
            flxMySpendingWrapperBudget.add();
            var flxMySpendingBudgetTable = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "85%",
                "id": "flxMySpendingBudgetTable",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMySpendingBudgetTable.setDefaultUnit(kony.flex.DP);
            var segMySpendingBudget = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "tagName": "table"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "lblCol1": "Label",
                            "lblCol2": "Label",
                            "lblCol3": "Label",
                            "lblSeperator": "-",
                            "lblSeperator1": "-"
                        },
                        [{
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }]
                    ],
                    [{
                            "lblCol1": "Label",
                            "lblCol2": "Label",
                            "lblCol3": "Label",
                            "lblSeperator": "-",
                            "lblSeperator1": "-"
                        },
                        [{
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }, {
                            "lblAssets": "Label",
                            "lblAssetsDummy": "",
                            "lblSeperator": "-",
                            "lblTotal": "Label",
                            "lblTotalDummy": "",
                            "lblUsed": "Label",
                            "lblUsedDummy": ""
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segMySpendingBudget",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "FinanceManagementMA",
                    "friendlyName": "flxPFMSpendingTable"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "FinanceManagementMA",
                    "friendlyName": "flxPFMSpendingHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxGroup": "flxGroup",
                    "flxPFMSpendingHeader": "flxPFMSpendingHeader",
                    "flxPFMSpendingTable": "flxPFMSpendingTable",
                    "flxRow": "flxRow",
                    "lblAssets": "lblAssets",
                    "lblAssetsDummy": "lblAssetsDummy",
                    "lblCol1": "lblCol1",
                    "lblCol2": "lblCol2",
                    "lblCol3": "lblCol3",
                    "lblSeperator": "lblSeperator",
                    "lblSeperator1": "lblSeperator1",
                    "lblTotal": "lblTotal",
                    "lblTotalDummy": "lblTotalDummy",
                    "lblUsed": "lblUsed",
                    "lblUsedDummy": "lblUsedDummy"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMySpendingBudgetTable.add(segMySpendingBudget);
            flxBudgetMain.add(lstSelectMonthBudget, lblLastMonthSpendingBudget, flxBudget2018WrapperdataUnavailable, flxMySpendingWrapperBudget, flxMySpendingBudgetTable);
            var flxSeperatorBudget = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorBudget",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorBudget.setDefaultUnit(kony.flex.DP);
            flxSeperatorBudget.add();
            flxPFMBudget2018.add(flxHeaderBudget, flxSeparatorBudget, flxBudgetMain, flxSeperatorBudget);
            flxPFMContainer2.add(flxPFMAccounts, flxPFMBudget2018);
            flxPFMContainer.add(flxPFMContainer1, flxPFMContainer2);
            flxPFMContainers.add(CommonHeader, flxPFMContainer);
            var flexCategorizedMonthlySpending = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "40dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flexCategorizedMonthlySpending",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "87.84%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flexCategorizedMonthlySpending.setDefaultUnit(kony.flex.DP);
            var CategorizedMonthlySpending = new com.InfinityOLB.FinanceManagementMA.CategorizedMonthlySpending({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "CategorizedMonthlySpending",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "FinanceManagementMA",
                "overrides": {
                    "CategorizedMonthlySpending": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "CommonHeader": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "CommonHeader.btnRequest": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.BulkUpdate\")"
                    },
                    "CommonHeader.flxHeader": {
                        "height": "50px"
                    },
                    "CommonHeader.lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.categorizedMonthlySpending\")",
                        "left": "2.5%"
                    },
                    "btnUnCategorized": {
                        "text": "Uncategorized"
                    },
                    "flxContainer": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": true,
                        "maxWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared"
                    },
                    "flxDonutChart": {
                        "left": "0dp",
                        "top": "160dp"
                    },
                    "flxLastMonthSpending": {
                        "clipBounds": false,
                        "height": "662dp"
                    },
                    "flxMySpendingWrapperdataUnavailableSpending": {
                        "isVisible": false
                    },
                    "flxSeparatorSort": {
                        "height": "662dp"
                    },
                    "flxSortCategory": {
                        "centerX": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "202dp"
                    },
                    "flxTransactions": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": true
                    },
                    "flxTransactionsHeader": {
                        "clipBounds": false,
                        "height": "662dp"
                    },
                    "imgInfoMySpendingUncategorized": {
                        "src": "info_large.png"
                    },
                    "imgSortAmount": {
                        "isVisible": false,
                        "src": "sorting.png"
                    },
                    "imgSortDate": {
                        "isVisible": false,
                        "src": "sorting.png"
                    },
                    "lblImgMySpendingUncategorized": {
                        "width": "33.33%"
                    },
                    "lblSortDescription": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.Bulkpayments.Description\")"
                    },
                    "segTransactions": {
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxBulkUpdate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxBulkUpdate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "367dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "673dp",
                "width": "100%",
                "zIndex": 100,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBulkUpdate.setDefaultUnit(kony.flex.DP);
            flxBulkUpdate.add();
            flexCategorizedMonthlySpending.add(CategorizedMonthlySpending, flxBulkUpdate);
            var flxUncategorizedTransactions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "40dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxUncategorizedTransactions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "87.84%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUncategorizedTransactions.setDefaultUnit(kony.flex.DP);
            var CommonHeaderUncategorized = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "CommonHeaderUncategorized",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            CommonHeaderUncategorized.setDefaultUnit(kony.flex.DP);
            var flxHeaderUncategorised = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxHeaderUncategorised",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderUncategorised.setDefaultUnit(kony.flex.DP);
            var flxSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3op60",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "centerY": "50%",
                "id": "lblHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.UncategorizedTransactions\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRequest = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.NameChangeRequest\")"
                },
                "centerY": "50%",
                "id": "btnRequest",
                "isVisible": true,
                "right": "-43.17%",
                "skin": "sknBtnSSP0273e315px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View Uncategorized Transactions"
            });
            flxHeaderUncategorised.add(flxSeperator, lblHeading, btnRequest);
            CommonHeaderUncategorized.add(flxHeaderUncategorised);
            var TransactionsUnCategorized = new com.InfinityOLB.FinanceManagementMA.Transactions({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TransactionsUnCategorized",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknf8f7f8modbr4pxbebebeshdw",
                "top": "0dp",
                "width": "100%",
                "appName": "FinanceManagementMA",
                "overrides": {
                    "Transactions": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "btnCancel": {
                        "right": "200dp",
                        "width": "150dp"
                    },
                    "btnDownload": {
                        "width": "150dp"
                    },
                    "flxButtons": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxCheckbox": {
                        "left": "86%",
                        "right": "5%",
                        "width": "10%"
                    },
                    "flxDate": {
                        "clipBounds": false,
                        "left": "1%"
                    },
                    "flxLeftBulkUpdate": {
                        "width": "56%"
                    },
                    "flxNoTransactions": {
                        "height": "412dp",
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxRight": {
                        "width": "44%"
                    },
                    "flxRightBulkUpdate": {
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxSegmentContainer": {
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxSeparatorNoResults": {
                        "isVisible": false
                    },
                    "flxSort": {
                        "isVisible": false
                    },
                    "flxSortAmount": {
                        "clipBounds": false,
                        "left": "65%",
                        "right": "0%",
                        "width": "32%"
                    },
                    "flxSortAmountBulk": {
                        "left": "viz.val_cleared",
                        "right": "18%"
                    },
                    "flxSortAmountButton": {
                        "right": "10%"
                    },
                    "flxSortBulkUpdate": {
                        "isVisible": true
                    },
                    "flxSortDateButton": {
                        "top": "5dp"
                    },
                    "flxSortDescriptionBulk": {
                        "clipBounds": false,
                        "right": "0%",
                        "width": "40%"
                    },
                    "flxSortTo": {
                        "left": "25%",
                        "top": "0dp"
                    },
                    "flxSortToBulk": {
                        "clipBounds": false
                    },
                    "imgCheckBox": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "src": "checked_box.png",
                        "top": "viz.val_cleared"
                    },
                    "imgInfo": {
                        "src": "info_large.png"
                    },
                    "imgPaginationFirst": {
                        "src": "pagination_inactive.png"
                    },
                    "imgPaginationLast": {
                        "src": "pagination_next_active.png"
                    },
                    "imgPaginationNext": {
                        "src": "pagination_last_active.png"
                    },
                    "imgPaginationPrevious": {
                        "src": "pagination_back_inactive.png"
                    },
                    "imgSortAmount": {
                        "right": "42%",
                        "src": "sorting_next.png"
                    },
                    "imgSortBulk": {
                        "src": "sorting.png"
                    },
                    "imgSortDate": {
                        "src": "sorting_next.png"
                    },
                    "imgSortDateBulk": {
                        "src": "sorting.png"
                    },
                    "imgSortDescription": {
                        "src": "sorting.png"
                    },
                    "imgSortDescriptionBulk": {
                        "src": "sorting.png"
                    },
                    "imgSortTo": {
                        "src": "sorting.png"
                    },
                    "lblCheckBox": {
                        "centerX": "50%",
                        "left": "viz.val_cleared"
                    },
                    "lblSortAmount": {
                        "left": "viz.val_cleared",
                        "right": "1%"
                    },
                    "lblSortAmountBulkUpdate": {
                        "left": "viz.val_cleared",
                        "right": "0%"
                    },
                    "lblSortDate": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.DueDate\")"
                    },
                    "lblSortDateBulk": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.DueDate\")",
                        "left": "0dp"
                    },
                    "lblSortDescription": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.Bulkpayments.Description\")"
                    },
                    "lblSortTo": {
                        "left": "7%"
                    },
                    "lblSortTransactionBulk": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.pfm.desc\")",
                        "left": "13%"
                    },
                    "segTransactions": {
                        "maxHeight": "412dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxBackButton = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100dp",
                "id": "flxBackButton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox0iada330a12024avs",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackButton.setDefaultUnit(kony.flex.DP);
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "50dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "0%",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PFM.Back\")",
                "width": "21.40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackButton.add(btnBack);
            flxUncategorizedTransactions.add(CommonHeaderUncategorized, TransactionsUnCategorized, flxBackButton);
            flxMainContainer.add(flxDowntimeWarning, flxPFMContainers, flexCategorizedMonthlySpending, flxUncategorizedTransactions);
            flxContainer.add(breadcrumb, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var CustomFooterMain = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "CustomFooterMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "top": "0dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(CustomFooterMain);
            flxFormContent.add(flxContainer, flxFooter);
            var flxPFMAssignCategory = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "150%",
                "id": "flxPFMAssignCategory",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPFMAssignCategory.setDefaultUnit(kony.flex.DP);
            var AssignCategory = new com.InfinityOLB.FinanceManagementMA.AssignCategory({
                "height": "100%",
                "id": "AssignCategory",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0c69b7ae145714d",
                "top": "0dp",
                "width": "100%",
                "appName": "FinanceManagementMA",
                "overrides": {
                    "AssignCategory": {
                        "height": "100%",
                        "left": "0dp"
                    },
                    "btnCancel": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnDownload": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxButtons": {
                        "height": "109px"
                    },
                    "flxCross": {
                        "left": "viz.val_cleared",
                        "right": "20dp"
                    },
                    "flxPopup": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxWarning": {
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "imgClose": {
                        "src": "icon_close_grey.png"
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgWarningPFM": {
                        "src": "error_yellow.png"
                    },
                    "lblHeader": {
                        "text": "A"
                    },
                    "lblSelectFormat": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {
                    "imgClose": {
                        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS
                    },
                    "imgCross": {
                        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS
                    }
                }
            }, {
                "overrides": {}
            });
            flxPFMAssignCategory.add(AssignCategory);
            var flxLoading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "FinanceManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxBottomContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "-35%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "breadcrumb": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "breadcrumb"
                    },
                    "breadcrumb.flxBreadcrumbcontainer": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98.50%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainers": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CommonHeader": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CommonHeader"
                    },
                    "CommonHeader.flxSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPFMContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainer1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxPFMOverallSpending": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "flxOverallSpendingWrapper": {
                        "width": {
                            "type": "string",
                            "value": "99.80%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectPeriod": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoTransactions": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblImg": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainerMySpending": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "imgMySpendingIcon": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderMySpending": {
                        "left": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "flxMySpendingWrapper": {
                        "width": {
                            "type": "string",
                            "value": "99.80%"
                        },
                        "segmentProps": []
                    },
                    "lblLastMonthSpending": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpendingMySpending": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpendingAmount": {
                        "left": {
                            "type": "string",
                            "value": "42%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxNoTransactionsMySpending": {
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxNoTransactionInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10%"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "imgInfoMySpending": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblMySpending": {
                        "left": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgMySpending": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainer2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMAccounts": {
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "imgMySpendingIconAccounts": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "flxMySpendingWrapperAccounts": {
                        "height": {
                            "type": "string",
                            "value": "349dp"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "99.80%"
                        },
                        "segmentProps": []
                    },
                    "segAccounts": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccounts": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "99.80%"
                        },
                        "segmentProps": []
                    },
                    "flxNoAccounts": {
                        "isCustomLayout": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgInfoAccounts": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoAccounts": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblimgAccounts": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPFMBudget2018": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "imgMySpendingIconBudget": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderBudget": {
                        "left": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "flxBudgetMain": {
                        "height": {
                            "type": "string",
                            "value": "447dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99.80%"
                        },
                        "segmentProps": []
                    },
                    "flxBudget2018WrapperdataUnavailable": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgInfoBudget2018": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblBudget2018": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgBudget2018": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMySpendingWrapperBudget": {
                        "width": {
                            "type": "string",
                            "value": "99.80%"
                        },
                        "segmentProps": []
                    },
                    "flxMySpendingBudgetTable": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "99.80%"
                        },
                        "segmentProps": []
                    },
                    "flexCategorizedMonthlySpending": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 100,
                        "segmentProps": [],
                        "instanceId": "CategorizedMonthlySpending"
                    },
                    "CategorizedMonthlySpending.CommonHeader": {
                        "top": {
                            "type": "string",
                            "value": "690dp"
                        },
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.CommonHeader.btnRequest": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.CommonHeader.flxHeader": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.CommonHeader.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.btnCategorized": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.btnUnCategorized": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxContainer": {
                        "minHeight": {
                            "type": "string",
                            "value": "663dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxLastMonthSpending": {
                        "height": {
                            "type": "string",
                            "value": "622dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxMySpendingWrapperdataUnavailableSpending": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxNoTransactions": {
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSegmentContainer": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSeparatorNoResults": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSeparatorSort": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSort": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxTabs": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99.30%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxTransactions": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxTransactionsHeader": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "740dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98.30%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "43.86%"
                        },
                        "top": {
                            "type": "string",
                            "value": "107dp"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.imgSortAmount": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lblImgMySpendingUncategorized": {
                        "width": {
                            "type": "string",
                            "value": "40.33%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lblLastMonthSpending": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lblOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lblOverallSpendingAmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "$3000.00",
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lstSelectMonth": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.rtxNoPaymentMessage": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "186dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.segTransactions": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxBulkUpdate": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "530dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "695dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "zIndex": 150,
                        "segmentProps": []
                    },
                    "flxUncategorizedTransactions": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                        "top": {
                            "type": "string",
                            "value": "-610dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "segmentProps": []
                    },
                    "btnRequest": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99.70%"
                        },
                        "segmentProps": [],
                        "instanceId": "TransactionsUnCategorized"
                    },
                    "TransactionsUnCategorized.btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.btnDownload": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "160px"
                        },
                        "width": {
                            "type": "string",
                            "value": "99.40%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxHeaderUncategorized": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxPagination": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxPaginationPrevious": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxPaginationWrapper": {
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSegmentContainer": {
                        "width": {
                            "type": "string",
                            "value": "99.40%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortAmountButton": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortDescription": {
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.imgSortAmount": {
                        "right": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortAmount": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortDate": {
                        "i18n_text": "i18n.ChequeManagement.Date",
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.rtxNoPaymentMessage": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.segTransactions": {
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBackButton": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "padding": [2, 0, 2, 0],
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "isVisible": true,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxPFMAssignCategory": {
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "AssignCategory"
                    },
                    "AssignCategory.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.btnDownload": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "140px"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.flxCross": {
                        "segmentProps": []
                    },
                    "AssignCategory.flxPopup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "115px"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.flxSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.flxWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.imgWarningPFM": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lblSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lblWarning": {
                        "left": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lbxSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopup"
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "52.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "42.50%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "42.50%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "segmentProps": []
                    },
                    "breadcrumb": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "breadcrumb"
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "83.84%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "rtxDowntimeWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainers": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CommonHeader": {
                        "zIndex": 1,
                        "segmentProps": [],
                        "instanceId": "CommonHeader"
                    },
                    "CommonHeader.btnRequest": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CommonHeader.flxHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-4dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CommonHeader.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainer": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainer1": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMOverallSpending": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "48.50%"
                        },
                        "segmentProps": []
                    },
                    "imgOverallSpendingIcon": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectPeriod": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "lstSelectPeriod": {
                        "left": {
                            "type": "string",
                            "value": "36%"
                        },
                        "segmentProps": []
                    },
                    "flxNoTransactions": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblImg": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainerMySpending": {
                        "left": {
                            "type": "string",
                            "value": "1.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgMySpendingIcon": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderMySpending": {
                        "left": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "lblLastMonthSpending": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "lstSelectMonth": {
                        "left": {
                            "type": "string",
                            "value": "36%"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpendingMySpending": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpendingAmount": {
                        "left": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxDonutChart": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxNoTransactionsMySpending": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": []
                    },
                    "imgInfoMySpending": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblMySpending": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgMySpending": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainer2": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMAccounts": {
                        "bottom": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "48.50%"
                        },
                        "segmentProps": []
                    },
                    "imgMySpendingIconAccounts": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "flxMySpendingWrapperAccounts": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "segAccounts": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "flxAccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoAccounts": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "imgInfoAccounts": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoAccounts": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblimgAccounts": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPFMBudget2018": {
                        "bottom": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "48.50%"
                        },
                        "segmentProps": []
                    },
                    "imgMySpendingIconBudget": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderBudget": {
                        "left": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "lstSelectMonthBudget": {
                        "left": {
                            "type": "string",
                            "value": "36%"
                        },
                        "segmentProps": []
                    },
                    "lblLastMonthSpendingBudget": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "flxBudget2018WrapperdataUnavailable": {
                        "segmentProps": []
                    },
                    "imgInfoBudget2018": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBudget2018": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgBudget2018": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flexCategorizedMonthlySpending": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.40%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.CommonHeader.btnRequest": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.CommonHeader.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "minHeight": {
                            "type": "string",
                            "value": "663dp"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxDonutChart": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "46%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxLastMonthSpending": {
                        "height": {
                            "type": "string",
                            "value": "372dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98.30%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxMySpendingWrapperdataUnavailableSpending": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "46%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxNoTransactionsMySpendingUncategorized": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSegmentContainer": {
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSeparatorSort": {
                        "height": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "top": {
                            "type": "string",
                            "value": "-345dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSort": {
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSortCategory": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxTransactions": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxTransactionsHeader": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98.30%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.imgInfoMySpendingUncategorized": {
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.imgSortAmount": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lblLastMonthSpending": {
                        "left": {
                            "type": "string",
                            "value": "3.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lblMySpendingUncategorized": {
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lblOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "3.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lblOverallSpendingAmount": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lstSelectMonth": {
                        "left": {
                            "type": "string",
                            "value": "3.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.segTransactions": {
                        "segmentProps": []
                    },
                    "flxUncategorizedTransactions": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "segmentProps": []
                    },
                    "btnRequest": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "instanceId": "TransactionsUnCategorized"
                    },
                    "TransactionsUnCategorized.flxButtons": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxCheckbox": {
                        "centerY": {
                            "type": "string",
                            "value": "55%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "9%"
                        },
                        "width": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxDate": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxHeaderUncategorized": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxNoTransactions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxPagination": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxRight": {
                        "width": {
                            "type": "string",
                            "value": "40.50%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxRightBulkUpdate": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSegmentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSort": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortAmount": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortAmountBulk": {
                        "layoutType": kony.flex.FREE_FORM,
                        "right": {
                            "type": "string",
                            "value": "15.60%"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "26%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortBulkUpdate": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortDate": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortDescription": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortDescriptionBulk": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortTo": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.imgSortAmount": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblCheckBox": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortAmount": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortAmountBulkUpdate": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortDateBulk": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortDescription": {
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortTo": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortToPfm": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortTransactionBulk": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.rtxNoPaymentMessage": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxBackButton": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "padding": [2, 0, 2, 0],
                        "right": {
                            "type": "string",
                            "value": "0px"
                        },
                        "skin": "sknBtnNormalSSPFFFFFF4vs",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "1600dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMAssignCategory": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AssignCategory.btnCancel": {
                        "segmentProps": []
                    },
                    "AssignCategory.btnDownload": {
                        "segmentProps": []
                    },
                    "AssignCategory.flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.flxCross": {
                        "segmentProps": []
                    },
                    "AssignCategory.flxPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.flxWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.imgWarningPFM": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lblSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lblWarning": {
                        "left": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lbxSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopup"
                    },
                    "CustomPopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": "121dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "breadcrumb": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "breadcrumb"
                    },
                    "flxMainContainer": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPFMContainers": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CommonHeader": {
                        "zIndex": 1,
                        "segmentProps": [],
                        "instanceId": "CommonHeader"
                    },
                    "CommonHeader.btnRequest": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CommonHeader.flxHeader": {
                        "top": {
                            "type": "string",
                            "value": "-4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CommonHeader.flxSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CommonHeader.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainer": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPFMOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknflxBordere3e3e3br5pxbebebeshdw",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49.25%"
                        },
                        "segmentProps": []
                    },
                    "imgOverallSpendingIcon": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "11%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectPeriod": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "flxNoTransactions": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblImg": {
                        "left": {
                            "type": "string",
                            "value": "11.75%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22.17%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainerMySpending": {
                        "left": {
                            "type": "string",
                            "value": "1.60%"
                        },
                        "skin": "sknflxBordere3e3e3br5pxbebebeshdw",
                        "width": {
                            "type": "string",
                            "value": "49.20%"
                        },
                        "segmentProps": []
                    },
                    "imgMySpendingIcon": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderMySpending": {
                        "left": {
                            "type": "string",
                            "value": "11%"
                        },
                        "segmentProps": []
                    },
                    "lblLastMonthSpending": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpendingMySpending": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpendingAmount": {
                        "left": {
                            "type": "string",
                            "value": "34%"
                        },
                        "segmentProps": []
                    },
                    "flxNoTransactionsMySpending": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "imgInfoMySpending": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblMySpending": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgMySpending": {
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "22.17%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainer2": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPFMAccounts": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49.25%"
                        },
                        "segmentProps": []
                    },
                    "imgMySpendingIconAccounts": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderAccounts": {
                        "left": {
                            "type": "string",
                            "value": "2.66%"
                        },
                        "segmentProps": []
                    },
                    "segAccounts": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "imgInfoAccounts": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoAccounts": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxPFMBudget2018": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49.20%"
                        },
                        "segmentProps": []
                    },
                    "imgMySpendingIconBudget": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "lblHeaderBudget": {
                        "segmentProps": []
                    },
                    "lblLastMonthSpendingBudget": {
                        "left": {
                            "type": "string",
                            "value": "5.32%"
                        },
                        "segmentProps": []
                    },
                    "flxBudget2018WrapperdataUnavailable": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgInfoBudget2018": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblBudget2018": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgBudget2018": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "23.28%"
                        },
                        "segmentProps": []
                    },
                    "flexCategorizedMonthlySpending": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.CommonHeader.btnRequest": {
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.CommonHeader.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "663dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSortCategory": {
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxTransactionsHeader": {
                        "left": {
                            "type": "string",
                            "value": "-2dp"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.imgSortAmount": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lblImgMySpendingUncategorized": {
                        "width": {
                            "type": "string",
                            "value": "33.33%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lblOverallSpendingAmount": {
                        "right": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.lstSelectMonth": {
                        "left": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "segmentProps": []
                    },
                    "flxUncategorizedTransactions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "89.50%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "segmentProps": []
                    },
                    "btnRequest": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": [],
                        "instanceId": "TransactionsUnCategorized"
                    },
                    "TransactionsUnCategorized.flxCheckbox": {
                        "left": {
                            "type": "string",
                            "value": "85.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxPaginationPrevious": {
                        "left": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxRight": {
                        "width": {
                            "type": "string",
                            "value": "40.50%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSort": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortAmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortAmountBulk": {
                        "right": {
                            "type": "string",
                            "value": "14.40%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortAmountButton": {
                        "right": {
                            "type": "string",
                            "value": "8%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortDate": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortDescription": {
                        "left": {
                            "type": "string",
                            "value": "54%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortTo": {
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.imgSortAmount": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortAmount": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.rtxNoPaymentMessage": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxBackButton": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "text": "Once a new statements is generated, the previous statement  will no longer be avialable",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "padding": [3, 0, 3, 0],
                        "right": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    },
                    "AssignCategory.flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.flxCross": {
                        "segmentProps": []
                    },
                    "AssignCategory.flxWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.imgWarningPFM": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "text": "Assign Category",
                        "segmentProps": []
                    },
                    "AssignCategory.lblSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lblWarning": {
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "30"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": "121dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "breadcrumb": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "breadcrumb"
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPFMContainers": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CommonHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "instanceId": "CommonHeader"
                    },
                    "CommonHeader.btnRequest": {
                        "right": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CommonHeader.flxHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "CommonHeader.flxSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CommonHeader.lblHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49.20%"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpending": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainerMySpending": {
                        "left": {
                            "type": "string",
                            "value": "1.60%"
                        },
                        "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                        "width": {
                            "type": "string",
                            "value": "49.20%"
                        },
                        "segmentProps": []
                    },
                    "lblOverallSpendingAmount": {
                        "left": {
                            "type": "string",
                            "value": "34%"
                        },
                        "segmentProps": []
                    },
                    "imgInfoMySpending": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblMySpending": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblImgMySpending": {
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxPFMContainer2": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPFMAccounts": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49.20%"
                        },
                        "segmentProps": []
                    },
                    "segAccounts": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "imgInfoAccounts": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoAccounts": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxPFMBudget2018": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1.60%"
                        },
                        "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49.20%"
                        },
                        "segmentProps": []
                    },
                    "flxBudget2018WrapperdataUnavailable": {
                        "segmentProps": []
                    },
                    "lblBudget2018": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flexCategorizedMonthlySpending": {
                        "isVisible": false,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.CommonHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.CommonHeader.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.btnUnCategorized": {
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "663dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxLeft": {
                        "width": {
                            "type": "string",
                            "value": "56%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSeparatorSort": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "-2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxSort": {
                        "width": {
                            "type": "string",
                            "value": "101%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.flxTransactionsHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67%"
                        },
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.imgSortAmount": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CategorizedMonthlySpending.rtxNoPaymentMessage": {
                        "text": "No Categorized Transactions found",
                        "segmentProps": []
                    },
                    "flxUncategorizedTransactions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "91"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1277dp"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99.60%"
                        },
                        "segmentProps": [],
                        "instanceId": "TransactionsUnCategorized"
                    },
                    "TransactionsUnCategorized.btnCancel": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.btnDownload": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxButtons": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxCheckbox": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "8.80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "4.60%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxDate": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxPaginationPrevious": {
                        "left": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortAmount": {
                        "right": {
                            "type": "string",
                            "value": "9%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortAmountBulk": {
                        "right": {
                            "type": "string",
                            "value": "13.60%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.flxSortDate": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.imgSortAmount": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortAmount": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.lblSortTo": {
                        "segmentProps": []
                    },
                    "TransactionsUnCategorized.rtxNoPaymentMessage": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxBackButton": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "padding": [3, 0, 3, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPFMAssignCategory": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "AssignCategory.btnCancel": {
                        "segmentProps": []
                    },
                    "AssignCategory.flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.flxWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.imgClose": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "AssignCategory.imgCross": {
                        "segmentProps": []
                    },
                    "AssignCategory.imgWarningPFM": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "text": "Assign Category",
                        "segmentProps": []
                    },
                    "AssignCategory.lblSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "AssignCategory.lblWarning": {
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.customhamburger.imgKony": {
                    "src": "kony_logo_white.png"
                },
                "customheader": {
                    "height": "121px"
                },
                "customheader.flxHamburger": {
                    "left": "-50%"
                },
                "customheader.flxHeaderMain": {
                    "height": "120px",
                    "width": "1366dp"
                },
                "customheader.flxSeperatorHor2": {
                    "top": "120dp"
                },
                "customheader.flxTopmenu": {
                    "top": "70dp",
                    "width": "1366dp"
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "breadcrumb": {
                    "height": "53dp",
                    "top": "0dp"
                },
                "breadcrumb.btnBreadcrumb1": {
                    "text": "ACCOUNTS"
                },
                "breadcrumb.btnBreadcrumb2": {
                    "centerY": "51%",
                    "left": "2.46%"
                },
                "breadcrumb.flxBottomBorder": {
                    "bottom": "0dp"
                },
                "breadcrumb.flxBreadcrumbcontainer": {
                    "centerX": "50%",
                    "height": "50dp",
                    "top": "1dp",
                    "width": "1366dp"
                },
                "breadcrumb.flxTopBorder": {
                    "top": "0dp"
                },
                "breadcrumb.lblBreadcrumb2": {
                    "text": "CATEGORIZED MONTHLY SPENDING"
                },
                "breadcrumb.lblBreadcrumb3": {
                    "text": "CATEGORIZED MONTHLY SPENDING"
                },
                "CommonHeader.flxHeader": {
                    "height": "50dp"
                },
                "CategorizedMonthlySpending.CommonHeader.flxHeader": {
                    "height": "50px"
                },
                "CategorizedMonthlySpending.CommonHeader.lblHeading": {
                    "left": "2.5%"
                },
                "CategorizedMonthlySpending.btnUnCategorized": {
                    "text": "Uncategorized"
                },
                "CategorizedMonthlySpending.flxContainer": {
                    "maxWidth": "",
                    "minHeight": ""
                },
                "CategorizedMonthlySpending.flxDonutChart": {
                    "left": "0dp",
                    "top": "160dp"
                },
                "CategorizedMonthlySpending.flxLastMonthSpending": {
                    "height": "662dp"
                },
                "CategorizedMonthlySpending.flxSeparatorSort": {
                    "height": "662dp"
                },
                "CategorizedMonthlySpending.flxSortCategory": {
                    "centerX": "",
                    "left": "",
                    "right": "202dp"
                },
                "CategorizedMonthlySpending.flxTransactionsHeader": {
                    "height": "662dp"
                },
                "CategorizedMonthlySpending.imgInfoMySpendingUncategorized": {
                    "src": "info_large.png"
                },
                "CategorizedMonthlySpending.imgSortAmount": {
                    "src": "sorting.png"
                },
                "CategorizedMonthlySpending.imgSortDate": {
                    "src": "sorting.png"
                },
                "CategorizedMonthlySpending.lblImgMySpendingUncategorized": {
                    "width": "33.33%"
                },
                "CategorizedMonthlySpending.segTransactions": {
                    "width": "100%"
                },
                "TransactionsUnCategorized.btnCancel": {
                    "right": "200dp",
                    "width": "150dp"
                },
                "TransactionsUnCategorized.btnDownload": {
                    "width": "150dp"
                },
                "TransactionsUnCategorized.flxButtons": {
                    "width": "100%"
                },
                "TransactionsUnCategorized.flxCheckbox": {
                    "left": "86%",
                    "right": "5%",
                    "width": "10%"
                },
                "TransactionsUnCategorized.flxDate": {
                    "left": "1%"
                },
                "TransactionsUnCategorized.flxLeftBulkUpdate": {
                    "width": "56%"
                },
                "TransactionsUnCategorized.flxNoTransactions": {
                    "height": "412dp",
                    "width": "100%"
                },
                "TransactionsUnCategorized.flxRight": {
                    "width": "44%"
                },
                "TransactionsUnCategorized.flxRightBulkUpdate": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "TransactionsUnCategorized.flxSegmentContainer": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "TransactionsUnCategorized.flxSortAmount": {
                    "left": "65%",
                    "right": "0%",
                    "width": "32%"
                },
                "TransactionsUnCategorized.flxSortAmountBulk": {
                    "left": "",
                    "right": "18%"
                },
                "TransactionsUnCategorized.flxSortAmountButton": {
                    "right": "10%"
                },
                "TransactionsUnCategorized.flxSortDateButton": {
                    "top": "5dp"
                },
                "TransactionsUnCategorized.flxSortDescriptionBulk": {
                    "right": "0%",
                    "width": "40%"
                },
                "TransactionsUnCategorized.flxSortTo": {
                    "left": "25%",
                    "top": "0dp"
                },
                "TransactionsUnCategorized.imgCheckBox": {
                    "centerX": "50%",
                    "left": "",
                    "src": "checked_box.png",
                    "top": ""
                },
                "TransactionsUnCategorized.imgInfo": {
                    "src": "info_large.png"
                },
                "TransactionsUnCategorized.imgPaginationFirst": {
                    "src": "pagination_inactive.png"
                },
                "TransactionsUnCategorized.imgPaginationLast": {
                    "src": "pagination_next_active.png"
                },
                "TransactionsUnCategorized.imgPaginationNext": {
                    "src": "pagination_last_active.png"
                },
                "TransactionsUnCategorized.imgPaginationPrevious": {
                    "src": "pagination_back_inactive.png"
                },
                "TransactionsUnCategorized.imgSortAmount": {
                    "right": "42%",
                    "src": "sorting_next.png"
                },
                "TransactionsUnCategorized.imgSortBulk": {
                    "src": "sorting.png"
                },
                "TransactionsUnCategorized.imgSortDate": {
                    "src": "sorting_next.png"
                },
                "TransactionsUnCategorized.imgSortDateBulk": {
                    "src": "sorting.png"
                },
                "TransactionsUnCategorized.imgSortDescription": {
                    "src": "sorting.png"
                },
                "TransactionsUnCategorized.imgSortDescriptionBulk": {
                    "src": "sorting.png"
                },
                "TransactionsUnCategorized.imgSortTo": {
                    "src": "sorting.png"
                },
                "TransactionsUnCategorized.lblCheckBox": {
                    "centerX": "50%",
                    "left": ""
                },
                "TransactionsUnCategorized.lblSortAmount": {
                    "left": "",
                    "right": "1%"
                },
                "TransactionsUnCategorized.lblSortAmountBulkUpdate": {
                    "left": "",
                    "right": "0%"
                },
                "TransactionsUnCategorized.lblSortDateBulk": {
                    "left": "0dp"
                },
                "TransactionsUnCategorized.lblSortTo": {
                    "left": "7%"
                },
                "TransactionsUnCategorized.lblSortTransactionBulk": {
                    "left": "13%"
                },
                "TransactionsUnCategorized.segTransactions": {
                    "maxHeight": "412dp"
                },
                "CustomFooterMain": {
                    "centerX": "50%",
                    "top": "0dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "CustomFooterMain.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "CustomFooterMain.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "AssignCategory": {
                    "height": "100%",
                    "left": "0dp"
                },
                "AssignCategory.btnCancel": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "AssignCategory.btnDownload": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "AssignCategory.flxButtons": {
                    "height": "109px"
                },
                "AssignCategory.flxCross": {
                    "left": "",
                    "right": "20dp"
                },
                "AssignCategory.flxWarning": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "AssignCategory.imgClose": {
                    "src": "icon_close_grey.png"
                },
                "AssignCategory.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "AssignCategory.imgWarningPFM": {
                    "src": "error_yellow.png"
                },
                "AssignCategory.lblHeader": {
                    "text": "A"
                },
                "AssignCategory.lblSelectFormat": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                }
            }
            this.add(flxHeader, flxFormContent, flxPFMAssignCategory, flxLoading, flxLogout);
        };
        return [{
            "addWidgets": addWidgetsfrmPersonalFinanceManagement,
            "enabledForIdleTimeout": true,
            "id": "frmPersonalFinanceManagement",
            "init": controller.AS_Form_ef3509b60474425dbf5352bd5df3569c,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_a71b3588cef84880b7449832947fe27c,
            "postShow": controller.AS_Form_j76ffebeb9504dd99c56d3766e15f0bb,
            "preShow": function(eventobject) {
                controller.AS_Form_fd9b9dde468744cfb9ec015b69f1543f(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Personal Finance Management",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "FinanceManagementMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_g11cf0172e714728bb68cfa47b9be073,
            "retainScrollPosition": false
        }]
    }
});