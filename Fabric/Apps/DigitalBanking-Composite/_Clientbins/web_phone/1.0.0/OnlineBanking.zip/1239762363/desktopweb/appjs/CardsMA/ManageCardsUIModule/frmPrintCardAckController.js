define("CardsMA/ManageCardsUIModule/userfrmPrintCardAckController", ['CommonUtilities', 'OLBConstants'], function(CommonUtilities, OLBConstants) {
    var orientationHandler = new OrientationHandler();
    return {
        showInfo: {},
        preShow: function() {
            var navMan = applicationManager.getNavigationManager();
            var scopeObj = this;
            this.showInfo = navMan.getCustomInfo("frmPrintCardAck");
            this.setUpFormData();
        },
        setUpFormData: function() {
            this.view.Acknowledgement.lblCardTransactionMessage.text = this.showInfo.successMessage;
            this.view.Acknowledgement.lblRefrenceNumber.text = this.showInfo.refNumber;
        },
        postShow: function() {
            scope = this;
            applicationManager.getNavigationManager().applyUpdates(this);
            var navMan = applicationManager.getNavigationManager();
            var cards = navMan.getCustomInfo("frmPrintCardAck");
            var data = cards.tableList[0].tableRows;
            this.showInfo.cards = data;
            //  var segData = [];
            var segData = [];
            data.forEach(function(transaction) {
                segData.push({
                    "lblValue": transaction.value,
                    "lblKey": transaction.key
                })
            })
            this.view.segCardDetails.setData(segData);
            setTimeout(function() {
                scope.printCall();
            }, "17ms");
            applicationManager.getNavigationManager().applyUpdates(this);
        },
        printCall: function() {
            var scope = this;
            kony.os.print();
            setTimeout(function() {
                scope.loadCardDetails();
            }, "17ms");
        },
        loadCardDetails: function() {
            applicationManager.getNavigationManager().navigateTo({
                "appName": "CardsMA",
                "friendlyName": "frmCardManagement"
            });
            kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                "moduleName": "ManageCardsUIModule",
                "appName": "CardsMA"
            }).presentationController.navigateToManageCards();
            kony.application.dismissLoadingScreen();
        }
    }
});
define("CardsMA/ManageCardsUIModule/frmPrintCardAckControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for frmPrintCardAck **/
    AS_Form_c375d193cd0e4104afe4ee4abd1aa115: function AS_Form_c375d193cd0e4104afe4ee4abd1aa115(eventobject) {
        var self = this;
        this.postShow();
    },
    /** preShow defined for frmPrintCardAck **/
    AS_Form_da5f5eb0807f4cf7b15c09616df31bf8: function AS_Form_da5f5eb0807f4cf7b15c09616df31bf8(eventobject) {
        var self = this;
        this.preShow();
    }
});
define("CardsMA/ManageCardsUIModule/frmPrintCardAckController", ["CardsMA/ManageCardsUIModule/userfrmPrintCardAckController", "CardsMA/ManageCardsUIModule/frmPrintCardAckControllerActions"], function() {
    var controller = require("CardsMA/ManageCardsUIModule/userfrmPrintCardAckController");
    var controllerActions = ["CardsMA/ManageCardsUIModule/frmPrintCardAckControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
