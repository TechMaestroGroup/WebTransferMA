define("OpenBankingMA/OpenBankingUIModule/frmAcknowledgement", function() {
    return function(controller) {
        function addWidgetsfrmAcknowledgement() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "64dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var openBankingHeader = new com.temenos.openBankingHeader({
                "height": "64dp",
                "id": "openBankingHeader",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA",
                "viewType": "openBankingHeader",
                "overrides": {
                    "openBankingHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var openBankingHeader_data = (appConfig.componentMetadata && appConfig.componentMetadata["OpenBankingMA"] && appConfig.componentMetadata["OpenBankingMA"]["frmAcknowledgement"] && appConfig.componentMetadata["OpenBankingMA"]["frmAcknowledgement"]["openBankingHeader"]) || {};
            flxHeader.add(openBankingHeader);
            var flxFormContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32dp",
                "width": "71.30%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "height": kony.flex.USE_PREFFERED_SIZE,
                "id": "lblHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLabel42424224pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.component.header.customAcknowledgement\")",
                "top": "0dp",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMainContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "374dp",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffWithBorderAndRadius16px",
                "top": "24dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "206dp",
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "48dp",
                "width": "680dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxImg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "51%",
                "clipBounds": false,
                "height": "96dp",
                "id": "flxImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "96dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImg.setDefaultUnit(kony.flex.DP);
            var imgGreenTick = new kony.ui.Image2({
                "height": "100%",
                "id": "imgGreenTick",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "successful.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImg.add(imgGreenTick);
            var lblSuccessMessage = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblSuccessMessage",
                "isVisible": true,
                "skin": "sknLabel42424224pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppconsent.successMsg\")",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRedirectInfo = new kony.ui.Label({
                "id": "lblRedirectInfo",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbl000d19SSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppconsnet.backtotpp\")",
                "top": "5dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBackTotppMsg = new kony.ui.Label({
                "id": "lblBackTotppMsg",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLb727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppconsent.navigationMsg\")",
                "top": "32dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "24dp",
                "isModalContainer": false,
                "right": "24dp",
                "skin": "slFbox",
                "top": "32dp",
                "width": "100%",
                "zIndex": 100,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "CONFIRM"
                },
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "sknBG293276B8pxSSBffffff15px",
                "height": "100%",
                "id": "btnContinue",
                "isVisible": true,
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.continue\")",
                "width": "250dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(btnContinue);
            flxContainer.add(flxImg, lblSuccessMessage, lblRedirectInfo, lblBackTotppMsg, flxButtons);
            flxMainContainer.add(flxContainer);
            flxFormContent.add(lblHeader, flxMainContainer);
            flxMain.add(flxHeader, flxFormContent);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxFormContent": {
                        "height": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "1000dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblRedirectInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblBackTotppMsg": {
                        "bottom": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "bottom": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "openBankingHeader": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "height": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "71.30%"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblRedirectInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblBackTotppMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxFormContent": {
                        "height": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "728dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "height": {
                            "type": "string",
                            "value": "374dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "width": {
                            "type": "string",
                            "value": "680dp"
                        },
                        "segmentProps": []
                    },
                    "lblRedirectInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblBackTotppMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "openBankingHeader": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "height": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "728dp"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblRedirectInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblBackTotppMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "openBankingHeader": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmAcknowledgement,
            "enabledForIdleTimeout": true,
            "id": "frmAcknowledgement",
            "init": controller.AS_Form_i96820c1acac43f29dc1126055f4dd9d,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_eb1f947653e845ac96f227cb4f4c68ca(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Acknowledgement",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "OpenBankingMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});