define("ArrangementsMA/MortgageServicesUIModule/frmEarlyPayOff", function() {
    return function(controller) {
        function addWidgetsfrmEarlyPayOff() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxHeading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "54dp",
                "id": "flxHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 205,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeading.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "centerY": "50%",
                "height": "24dp",
                "id": "lblHeader",
                "isVisible": true,
                "left": "6%",
                "skin": "sknSSPSemiBold42424220px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.SimulateEarlyPayOff\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var byPass = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "height": "30dp",
                "id": "byPass",
                "isVisible": true,
                "left": "320dp",
                "skin": "btnSkipNavigation",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.SkiptoInstructions\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeading.add(lblHeader, byPass);
            var flxError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "54dp",
                "id": "flxError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "1200dp",
                "zIndex": 205,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgError",
                "isVisible": true,
                "left": "20dp",
                "src": "errorclose_red.png",
                "width": "30dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "0dp",
                "centerY": "50%",
                "height": "24dp",
                "id": "lblErrMessage",
                "isVisible": true,
                "left": "60dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.PayOffServerError\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "20dp",
                "src": "close_blue.png",
                "width": "30dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError.add(imgError, lblErrMessage, imgClose);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "17dp",
                "width": "90%",
                "zIndex": 2,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxBackNavigationMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "30dp",
                "id": "flxBackNavigationMobile",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackNavigationMobile.setDefaultUnit(kony.flex.DP);
            var flxImgBackNav = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    },
                    "a11yLabel": "Back navigation link: Back to Accounts Overview"
                },
                "clipBounds": true,
                "focusSkin": "flxHoverSkinPointer",
                "height": "100%",
                "id": "flxImgBackNav",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "360dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxImgBackNav.setDefaultUnit(kony.flex.DP);
            var imgBackMobile = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgBackMobile",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknImgPointer5vs",
                "src": "arrow_right_blue.png",
                "width": "17dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            var lblBackMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblBackMobile",
                "isVisible": true,
                "left": "14dp",
                "skin": "sknSSP4176a415px",
                "text": "Back to Mortgage Facility",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgBackNav.add(imgBackMobile, lblBackMobile);
            flxBackNavigationMobile.add(flxImgBackNav);
            var flxBackNavigation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "30dp",
                "id": "flxBackNavigation",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackNavigation.setDefaultUnit(kony.flex.DP);
            var flxImgBackNavigation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    },
                    "a11yLabel": "Back navigation link: Back to Accounts Overview"
                },
                "clipBounds": true,
                "focusSkin": "flxHoverSkinPointer",
                "height": "100%",
                "id": "flxImgBackNavigation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "360dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxImgBackNavigation.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgBack",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknImgPointer5vs",
                "src": "arrow_right_blue.png",
                "width": "17dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            var lblBack = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblBack",
                "isVisible": true,
                "left": "14dp",
                "skin": "sknSSP4176a415px",
                "text": "Back to Mortgage Facility",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgBackNavigation.add(imgBack, lblBack);
            var btnByPass = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "height": "30dp",
                "id": "btnByPass",
                "isVisible": true,
                "left": "320dp",
                "skin": "btnSkipNavigation",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Skiptotransactions\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackNavigation.add(flxImgBackNavigation, btnByPass);
            var flxActionsMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxActionsMobile",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "72.5%",
                "skin": "slFbox",
                "top": "118dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActionsMobile.setDefaultUnit(kony.flex.DP);
            flxActionsMobile.add();
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "475dp",
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "786dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var lblInlineMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblInlineMessage",
                "isVisible": false,
                "left": "20dp",
                "skin": "sknLabelSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.PayOffServerError\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flx1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flx1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx1.setDefaultUnit(kony.flex.DP);
            var lblFacility = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblFacility",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.Facility\")",
                "top": "0dp",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblFacilityValue",
                "isVisible": true,
                "left": "24dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Mortgage Facility 1 - 4556",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx1.add(lblFacility, lblFacilityValue);
            var flx2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flx2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx2.setDefaultUnit(kony.flex.DP);
            var lblLoanAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblLoanAccount",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.LoanAccount\")",
                "top": "0dp",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoanAccountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblLoanAccountValue",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Primary Loan Account - 8760",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx2.add(lblLoanAccount, lblLoanAccountValue);
            var flx3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flx3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx3.setDefaultUnit(kony.flex.DP);
            var lblCurrOutstandingBal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblCurrOutstandingBal",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.CurrentOutstandingbalance\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrOutstandingBalValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblCurrOutstandingBalValue",
                "isVisible": true,
                "left": "38dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "150,054.00",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx3.add(lblCurrOutstandingBal, lblCurrOutstandingBalValue);
            var flx4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flx4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx4.setDefaultUnit(kony.flex.DP);
            var lblCurrMaturityDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblCurrMaturityDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.CurrentMaturityDateWithColon\")",
                "top": "0dp",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrMaturityDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblCurrMaturityDateValue",
                "isVisible": true,
                "left": "24dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "12/02/2023",
                "top": "0dp",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx4.add(lblCurrMaturityDate, lblCurrMaturityDateValue);
            var flxSimulationInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSimulationInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulationInfo.setDefaultUnit(kony.flex.DP);
            var lblPayOffSimDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblPayOffSimDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.PayoffsimulationDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "25dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImage.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "45%",
                "height": "15dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "5dp",
                "src": "info_lined.png",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImage.add(imgInfo);
            var flxInformationText = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "120dp",
                "id": "flxInformationText",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "22dp",
                "width": "300dp",
                "zIndex": 51,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformationText.setDefaultUnit(kony.flex.DP);
            var flxInformation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "46dp",
                "id": "flxInformation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 101,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformation.setDefaultUnit(kony.flex.DP);
            var lblInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblInfo",
                "isVisible": true,
                "left": "7.44%",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Payoff simulation date",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 101
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCross = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this popup"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "btnCross",
                "isVisible": true,
                "right": "20dp",
                "skin": "btnOLBFontIcon15px",
                "text": "g",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 101
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInformation.add(lblInfo, btnCross);
            var flxSeparator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "0dp",
                "width": "100%",
                "zIndex": 101,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            var flxAccountType = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "80dp",
                "id": "flxAccountType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0px",
                "width": "100%",
                "zIndex": 101,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountType.setDefaultUnit(kony.flex.DP);
            var RichTextInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20dp",
                "id": "RichTextInfo",
                "isVisible": false,
                "left": "20dp",
                "right": "20dp",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.PayoffsimulationDateInfo\")",
                "top": "5dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTextInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "20dp",
                "id": "lblTextInfo",
                "isVisible": true,
                "left": "22dp",
                "right": "20dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.PayoffsimulationDateInfo\")",
                "top": "6dp",
                "width": "260dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountType.add(RichTextInfo, lblTextInfo);
            flxInformationText.add(flxInformation, flxSeparator1, flxAccountType);
            flxSimulationInfo.add(lblPayOffSimDate, flxImage, flxInformationText);
            var flx5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flx5",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "460dp",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx5.setDefaultUnit(kony.flex.DP);
            var flxByDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "40dp",
                "id": "flxByDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 50,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxByDate.setDefaultUnit(kony.flex.DP);
            var calDateFrom = new kony.ui.Calendar({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "K1709533028932",
                        "aria-required": false,
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "calendarIcon": "calender_1.png",
                "dateComponents": [null, null, null],
                "dateFormat": "dd/MM/yyyy",
                "focusSkin": "sknCalTransactionsFocus",
                "hour": 0,
                "id": "calDateFrom",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "onTouchStart": controller.AS_Calendar_f6684423b8d341208d8cb1b21da424ee,
                "placeholder": "dd/MM/yyyy",
                "seconds": 0,
                "skin": "sknCalTransactions",
                "top": "0dp",
                "viewConfig": {
                    "gridConfig": {
                        "allowWeekendSelectable": true,
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 50
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxByDate.add(calDateFrom);
            flx5.add(flxByDate);
            var flxSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "145dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "80dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Continue to confirmation"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "left": "0",
                "right": "20dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.tab.common.Continue\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel simulate early payoff process"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxButtons.add(btnContinue, btnCancel);
            flxContainer.add(lblInlineMessage, flx1, flx2, flx3, flx4, flxSimulationInfo, flx5, flxSeparator, flxButtons);
            var flxInstructionPoint = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "184dp",
                "id": "flxInstructionPoint",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "24dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "390dp",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInstructionPoint.setDefaultUnit(kony.flex.DP);
            var flxInstructions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "20dp",
                "id": "flxInstructions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "97.46%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInstructions.setDefaultUnit(kony.flex.DP);
            var imgInstructions = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "24dp",
                "id": "imgInstructions",
                "isVisible": true,
                "left": "0dp",
                "src": "idea_icon.png",
                "top": "0dp",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInstructionHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "height": "24dp",
                "id": "lblInstructionHeader",
                "isVisible": true,
                "left": "6dp",
                "skin": "sknSSPSemiBold42424220px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.Instructions\")",
                "top": "0dp",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInstructions.add(imgInstructions, lblInstructionHeader);
            var flxPoints = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20dp",
                "clipBounds": false,
                "height": "100dp",
                "id": "flxPoints",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "28dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "20dp",
                "width": "350dp",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPoints.setDefaultUnit(kony.flex.DP);
            var flxPoint1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "50dp",
                "clipBounds": false,
                "id": "flxPoint1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPoint1.setDefaultUnit(kony.flex.DP);
            var imgPoint1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "15dp",
                "id": "imgPoint1",
                "isVisible": true,
                "left": "0dp",
                "src": "ellipse_dot.png",
                "top": "0dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPoint1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPoint1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPoint1.add(imgPoint1, lblPoint1);
            var flxPoint2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxPoint2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "350dp",
                "zIndex": 203,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPoint2.setDefaultUnit(kony.flex.DP);
            var imgPoint2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "15dp",
                "id": "imgPoint2",
                "isVisible": true,
                "left": "0dp",
                "src": "ellipse_dot.png",
                "top": "0",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPoint2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "0dp",
                "id": "lblPoint2",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.PayoffInstructions2\")",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPoint2.add(imgPoint2, lblPoint2);
            flxPoints.add(flxPoint1, flxPoint2);
            flxInstructionPoint.add(flxInstructions, flxPoints);
            flxMain.add(flxBackNavigationMobile, flxBackNavigation, flxActionsMobile, flxContainer, flxInstructionPoint);
            flxMainWrapper.add(flxHeading, flxError, flxMain);
            var flxFooter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "height": "150dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "maxWidth": "1200dp",
                        "top": "75dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMainWrapper, flxFooter);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopupNew = new com.InfinityOLB.ArrangementsMA.CustomPopupNew({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopupNew",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ArrangementsMA",
                "viewType": "CustomPopupNew",
                "overrides": {
                    "CustomPopupNew": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var CustomPopupNew_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmEarlyPayOff"] && appConfig.componentMetadata["ArrangementsMA"]["frmEarlyPayOff"]["CustomPopupNew"]) || {};
            CustomPopupNew.lblMsg = CustomPopupNew_data.lblMsg || "Account Closure";
            flxPopup.add(CustomPopupNew);
            var flxDownloadTransaction = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxDownloadTransaction",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadTransaction.setDefaultUnit(kony.flex.DP);
            var downloadTransction = new com.InfinityOLB.ArrangementsMA.downloadTransction({
                "height": "100%",
                "id": "downloadTransction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0c69b7ae145714d",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "btnCancel": {
                        "centerX": "viz.val_cleared",
                        "left": "0",
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "btnClose": {
                        "bottom": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "top": "20dp"
                    },
                    "btnDownload": {
                        "centerX": "viz.val_cleared",
                        "height": "50dp",
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "downloadTransction": {
                        "width": "100%"
                    },
                    "flxButtons": {
                        "bottom": "viz.val_cleared",
                        "height": "80dp",
                        "responsiveConfig": {
                            "offset": {
                                "640": 0,
                                "1024": 0,
                                "1366": 0,
                                "1380": 0
                            },
                            "span": {
                                "640": 12,
                                "1024": 12,
                                "1366": 12,
                                "1380": 12
                            }
                        },
                        "reverseLayoutDirection": true,
                        "top": "0dp",
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "flxDisclaimer": {
                        "centerX": "viz.val_cleared",
                        "height": "100%",
                        "left": "20dp",
                        "top": "20dp",
                        "width": "460dp"
                    },
                    "flxDisclaimerInfo": {
                        "bottom": "viz.val_cleared",
                        "height": "80px"
                    },
                    "flxFromDate": {
                        "isVisible": false
                    },
                    "flxHeader": {
                        "height": "50px"
                    },
                    "flxInfoIcon": {
                        "height": "14dp",
                        "left": "10dp",
                        "top": "10dp",
                        "width": "14dp"
                    },
                    "flxMiddle": {
                        "height": "92dp",
                        "responsiveConfig": {
                            "offset": {
                                "640": 0,
                                "1024": 0,
                                "1366": 0,
                                "1380": 0
                            },
                            "span": {
                                "640": 12,
                                "1024": 12,
                                "1366": 12,
                                "1380": 12
                            }
                        },
                        "top": "20dp"
                    },
                    "flxPopup": {
                        "centerX": "47.58%",
                        "height": "310dp",
                        "top": "310px",
                        "width": "500dp"
                    },
                    "flxSelectFormat": {
                        "isVisible": false
                    },
                    "flxSeperator2": {
                        "top": "97%"
                    },
                    "flxToDate": {
                        "isVisible": false
                    },
                    "imgArrow": {
                        "centerY": 64,
                        "left": "viz.val_cleared",
                        "right": "11dp",
                        "top": "20dp",
                        "width": "15px"
                    },
                    "infoIcon": {
                        "height": "100%",
                        "left": 0,
                        "src": "exclaim_info.png",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "lblDisclaimer": {
                        "bottom": "8dp",
                        "height": "90%",
                        "isVisible": true,
                        "left": "32dp",
                        "top": "10dp",
                        "width": "412dp"
                    },
                    "lblHeader": {
                        "height": "20px",
                        "left": "20dp",
                        "text": "DOWNLOAD TRANSACTIONS",
                        "top": "20dp"
                    },
                    "lblPickDateRange": {
                        "isVisible": false
                    },
                    "lblSelectFormat": {
                        "left": "20dp",
                        "top": "25px"
                    },
                    "lblSelectImg": {
                        "isVisible": false,
                        "text": "O"
                    },
                    "lblTo": {
                        "isVisible": false
                    },
                    "lbxSelectFormat": {
                        "left": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "20dp",
                        "top": "20px",
                        "width": "230dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDownloadTransaction.add(downloadTransction);
            var flxClearSearchError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "150%",
                "id": "flxClearSearchError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClearSearchError.setDefaultUnit(kony.flex.DP);
            var flxClearSearchErrorPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "centerX": "47.58%",
                "clipBounds": true,
                "height": "269dp",
                "id": "flxClearSearchErrorPopup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": true,
                "skin": "Copysknflxffffff",
                "top": "330px",
                "width": "500dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClearSearchErrorPopup.setDefaultUnit(kony.flex.DP);
            var flxSEHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxSEHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSEHeader.setDefaultUnit(kony.flex.DP);
            var lblSEHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "20px",
                "id": "lblSEHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.settings.accessibility.error\")",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnSEClose = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "btnSEClose",
                "isVisible": false,
                "right": "20dp",
                "skin": "btnOLBFontIcon15px",
                "text": "g",
                "width": "20px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSEHeader.add(lblSEHeader, btnSEClose);
            var flxSESeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSESeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSESeparator.setDefaultUnit(kony.flex.DP);
            flxSESeparator.add();
            var lblSEDisclaimer = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSEDisclaimer",
                "isVisible": true,
                "left": "23dp",
                "right": "20dp",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.deleteSearchErrorMsg\")",
                "top": "19dp",
                "width": "457dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSESeparator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSESeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "80dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSESeparator1.setDefaultUnit(kony.flex.DP);
            flxSESeparator1.add();
            var flxSEButton = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "80dp",
                "id": "flxSEButton",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSEButton.setDefaultUnit(kony.flex.DP);
            var btnSEOk = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnSEOk",
                "isVisible": true,
                "left": "0",
                "right": "20dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.ok\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnSECancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnSECancel",
                "isVisible": false,
                "right": "20dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxSEButton.add(btnSEOk, btnSECancel);
            flxClearSearchErrorPopup.add(flxSEHeader, flxSESeparator, lblSEDisclaimer, flxSESeparator1, flxSEButton);
            flxClearSearchError.add(flxClearSearchErrorPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Loading"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "segmentProps": []
                    },
                    "flxHeading": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "byPass": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "imgError": {
                        "segmentProps": []
                    },
                    "lblErrMessage": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "imgClose": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigationMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNav": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "s018b592f2be4ccf98f6e95b092c9c4c",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgBackMobile": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "lblBackMobile": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigation": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNavigation": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "s018b592f2be4ccf98f6e95b092c9c4c",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgBack": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "lblBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": []
                    },
                    "flxActionsMobile": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblInlineMessage": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flx1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblFacility": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblFacilityValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flx2": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblLoanAccount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblLoanAccountValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flx3": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBal": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBalValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flx4": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrMaturityDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrMaturityDateValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSimulationInfo": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayOffSimDate": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "segmentProps": []
                    },
                    "flxInformationText": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "-30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "230px"
                        },
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "RichTextInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblTextInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flx5": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxByDate": {
                        "width": {
                            "type": "string",
                            "value": "290dp"
                        },
                        "segmentProps": []
                    },
                    "calDateFrom": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "36.44%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-90%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxInstructionPoint": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "205dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100.25%"
                        },
                        "segmentProps": []
                    },
                    "flxInstructions": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "imgInstructions": {
                        "segmentProps": []
                    },
                    "lblInstructionHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxPoints": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxPoint1": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "imgPoint1": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblPoint1": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxPoint2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "imgPoint2": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "lblPoint2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15%"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupNew": {
                        "segmentProps": []
                    },
                    "flxDownloadTransaction": {
                        "height": {
                            "type": "string",
                            "value": "250%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnCancel": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnDownload": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "82%"
                        },
                        "width": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimerInfo": {
                        "height": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.infoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lbxSelectFormat": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearchError": {
                        "height": {
                            "type": "string",
                            "value": "150%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearchErrorPopup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "390dp"
                        },
                        "segmentProps": []
                    },
                    "btnSEClose": {
                        "segmentProps": []
                    },
                    "lblSEDisclaimer": {
                        "skin": "sknLblSSP42424213px",
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxSEButton": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnSEOk": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnSECancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "byPass": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "728dp"
                        },
                        "segmentProps": []
                    },
                    "imgError": {
                        "segmentProps": []
                    },
                    "lblErrMessage": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "i18n_text": "i18n.Accounts.PayOffServerError",
                        "width": {
                            "type": "string",
                            "value": "613dp"
                        },
                        "segmentProps": []
                    },
                    "imgClose": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigationMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNav": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackMobile": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigation": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNavigation": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxActionsMobile": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblInlineMessage": {
                        "i18n_text": "i18n.Accounts.PayOffServerError",
                        "width": {
                            "type": "string",
                            "value": "613dp"
                        },
                        "segmentProps": []
                    },
                    "flx1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblFacility": {
                        "segmentProps": []
                    },
                    "lblFacilityValue": {
                        "segmentProps": []
                    },
                    "flx2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblLoanAccount": {
                        "segmentProps": []
                    },
                    "lblLoanAccountValue": {
                        "segmentProps": []
                    },
                    "flx3": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBal": {
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBalValue": {
                        "segmentProps": []
                    },
                    "flx4": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCurrMaturityDate": {
                        "segmentProps": []
                    },
                    "lblCurrMaturityDateValue": {
                        "segmentProps": []
                    },
                    "flxSimulationInfo": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblPayOffSimDate": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "segmentProps": []
                    },
                    "flxInformationText": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblTextInfo": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flx5": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxByDate": {
                        "segmentProps": []
                    },
                    "calDateFrom": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "segmentProps": []
                    },
                    "flxInstructionPoint": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxInstructions": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgInstructions": {
                        "segmentProps": []
                    },
                    "lblInstructionHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxPoints": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPoint1": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgPoint1": {
                        "segmentProps": []
                    },
                    "lblPoint1": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxPoint2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgPoint2": {
                        "top": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblPoint2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupNew": {
                        "height": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnClose": {
                        "text": "",
                        "segmentProps": []
                    },
                    "downloadTransction.btnDownload": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "78%"
                        },
                        "width": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimerInfo": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "97px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.infoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearchError": {
                        "segmentProps": []
                    },
                    "flxClearSearchErrorPopup": {
                        "segmentProps": []
                    },
                    "lblSEDisclaimer": {
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxSEButton": {
                        "segmentProps": []
                    },
                    "btnSEOk": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "byPass": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "imgError": {
                        "segmentProps": []
                    },
                    "imgClose": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "flxBackNavigationMobile": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "58%"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNav": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblBackMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigation": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "58%"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNavigation": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblBack": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxActionsMobile": {
                        "top": {
                            "type": "string",
                            "value": "106dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "segmentProps": []
                    },
                    "flx1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblFacility": {
                        "segmentProps": []
                    },
                    "lblFacilityValue": {
                        "segmentProps": []
                    },
                    "flx2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblLoanAccount": {
                        "segmentProps": []
                    },
                    "lblLoanAccountValue": {
                        "segmentProps": []
                    },
                    "flx3": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBal": {
                        "segmentProps": []
                    },
                    "lblCurrOutstandingBalValue": {
                        "segmentProps": []
                    },
                    "flx4": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCurrMaturityDate": {
                        "segmentProps": []
                    },
                    "lblCurrMaturityDateValue": {
                        "segmentProps": []
                    },
                    "flxSimulationInfo": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblPayOffSimDate": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "segmentProps": []
                    },
                    "flxInformationText": {
                        "height": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "-40dp"
                        },
                        "segmentProps": []
                    },
                    "flxInformation": {
                        "segmentProps": []
                    },
                    "flxSeparator1": {
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "segmentProps": []
                    },
                    "lblTextInfo": {
                        "segmentProps": []
                    },
                    "flx5": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxByDate": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "top": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "segmentProps": []
                    },
                    "flxInstructionPoint": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxInstructions": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgInstructions": {
                        "segmentProps": []
                    },
                    "lblInstructionHeader": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPoints": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPoint1": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgPoint1": {
                        "segmentProps": []
                    },
                    "lblPoint1": {
                        "segmentProps": []
                    },
                    "flxPoint2": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "imgPoint2": {
                        "segmentProps": []
                    },
                    "lblPoint2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "78%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimerInfo": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "325dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.infoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearchError": {
                        "segmentProps": []
                    },
                    "flxClearSearchErrorPopup": {
                        "segmentProps": []
                    },
                    "lblSEDisclaimer": {
                        "i18n_text": "i18n.ViewStatements.DisclaimerInfo",
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxSEButton": {
                        "segmentProps": []
                    },
                    "btnSEOk": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxMainWrapper": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "byPass": {
                        "i18n_text": "i18n.Accounts.SkiptoInstructions",
                        "left": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "flxActionsMobile": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "118dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "segmentProps": []
                    },
                    "flx1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx2": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx3": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flx4": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxSimulationInfo": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxInformationText": {
                        "height": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "-40dp"
                        },
                        "segmentProps": []
                    },
                    "flxInformation": {
                        "segmentProps": []
                    },
                    "flxSeparator1": {
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "segmentProps": []
                    },
                    "lblTextInfo": {
                        "segmentProps": []
                    },
                    "flx5": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxByDate": {
                        "segmentProps": []
                    },
                    "calDateFrom": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "segmentProps": []
                    },
                    "flxInstructionPoint": {
                        "height": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxInstructions": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPoints": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPoint1": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPoint2": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblPoint2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimerInfo": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "325dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "height": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearchError": {
                        "segmentProps": []
                    },
                    "flxClearSearchErrorPopup": {
                        "segmentProps": []
                    },
                    "btnSEClose": {
                        "segmentProps": []
                    },
                    "lblSEDisclaimer": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxSEButton": {
                        "segmentProps": []
                    },
                    "btnSEOk": {
                        "segmentProps": []
                    },
                    "btnSECancel": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customfooter": {
                    "centerX": "50%",
                    "height": "150dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "maxWidth": "1200dp",
                    "top": "75dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopupNew": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": ""
                },
                "downloadTransction.btnCancel": {
                    "centerX": "",
                    "left": "0",
                    "right": "20dp",
                    "width": "150dp"
                },
                "downloadTransction.btnClose": {
                    "bottom": "",
                    "left": "",
                    "right": "20dp",
                    "top": "20dp"
                },
                "downloadTransction.btnDownload": {
                    "centerX": "",
                    "height": "50dp",
                    "left": "",
                    "right": "20dp",
                    "width": "150dp"
                },
                "downloadTransction": {
                    "width": "100%"
                },
                "downloadTransction.flxButtons": {
                    "bottom": "",
                    "height": "80dp",
                    "reverseLayoutDirection": true,
                    "top": "0dp",
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "downloadTransction.flxDisclaimer": {
                    "centerX": "",
                    "height": "100%",
                    "left": "20dp",
                    "top": "20dp",
                    "width": "460dp"
                },
                "downloadTransction.flxDisclaimerInfo": {
                    "bottom": "",
                    "height": "80px"
                },
                "downloadTransction.flxHeader": {
                    "height": "50px"
                },
                "downloadTransction.flxInfoIcon": {
                    "height": "14dp",
                    "left": "10dp",
                    "top": "10dp",
                    "width": "14dp"
                },
                "downloadTransction.flxMiddle": {
                    "height": "92dp",
                    "top": "20dp"
                },
                "downloadTransction.flxPopup": {
                    "centerX": "47.58%",
                    "height": "310dp",
                    "top": "310px",
                    "width": "500dp"
                },
                "downloadTransction.flxSeperator2": {
                    "top": "97%"
                },
                "downloadTransction.imgArrow": {
                    "centerY": 64,
                    "left": "",
                    "right": "11dp",
                    "top": "20dp",
                    "width": "15px"
                },
                "downloadTransction.infoIcon": {
                    "height": "100%",
                    "left": 0,
                    "src": "exclaim_info.png",
                    "top": "0dp",
                    "width": "100%"
                },
                "downloadTransction.lblDisclaimer": {
                    "bottom": "8dp",
                    "height": "90%",
                    "left": "32dp",
                    "top": "10dp",
                    "width": "412dp"
                },
                "downloadTransction.lblHeader": {
                    "height": "20px",
                    "left": "20dp",
                    "text": "DOWNLOAD TRANSACTIONS",
                    "top": "20dp"
                },
                "downloadTransction.lblSelectFormat": {
                    "left": "20dp",
                    "top": "25px"
                },
                "downloadTransction.lblSelectImg": {
                    "text": "O"
                },
                "downloadTransction.lbxSelectFormat": {
                    "left": "",
                    "minWidth": "",
                    "right": "20dp",
                    "top": "20px",
                    "width": "230dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxLogout, flxPopup, flxDownloadTransaction, flxClearSearchError, flxLoading);
        };
        return [{
            "addWidgets": addWidgetsfrmEarlyPayOff,
            "enabledForIdleTimeout": true,
            "id": "frmEarlyPayOff",
            "init": controller.AS_Form_c99ee7ccf73e42468c1b55f8753f658e,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_f8e1000819b145d7ab259f61a1778f91,
            "preShow": function(eventobject) {
                controller.AS_Form_ff5ffc9a0c464ad7a49beb5ebf20c73b(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Simulate Early Payoff",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_cfacbcf807f04f0592e09cadf6df1c7e,
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": true
        }]
    }
});