define("ManageProfileMA/SettingsNewUIModule/frmAddressSettings", function() {
    return function(controller) {
        function addWidgetsfrmAddressSettings() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.profilesettings\")"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblHeading",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "text": "Settings",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxProfileError = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxProfileError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileError.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgError",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxError = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.Transfers.WecouldntfindanexactmatchPleaseenteryourpayeeinformationasitappearsonyourbill\")"
                },
                "centerY": "50%",
                "id": "rtxError",
                "isVisible": true,
                "left": "76dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.WecouldntfindanexactmatchPleaseenteryourpayeeinformationasitappearsonyourbill\")",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileError.add(imgError, rtxError);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "27dp",
                "width": "87.80%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.updateSettingAndPreferences\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Settings"
            });
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Dropdown"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "262dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxProfileMenu": {
                        "isVisible": true
                    },
                    "flxSeperator": {
                        "bottom": 0,
                        "height": "700dp"
                    },
                    "profileMenu": {
                        "centerX": "viz.val_cleared",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxAddressWrapper = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "710dp",
                "id": "flxAddressWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "700dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddressWrapper.setDefaultUnit(kony.flex.DP);
            var addressInfo = new com.InfinityOLB.PortfolioManagementMA.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "addressInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100,
                "appName": "PortfolioManagementMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": true,
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%",
                        "zIndex": 100
                    },
                    "RichTextInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profileManagement.profileImageInfo\")",
                        "isVisible": true
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAddNewAddressWrapper = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAddNewAddressWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddNewAddressWrapper.setDefaultUnit(kony.flex.DP);
            var flxAddNewAddressHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxAddNewAddressHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddNewAddressHeader.setDefaultUnit(kony.flex.DP);
            var flxAddNewAddressSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAddNewAddressSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddNewAddressSeperator.setDefaultUnit(kony.flex.DP);
            flxAddNewAddressSeperator.add();
            var lblAddNewAddressHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")"
                },
                "centerY": "50%",
                "id": "lblAddNewAddressHeader",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddNewAddressHeader.add(flxAddNewAddressSeperator, lblAddNewAddressHeader);
            var flxAddNewAddressContainer = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "655dp",
                "horizontalScrollIndicator": true,
                "id": "flxAddNewAddressContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "10dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddNewAddressContainer.setDefaultUnit(kony.flex.DP);
            var flxAddNewAddress = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "555dp",
                "id": "flxAddNewAddress",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "98%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddNewAddress.setDefaultUnit(kony.flex.DP);
            var flxErrorAddAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52dp",
                "id": "flxErrorAddAddress",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknrounded",
                "top": "10dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorAddAddress.setDefaultUnit(kony.flex.DP);
            var imgErrorAddAddress = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgErrorAddAddress",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrortxt = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Pageleveltransaction\")"
                },
                "centerY": "50%",
                "id": "lblErrortxt",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknlblff000015px",
                "text": "Page level/transaction level errors appear here.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorAddAddress.add(imgErrorAddAddress, lblErrortxt);
            var lbxType = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxType",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["Key798", "Home"],
                    ["Key2778084114", "Office"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "20dp",
                "width": "30.16%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var tbxAddressLine1 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxAddressLine1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.AddressLine01\")",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "65.02%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var tbxAddressLine2 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine2\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxAddressLine2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.AddressLine02\")",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "65.02%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lbxCountry = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxCountry",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["Key798", "USA"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "20dp",
                "width": "30.16%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lbxState = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxState",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["Key798", "California"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "20dp",
                "width": "30.16%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var tbxCityName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine2\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxCityName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.City\")",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "65.02%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var tbxZipcode = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Zipcode"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxZipcode",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.common.zipcode\")",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "30.16%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxSetAsPreferred = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "flxSetAsPreferred",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "75%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSetAsPreferred.setDefaultUnit(kony.flex.DP);
            var flxSetAsPreferredCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxSetAsPreferredCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSetAsPreferredCheckBox.setDefaultUnit(kony.flex.DP);
            var imgSetAsPreferredCheckBox = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.settings.accessibility.checkbox\")"
                },
                "height": "20dp",
                "id": "imgSetAsPreferredCheckBox",
                "isVisible": false,
                "left": "0%",
                "skin": "slImage",
                "src": "checked_box.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "checkbox"
            });
            var lblSetAsPreferredCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.settings.accessibility.checkbox\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblSetAsPreferredCheckBox",
                "isVisible": true,
                "skin": "sknlblDelete20px",
                "text": "C",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSetAsPreferredCheckBox.add(imgSetAsPreferredCheckBox, lblSetAsPreferredCheckBox);
            var lblSetAsPreferred = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.SetAsPreferredCommunicationAddress\")"
                },
                "centerY": "50%",
                "id": "lblSetAsPreferred",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.SetAsPreferredCommunicationAddress\")",
                "top": 5,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSetAsPreferred.add(flxSetAsPreferredCheckBox, lblSetAsPreferred);
            var flxInfoAddAddress = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "52dp",
                "id": "flxInfoAddAddress",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknrounded",
                "top": "20dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoAddAddress.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.NAO.Info\")"
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgInfo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "info.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfoTxt = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddAnotherPrimaryAddress\")"
                },
                "centerY": "50%",
                "id": "lblInfoTxt",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknLblSSP33333315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddAnotherPrimaryAddress\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoAddAddress.add(imgInfo, lblInfoTxt);
            flxAddNewAddress.add(flxErrorAddAddress, lbxType, tbxAddressLine1, tbxAddressLine2, lbxCountry, lbxState, tbxCityName, tbxZipcode, flxSetAsPreferred, flxInfoAddAddress);
            var flxAddNewAddressButtons = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxAddNewAddressButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddNewAddressButtons.setDefaultUnit(kony.flex.DP);
            var flxSeperator7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator7.setDefaultUnit(kony.flex.DP);
            flxSeperator7.add();
            var btnAddNewAddressAdd = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.ADD\")"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnAddNewAddressAdd",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.ADD\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtn3343a8Border3343a82pxRadius2pxhover",
                "toolTip": "Add"
            });
            var btnAddNewAddressCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Cancel\")"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnAddNewAddressCancel",
                "isVisible": true,
                "right": "170dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxAddNewAddressButtons.add(flxSeperator7, btnAddNewAddressAdd, btnAddNewAddressCancel);
            flxAddNewAddressContainer.add(flxAddNewAddress, flxAddNewAddressButtons);
            flxAddNewAddressWrapper.add(flxAddNewAddressHeader, flxAddNewAddressContainer);
            var flxEditAddressWrapper = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "710dp",
                "id": "flxEditAddressWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditAddressWrapper.setDefaultUnit(kony.flex.DP);
            var flxEditAddressHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50px",
                "id": "flxEditAddressHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "98%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditAddressHeader.setDefaultUnit(kony.flex.DP);
            var flxEditAddressSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEditAddressSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditAddressSeperator.setDefaultUnit(kony.flex.DP);
            flxEditAddressSeperator.add();
            var lblEditAddressHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.editAddress\")"
                },
                "centerY": "50%",
                "id": "lblEditAddressHeader",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.editAddress\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEditAddressHeader.add(flxEditAddressSeperator, lblEditAddressHeader);
            var flxEmailAddressContainer = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "650dp",
                "horizontalScrollIndicator": true,
                "id": "flxEmailAddressContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "10dp",
                "verticalScrollIndicator": true,
                "width": "99%"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailAddressContainer.setDefaultUnit(kony.flex.DP);
            var flxEditAddress = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "550px",
                "id": "flxEditAddress",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditAddress.setDefaultUnit(kony.flex.DP);
            var flxErrorEditAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52dp",
                "id": "flxErrorEditAddress",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknrounded",
                "top": "10dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorEditAddress.setDefaultUnit(kony.flex.DP);
            var imgErrorEditAddres = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgErrorEditAddres",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorEditAddress = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Pageleveltransaction\")"
                },
                "centerY": "50%",
                "id": "lblErrorEditAddress",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknlblff000015px",
                "text": "Page level/transaction level errors appear here.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorEditAddress.add(imgErrorEditAddres, lblErrorEditAddress);
            var lbxEditType = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxEditType",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["Key798", "Home"],
                    ["Key2138219505", "Office"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "20dp",
                "width": "30.16%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var tbxEditAddressLine1 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEditAddressLine1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "Address line 1",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "text": "201, Cowper Street",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "65.02%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var tbxEditAddressLine2 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine2\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEditAddressLine2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "Address line 2",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "text": "Palo Alto, Santa Clara",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "65.02%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var tbxEditCountry = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine2\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEditCountry",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Country\")",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "65.02%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var tbxEditState = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine2\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEditState",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.common.state\")",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "65.02%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lbxEditCountry = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxEditCountry",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["Key798", "US"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "20dp",
                "width": "30.16%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var lbxEditState = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxEditState",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["Key798", "California"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "20dp",
                "width": "30.16%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var tbxEdtCity = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine2\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEdtCity",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.common.city\")",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "65.02%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var tbxEditCity = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "tbxEditCity",
                "isVisible": false,
                "left": "0%",
                "masterData": [
                    ["Key798", "Los Angeles"]
                ],
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "20dp",
                "width": "30.16%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var tbxEditZipcode = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Zipcode"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEditZipcode",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "Zipcode",
                "secureTextEntry": false,
                "skin": "skntxtSSP424242Bordere3e3e3Op100Radius2px",
                "text": "94301",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20dp",
                "width": "30.16%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxEditSetAsPreferred = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30px",
                "id": "flxEditSetAsPreferred",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "75%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditSetAsPreferred.setDefaultUnit(kony.flex.DP);
            var flxEditSetAsPreferredCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxEditSetAsPreferredCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditSetAsPreferredCheckBox.setDefaultUnit(kony.flex.DP);
            var imgEditSetAsPreferredCheckBox = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.settings.accessibility.checkbox\")"
                },
                "height": "20dp",
                "id": "imgEditSetAsPreferredCheckBox",
                "isVisible": false,
                "left": "0%",
                "skin": "slImage",
                "src": "checked_box.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "checkbox"
            });
            var lblEditSetAsPreferredCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.settings.accessibility.checkbox\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblEditSetAsPreferredCheckBox",
                "isVisible": true,
                "skin": "sknlblDelete20px",
                "text": "C",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEditSetAsPreferredCheckBox.add(imgEditSetAsPreferredCheckBox, lblEditSetAsPreferredCheckBox);
            var lblEditSetAsPreferred = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.SetAsPreferredCommunicationAddress\")"
                },
                "centerY": "50%",
                "id": "lblEditSetAsPreferred",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.SetAsPreferredCommunicationAddress\")",
                "top": 5,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEditSetAsPreferred.add(flxEditSetAsPreferredCheckBox, lblEditSetAsPreferred);
            var flxInfoEditAddress = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "52dp",
                "id": "flxInfoEditAddress",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknrounded",
                "top": "20dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoEditAddress.setDefaultUnit(kony.flex.DP);
            var imgEditInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.NAO.Info\")"
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgEditInfo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "info.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEditInfoTxt = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddAnotherPrimaryAddress\")"
                },
                "centerY": "50%",
                "id": "lblEditInfoTxt",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknLblSSP33333315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddAnotherPrimaryAddress\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoEditAddress.add(imgEditInfo, lblEditInfoTxt);
            flxEditAddress.add(flxErrorEditAddress, lbxEditType, tbxEditAddressLine1, tbxEditAddressLine2, tbxEditCountry, tbxEditState, lbxEditCountry, lbxEditState, tbxEdtCity, tbxEditCity, tbxEditZipcode, flxEditSetAsPreferred, flxInfoEditAddress);
            var flxEditAddressButtons = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": true,
                "height": "80px",
                "id": "flxEditAddressButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditAddressButtons.setDefaultUnit(kony.flex.DP);
            var flxEditSeperator7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEditSeperator7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "98%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditSeperator7.setDefaultUnit(kony.flex.DP);
            flxEditSeperator7.add();
            var btnEditAddressCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Cancel\")"
                },
                "height": "40dp",
                "id": "btnEditAddressCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "top": "20dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            var btnEditAddressSave = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")"
                },
                "height": "40dp",
                "id": "btnEditAddressSave",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "top": "20dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtn3343a8Border3343a82pxRadius2pxhover",
                "toolTip": "Save"
            });
            flxEditAddressButtons.add(flxEditSeperator7, btnEditAddressCancel, btnEditAddressSave);
            flxEmailAddressContainer.add(flxEditAddress, flxEditAddressButtons);
            flxEditAddressWrapper.add(flxEditAddressHeader, flxEmailAddressContainer);
            var flxAddressesWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddressesWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddressesWrapper.setDefaultUnit(kony.flex.DP);
            var flxAddresses = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddresses",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddresses.setDefaultUnit(kony.flex.DP);
            var flxAddressHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50px",
                "id": "flxAddressHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddressHeader.setDefaultUnit(kony.flex.DP);
            var lblAddressHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblAddressHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Address\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddressSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAddressSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddressSeparator.setDefaultUnit(kony.flex.DP);
            flxAddressSeparator.add();
            var flxInfoIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-haspopup": true,
                        "role": "button"
                    },
                    "a11yLabel": "Know more information about Address"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxInfoIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "55dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_ec667afa80aa4658a81f8059023e3d11,
                "top": "19dp",
                "width": "20dp",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoIcon.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "15dp",
                "id": "imgInfoIcon",
                "isVisible": true,
                "left": "0dp",
                "src": "info_grey.png",
                "top": "0dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoIcon.add(imgInfoIcon);
            var btnAddNewAddress = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link"
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")"
                },
                "centerY": "50%",
                "height": "42dp",
                "id": "btnAddNewAddress",
                "isVisible": true,
                "right": "3dp",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP3343A813PxBg0hover"
            });
            flxAddressHeader.add(lblAddressHeading, flxAddressSeparator, flxInfoIcon, btnAddNewAddress);
            var flxAddressBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddressBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddressBody.setDefaultUnit(kony.flex.DP);
            var segprofilemanagementAddressnew = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "ul"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "btnDelete": "kony.i18n.getLocalizedString(\"kony.mb.common.Delete\")",
                            "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                            "imgInfoIcon": "info_grey.png",
                            "imgPendingIcon": "inprogress.png",
                            "imgelipses": "activewealth.png",
                            "lblAddessLine2": "Palo Alto, Santa clara county",
                            "lblAddressLine1": "201, Cowper street",
                            "lblAddressLine3": "California, US, 94301",
                            "lblHome": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Home\")",
                            "lblPendingRequest": "Your change address request is pending, it will take time to reflect.",
                            "lblPrimary": "Primary Communication",
                            "lblUsedFor": "Used For:"
                        },
                        [{
                            "btnDelete": "",
                            "btnEdit": "",
                            "imgInfoIcon": "",
                            "imgPendingIcon": "",
                            "imgelipses": "",
                            "lblAddessLine2": "",
                            "lblAddressLine1": "",
                            "lblAddressLine3": "",
                            "lblHome": "",
                            "lblPendingRequest": "",
                            "lblPrimary": "",
                            "lblUsedFor": ""
                        }]
                    ],
                    [{
                            "btnDelete": "kony.i18n.getLocalizedString(\"kony.mb.common.Delete\")",
                            "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                            "imgInfoIcon": "info_grey.png",
                            "imgPendingIcon": "inprogress.png",
                            "imgelipses": "activewealth.png",
                            "lblAddessLine2": "Palo Alto, Santa clara county",
                            "lblAddressLine1": "201, Cowper street",
                            "lblAddressLine3": "California, US, 94301",
                            "lblHome": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Home\")",
                            "lblPendingRequest": "Your change address request is pending, it will take time to reflect.",
                            "lblPrimary": "Primary Communication",
                            "lblUsedFor": "Used For:"
                        },
                        [{
                            "btnDelete": "",
                            "btnEdit": "",
                            "imgInfoIcon": "",
                            "imgPendingIcon": "",
                            "imgelipses": "",
                            "lblAddessLine2": "",
                            "lblAddressLine1": "",
                            "lblAddressLine3": "",
                            "lblHome": "",
                            "lblPendingRequest": "",
                            "lblPrimary": "",
                            "lblUsedFor": ""
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segprofilemanagementAddressnew",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ManageProfileMA",
                    "friendlyName": "flxProfileManagement"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ManageProfileMA",
                    "friendlyName": "flxProfileManagement"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "20dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnDelete": "btnDelete",
                    "btnEdit": "btnEdit",
                    "flxAddress": "flxAddress",
                    "flxAddressDetailContainer": "flxAddressDetailContainer",
                    "flxAddressWrapper": "flxAddressWrapper",
                    "flxAreaOfAddress": "flxAreaOfAddress",
                    "flxEdit": "flxEdit",
                    "flxImgElipses": "flxImgElipses",
                    "flxPendingRequest": "flxPendingRequest",
                    "flxPrimary": "flxPrimary",
                    "flxProfileManagement": "flxProfileManagement",
                    "flxUsedFor": "flxUsedFor",
                    "imgInfoIcon": "imgInfoIcon",
                    "imgPendingIcon": "imgPendingIcon",
                    "imgelipses": "imgelipses",
                    "lblAddessLine2": "lblAddessLine2",
                    "lblAddressLine1": "lblAddressLine1",
                    "lblAddressLine3": "lblAddressLine3",
                    "lblHome": "lblHome",
                    "lblPendingRequest": "lblPendingRequest",
                    "lblPrimary": "lblPrimary",
                    "lblUsedFor": "lblUsedFor"
                },
                "widgetSkin": "sknSegBgF9F9F9Round24PxTab",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "53dp",
                "id": "flxInfo",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "60dp",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0dp",
                "width": "270dp",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfo.setDefaultUnit(kony.flex.DP);
            var lblInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblInfo",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlblSSP42424213pxBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Info\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfoAddress = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblInfoAddress",
                "isVisible": true,
                "left": "20dp",
                "right": "64dp",
                "skin": "bbSknLbl424242SSP12Px",
                "text": "You can add upto 3 addresses",
                "top": "25dp",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yLabel": "Close this dialog"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "13dp",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxCloseIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "230dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_g670a3be248848e9bca96927db0add9e,
                "right": "11dp",
                "top": "11dp",
                "width": "20dp",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseIcon.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "presentation",
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "0dp",
                "height": "20dp",
                "id": "imgClose",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "src": "blue_close_icon.png",
                "top": "0dp",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseIcon.add(imgClose);
            flxInfo.add(lblInfo, lblInfoAddress, flxCloseIcon);
            flxAddressBody.add(segprofilemanagementAddressnew, flxInfo);
            var flxNoInfoWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxNoInfoWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoInfoWarning.setDefaultUnit(kony.flex.DP);
            var flxNoInfoWarningWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "id": "flxNoInfoWarningWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoInfoWarningWrapper.setDefaultUnit(kony.flex.DP);
            var lblNoInfoWarning = new kony.ui.Label({
                "id": "lblNoInfoWarning",
                "isVisible": true,
                "left": "112dp",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profile.noAddress\")",
                "top": "23dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoInfoWarningImage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.NAO.Info\")"
                },
                "id": "lblNoInfoWarningImage",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknlbl4a90e230OLBFontIconsPx",
                "text": "K",
                "top": "15px",
                "width": "32px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoInfoWarningWrapper.add(lblNoInfoWarning, lblNoInfoWarningImage);
            flxNoInfoWarning.add(flxNoInfoWarningWrapper);
            var btnAddNewAddressMobile = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Cancel\")"
                },
                "height": "40dp",
                "id": "btnAddNewAddressMobile",
                "isVisible": false,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")",
                "top": "20dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxAddresses.add(flxAddressHeader, flxAddressBody, flxNoInfoWarning, btnAddNewAddressMobile);
            var flxCombinedAddresses = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCombinedAddresses",
                "isVisible": false,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCombinedAddresses.setDefaultUnit(kony.flex.DP);
            var flxPersonalAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPersonalAddress",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalAddress.setDefaultUnit(kony.flex.DP);
            var flxPersonalAddressHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxPersonalAddressHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "99%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalAddressHeader.setDefaultUnit(kony.flex.DP);
            var flxPersonalAddressSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPersonalAddressSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalAddressSeparator.setDefaultUnit(kony.flex.DP);
            flxPersonalAddressSeparator.add();
            var lblPersonalAddressHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblPersonalAddressHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PersonalBankingAddress\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewPersonalAddress = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link"
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")"
                },
                "centerY": "50%",
                "id": "btnAddNewPersonalAddress",
                "isVisible": true,
                "right": "0%",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP3343A813PxBg0hover"
            });
            flxPersonalAddressHeader.add(flxPersonalAddressSeparator, lblPersonalAddressHeading, btnAddNewPersonalAddress);
            var flxPersonalAddressBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPersonalAddressBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "flxe3e3e3e30pxradius",
                "top": "0dp",
                "width": "99%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalAddressBody.setDefaultUnit(kony.flex.DP);
            var segPersonalAddresses = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }],
                "groupCells": false,
                "id": "segPersonalAddresses",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ManageProfileMA",
                    "friendlyName": "flxProfileManagementAddresses"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnDelete": "btnDelete",
                    "btnDeleteMobile": "btnDeleteMobile",
                    "btnEdit": "btnEdit",
                    "btnEditMobile": "btnEditMobile",
                    "flxActions": "flxActions",
                    "flxActionsMobile": "flxActionsMobile",
                    "flxAddress": "flxAddress",
                    "flxAddressDetails": "flxAddressDetails",
                    "flxAddressWrapper": "flxAddressWrapper",
                    "flxCommunicationAddress": "flxCommunicationAddress",
                    "flxInfo": "flxInfo",
                    "flxRow": "flxRow",
                    "imgCommunicationAddressInfo": "imgCommunicationAddressInfo",
                    "lblAddessLine2": "lblAddessLine2",
                    "lblAddressLine1": "lblAddressLine1",
                    "lblAddressLine3": "lblAddressLine3",
                    "lblAddressType": "lblAddressType",
                    "lblCommunicationAddress": "lblCommunicationAddress",
                    "lblSeperator": "lblSeperator",
                    "lblSeperatorActions": "lblSeperatorActions"
                },
                "widgetSkin": "Copyseg0j1ef31990dd644",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPersonalAddressBody.add(segPersonalAddresses);
            var btnAddNewPersonalAddressMobile = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Cancel\")"
                },
                "height": "40dp",
                "id": "btnAddNewPersonalAddressMobile",
                "isVisible": false,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")",
                "top": "20dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxPersonalAddress.add(flxPersonalAddressHeader, flxPersonalAddressBody, btnAddNewPersonalAddressMobile);
            var flxAddressTypeSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAddressTypeSeparator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddressTypeSeparator.setDefaultUnit(kony.flex.DP);
            flxAddressTypeSeparator.add();
            var flxBusinessAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBusinessAddress",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessAddress.setDefaultUnit(kony.flex.DP);
            var flxBusinessAddressHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxBusinessAddressHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessAddressHeader.setDefaultUnit(kony.flex.DP);
            var flxBusinessAddressSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBusinessAddressSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessAddressSeparator.setDefaultUnit(kony.flex.DP);
            flxBusinessAddressSeparator.add();
            var lblBusinessAddressHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblBusinessAddressHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.BusinessBankingAddress\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewBusinessAddress = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link"
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")"
                },
                "centerY": "50%",
                "id": "btnAddNewBusinessAddress",
                "isVisible": false,
                "right": "0%",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP3343A813PxBg0hover"
            });
            flxBusinessAddressHeader.add(flxBusinessAddressSeparator, lblBusinessAddressHeading, btnAddNewBusinessAddress);
            var flxBusinessAddressBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBusinessAddressBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxe3e3e3e30pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessAddressBody.setDefaultUnit(kony.flex.DP);
            var segBusinessAddresses = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }, {
                    "btnDelete": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnDeleteMobile": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                    "btnEdit": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "btnEditMobile": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                    "imgCommunicationAddressInfo": "info_grey.png",
                    "lblAddessLine2": "Palo Alto, Santa clara county",
                    "lblAddressLine1": "201, Cowper street",
                    "lblAddressLine3": "California, US, 94301",
                    "lblAddressType": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.HomeAddress\")",
                    "lblCommunicationAddress": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.CommunicationAddress\")",
                    "lblSeperator": "-",
                    "lblSeperatorActions": "-"
                }],
                "groupCells": false,
                "id": "segBusinessAddresses",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ManageProfileMA",
                    "friendlyName": "flxProfileManagementAddresses"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnDelete": "btnDelete",
                    "btnDeleteMobile": "btnDeleteMobile",
                    "btnEdit": "btnEdit",
                    "btnEditMobile": "btnEditMobile",
                    "flxActions": "flxActions",
                    "flxActionsMobile": "flxActionsMobile",
                    "flxAddress": "flxAddress",
                    "flxAddressDetails": "flxAddressDetails",
                    "flxAddressWrapper": "flxAddressWrapper",
                    "flxCommunicationAddress": "flxCommunicationAddress",
                    "flxInfo": "flxInfo",
                    "flxRow": "flxRow",
                    "imgCommunicationAddressInfo": "imgCommunicationAddressInfo",
                    "lblAddessLine2": "lblAddessLine2",
                    "lblAddressLine1": "lblAddressLine1",
                    "lblAddressLine3": "lblAddressLine3",
                    "lblAddressType": "lblAddressType",
                    "lblCommunicationAddress": "lblCommunicationAddress",
                    "lblSeperator": "lblSeperator",
                    "lblSeperatorActions": "lblSeperatorActions"
                },
                "widgetSkin": "Copyseg0j1ef31990dd644",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBusinessAddressBody.add(segBusinessAddresses);
            var btnAddNewBusinessAddressMobile = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Cancel\")"
                },
                "height": "40dp",
                "id": "btnAddNewBusinessAddressMobile",
                "isVisible": false,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewAddress\")",
                "top": "20dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxBusinessAddress.add(flxBusinessAddressHeader, flxBusinessAddressBody, btnAddNewBusinessAddressMobile);
            flxCombinedAddresses.add(flxPersonalAddress, flxAddressTypeSeparator, flxBusinessAddress);
            flxAddressesWrapper.add(flxAddresses, flxCombinedAddresses);
            flxAddressWrapper.add(addressInfo, flxAddNewAddressWrapper, flxEditAddressWrapper, flxAddressesWrapper);
            flxRight.add(flxAddressWrapper);
            flxContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxMainContainer.add(flxContainer);
            flxMain.add(lblHeading, flxProfileError, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "800dp",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopupCancel = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopupCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "width": "40%"
                    },
                    "btnYes": {
                        "width": "40%"
                    },
                    "flxCross": {
                        "right": "20dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                        "left": "20dp"
                    },
                    "lblPopupMessage": {
                        "left": "20dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCancelPopup.add(CustomPopupCancel);
            var flxDelete = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDelete",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDelete.setDefaultUnit(kony.flex.DP);
            var CopyflxDelete0e50a3339fe454b = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "268dp",
                "id": "CopyflxDelete0e50a3339fe454b",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxDelete0e50a3339fe454b.setDefaultUnit(kony.flex.DP);
            var flxDeleteHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDeleteClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteClose.setDefaultUnit(kony.flex.DP);
            var CopyimgDeleteClose0ee315396d8944f = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "CopyimgDeleteClose0ee315396d8944f",
                "isVisible": false,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcross = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblcross",
                "isVisible": true,
                "skin": "sknOlbFonts0273e317px",
                "text": "g",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeleteClose.add(CopyimgDeleteClose0ee315396d8944f, lblcross);
            flxDeleteHeader.add(lblDeleteHeader, flxDeleteClose);
            var flxDeleteSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxDeleteSeperator.add();
            var flxDeleteContents = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "105dp",
                "id": "flxDeleteContents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteContents.setDefaultUnit(kony.flex.DP);
            var lblPopupMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "id": "lblPopupMessage",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.deleteAddress\")",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeleteContents.add(lblPopupMessage);
            var flxDeleteSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxDeleteSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteSeperator2.setDefaultUnit(kony.flex.DP);
            flxDeleteSeperator2.add();
            var flxDeleteButtons = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": true,
                "height": "80px",
                "id": "flxDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.Yes\")"
                },
                "bottom": 30,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnYes",
                "isVisible": true,
                "left": "51.58%",
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.No\")"
                },
                "bottom": 30,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnNo",
                "isVisible": true,
                "left": "3.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxDeleteButtons.add(btnYes, btnNo);
            CopyflxDelete0e50a3339fe454b.add(flxDeleteHeader, flxDeleteSeperator, flxDeleteContents, flxDeleteSeperator2, flxDeleteButtons);
            flxDelete.add(CopyflxDelete0e50a3339fe454b);
            flxDialogs.add(flxLogout, flxCancelPopup, flxDelete);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmAddressSettings": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Profile Settings",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "rtxError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "We couldn't find an exact match.Please enter your payee information as it appears on your bill.",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "profileMenu.flxProfileMenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "profileMenu.flxSeperator": {
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "profileMenu"
                    },
                    "flxRight": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "520dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxAddressWrapper": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "addressInfo": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "addressInfo.RichTextInfo": {
                        "isVisible": true,
                        "text": "Add supported image formats like JPEG and PNG.",
                        "segmentProps": []
                    },
                    "flxAddNewAddressWrapper": {
                        "height": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "isVisible": false,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAddNewAddressHeader": {
                        "segmentProps": []
                    },
                    "flxAddNewAddressSeperator": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblAddNewAddressHeader": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewAddressContainer": {
                        "height": {
                            "type": "string",
                            "value": "740dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAddNewAddress": {
                        "height": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "minHeight": {
                            "type": "number",
                            "value": "560"
                        },
                        "segmentProps": []
                    },
                    "flxErrorAddAddress": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lbxType": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxAddressLine1": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxAddressLine2": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lbxCountry": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lbxState": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxCityName": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxZipcode": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSetAsPreferred": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxInfoAddAddress": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewAddressButtons": {
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator7": {
                        "segmentProps": []
                    },
                    "btnAddNewAddressAdd": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewAddressCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEditAddressWrapper": {
                        "height": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxEditAddressHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxEmailAddressContainer": {
                        "height": {
                            "type": "string",
                            "value": "740dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxEditAddress": {
                        "height": {
                            "type": "string",
                            "value": "560px"
                        },
                        "minHeight": {
                            "type": "number",
                            "value": "470"
                        },
                        "segmentProps": []
                    },
                    "flxErrorEditAddress": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lbxEditType": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxEditAddressLine1": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxEditAddressLine2": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxEditCountry": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxEditState": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lbxEditCountry": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lbxEditState": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxEdtCity": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxEditCity": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxEditZipcode": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEditSetAsPreferred": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxInfoEditAddress": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEditAddressButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "btnEditAddressCancel": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnEditAddressSave": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAddressesWrapper": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAddresses": {
                        "segmentProps": []
                    },
                    "flxAddressHeader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAddressHeading": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddressSeparator": {
                        "top": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewAddress": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAddressBody": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segprofilemanagementAddressnew": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewAddressMobile": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "i18n_text": "i18n.ProfileManagement.AddNewAddress",
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxCombinedAddresses": {
                        "segmentProps": []
                    },
                    "flxPersonalAddress": {
                        "segmentProps": []
                    },
                    "flxPersonalAddressHeader": {
                        "segmentProps": []
                    },
                    "btnAddNewPersonalAddress": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPersonalAddressBody": {
                        "segmentProps": []
                    },
                    "segPersonalAddresses": {
                        "data": [{
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ManageProfileMA",
                            "friendlyName": "flxProfileManagementAddresses"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "btnDelete": "btnDelete",
                            "btnEdit": "btnEdit",
                            "flxAddress": "flxAddress",
                            "flxAddressDetailContainer": "flxAddressDetailContainer",
                            "flxAddressWrapper": "flxAddressWrapper",
                            "flxEdit": "flxEdit",
                            "flxPrimary": "flxPrimary",
                            "flxProfileManagementAddresses": "flxProfileManagementAddresses",
                            "flxUsedFor": "flxUsedFor",
                            "lblAddessLine2": "lblAddessLine2",
                            "lblAddressLine1": "lblAddressLine1",
                            "lblAddressLine3": "lblAddressLine3",
                            "lblHome": "lblHome",
                            "lblPrimary": "lblPrimary",
                            "lblSeperator": "lblSeperator",
                            "lblUsedFor": "lblUsedFor"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ManageProfileMA"
                    },
                    "btnAddNewPersonalAddressMobile": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAddressTypeSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBusinessAddress": {
                        "segmentProps": []
                    },
                    "flxBusinessAddressHeader": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewBusinessAddress": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBusinessAddressBody": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "segBusinessAddresses": {
                        "data": [{
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }, {
                            "btnDelete": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Delete"
                            },
                            "btnEdit": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.billPay.Edit",
                                "text": "EDIT"
                            },
                            "lblAddessLine2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Palo Alto, Santa clara county"
                            },
                            "lblAddressLine1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "201, Cowper street"
                            },
                            "lblAddressLine3": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "California, US, 94301"
                            },
                            "lblHome": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.ProfileManagement.Home",
                                "text": "Home"
                            },
                            "lblPrimary": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Primary Communication"
                            },
                            "lblSeperator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "MAKE TRANSFER"
                            },
                            "lblUsedFor": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Used For:"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ManageProfileMA",
                            "friendlyName": "flxProfileManagementAddresses"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "btnDelete": "btnDelete",
                            "btnEdit": "btnEdit",
                            "flxAddress": "flxAddress",
                            "flxAddressDetailContainer": "flxAddressDetailContainer",
                            "flxAddressWrapper": "flxAddressWrapper",
                            "flxEdit": "flxEdit",
                            "flxPrimary": "flxPrimary",
                            "flxProfileManagementAddresses": "flxProfileManagementAddresses",
                            "flxUsedFor": "flxUsedFor",
                            "lblAddessLine2": "lblAddessLine2",
                            "lblAddressLine1": "lblAddressLine1",
                            "lblAddressLine3": "lblAddressLine3",
                            "lblHome": "lblHome",
                            "lblPrimary": "lblPrimary",
                            "lblSeperator": "lblSeperator",
                            "lblUsedFor": "lblUsedFor"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ManageProfileMA"
                    },
                    "btnAddNewBusinessAddressMobile": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "height": {
                            "type": "string",
                            "value": "2000dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "178dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "178dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.flxCross": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "CopyflxDelete0e50a3339fe454b": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteHeader": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "lblDeleteHeader": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteContents": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "lblPopupMessage": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxDeleteSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "segmentProps": []
                    },
                    "btnYes": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "btnNo": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "40%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "profileMenu.flxSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "720dp"
                        },
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "profileMenu"
                    },
                    "flxRight": {
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddressWrapper": {
                        "segmentProps": []
                    },
                    "addressInfo": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewAddressWrapper": {
                        "height": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewAddressHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.29%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.80%"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewAddressContainer": {
                        "left": {
                            "type": "string",
                            "value": "2.29%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.71%"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewAddressButtons": {
                        "left": {
                            "type": "string",
                            "value": "2.29%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.71%"
                        },
                        "segmentProps": []
                    },
                    "flxEditAddressWrapper": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEditAddressHeader": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailAddressContainer": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "tbxEditCountry": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "tbxEditState": {
                        "segmentProps": []
                    },
                    "lbxEditCountry": {
                        "segmentProps": []
                    },
                    "lbxEditState": {
                        "segmentProps": []
                    },
                    "flxEditAddressButtons": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAddressesWrapper": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAddresses": {
                        "segmentProps": []
                    },
                    "flxAddressHeader": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAddressHeading": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxAddressSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewAddress": {
                        "segmentProps": []
                    },
                    "flxAddressBody": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segprofilemanagementAddressnew": {
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarningWrapper": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarningImage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCombinedAddresses": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPersonalAddress": {
                        "segmentProps": []
                    },
                    "flxPersonalAddressHeader": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxPersonalAddressBody": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxBusinessAddress": {
                        "segmentProps": []
                    },
                    "flxBusinessAddressHeader": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewBusinessAddress": {
                        "segmentProps": []
                    },
                    "flxBusinessAddressBody": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "130%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.flxCross": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.imgCross": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CopyflxDelete0e50a3339fe454b": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblPopupMessage": {
                        "text": "Are you sure you want to delete this Address?",
                        "segmentProps": []
                    },
                    "btnYes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "skin": "sknlblUserName",
                        "text": "Settings",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "number",
                            "value": "10"
                        },
                        "isVisible": false,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "profileMenu"
                    },
                    "flxRight": {
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "addressInfo": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewAddressWrapper": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxEditAddressWrapper": {
                        "height": {
                            "type": "string",
                            "value": "710dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "tbxEditCountry": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAddressesWrapper": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblAddressHeading": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "61dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddressBody": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "segprofilemanagementAddressnew": {
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarningWrapper": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarningImage": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "text": "K",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "segmentProps": []
                    },
                    "lblPopupMessage": {
                        "text": "Are you sure you want to delete this Address?",
                        "segmentProps": []
                    },
                    "btnYes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "btnNo": {
                        "bottom": {
                            "type": "number",
                            "value": "30"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmAddressSettings": {
                        "segmentProps": []
                    },
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "addressInfo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAddNewAddressWrapper": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxEditAddressWrapper": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "tbxEditCountry": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAddressesWrapper": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "860dp"
                        },
                        "segmentProps": []
                    },
                    "lblAddressHeading": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "61dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "segprofilemanagementAddressnew": {
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarningWrapper": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarningImage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "skin": "sknlbl4a90e230OLBFontIconsPx",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "35px"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblPopupMessage": {
                        "text": "Are you sure you want to delete this Address?",
                        "segmentProps": []
                    },
                    "flxDeleteButtons": {
                        "segmentProps": []
                    },
                    "btnYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "profileMenu.flxSeperator": {
                    "bottom": 0,
                    "height": "700dp"
                },
                "profileMenu": {
                    "centerX": "",
                    "width": "100%"
                },
                "addressInfo": {
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%",
                    "zIndex": 100
                },
                "addressInfo.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "addressInfo.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "CustomPopupCancel": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopupCancel.btnNo": {
                    "width": "40%"
                },
                "CustomPopupCancel.btnYes": {
                    "width": "40%"
                },
                "CustomPopupCancel.flxCross": {
                    "right": "20dp"
                },
                "CustomPopupCancel.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                },
                "CustomPopupCancel.lblHeading": {
                    "left": "20dp"
                },
                "CustomPopupCancel.lblPopupMessage": {
                    "left": "20dp"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmAddressSettings,
            "enabledForIdleTimeout": true,
            "id": "frmAddressSettings",
            "init": controller.AS_Form_efa8f2b442c641af8bbed6eaeaa90744,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "title": "Address Settings",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ManageProfileMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});