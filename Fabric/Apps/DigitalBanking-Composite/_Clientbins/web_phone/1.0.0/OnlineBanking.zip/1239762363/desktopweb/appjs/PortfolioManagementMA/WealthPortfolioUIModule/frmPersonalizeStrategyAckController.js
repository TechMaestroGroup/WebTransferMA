/* eslint-disable */
define("PortfolioManagementMA/WealthPortfolioUIModule/userfrmPersonalizeStrategyAckController", ['FormControllerUtility', 'ViewConstants', 'CommonUtilities', 'OLBConstants', 'CampaignUtility'], function(FormControllerUtility, ViewConstants, CommonUtilities, OLBConstants, CampaignUtility) {
    return {
        //Type your controller code here 
        onNavigate: function() {
            this.view.preShow = this.preShow;
            this.view.postShow = this.postShow;
        },
        init: function() {
            this.view.onBreakpointChange = this.onBreakpointChange;
        },
        onBreakpointChange: function(form, width) {
            if (width == 640) {
                this.view.flxBrowserWarn.setVisibility(true);
                this.view.flxBrowserWarn.height = "320dp"
                this.view.formTemplate12.setVisibility(false);
            } else {
                this.view.flxBrowserWarn.setVisibility(false);
                this.view.formTemplate12.setVisibility(true);
            }
        },
        postShow: function() {
            if (kony.application.getCurrentBreakpoint() >= 1024) {
                // WIW-863 Strategy and acknowledgment box size and height is not matching
                var element = document.querySelector('[kwp="frmPersonalizeStrategyAck_formTemplate12_flxStrategy"]');
                if (element) {
                    this.view.formTemplate12.flxContentTCCenter.flxAck.height = element.offsetHeight + "px";
                }
                // this.view.formTemplate12.flxContentTCCenter.flxAck.height = this.view.formTemplate12.flxContentTCCenter.flxStrategy.minHeight;
            }
        },
        preShow: function() {
            this.view.formTemplate12.flxPageFooter.isVisible = false;
            this.view.onTouchEnd = this.onFormTouchEnd;
            var data = applicationManager.getNavigationManager().getCustomInfo('personalizedStrategyData');
            this.view.formTemplate12.flxContentTCCenter.lblStrategyDummy.text = this.view.formTemplate12.flxContentTCCenter.lblStrategy.text + this.view.formTemplate12.flxContentTCCenter.lblActive.text
            this.view.formTemplate12.flxContentTCCenter.lblTotalDummy.text = this.view.formTemplate12.flxContentTCCenter.lblTotal.text + this.view.formTemplate12.flxContentTCCenter.lblRecommended.text + this.view.formTemplate12.flxContentTCCenter.lblPercentage.text;
            this.view.formTemplate12.flxContentTCCenter.lblPercentageDummy.text = this.view.formTemplate12.flxContentTCCenter.lblTotal.text + this.view.formTemplate12.flxContentTCCenter.lblTarget.text + this.view.formTemplate12.flxContentTCCenter.lblPercentage2.text;
            //creating the template
            let template = JSON.stringify({
                "templateID": "flxSegPersonalizeStrategyOLB",
                "microAppName": "PortfolioManagementMA"
            });
            let configParam = {
                "serviceParameters": {},
                "dataMapping": {
                    "segListDetail": {
                        "segmentMasterData": "${CNTX.segData}",
                        "segmentUI": {
                            "rowTemplate": {
                                //segment widget mapping
                                "lblSegment": "${segmentMasterData.assetName}",
                                "lblRecommended": "${segmentMasterData.weight1}",
                                "lblTarget": "${segmentMasterData.weight2}",
                                "lblRecommendedDummy": "${segmentMasterData.assetName}",
                                "lblTargetDummy": "${segmentMasterData.assetName}"
                            }
                        }
                    }
                },
                "rowTemplateConfig": template,
                "headerTemplateConfig": ""
            };
            this.view.formTemplate12.flxContentTCCenter.flxMainContent.flxAckMain.flxStrategy.flxSegment.segList.setConfigsFromParent(configParam);
            this.view.formTemplate12.flxContentTCCenter.flxMainContent.flxAckMain.flxStrategy.flxSegment.segList.updateContext(data);
            this.view.formTemplate12.flxContentTCCenter.lblPercentage2.text = applicationManager.getNavigationManager().getCustomInfo('personalizedWeight');
        },
    }
});
define("PortfolioManagementMA/WealthPortfolioUIModule/frmPersonalizeStrategyAckControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnReview **/
    AS_Button_c6c045e09620491190957a2a08b5ab44: function AS_Button_c6c045e09620491190957a2a08b5ab44(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation({
            "appName": "PortfolioManagementMA",
            "friendlyName": "frmStrategyAllocation"
        });
        ntf.navigate();
    },
    /** onClick defined for btnPersonalize **/
    AS_Button_efe89d4d7b7745aeaad29bd71c58bfff: function AS_Button_efe89d4d7b7745aeaad29bd71c58bfff(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation({
            "appName": "PortfolioManagementMA",
            "friendlyName": "frmPersonalizeStrategy"
        });
        ntf.navigate();
    },
    /** init defined for frmPersonalizeStrategyAck **/
    AS_Form_a8cbe5f49b1b4d13b2badad20626ee64: function AS_Form_a8cbe5f49b1b4d13b2badad20626ee64(eventobject) {
        var self = this;
        this.init()
    }
});
define("PortfolioManagementMA/WealthPortfolioUIModule/frmPersonalizeStrategyAckController", ["PortfolioManagementMA/WealthPortfolioUIModule/userfrmPersonalizeStrategyAckController", "PortfolioManagementMA/WealthPortfolioUIModule/frmPersonalizeStrategyAckControllerActions"], function() {
    var controller = require("PortfolioManagementMA/WealthPortfolioUIModule/userfrmPersonalizeStrategyAckController");
    var controllerActions = ["PortfolioManagementMA/WealthPortfolioUIModule/frmPersonalizeStrategyAckControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
