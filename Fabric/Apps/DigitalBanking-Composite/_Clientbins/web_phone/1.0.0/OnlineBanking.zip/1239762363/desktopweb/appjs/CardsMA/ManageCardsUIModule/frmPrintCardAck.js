define("CardsMA/ManageCardsUIModule/frmPrintCardAck", function() {
    return function(controller) {
        function addWidgetsfrmPrintCardAck() {
            this.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "800dp",
                "id": "flxAcknowledgment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgment.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxHeader",
                "top": "50dp",
                "width": "98%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var Image0c47610df966b4c = new kony.ui.Image2({
                "height": "40dp",
                "id": "Image0c47610df966b4c",
                "isVisible": true,
                "left": "4%",
                "src": "kony_logo.png",
                "top": "15px",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(Image0c47610df966b4c);
            var lblCardAcknowledgement = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.LockCard\")",
                    "tagName": "span"
                },
                "id": "lblCardAcknowledgement",
                "isVisible": false,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.LockCard\")",
                "top": "80dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxAcknowledgementMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcknowledgementMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.08%",
                "minHeight": "300dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "150dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementMain.setDefaultUnit(kony.flex.DP);
            var Acknowledgement = new com.konyolb.CardManagement.Acknowledgement({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "Acknowledgement",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "minHeight": "250dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA",
                "overrides": {
                    "Acknowledgement": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "minHeight": "250dp"
                    },
                    "ImgAcknowledgement": {
                        "height": "75dp",
                        "isVisible": true,
                        "src": "selectgoal.png",
                        "width": "75dp"
                    },
                    "confirmHeaders.lblHeading": {
                        "left": "20dp"
                    },
                    "lblCardTransactionMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.AckMessage1\")"
                    },
                    "lblRefrenceNumber": {
                        "isVisible": false,
                        "top": "2dp"
                    },
                    "lblRequestID": {
                        "isVisible": false,
                        "top": "20px"
                    },
                    "lblUnlockCardMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.AckMessage2\")",
                        "isVisible": true,
                        "width": "90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAcknowledgementMain.add(Acknowledgement);
            var flxCardDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "350dp",
                "id": "flxCardDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "450dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardDetails.setDefaultUnit(kony.flex.DP);
            var lblCardDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.LockCard\")",
                    "tagName": "span"
                },
                "id": "lblCardDetails",
                "isVisible": false,
                "left": "86dp",
                "skin": "sknlblUserName",
                "text": "Lock Card",
                "top": "80dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var segCardDetails = new kony.ui.SegmentedUI2({
                "groupCells": false,
                "height": "240dp",
                "id": "segCardDetails",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCardDetails.add(lblCardDetails, flxSeperator1, segCardDetails);
            var flxBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "775dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var lblCopyRight = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.LockCard\")",
                    "tagName": "span"
                },
                "id": "lblCopyRight",
                "isVisible": true,
                "left": "86dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab1\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxBottom.add(lblCopyRight);
            flxAcknowledgment.add(flxHeader, lblCardAcknowledgement, flxAcknowledgementMain, flxCardDetails, flxBottom);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxAcknowledgment": {
                        "height": {
                            "type": "string",
                            "value": "900dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "102.45%"
                        },
                        "segmentProps": []
                    },
                    "lblCardAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRefrenceNumber": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRequestID": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCardDetails": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblCardDetails": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyRight": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxAcknowledgment": {
                        "height": {
                            "type": "string",
                            "value": "900dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCardAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "Acknowledgement": {
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRefrenceNumber": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRequestID": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCardDetails": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "lblCardDetails": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyRight": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxAcknowledgment": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCardAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "skin": "CopysknFlxffffffBorder1",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "Acknowledgement": {
                        "segmentProps": []
                    },
                    "Acknowledgement.ImgAcknowledgement": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRefrenceNumber": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRequestID": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "Acknowledgement.lblUnlockCardMessage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCardDetails": {
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "skin": "CopysknFlxffffffBorder1",
                        "top": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblCardDetails": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "Card Details",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator1": {
                        "height": {
                            "type": "string",
                            "value": "2px"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "segCardDetails": {
                        "data": [{
                            "lblKey": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "ABCDCard"
                            },
                            "lblValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "CardName"
                            }
                        }, {
                            "lblKey": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Newcard"
                            },
                            "lblValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Carddetails"
                            }
                        }, {
                            "lblKey": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "A"
                            },
                            "lblValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "a"
                            }
                        }, {
                            "lblKey": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "a"
                            },
                            "lblValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "B"
                            }
                        }],
                        "height": {
                            "type": "string",
                            "value": "75%"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "CardsMA",
                            "friendlyName": "flxAckPrint"
                        }),
                        "sectionHeaderTemplate": "",
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "widgetDataMap": {
                            "flxAckPrint": "flxAckPrint",
                            "lblKey": "lblKey",
                            "lblValue": "lblValue"
                        },
                        "zIndex": 10,
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "CardsMA"
                    },
                    "flxBottom": {
                        "top": {
                            "type": "string",
                            "value": "840dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyRight": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "Acknowledgement": {
                    "minHeight": "250dp"
                },
                "Acknowledgement.ImgAcknowledgement": {
                    "height": "75dp",
                    "src": "selectgoal.png",
                    "width": "75dp"
                },
                "Acknowledgement.confirmHeaders.lblHeading": {
                    "left": "20dp"
                },
                "Acknowledgement.lblRefrenceNumber": {
                    "top": "2dp"
                },
                "Acknowledgement.lblRequestID": {
                    "top": "20px"
                },
                "Acknowledgement.lblUnlockCardMessage": {
                    "width": "90%"
                }
            }
            this.add(flxAcknowledgment);
        };
        return [{
            "addWidgets": addWidgetsfrmPrintCardAck,
            "enabledForIdleTimeout": false,
            "id": "frmPrintCardAck",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_c375d193cd0e4104afe4ee4abd1aa115,
            "preShow": function(eventobject) {
                controller.AS_Form_da5f5eb0807f4cf7b15c09616df31bf8(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "CardsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});