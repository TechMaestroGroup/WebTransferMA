define("AuthenticationMA/AuthUIModule/frmConsent", function() {
    return function(controller) {
        function addWidgetsfrmConsent() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMainConatainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMainConatainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainConatainer.setDefaultUnit(kony.flex.DP);
            var flxAuthoriseConsent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAuthoriseConsent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAuthoriseConsent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxLogoKA = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "42dp",
                "id": "flxLogoKA",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100dp",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogoKA.setDefaultUnit(kony.flex.DP);
            var imgLogoKA = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "42dp",
                "id": "imgLogoKA",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "0",
                "width": "100dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLogoKA.add(imgLogoKA);
            flxHeader.add(flxLogoKA);
            var flxHeaderSeperatorKA = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxHeaderSeperatorKA",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknflxe3e3e3",
                "top": "0",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSeperatorKA.setDefaultUnit(kony.flex.DP);
            flxHeaderSeperatorKA.add();
            var flxContentContainerKA = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContentContainerKA",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainerKA.setDefaultUnit(kony.flex.DP);
            var lblAuthoriseConsentHeaderKA = new kony.ui.Label({
                "id": "lblAuthoriseConsentHeaderKA",
                "isVisible": true,
                "left": "20%",
                "skin": "sknLabel42424224pxSemiBold",
                "text": "Authorise Consent",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAuthorise = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "200dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAuthorise",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknffffffBorder1pxE2E9F0",
                "top": "25dp",
                "width": "60%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAuthorise.setDefaultUnit(kony.flex.DP);
            var flxImgAuthorise = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "96dp",
                "id": "flxImgAuthorise",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "48dp",
                "width": "96dp",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgAuthorise.setDefaultUnit(kony.flex.DP);
            var imgAuthorise = new kony.ui.Image2({
                "height": "100%",
                "id": "imgAuthorise",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0dp",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgAuthorise.add(imgAuthorise);
            var rtxAuthConsentMsg = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "By accessing the information provided at the Kony Mobile Banking site, you agree to the following terms and conditions. The material available on these sites has been produced by independent providers and are not the opinions or recommendations of kony Mobile Banking. Proin elit quam, feugiat quis sem eu, euismod feugiat lacus. Donec posuere sapien eu auctor lacinia. Quisque dictum augue nec auctor venenatis. Cras tincidunt tristique mauris, non tincidunt metus elementum quis.</br></br>\n\nBy accessing the information provided at the Kony Mobile Banking site, you agree to the following terms and conditions. The material available on these sites has been produced by independent providers and are not the opinions or recommendations of kony Mobile Banking. Proin elit quam, feugiat quis sem eu, euismod feugiat lacus. Donec posuere sapien eu auctor lacinia. Quisque dictum augue nec auctor venenatis. Cras tincidunt tristique mauris, non tincidunt metus elementum quis.</br></br>\n\nBy accessing the information provided at the Kony Mobile Banking site, you agree to the following terms and conditions."
                },
                "centerX": "50%",
                "id": "rtxAuthConsentMsg",
                "isVisible": true,
                "left": "2.50%",
                "skin": "bbSknRtx424242SSP17Px",
                "text": "Authorise <b>TeePee</b> to read your account information",
                "top": "15dp",
                "width": "95%",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAuthConsentMsg1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.Enroll.EnterLastName\")"
                },
                "centerX": "50%",
                "id": "lblAuthConsentMsg1",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.authoriseConsentMsg1\")",
                "textStyle": {},
                "top": "8dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAuthConsentMsg2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.Enroll.EnterLastName\")"
                },
                "centerX": "50%",
                "id": "lblAuthConsentMsg2",
                "isVisible": true,
                "skin": "bbSknLbl8f99acSSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.authoriseConsentMsg2\")",
                "textStyle": {},
                "top": "24dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAuthConsentMsg3 = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblAuthConsentMsg3",
                "isVisible": false,
                "maxNumberOfLines": 1,
                "skin": "bbSknLbl8f99acSSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.authoriseConsentMsg2\")",
                "textStyle": {},
                "textTruncatePosition": constants.TEXT_TRUNCATE_END,
                "top": "16dp",
                "width": "100%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxButtonsContainerKA = new kony.ui.FlexContainer({
                "bottom": "48dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxButtonsContainerKA",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "48dp",
                "width": "43%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtonsContainerKA.setDefaultUnit(kony.flex.DP);
            var btnAuthoriseCancelKA = new kony.ui.Button({
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "40dp",
                "id": "btnAuthoriseCancelKA",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "text": "Cancel",
                "top": "0",
                "width": "47%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            var btnAuthoriseContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.next\")"
                },
                "bottom": "20dp",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40dp",
                "id": "btnAuthoriseContinue",
                "isVisible": true,
                "left": "5%",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.continue\")",
                "top": "0dp",
                "width": "47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px"
            });
            flxButtonsContainerKA.add(btnAuthoriseCancelKA, btnAuthoriseContinue);
            flxAuthorise.add(flxImgAuthorise, rtxAuthConsentMsg, lblAuthConsentMsg1, lblAuthConsentMsg2, lblAuthConsentMsg3, flxButtonsContainerKA);
            flxContentContainerKA.add(lblAuthoriseConsentHeaderKA, flxAuthorise);
            flxAuthoriseConsent.add(flxHeader, flxHeaderSeperatorKA, flxContentContainerKA);
            var flxLogin = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "548dp",
                "id": "flxLogin",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknffffffBorder1pxE2E9F0",
                "top": "56dp",
                "width": "70%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogin.setDefaultUnit(kony.flex.DP);
            var flxLoginComponentContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "528dp",
                "id": "flxLoginComponentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "350dp",
                "zIndex": 10,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginComponentContainer.setDefaultUnit(kony.flex.DP);
            var flxImg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "55dp",
                "id": "flxImg",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "85%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImg.setDefaultUnit(kony.flex.DP);
            var flxImgKony = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "38dp",
                "id": "flxImgKony",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "122dp",
                "zIndex": 6,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgKony.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "digital_banking.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgKony.add(imgKony);
            flxImg.add(flxImgKony);
            var loginComponent = new com.InfinityOLB.AuthenticationMA.login({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "id": "loginComponent",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "viewType": "loginComponent",
                "overrides": {
                    "login": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var loginComponent_data = (appConfig.componentMetadata && appConfig.componentMetadata["AuthenticationMA"] && appConfig.componentMetadata["AuthenticationMA"]["frmConsent"] && appConfig.componentMetadata["AuthenticationMA"]["frmConsent"]["loginComponent"]) || {};
            loginComponent.identityServiceName = loginComponent_data.identityServiceName || "DbxUserLogin";
            loginComponent.successCallback = loginComponent_data.successCallback || "{$.c.successCallback}";
            loginComponent.labelSkin = loginComponent_data.labelSkin || "{\"640\":{\"skin\":\"sknSSP72727213Px\"},\"768\":{\"skin\":\"sknlbl727272SSPReg15px\"},\"1024\":{\"skin\":\"sknlbl727272SSPReg15px\"},\"default\":{\"skin\":\"sknlbl727272SSPReg15px\"}}";
            loginComponent.riskScore = loginComponent_data.riskScore || "{$.c.riskScore}";
            loginComponent.username = loginComponent_data.username || "";
            loginComponent.failureCallback = loginComponent_data.failureCallback || "{$.c.failureCallback}";
            loginComponent.flxSkins = loginComponent_data.flxSkins || "{\"normalSkin\":\"sknBorderE3E3E3\", \"focusSkin\":\"sknFocusBorder293275\", \"errorSkin\" : \"sknborderff0000error\"}";
            loginComponent.closePopups = loginComponent_data.closePopups || "null";
            loginComponent.primaryBtnEnableSkin = loginComponent_data.primaryBtnEnableSkin || "{\"normal\":\"sknBtnNormalSSPFFFFFF15Px\", \"hoverSkin\":\"sknBtnNormalSSPFFFFFFHover15Px\", \"focusSkin\":\"sknBtnNormalSSPFFFFFF15PxFocus\"}";
            loginComponent.primaryBtnDisableSkin = loginComponent_data.primaryBtnDisableSkin || "{\"normal\":\"sknBtnBlockedSSPFFFFFF15Px\", \"hoverSkin\":\"sknBtnBlockedSSPFFFFFF15Px\", \"focusSkin\":\"sknBtnBlockedSSPFFFFFF15Px\"}";
            var btnCancel = new kony.ui.Button({
                "centerX": "50%",
                "focusSkin": "sknBtnSSP0273E314Px",
                "id": "btnCancel",
                "isVisible": true,
                "maxWidth": "45%",
                "right": "0dp",
                "skin": "sknBtnSSP0273E314Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.cancel\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP0273E314Px"
            });
            flxLoginComponentContainer.add(flxImg, loginComponent, btnCancel);
            flxLogin.add(flxLoginComponentContainer);
            var flxCancel = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancel",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancel.setDefaultUnit(kony.flex.DP);
            var CancelPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CancelPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxSeperator": {
                        "isVisible": false
                    },
                    "flxSeperator2": {
                        "isVisible": false
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.CancelAlert\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCancel.add(CancelPopup);
            flxMainConatainer.add(flxAuthoriseConsent, flxLogin, flxCancel);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxAuthoriseConsent": {
                        "segmentProps": []
                    },
                    "flxLogoKA": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblAuthoriseConsentHeaderKA": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAuthorise": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "rtxAuthConsentMsg": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblAuthConsentMsg1": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblAuthConsentMsg2": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblAuthConsentMsg3": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxButtonsContainerKA": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnAuthoriseCancelKA": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnAuthoriseContinue": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLogin": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLoginComponentContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "segmentProps": []
                    },
                    "imgKony": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "loginComponent": {
                        "segmentProps": []
                    },
                    "flxCancel": {
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CancelPopup.flxSeperator2": {
                        "segmentProps": []
                    },
                    "CancelPopup.lblPopupMessage": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxAuthoriseConsent": {
                        "segmentProps": []
                    },
                    "flxLogoKA": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblAuthoriseConsentHeaderKA": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAuthorise": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxLogin": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLoginComponentContainer": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "segmentProps": []
                    },
                    "imgKony": {
                        "segmentProps": []
                    },
                    "loginComponent": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCancel": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxAuthoriseConsent": {
                        "segmentProps": []
                    },
                    "flxLogin": {
                        "width": {
                            "type": "string",
                            "value": "728dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "loginComponent": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                }
            }
            this.add(flxMainConatainer);
        };
        return [{
            "addWidgets": addWidgetsfrmConsent,
            "enabledForIdleTimeout": false,
            "id": "frmConsent",
            "init": controller.AS_Form_b4e31cb65068430699615ca83f1acad0,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmTransparent",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AuthenticationMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});