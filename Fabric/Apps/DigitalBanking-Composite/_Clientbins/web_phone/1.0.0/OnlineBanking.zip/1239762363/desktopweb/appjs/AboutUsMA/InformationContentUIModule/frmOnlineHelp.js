define("AboutUsMA/InformationContentUIModule/frmOnlineHelp", function() {
    return function(controller) {
        function addWidgetsfrmOnlineHelp() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "120dp",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheader": {
                        "height": "120dp",
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxFeedback": {
                        "zIndex": 1002
                    },
                    "topmenu.flxHelp": {
                        "right": "5%",
                        "width": "70dp",
                        "zIndex": 1040
                    },
                    "topmenu.flxMenusMain": {
                        "zIndex": 100
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "CopysknBorderE0g0878f2d2c094a",
                "top": "40dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknRtx424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.ThereisomeerrorintheserverWecouldnotcompleteyourrequestofaddingtheaccount\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxHelp = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "23px",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxHelp",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7dp",
                "width": "1250px",
                "zIndex": 2,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHelp.setDefaultUnit(kony.flex.DP);
            var flxMobileHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxMobileHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "2dp",
                "width": "100%",
                "zIndex": 11,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMobileHeader.setDefaultUnit(kony.flex.DP);
            var lblMobileContentHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblMobileContentHeader",
                "isVisible": true,
                "left": "125dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.OnlineHelp.Login\")",
                "top": "22dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropdownMobile = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxDropdownMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "114dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "66dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdownMobile.setDefaultUnit(kony.flex.DP);
            var imgDropdownMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": " "
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "imgDropdownMobile",
                "isVisible": true,
                "skin": "sknLblNewFontType0273E320px",
                "text": "e",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 3, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Search"
            });
            flxDropdownMobile.add(imgDropdownMobile);
            flxMobileHeader.add(lblMobileContentHeader, flxDropdownMobile);
            var help = new com.InfinityOLB.AboutUs.help({
                "height": "745dp",
                "id": "help",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "AboutUsMA",
                "overrides": {
                    "CopyimgSearchIcon0bd7ebbaf387149": {
                        "isVisible": true
                    },
                    "flxContent": {
                        "height": "672dp",
                        "left": "3dp",
                        "width": "100%",
                        "zIndex": 1
                    },
                    "flxHeader": {
                        "centerX": "50%",
                        "clipBounds": true,
                        "height": "60dp",
                        "width": "100%"
                    },
                    "flxMenu1": {
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100.70%"
                    },
                    "flxMenu2": {
                        "left": "-1dp",
                        "width": "100.70%"
                    },
                    "flxMenu3": {
                        "left": "-1dp",
                        "width": "100.70%"
                    },
                    "flxMenuWrapper": {
                        "enableScrolling": false,
                        "height": "670dp",
                        "left": "0dp",
                        "zIndex": 10
                    },
                    "flxRight": {
                        "height": "670dp",
                        "top": "0dp"
                    },
                    "flxSeperator1": {
                        "height": "670px",
                        "isVisible": true,
                        "width": "2px",
                        "zIndex": 105
                    },
                    "flxSubMenu1": {
                        "isVisible": false
                    },
                    "flxSubMenu1Option1": {
                        "width": "100%"
                    },
                    "flxSubMenu2": {
                        "isVisible": false
                    },
                    "flxSubMenu3": {
                        "isVisible": false
                    },
                    "imgAccountSettingsCollapse": {
                        "src": "arrow_down.png"
                    },
                    "imgClearSearch": {
                        "src": "search_close.png"
                    },
                    "imgMenu1Collapse": {
                        "src": "arrow_down.png"
                    },
                    "imgSearch": {
                        "centerY": "51%",
                        "isVisible": false,
                        "src": "search.png"
                    },
                    "imgSearchIcon": {
                        "right": "2px"
                    },
                    "imgSecuritySettingsCollapse": {
                        "src": "arrow_down.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip_2.png"
                    },
                    "lblHeading": {
                        "bottom": "15dp",
                        "centerY": "viz.val_cleared",
                        "height": "25dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.topmenu.help\")",
                        "left": "0%",
                        "top": "viz.val_cleared"
                    },
                    "lblImgMenu1": {
                        "centerY": "60%",
                        "height": "27px",
                        "left": "6.50%",
                        "text": "a",
                        "top": "8dp",
                        "width": "24px"
                    },
                    "lblImgMenu2": {
                        "left": "6.50%",
                        "width": "25px"
                    },
                    "lblImgMenu3": {
                        "left": "6.50%"
                    },
                    "lblM1O1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.login\")",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblM1O2": {
                        "left": "20%"
                    },
                    "lblM1O3": {
                        "left": "20%"
                    },
                    "lblM1O4": {
                        "left": "20%",
                        "top": "viz.val_cleared"
                    },
                    "lblM2O1": {
                        "left": "20%"
                    },
                    "lblM2O2": {
                        "left": "20%"
                    },
                    "lblM2O3": {
                        "left": "20%"
                    },
                    "lblM2O4": {
                        "left": "20%"
                    },
                    "lblM3O1": {
                        "left": "20%"
                    },
                    "lblM3O2": {
                        "left": "20%"
                    },
                    "rtxDescription": {
                        "right": "40px",
                        "top": "15px"
                    },
                    "tbxHelpSearch": {
                        "placeholder": "Search keywords"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHelp.add(flxMobileHeader, help);
            flxMainContainer.add(flxDowntimeWarning, flxHelp);
            var flxFooter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "90dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "1000dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMainContainer, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "CopyslFbox0i94559a2949d45",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1200,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(CustomPopup);
            flxDialogs.add(flxPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "Help",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.imgMenu": {
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "rtxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": []
                    },
                    "flxHelp": {
                        "skin": "CopyslFbox0c4012e09529149",
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "flxMobileHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxf1ab15",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblMobileContentHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknLblSSP42424215px",
                        "text": "Sign In",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdownMobile": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "imgDropdownMobile": {
                        "skin": "sknLblNewFontType0273E320px",
                        "text": "O",
                        "hoverSkin": "sknLblNewFontType0273E320px",
                        "segmentProps": []
                    },
                    "help.flxContent": {
                        "height": {
                            "type": "string",
                            "value": "715dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "help.flxDescriptionAndFAQHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "help.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.flxHeaderSeperator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "help.flxHelpDetails": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxHelpHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.flxMenu1": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "help.flxMenu1Collapse": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.flxMenu2": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "help.flxMenu2Collapse": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.flxMenu3": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "help.flxMenu3Collapse": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.flxMenuWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minHeight": {
                            "type": "number",
                            "value": "650"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "-20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "help.flxRight": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSearch": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.flxSubMenu1": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "help.flxSubMenu1Option1": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu1Option2": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu1Option3": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu1Option4": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu2": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu2Option1": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu2Option2": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu2Option3": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu2Option4": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu3": {
                        "segmentProps": []
                    },
                    "help.flxSubMenu3Option1": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu3Option2": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "segmentProps": []
                    },
                    "help": {
                        "height": {
                            "type": "string",
                            "value": "720dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "zIndex": 10,
                        "segmentProps": [],
                        "instanceId": "help"
                    },
                    "help.imgToolTip": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "-20dp"
                        },
                        "segmentProps": []
                    },
                    "help.lblFAQ": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.lblHeading": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.lblImgMenu1": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "help.lblImgMenu2": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "help.lblImgMenu3": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "24px"
                        },
                        "segmentProps": []
                    },
                    "help.lblM1O1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20.50%"
                        },
                        "segmentProps": []
                    },
                    "help.lblM1O2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "help.lblM1O3": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "help.lblM1O4": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20.50%"
                        },
                        "segmentProps": []
                    },
                    "help.lblMenu1": {
                        "left": {
                            "type": "string",
                            "value": "20.56%"
                        },
                        "segmentProps": []
                    },
                    "help.rtxDescription": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.btnLogout": {
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxMessages": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxVerticalSeperator3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxHelp": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMobileHeader": {
                        "segmentProps": []
                    },
                    "help.flxClearSearch": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "help.flxContent": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "help.flxHeader": {
                        "segmentProps": []
                    },
                    "help.flxMenu1": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxMenu1Collapse": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "help.flxMenu2Collapse": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "help.flxMenu3Collapse": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "help.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "help.flxRight": {
                        "left": {
                            "type": "string",
                            "value": "35.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "64.50%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSeperator1": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "help.flxSubMenu1Option3": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "help.imgSearch": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "help.imgSearchIcon": {
                        "segmentProps": []
                    },
                    "help.lblHeading": {
                        "segmentProps": []
                    },
                    "help.lblImgMenu1": {
                        "segmentProps": []
                    },
                    "help.lblImgMenu2": {
                        "segmentProps": []
                    },
                    "help.lblImgMenu3": {
                        "segmentProps": []
                    },
                    "help.lblM1O3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.btnLogout": {
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxMessages": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxVerticalSeperator3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "left": {
                            "type": "string",
                            "value": "0.50%"
                        },
                        "segmentProps": []
                    },
                    "flxHelp": {
                        "width": {
                            "type": "string",
                            "value": "88.40%"
                        },
                        "segmentProps": []
                    },
                    "help.flxContent": {
                        "segmentProps": []
                    },
                    "help.flxMenu1": {
                        "segmentProps": []
                    },
                    "help.flxMenuWrapper": {
                        "segmentProps": []
                    },
                    "help.flxRight": {
                        "segmentProps": []
                    },
                    "help.flxSeperator1": {
                        "segmentProps": []
                    },
                    "help.imgSearch": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "help.imgSearchIcon": {
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "help.lblHeading": {
                        "segmentProps": []
                    },
                    "help.lblM1O1": {
                        "left": {
                            "type": "string",
                            "value": "20.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "5.60%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.btnLogout": {
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxMessages": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxResetUserImg": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxUserId": {
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxVerticalSeperator3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "left": {
                            "type": "string",
                            "value": "0.70%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "left": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "flxHelp": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "skin": "sknFlxf8f7f8",
                        "width": {
                            "type": "string",
                            "value": "1266dp"
                        },
                        "segmentProps": []
                    },
                    "help.flxContent": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "help.flxHeader": {
                        "segmentProps": []
                    },
                    "help.flxHelpHeader": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "help.flxMenu1": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "help.flxMenuWrapper": {
                        "segmentProps": []
                    },
                    "help.flxRight": {
                        "segmentProps": []
                    },
                    "help.flxSearch": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.flxSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "help.flxSeperator1": {
                        "segmentProps": []
                    },
                    "help.flxSubMenu1Option2": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "help.imgSearch": {
                        "src": "search.png",
                        "segmentProps": []
                    },
                    "help.imgSearchIcon": {
                        "right": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "help.lblFAQ": {
                        "text": "Frequently Asked Questions:",
                        "segmentProps": []
                    },
                    "help.lblHeading": {
                        "segmentProps": []
                    },
                    "help.segResults": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxf8f7f8",
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader": {
                    "height": "120dp",
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.topmenu.flxFeedback": {
                    "zIndex": 1002
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp",
                    "zIndex": 1040
                },
                "customheader.topmenu.flxMenusMain": {
                    "zIndex": 100
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "help.flxContent": {
                    "height": "672dp",
                    "left": "3dp",
                    "width": "100%",
                    "zIndex": 1
                },
                "help.flxHeader": {
                    "centerX": "50%",
                    "height": "60dp",
                    "width": "100%"
                },
                "help.flxMenu1": {
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100.70%"
                },
                "help.flxMenu2": {
                    "left": "-1dp",
                    "width": "100.70%"
                },
                "help.flxMenu3": {
                    "left": "-1dp",
                    "width": "100.70%"
                },
                "help.flxMenuWrapper": {
                    "height": "670dp",
                    "left": "0dp",
                    "zIndex": 10
                },
                "help.flxRight": {
                    "height": "670dp",
                    "top": "0dp"
                },
                "help.flxSeperator1": {
                    "height": "670px",
                    "width": "2px",
                    "zIndex": 105
                },
                "help.flxSubMenu1Option1": {
                    "width": "100%"
                },
                "help.imgAccountSettingsCollapse": {
                    "src": "arrow_down.png"
                },
                "help.imgClearSearch": {
                    "src": "search_close.png"
                },
                "help.imgMenu1Collapse": {
                    "src": "arrow_down.png"
                },
                "help.imgSearch": {
                    "centerY": "51%",
                    "src": "search.png"
                },
                "help.imgSearchIcon": {
                    "right": "2px"
                },
                "help.imgSecuritySettingsCollapse": {
                    "src": "arrow_down.png"
                },
                "help.imgToolTip": {
                    "src": "tool_tip_2.png"
                },
                "help.lblHeading": {
                    "bottom": "15dp",
                    "centerY": "",
                    "height": "25dp",
                    "left": "0%",
                    "top": ""
                },
                "help.lblImgMenu1": {
                    "centerY": "60%",
                    "height": "27px",
                    "left": "6.50%",
                    "text": "a",
                    "top": "8dp",
                    "width": "24px"
                },
                "help.lblImgMenu2": {
                    "left": "6.50%",
                    "width": "25px"
                },
                "help.lblImgMenu3": {
                    "left": "6.50%"
                },
                "help.lblM1O1": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "help.lblM1O2": {
                    "left": "20%"
                },
                "help.lblM1O3": {
                    "left": "20%"
                },
                "help.lblM1O4": {
                    "left": "20%",
                    "top": ""
                },
                "help.lblM2O1": {
                    "left": "20%"
                },
                "help.lblM2O2": {
                    "left": "20%"
                },
                "help.lblM2O3": {
                    "left": "20%"
                },
                "help.lblM2O4": {
                    "left": "20%"
                },
                "help.lblM3O1": {
                    "left": "20%"
                },
                "help.lblM3O2": {
                    "left": "20%"
                },
                "help.rtxDescription": {
                    "right": "40px",
                    "top": "15px"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs, flxLoading, flxLogout);
        };
        return [{
            "addWidgets": addWidgetsfrmOnlineHelp,
            "enabledForIdleTimeout": true,
            "id": "frmOnlineHelp",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_bcdd23043a504fefa3823205f8287fea,
            "postShow": controller.AS_Form_c4f8c3c70e87454aa48521219d5868be,
            "preShow": function(eventobject) {
                controller.AS_Form_abea803ff6bc481a97207deeb97b901d(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.common.OnlineHelp\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AboutUsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_h11dcaf8ac644af7aaf32597aa3ce815,
            "retainScrollPosition": false
        }]
    }
});