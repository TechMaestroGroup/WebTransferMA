define("AboutUsMA/FeedbackUIModule/frmCustomerFeedback", function() {
    return function(controller) {
        function addWidgetsfrmCustomerFeedback() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderPreLogin = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "70dp",
                "id": "flxHeaderPreLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderPreLogin.setDefaultUnit(kony.flex.DP);
            var flxMainHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "banner"
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "70px",
                "id": "flxMainHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 3,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainHeader.setDefaultUnit(kony.flex.DP);
            var btnSkipContent = new kony.ui.Button({
                "height": "50dp",
                "id": "btnSkipContent",
                "isVisible": true,
                "left": "210dp",
                "skin": "btnSkipNavigation",
                "text": "Skip To Main Content",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxKony = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "42dp",
                "id": "flxKony",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "80dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100dp",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKony.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Infinity Digital Banking"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "42dp",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "kony_logo.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxKony.add(imgKony);
            var lblSeperator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": 37,
                "height": "25dp",
                "id": "lblSeperator",
                "isVisible": true,
                "right": "10.90%",
                "skin": "sknLabelD8D8D8bg",
                "text": "-",
                "width": "1dp",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var FlexGroup0bb8635a53b8241 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "FlexGroup0bb8635a53b8241",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            FlexGroup0bb8635a53b8241.setDefaultUnit(kony.flex.DP);
            var lblKonyBank = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblKonyBank",
                "isVisible": true,
                "right": "15%",
                "skin": "sknLblSSP33333315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.YouHaveNotLoggedIn\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgReminder = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "28dp",
                "id": "imgReminder",
                "isVisible": true,
                "left": "75.30%",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexGroup0bb8635a53b8241.add(lblKonyBank, imgReminder);
            var btnLogin = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Log In"
                },
                "height": "50dp",
                "id": "btnLogin",
                "isVisible": false,
                "left": "1227dp",
                "skin": "sknButtonLogin3343a8",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.login\")",
                "top": "10dp",
                "width": "90dp",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Login"
            });
            var flxSignin = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.login\")"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "51.43%",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSignin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "85dp",
                "width": "40dp",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSignin.setDefaultUnit(kony.flex.DP);
            var imgLogout = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25dp",
                "id": "imgLogout",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "login_icon_locateus.png",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSignin.add(imgLogout);
            flxMainHeader.add(btnSkipContent, flxKony, lblSeperator, FlexGroup0bb8635a53b8241, btnLogin, flxSignin);
            var flxLeftContainers = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxLeftContainers",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknc6daf3",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContainers.setDefaultUnit(kony.flex.DP);
            flxLeftContainers.add();
            var flxRightContainers = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxRightContainers",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50%",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainers.setDefaultUnit(kony.flex.DP);
            flxRightContainers.add();
            var flxSeperatorHor2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8dp",
                "id": "flxSeperatorHor2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxBlueShadow",
                "top": "70dp",
                "width": "100%",
                "zIndex": 100,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxMouseIndication"
            });
            flxSeperatorHor2.setDefaultUnit(kony.flex.DP);
            flxSeperatorHor2.add();
            flxHeaderPreLogin.add(flxMainHeader, flxLeftContainers, flxRightContainers, flxSeperatorHor2);
            var flxHeaderPostLogin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderPostLogin",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderPostLogin.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121dp",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customhamburger.imgCollapseAccounts": {
                        "src": "arrow_down.png"
                    },
                    "customhamburger.imgKony": {
                        "src": "kony_logo_white.png"
                    },
                    "customheader": {
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxTopmenu": {
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "imgKony": {
                        "left": "0dp",
                        "src": "kony_logo.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxHelp": {
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "isVisible": true,
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxLoginMobile = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLoginMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "556dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-52dp",
                "width": "10%",
                "zIndex": 2000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginMobile.setDefaultUnit(kony.flex.DP);
            var lblLoginMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblLoginMobile",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknLblffffff15pxSSP",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.login\")",
                "width": "65%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoginMobile.add(lblLoginMobile);
            flxHeaderPostLogin.add(customheader, flxLoginMobile);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8Border0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxFeedback = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxFeedback",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedback.setDefaultUnit(kony.flex.DP);
            var flxFeedbackContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFeedbackContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "62dp",
                "isModalContainer": false,
                "right": "62dp",
                "skin": "sknFlxf8f7f8Border0",
                "top": "30dp",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackContainer.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "15dp",
                "width": "95.50%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "8dp",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "80dp",
                "right": "70dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "8dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCloseDowntimeWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10dp",
                "top": "10dp",
                "width": "40dp",
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseDowntimeWarning.add(imgCloseDowntimeWarning);
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, flxCloseDowntimeWarning);
            var Feedback = new com.InfinityOLB.AboutUs.Feedback({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "Feedback",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA",
                "overrides": {
                    "AllForms": {
                        "clipBounds": false,
                        "isVisible": false,
                        "left": "100dp",
                        "top": "420dp"
                    },
                    "Feedback": {
                        "isVisible": true,
                        "width": "100%"
                    },
                    "LblAddFeatureRequest": {
                        "height": "25dp",
                        "text": "Label",
                        "top": "1dp"
                    },
                    "confirmButtons": {
                        "height": "210px",
                        "top": "20dp"
                    },
                    "confirmButtons.btnCancel": {
                        "isVisible": false
                    },
                    "confirmButtons.btnConfirm": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.Submit\")",
                        "width": "150dp"
                    },
                    "confirmButtons.btnModify": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                        "right": "200dp",
                        "width": "150dp"
                    },
                    "confirmButtons.flxHorizontalLine": {
                        "top": "0dp"
                    },
                    "flxAddFeatureRequest": {
                        "top": "20dp"
                    },
                    "flxAddFeatureRequestandimg": {
                        "left": "0dp",
                        "width": "100%",
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "flxAddRequest": {
                        "width": "15%"
                    },
                    "flxHeader": {
                        "height": "67dp",
                        "top": "0dp"
                    },
                    "flxImgInfoIcon": {
                        "height": "25dp",
                        "isVisible": true,
                        "left": "10dp",
                        "right": "viz.val_cleared",
                        "top": "4dp",
                        "width": "25dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxMain": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "top": "67dp",
                        "width": "96.50%"
                    },
                    "flxPlusIcon": {
                        "centerY": "viz.val_cleared",
                        "height": "24dp",
                        "isVisible": true,
                        "width": "24dp"
                    },
                    "flxRating": {
                        "clipBounds": false,
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "flxRating1": {
                        "left": "10dp"
                    },
                    "flxRatingimg": {
                        "clipBounds": false,
                        "left": "10dp",
                        "top": "81dp"
                    },
                    "flxUserFeedback": {
                        "isVisible": false
                    },
                    "flxaddress": {
                        "clipBounds": false
                    },
                    "imgAdd": {
                        "height": "24dp",
                        "left": "4dp",
                        "src": "plus_icon.png",
                        "top": "4dp",
                        "width": "15dp"
                    },
                    "imgInfo": {
                        "height": "15dp",
                        "left": "19.5%",
                        "src": "info_grey.png",
                        "top": "7dp",
                        "width": "15dp"
                    },
                    "imgInfoIcon": {
                        "src": "info_grey.png",
                        "top": "0dp",
                        "width": "20dp"
                    },
                    "lblAddYourComments": {
                        "top": "87dp"
                    },
                    "lblCharCountComments": {
                        "top": "95dp"
                    },
                    "lblHeading": {
                        "bottom": "15dp",
                        "centerY": "viz.val_cleared",
                        "height": "25dp",
                        "left": "0dp",
                        "top": "25dp"
                    },
                    "lblPlusIcon": {
                        "height": "24dp",
                        "width": "19dp"
                    },
                    "lblRateYourExpeience": {
                        "top": "0dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblRatingtxt": {
                        "left": "26.50%"
                    },
                    "txtareaUserAdditionalComments": {
                        "maxTextLength": 1000
                    },
                    "txtareaUserComments": {
                        "bottom": "20dp",
                        "maxTextLength": 1000,
                        "top": "120dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            Feedback.confirmButtons.btnConfirm.onClick = controller.AS_Button_de264b9824ac4f68843c416991eff063;
            Feedback.confirmButtons.btnModify.onClick = controller.AS_Button_c667bf53388c4a81b111f208040f9e49;
            Feedback.flxAddFeatureRequestandimg.onClick = controller.AS_FlexContainer_i82dddffde6e4f2ea6bffbf21f35369a;
            Feedback.flxRating1.onClick = controller.AS_FlexContainer_a4a94fb507bd48198e03f507309b9df6;
            Feedback.flxRating2.onClick = controller.AS_FlexContainer_d51cd9167b614bbd8ab68e4c039a1d68;
            Feedback.flxRating3.onClick = controller.AS_FlexContainer_e00aaf44e15a4151b448616bf7a89e56;
            Feedback.flxRating4.onClick = controller.AS_FlexContainer_hda99f509f614811ab2e5e30282c8b21;
            Feedback.flxRating5.onClick = controller.AS_FlexContainer_b4530ef487bb472a862380bfb551c0d3;
            flxFeedbackContainer.add(flxDowntimeWarning, Feedback);
            flxFeedback.add(flxFeedbackContainer);
            var flxFeedbackAcknowledgement = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxFeedbackAcknowledgement",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8Border0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackAcknowledgement.setDefaultUnit(kony.flex.DP);
            var flxSurveyHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "63dp",
                "id": "flxSurveyHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 20,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSurveyHeader.setDefaultUnit(kony.flex.DP);
            var lblSurvey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50.50%",
                "centerY": "50%",
                "height": "25dp",
                "id": "lblSurvey",
                "isVisible": true,
                "skin": "sknLabelSSP42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.Survey\")",
                "top": "20dp",
                "width": "1200dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSurveyHeader.add(lblSurvey);
            var flxFeedbackAcknowledgementSurvey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxFeedbackAcknowledgementSurvey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackAcknowledgementSurvey.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgementThankyouMessage = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "90dp",
                "id": "flxAcknowledgementThankyouMessage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "sknf8f7f8modbr4pxbebebeshdw",
                "top": "5dp",
                "width": "99.10%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementThankyouMessage.setDefaultUnit(kony.flex.DP);
            var imgSuccessGreen = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "height": "60dp",
                "id": "imgSuccessGreen",
                "isVisible": true,
                "left": "2.35%",
                "skin": "slImage",
                "src": "success_green.png",
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Print"
            });
            var lblThankYouMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblThankYouMsg",
                "isVisible": true,
                "left": "9%",
                "skin": "sknSSP42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18.CustomerFeedback.ThankyouForCompletingTheSurvey\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblWeValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblWeValue",
                "isVisible": true,
                "left": "9%",
                "skin": "sknSSP42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18.CustomerFeedback.ThankyouForCompletingTheSurvey\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxHeaderAck = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxHeaderAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "53dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderAck.setDefaultUnit(kony.flex.DP);
            var lblAck = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblAck",
                "isVisible": true,
                "skin": "sknLabelSSP42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Acknowledgement\")",
                "top": "20dp",
                "width": "1200dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxHorizontalLine2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine2.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine2.add();
            flxHeaderAck.add(lblAck, flxHorizontalLine2);
            flxAcknowledgementThankyouMessage.add(imgSuccessGreen, lblThankYouMsg, lblWeValue, flxHeaderAck);
            var flxFeedbackDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "5dp",
                "clipBounds": false,
                "id": "flxFeedbackDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "sknf8f7f8modbr4pxbebebeshdw",
                "top": "20dp",
                "width": "99.10%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackDetails.setDefaultUnit(kony.flex.DP);
            var confirmHeaders = new com.InfinityOLB.BillPay.PayDueAmount.confirmHeaders({
                "height": "60dp",
                "id": "confirmHeaders",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA",
                "overrides": {
                    "confirmHeaders": {
                        "left": "0dp",
                        "top": "0dp",
                        "zIndex": 1
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.FeedbackDetails\")",
                        "left": "2.10%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxaddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxaddress",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxaddress.setDefaultUnit(kony.flex.DP);
            var flxQuestion1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxQuestion1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "Copysknflxffffffnobor",
                "top": "30dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuestion1.setDefaultUnit(kony.flex.DP);
            var lblQuestionNo1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblQuestionNo1",
                "isVisible": true,
                "left": "2%",
                "skin": "sknSSP72727215Px",
                "text": "1.",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblQuestion1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblQuestion1",
                "isVisible": true,
                "left": "3.50%",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.HowEasyWasTheMoneyTransferProcess?\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAnswer1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAnswer1",
                "isVisible": true,
                "left": "3.50%",
                "skin": "sknLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.Easy\")",
                "top": "23dp",
                "width": "33%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxQuestion1.add(lblQuestionNo1, lblQuestion1, lblAnswer1);
            var flxQuestion2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxQuestion2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "Copysknflxffffffnobor",
                "top": "30dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuestion2.setDefaultUnit(kony.flex.DP);
            var lblQuestionNo2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblQuestionNo2",
                "isVisible": true,
                "left": "2%",
                "skin": "sknSSP72727215Px",
                "text": "2.",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblQuestion2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblQuestion2",
                "isVisible": true,
                "left": "3.50%",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.ImproveOnlineExperience\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAnswer2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAnswer2",
                "isVisible": true,
                "left": "3.50%",
                "skin": "sknLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.Transfers&BillPay\")",
                "top": "23dp",
                "width": "33%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxQuestion2.add(lblQuestionNo2, lblQuestion2, lblAnswer2);
            var flxQuestion3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxQuestion3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "Copysknflxffffffnobor",
                "top": "30dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuestion3.setDefaultUnit(kony.flex.DP);
            var lblQuestionNo3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblQuestionNo3",
                "isVisible": true,
                "left": "2%",
                "skin": "sknSSP72727215Px",
                "text": "3.",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblQuestion3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblQuestion3",
                "isVisible": true,
                "left": "3.50%",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.WhatFeatureDoYouWantTosee??\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAnswer3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAnswer3",
                "isVisible": true,
                "left": "3.50%",
                "skin": "sknLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.userfeedback\")",
                "top": "23dp",
                "width": "33%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxQuestion3.add(lblQuestionNo3, lblQuestion3, lblAnswer3);
            flxaddress.add(flxQuestion1, flxQuestion2, flxQuestion3);
            var flxSeperatorhor = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorhor",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "40dp",
                "width": "95%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorhor.setDefaultUnit(kony.flex.DP);
            flxSeperatorhor.add();
            var flxButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "110dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnDone = new kony.ui.Button({
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnDone",
                "isVisible": true,
                "onClick": controller.AS_Button_cbbb8d01036e407fb4e2de2921cf18ae,
                "right": "2.70%",
                "skin": "sknbtnSSPffffff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Done\")",
                "top": "40dp",
                "width": "24%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Done"
            });
            flxButtons.add(btnDone);
            flxFeedbackDetails.add(confirmHeaders, flxSeperator2, flxaddress, flxSeperatorhor, flxButtons);
            flxFeedbackAcknowledgementSurvey.add(flxAcknowledgementThankyouMessage, flxFeedbackDetails);
            flxFeedbackAcknowledgement.add(flxSurveyHeader, flxFeedbackAcknowledgementSurvey);
            var flxAcknowledgementContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAcknowledgementContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementContainer.setDefaultUnit(kony.flex.DP);
            var CopyflxSurveyHeader0g535a03984564f = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "67dp",
                "id": "CopyflxSurveyHeader0g535a03984564f",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 20,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSurveyHeader0g535a03984564f.setDefaultUnit(kony.flex.DP);
            var CopylblSurvey0cb6dc11415f44a = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "bottom": "15dp",
                "centerX": "50%",
                "height": "25dp",
                "id": "CopylblSurvey0cb6dc11415f44a",
                "isVisible": true,
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.Feedback\")",
                "width": "1200dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxSurveyHeader0g535a03984564f.add(CopylblSurvey0cb6dc11415f44a);
            var flxAcknowledgementMain = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "410dp",
                "id": "flxAcknowledgementMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "sknf8f7f8modbr4pxbebebeshdw",
                "top": "68dp",
                "width": "43.27%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementMain.setDefaultUnit(kony.flex.DP);
            var acknowledgment = new com.InfinityOLB.AboutUs.acknowledgment({
                "height": "410dp",
                "id": "acknowledgment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9noshadow",
                "width": "100%",
                "appName": "AboutUsMA",
                "overrides": {
                    "ImgAcknowledged": {
                        "src": "success_green.png",
                        "top": "136dp"
                    },
                    "acknowledgment": {
                        "height": "410dp"
                    },
                    "confirmHeaders": {
                        "top": "0dp"
                    },
                    "confirmHeaders.flxHeader": {
                        "height": "50dp",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "confirmHeaders.lblHeading": {
                        "left": "2.50%",
                        "top": "viz.val_cleared"
                    },
                    "flxSeperator": {
                        "centerX": "viz.val_cleared",
                        "left": "0px",
                        "top": "50dp",
                        "width": "100%"
                    },
                    "flxTakeSurvey": {
                        "width": "30%"
                    },
                    "lblRefrenceNumber": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.WoulduLikeToTakeATwoMinuteSurvey\")",
                        "top": "224dp"
                    },
                    "lblRefrenceNumberValue": {
                        "top": "330dp"
                    },
                    "lblTransactionMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.ThankuForSubmittingYourFeedback\")",
                        "top": "90px"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAcknowledgementMain.add(acknowledgment);
            var flxTransactionDetails = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "410dp",
                "id": "flxTransactionDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50.59%",
                "isModalContainer": false,
                "skin": "sknf8f7f8modbr4pxbebebeshdw",
                "top": "68dp",
                "width": "43.27%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionDetails.setDefaultUnit(kony.flex.DP);
            var CustomerFeedbackDetails = new com.InfinityOLB.AboutUs.CustomerFeedbackDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "CustomerFeedbackDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AboutUsMA",
                "overrides": {
                    "confirmHeaders": {
                        "height": "50dp"
                    },
                    "confirmHeaders.flxHeader": {
                        "height": "50dp",
                        "width": "100%"
                    },
                    "confirmHeaders.lblHeading": {
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.FeedbackDetails\")",
                        "left": "2.50%",
                        "top": "viz.val_cleared"
                    },
                    "flxHorizontalLine": {
                        "centerX": "viz.val_cleared",
                        "width": "100%"
                    },
                    "flxQuestion1": {
                        "left": "0dp",
                        "top": "30dp"
                    },
                    "flxRateYourExperience": {
                        "clipBounds": false
                    },
                    "flxRatingimg": {
                        "top": "31dp"
                    },
                    "flxScrollContainerCustomerFeedback": {
                        "centerX": "viz.val_cleared",
                        "height": "345px",
                        "width": "100%"
                    },
                    "flxaddress": {
                        "clipBounds": false,
                        "left": "18dp",
                        "width": "100%"
                    },
                    "lblAnswer1": {
                        "top": "35dp",
                        "width": "80%"
                    },
                    "lblcomments": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CustomerFeedback.ILikeTheSimpleProcees...\")",
                        "width": "80%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxHorizontalLine = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "0dp",
                "id": "flxHorizontalLine",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine.add();
            var btnAddAnotherAccount = new kony.ui.Button({
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnAddAnotherAccount",
                "isVisible": true,
                "left": "72.91%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Done\")",
                "top": "516dp",
                "width": "20.90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxTransactionDetails.add(CustomerFeedbackDetails, flxHorizontalLine, btnAddAnotherAccount);
            var flxSpace = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "36dp",
                "id": "flxSpace",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "566dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpace.setDefaultUnit(kony.flex.DP);
            flxSpace.add();
            flxAcknowledgementContainer.add(CopyflxSurveyHeader0g535a03984564f, flxAcknowledgementMain, flxTransactionDetails, flxSpace);
            flxMainContainer.add(flxFeedback, flxFeedbackAcknowledgement, flxAcknowledgementContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var CustomFooterMain = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "CustomFooterMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(CustomFooterMain);
            flxFormContent.add(flxMainContainer, flxFooter);
            var flxPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1200
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(CustomPopup);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "AboutUsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeaderPreLogin": {
                        "height": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxBlueGradientHeader",
                        "segmentProps": []
                    },
                    "flxMainHeader": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnSkipContent": {
                        "isVisible": false,
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblKonyBank": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Feedback",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgReminder": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "64%"
                        },
                        "segmentProps": []
                    },
                    "btnLogin": {
                        "left": {
                            "type": "string",
                            "value": "534dp"
                        },
                        "text": "LOGIN",
                        "segmentProps": []
                    },
                    "flxSignin": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "imgLogout": {
                        "segmentProps": []
                    },
                    "flxHeaderPostLogin": {
                        "height": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "customheader.customhamburger.flxMenuWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxBottomBlue": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "Feedback",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblLoginMobile": {
                        "text": "Log in",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxFeedback": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackContainer": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarning": {
                        "segmentProps": []
                    },
                    "Feedback.AllForms": {
                        "left": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.LblAddFeatureRequest": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "text": "Add Feature Request",
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.confirmButtons": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.confirmButtons.btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.confirmButtons.btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.confirmButtons.flxHorizontalLine": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxAddFeatureRequest": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxAddFeatureRequestandimg": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxAddRequest": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Feedback.flxImgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxMain": {
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98.50%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxPlusIcon": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating2": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating3": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating4": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating5": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRatingimg": {
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxUserFeedback": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "Feedback.imgAdd": {
                        "segmentProps": []
                    },
                    "Feedback.imgInfo": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.imgInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "-1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.lblAddYourComments": {
                        "top": {
                            "type": "string",
                            "value": "165dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.lblCharCountComments": {
                        "top": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.lblPlusIcon": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.lblQuestion": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.lblRateYourExpeience": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.lblRatingtxt": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.txtareaUserAdditionalComments": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.txtareaUserComments": {
                        "top": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgement": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSurveyHeader": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSurvey": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgementSurvey": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementThankyouMessage": {
                        "height": {
                            "type": "string",
                            "value": "282dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98.60%"
                        },
                        "segmentProps": []
                    },
                    "imgSuccessGreen": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblThankYouMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "lblWeValue": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderAck": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Survey",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackDetails": {
                        "width": {
                            "type": "string",
                            "value": "98.60%"
                        },
                        "segmentProps": []
                    },
                    "confirmHeaders": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "instanceId": "confirmHeaders"
                    },
                    "confirmHeaders.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "confirmHeaders.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "btnDone": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopyflxSurveyHeader0g535a03984564f": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "height": {
                            "type": "string",
                            "value": "380dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.ImgAcknowledged": {
                        "height": {
                            "type": "string",
                            "value": "58dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "58dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment": {
                        "height": {
                            "type": "string",
                            "value": "380dp"
                        },
                        "segmentProps": [],
                        "instanceId": "acknowledgment"
                    },
                    "acknowledgment.confirmHeaders": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders.flxHeader": {
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders.lblHeading": {
                        "segmentProps": []
                    },
                    "acknowledgment.flxSeperator": {
                        "segmentProps": []
                    },
                    "acknowledgment.flxTakeSurvey": {
                        "top": {
                            "type": "string",
                            "value": "325px"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.lblRefrenceNumber": {
                        "top": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.lblTakeSurvey": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.lblTransactionMessage": {
                        "left": {
                            "type": "string",
                            "value": "89dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "75px"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "height": {
                            "type": "string",
                            "value": "530dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9noshadow",
                        "top": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.confirmHeaders": {
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.confirmHeaders.flxHeader": {
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.confirmHeaders.lblHeading": {
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.flxMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.flxQuestion1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.flxRateYourExperience": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.flxRatingimg": {
                        "top": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.flxaddress": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.lblAnswer1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.lblQuestion1": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.lblRateYourExpeience": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddAnotherAccount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSpace": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "566dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxMainHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgKony": {
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "right": {
                            "type": "string",
                            "value": "8.90%"
                        },
                        "segmentProps": []
                    },
                    "lblKonyBank": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "right": {
                            "type": "string",
                            "value": "14%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "imgReminder": {
                        "left": {
                            "type": "string",
                            "value": "61%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "btnLogin": {
                        "left": {
                            "type": "string",
                            "value": "670dp"
                        },
                        "segmentProps": []
                    },
                    "flxSignin": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgLogout": {
                        "segmentProps": []
                    },
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.imgLogout": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedback": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackContainer": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarning": {
                        "segmentProps": []
                    },
                    "Feedback.AllForms": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": [],
                        "instanceId": "Feedback"
                    },
                    "Feedback.LblAddFeatureRequest": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Add Feature Request",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.confirmButtons": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.confirmButtons.btnConfirm": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.confirmButtons.btnModify": {
                        "right": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxAddFeatureRequest": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "Feedback.flxAddFeatureRequestandimg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxAddRequest": {
                        "width": {
                            "type": "string",
                            "value": "17%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxHorizontalLine": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Feedback.flxImgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxMain": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxPlusIcon": {
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRatingimg": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxUserFeedback": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxaddress": {
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "Feedback.imgAdd": {
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.imgInfo": {
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.lblHeading": {
                        "segmentProps": []
                    },
                    "Feedback.lblRatingtxt": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.txtareaUserAdditionalComments": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "Feedback.txtareaUserComments": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgement": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxSurveyHeader": {
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSurvey": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "skin": "sknLabelSSP42424217px",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgementSurvey": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementThankyouMessage": {
                        "skin": "sknFFFFFFmodbr4pxbebebeshdw",
                        "segmentProps": []
                    },
                    "lblThankYouMsg": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "11%"
                        },
                        "skin": "sknSupportedFileTypes",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "lblWeValue": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxHeaderAck": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFeedbackDetails": {
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "segmentProps": []
                    },
                    "btnDone": {
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopyflxSurveyHeader0g535a03984564f": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopylblSurvey0cb6dc11415f44a": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.ImgAcknowledged": {
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "acknowledgment"
                    },
                    "acknowledgment.flxTakeSurvey": {
                        "top": {
                            "type": "string",
                            "value": "340px"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.lblRefrenceNumber": {
                        "top": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnAddAnotherAccount": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "440dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeaderPreLogin": {
                        "segmentProps": []
                    },
                    "flxMainHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "right": {
                            "type": "string",
                            "value": "140px"
                        },
                        "segmentProps": []
                    },
                    "FlexGroup0bb8635a53b8241": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "lblKonyBank": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgReminder": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnLogin": {
                        "left": {
                            "type": "string",
                            "value": "1227dp"
                        },
                        "text": "LOGIN",
                        "segmentProps": []
                    },
                    "flxSignin": {
                        "segmentProps": []
                    },
                    "imgLogout": {
                        "segmentProps": []
                    },
                    "flxHeaderPostLogin": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.imgLogout": {
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "Feedback",
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "left": {
                            "type": "string",
                            "value": "0.50%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "segmentProps": []
                    },
                    "flxFeedback": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackContainer": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88.40%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "Feedback.AllForms": {
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.LblAddFeatureRequest": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.confirmButtons": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxAddFeatureRequest": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "Feedback.flxAddFeatureRequestandimg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxAddRequest": {
                        "width": {
                            "type": "string",
                            "value": "17%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxImgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxMain": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRatingimg": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.lblHeading": {
                        "segmentProps": []
                    },
                    "Feedback.lblRatingtxt": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgement": {
                        "segmentProps": []
                    },
                    "flxSurveyHeader": {
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblSurvey": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgementSurvey": {
                        "segmentProps": []
                    },
                    "lblThankYouMsg": {
                        "skin": "sknLabel42424224px",
                        "segmentProps": []
                    },
                    "lblWeValue": {
                        "isVisible": false,
                        "skin": "sknLabel42424224px",
                        "segmentProps": []
                    },
                    "flxHeaderAck": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 100000,
                        "segmentProps": []
                    },
                    "lblAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine2": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "segmentProps": []
                    },
                    "btnDone": {
                        "focusSkin": "sknBtnHoverSSPFFFFFF15Px",
                        "skin": "sknBtnHoverSSPFFFFFF15Px",
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopyflxSurveyHeader0g535a03984564f": {
                        "width": {
                            "type": "string",
                            "value": "88.50%"
                        },
                        "segmentProps": []
                    },
                    "CopylblSurvey0cb6dc11415f44a": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "segmentProps": []
                    },
                    "btnAddAnotherAccount": {
                        "top": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeaderPreLogin": {
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "imgKony": {
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "right": {
                            "type": "string",
                            "value": "140px"
                        },
                        "segmentProps": []
                    },
                    "FlexGroup0bb8635a53b8241": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "lblKonyBank": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgReminder": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "number",
                            "value": "20"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderPostLogin": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxUserActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxResetUserImg": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxUserId": {
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoginMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedback": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxFeedbackContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "segmentProps": []
                    },
                    "Feedback.AllForms": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "Feedback": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "instanceId": "Feedback"
                    },
                    "Feedback.LblAddFeatureRequest": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Add Feature Request",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxAddFeatureRequestandimg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxImgInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating1": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating2": {
                        "left": {
                            "type": "string",
                            "value": "0.50%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating3": {
                        "left": {
                            "type": "string",
                            "value": "0.50%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating4": {
                        "left": {
                            "type": "string",
                            "value": "0.50%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRating5": {
                        "left": {
                            "type": "string",
                            "value": "0.50%"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxRatingimg": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.flxUserFeedback": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.imgAdd": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "Feedback.lblHeading": {
                        "segmentProps": []
                    },
                    "Feedback.lblRatingtxt": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgement": {
                        "segmentProps": []
                    },
                    "lblSurvey": {
                        "text": "Feedback",
                        "segmentProps": []
                    },
                    "flxFeedbackAcknowledgementSurvey": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderAck": {
                        "isVisible": false,
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblQuestion3": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "49.80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "CopyflxSurveyHeader0g535a03984564f": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "67dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders.flxHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.confirmHeaders.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgment.flxSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "21px"
                        },
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "67dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.confirmHeaders": {
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.confirmHeaders.flxHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.confirmHeaders.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.flxHorizontalLine": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.flxScrollContainerCustomerFeedback": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "357px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomerFeedbackDetails.flxaddress": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxHorizontalLine": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnAddAnotherAccount": {
                        "left": {
                            "type": "string",
                            "value": "75%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.customhamburger.imgCollapseAccounts": {
                    "src": "arrow_down.png"
                },
                "customheader.customhamburger.imgKony": {
                    "src": "kony_logo_white.png"
                },
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.imgKony": {
                    "left": "0dp",
                    "src": "kony_logo.png"
                },
                "customheader.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "Feedback.AllForms": {
                    "left": "100dp",
                    "top": "420dp"
                },
                "Feedback": {
                    "width": "100%"
                },
                "Feedback.LblAddFeatureRequest": {
                    "height": "25dp",
                    "text": "Label",
                    "top": "1dp"
                },
                "Feedback.confirmButtons": {
                    "height": "210px",
                    "top": "20dp"
                },
                "Feedback.confirmButtons.btnConfirm": {
                    "width": "150dp"
                },
                "Feedback.confirmButtons.btnModify": {
                    "right": "200dp",
                    "width": "150dp"
                },
                "Feedback.confirmButtons.flxHorizontalLine": {
                    "top": "0dp"
                },
                "Feedback.flxAddFeatureRequest": {
                    "top": "20dp"
                },
                "Feedback.flxAddFeatureRequestandimg": {
                    "left": "0dp",
                    "width": "100%",
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "Feedback.flxAddRequest": {
                    "width": "15%"
                },
                "Feedback.flxHeader": {
                    "height": "67dp",
                    "top": "0dp"
                },
                "Feedback.flxImgInfoIcon": {
                    "height": "25dp",
                    "left": "10dp",
                    "right": "",
                    "top": "4dp",
                    "width": "25dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "Feedback.flxMain": {
                    "bottom": "",
                    "minHeight": "",
                    "top": "67dp",
                    "width": "96.50%"
                },
                "Feedback.flxPlusIcon": {
                    "centerY": "",
                    "height": "24dp",
                    "width": "24dp"
                },
                "Feedback.flxRating": {
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "Feedback.flxRating1": {
                    "left": "10dp"
                },
                "Feedback.flxRatingimg": {
                    "left": "10dp",
                    "top": "81dp"
                },
                "Feedback.imgAdd": {
                    "height": "24dp",
                    "left": "4dp",
                    "src": "plus_icon.png",
                    "top": "4dp",
                    "width": "15dp"
                },
                "Feedback.imgInfo": {
                    "height": "15dp",
                    "left": "19.5%",
                    "src": "info_grey.png",
                    "top": "7dp",
                    "width": "15dp"
                },
                "Feedback.imgInfoIcon": {
                    "src": "info_grey.png",
                    "top": "0dp",
                    "width": "20dp"
                },
                "Feedback.lblAddYourComments": {
                    "top": "87dp"
                },
                "Feedback.lblCharCountComments": {
                    "top": "95dp"
                },
                "Feedback.lblHeading": {
                    "bottom": "15dp",
                    "centerY": "",
                    "height": "25dp",
                    "left": "0dp",
                    "top": "25dp"
                },
                "Feedback.lblPlusIcon": {
                    "height": "24dp",
                    "width": "19dp"
                },
                "Feedback.lblRateYourExpeience": {
                    "top": "0dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "Feedback.lblRatingtxt": {
                    "left": "26.50%"
                },
                "Feedback.txtareaUserComments": {
                    "bottom": "20dp",
                    "top": "120dp"
                },
                "confirmHeaders": {
                    "left": "0dp",
                    "top": "0dp",
                    "zIndex": 1
                },
                "confirmHeaders.lblHeading": {
                    "left": "2.10%"
                },
                "acknowledgment.ImgAcknowledged": {
                    "src": "success_green.png",
                    "top": "136dp"
                },
                "acknowledgment": {
                    "height": "410dp"
                },
                "acknowledgment.confirmHeaders": {
                    "top": "0dp"
                },
                "acknowledgment.confirmHeaders.flxHeader": {
                    "height": "50dp",
                    "top": "0dp",
                    "width": "100%"
                },
                "acknowledgment.confirmHeaders.lblHeading": {
                    "left": "2.50%",
                    "top": ""
                },
                "acknowledgment.flxSeperator": {
                    "centerX": "",
                    "left": "0px",
                    "top": "50dp",
                    "width": "100%"
                },
                "acknowledgment.flxTakeSurvey": {
                    "width": "30%"
                },
                "acknowledgment.lblRefrenceNumber": {
                    "top": "224dp"
                },
                "acknowledgment.lblRefrenceNumberValue": {
                    "top": "330dp"
                },
                "acknowledgment.lblTransactionMessage": {
                    "top": "90px"
                },
                "CustomerFeedbackDetails.confirmHeaders": {
                    "height": "50dp"
                },
                "CustomerFeedbackDetails.confirmHeaders.flxHeader": {
                    "height": "50dp",
                    "width": "100%"
                },
                "CustomerFeedbackDetails.confirmHeaders.lblHeading": {
                    "centerY": "50%",
                    "left": "2.50%",
                    "top": ""
                },
                "CustomerFeedbackDetails.flxHorizontalLine": {
                    "centerX": "",
                    "width": "100%"
                },
                "CustomerFeedbackDetails.flxQuestion1": {
                    "left": "0dp",
                    "top": "30dp"
                },
                "CustomerFeedbackDetails.flxRatingimg": {
                    "top": "31dp"
                },
                "CustomerFeedbackDetails.flxScrollContainerCustomerFeedback": {
                    "centerX": "",
                    "height": "345px",
                    "width": "100%"
                },
                "CustomerFeedbackDetails.flxaddress": {
                    "left": "18dp",
                    "width": "100%"
                },
                "CustomerFeedbackDetails.lblAnswer1": {
                    "top": "35dp",
                    "width": "80%"
                },
                "CustomerFeedbackDetails.lblcomments": {
                    "width": "80%"
                }
            }
            this.add(flxHeaderPreLogin, flxHeaderPostLogin, flxFormContent, flxPopup, flxLogout, flxLoading);
        };
        return [{
            "addWidgets": addWidgetsfrmCustomerFeedback,
            "enabledForIdleTimeout": true,
            "id": "frmCustomerFeedback",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_h0e63388a380494f8b404b73e01bd89f,
            "postShow": controller.AS_Form_c0671ee55270431889671eb0bea88a72,
            "preShow": function(eventobject) {
                controller.AS_Form_fb3f66c1ddce478e8b2bc220d94107c3(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Customer Feedback",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AboutUsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_b2492b13fe2c403b9d131432c35ebb80,
            "retainScrollPosition": false
        }]
    }
});