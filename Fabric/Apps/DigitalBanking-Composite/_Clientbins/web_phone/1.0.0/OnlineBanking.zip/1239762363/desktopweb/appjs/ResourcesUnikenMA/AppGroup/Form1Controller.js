define("ResourcesUnikenMA/AppGroup/userForm1Controller", {
    //Type your controller code here 
});
define("ResourcesUnikenMA/AppGroup/Form1ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("ResourcesUnikenMA/AppGroup/Form1Controller", ["ResourcesUnikenMA/AppGroup/userForm1Controller", "ResourcesUnikenMA/AppGroup/Form1ControllerActions"], function() {
    var controller = require("ResourcesUnikenMA/AppGroup/userForm1Controller");
    var controllerActions = ["ResourcesUnikenMA/AppGroup/Form1ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
