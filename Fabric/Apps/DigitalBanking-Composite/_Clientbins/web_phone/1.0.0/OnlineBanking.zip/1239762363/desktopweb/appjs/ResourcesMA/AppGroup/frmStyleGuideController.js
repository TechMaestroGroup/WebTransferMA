define("ResourcesMA/AppGroup/userfrmStyleGuideController", {
    //Type your controller code here 
});
define("ResourcesMA/AppGroup/frmStyleGuideControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("ResourcesMA/AppGroup/frmStyleGuideController", ["ResourcesMA/AppGroup/userfrmStyleGuideController", "ResourcesMA/AppGroup/frmStyleGuideControllerActions"], function() {
    var controller = require("ResourcesMA/AppGroup/userfrmStyleGuideController");
    var controllerActions = ["ResourcesMA/AppGroup/frmStyleGuideControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
