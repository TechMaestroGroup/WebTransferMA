define("ManageProfileMA/SettingsNewUIModule/frmeBankingAccess", function() {
    return function(controller) {
        function addWidgetsfrmeBankingAccess() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.profilesettings\")",
                        "isVisible": false
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblHeading",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Settingscapson\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "87.80%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.updateSettingAndPreferences\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Settings"
            });
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "maxHeight": "700dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "262dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "maxHeight": "700dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxBankingAccess = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBankingAccess",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "550dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankingAccess.setDefaultUnit(kony.flex.DP);
            var flxBankingAccessContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxBankingAccessContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "67dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "125dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankingAccessContainer.setDefaultUnit(kony.flex.DP);
            var flxEBankingAccessWrapper = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "98%",
                "id": "flxEBankingAccessWrapper",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 20,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEBankingAccessWrapper.setDefaultUnit(kony.flex.DP);
            var flxEBankingAccessMainHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxEBankingAccessMainHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEBankingAccessMainHeader.setDefaultUnit(kony.flex.DP);
            var lblEBamkingAccessHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblEBamkingAccessHeader",
                "isVisible": true,
                "left": "20dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profile.eBankingAccess\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEBankingAccessMainHeader.add(lblEBamkingAccessHeader);
            var flxEBankingAccessHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEBankingAccessHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEBankingAccessHeader.setDefaultUnit(kony.flex.DP);
            flxEBankingAccessHeader.add();
            var flxEBankingAccessMainContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80%",
                "id": "flxEBankingAccessMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEBankingAccessMainContainer.setDefaultUnit(kony.flex.DP);
            var flxEBankingAccessContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxEBankingAccessContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEBankingAccessContainer.setDefaultUnit(kony.flex.DP);
            var flxEBankingAccessMessageWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEBankingAccessMessageWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEBankingAccessMessageWrapper.setDefaultUnit(kony.flex.DP);
            var flxEBankingAccessInfoMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEBankingAccessInfoMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEBankingAccessInfoMessage.setDefaultUnit(kony.flex.DP);
            var flxInfoWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInfoWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoWrapper.setDefaultUnit(kony.flex.DP);
            var flxImgInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxImgInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "30dp",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgInfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "30dp",
                "id": "imgInfo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_icon_blue.png",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgInfo.add(imgInfo);
            var lblEBankingInfoMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEBankingInfoMessage",
                "isVisible": true,
                "left": "70dp",
                "right": "20dp",
                "skin": "ICSknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.settings.eBankingAccessInfoMessage\")",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoWrapper.add(flxImgInfo, lblEBankingInfoMessage);
            var gapflxInfoWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "20dp",
                "id": "gapflxInfoWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            gapflxInfoWrapper.setDefaultUnit(kony.flex.DP);
            gapflxInfoWrapper.add();
            flxEBankingAccessInfoMessage.add(flxInfoWrapper, gapflxInfoWrapper);
            flxEBankingAccessMessageWrapper.add(flxEBankingAccessInfoMessage);
            var flxListOfEntitiesContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxListOfEntitiesContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListOfEntitiesContainer.setDefaultUnit(kony.flex.DP);
            var flxListOfEntitiesWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxListOfEntitiesWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "skne3e3e3br3pxradius",
                "top": "0dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListOfEntitiesWrapper.setDefaultUnit(kony.flex.DP);
            var flxEntityTitle = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "48dp",
                "id": "flxEntityTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEntityTitle.setDefaultUnit(kony.flex.DP);
            var lblEntityTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "h3"
                },
                "id": "lblEntityTitle",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPSemiBold42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Profile.Entities\")",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            var flxSearchWrapper = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSearchWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "sknBorderE3E3E3",
                "top": "10dp",
                "width": "335dp",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchWrapper.setDefaultUnit(kony.flex.DP);
            var flxSearchIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Search icon"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSearchIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "top": "0",
                "width": "20dp",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchIcon.setDefaultUnit(kony.flex.DP);
            var lblSearchIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblSearchIcon",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknlblSearchfonticon19px0273e3",
                "text": "e",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIcon.add(lblSearchIcon);
            var tbxSearchBox = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "height": "100%",
                "id": "tbxSearchBox",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"kony.mb.settings.searchByEntityName\")",
                "secureTextEntry": false,
                "skin": "tbxPlaceholderskna0a0a015px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [33, 10, 100, 12],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxClearSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.CLEARSEARCH\")"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxClearSearch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10dp",
                "top": "0",
                "width": "20dp",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClearSearch.setDefaultUnit(kony.flex.DP);
            var imgClearSearch = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgClearSearch",
                "isVisible": true,
                "left": "0",
                "src": "closewealth.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClearSearch.add(imgClearSearch);
            flxSearchWrapper.add(flxSearchIcon, tbxSearchBox, flxClearSearch);
            flxEntityTitle.add(lblEntityTitle, flxSeparator1, flxSearchWrapper);
            var flxSelectAll = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSelectAll",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxf9f9f9",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAll.setDefaultUnit(kony.flex.DP);
            var flxImgCheckBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-checked": false,
                        "aria-labelledby": "lblSelectAll",
                        "role": "checkbox",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxImgCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "top": 0,
                "width": "20dp",
                "zIndex": 10,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgCheckBox.setDefaultUnit(kony.flex.DP);
            var imgSelectAll = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgSelectAll",
                "isVisible": true,
                "left": "0",
                "src": "inactivecheckbox.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgCheckBox.add(imgSelectAll);
            var lblSelectAll = new kony.ui.Label({
                "id": "lblSelectAll",
                "isVisible": true,
                "left": "49dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.selectAll\")",
                "top": "11dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            flxSelectAll.add(flxImgCheckBox, lblSelectAll, flxSeparator2);
            var flxListOfEntities = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxListOfEntities",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListOfEntities.setDefaultUnit(kony.flex.DP);
            var segListOfEntities = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "btnTnC": "Terms & Conditions",
                    "imgSelect": "inactivecheckbox.png",
                    "imgStatus": "bb_user_active1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblEntityName": "HSBC Bank India",
                    "lblEntityStatus": "Active",
                    "lblIAccept": "I accept the"
                }, {
                    "btnTnC": "Terms & Conditions",
                    "imgSelect": "inactivecheckbox.png",
                    "imgStatus": "bb_user_active1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblEntityName": "HSBC Bank India",
                    "lblEntityStatus": "Active",
                    "lblIAccept": "I accept the"
                }, {
                    "btnTnC": "Terms & Conditions",
                    "imgSelect": "inactivecheckbox.png",
                    "imgStatus": "bb_user_active1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblEntityName": "HSBC Bank India",
                    "lblEntityStatus": "Active",
                    "lblIAccept": "I accept the"
                }, {
                    "btnTnC": "Terms & Conditions",
                    "imgSelect": "inactivecheckbox.png",
                    "imgStatus": "bb_user_active1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblEntityName": "HSBC Bank India",
                    "lblEntityStatus": "Active",
                    "lblIAccept": "I accept the"
                }, {
                    "btnTnC": "Terms & Conditions",
                    "imgSelect": "inactivecheckbox.png",
                    "imgStatus": "bb_user_active1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblEntityName": "HSBC Bank India",
                    "lblEntityStatus": "Active",
                    "lblIAccept": "I accept the"
                }, {
                    "btnTnC": "Terms & Conditions",
                    "imgSelect": "inactivecheckbox.png",
                    "imgStatus": "bb_user_active1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblEntityName": "HSBC Bank India",
                    "lblEntityStatus": "Active",
                    "lblIAccept": "I accept the"
                }],
                "groupCells": false,
                "id": "segListOfEntities",
                "isVisible": true,
                "left": "0",
                "maxHeight": "291dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ManageProfileMA",
                    "friendlyName": "flxEBankingListOfEntities"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnTnC": "btnTnC",
                    "flxDefaultEntity": "flxDefaultEntity",
                    "flxEBankingListOfEntities": "flxEBankingListOfEntities",
                    "flxEntity": "flxEntity",
                    "flxImgStatus": "flxImgStatus",
                    "flxMainWrapper": "flxMainWrapper",
                    "flxSelect": "flxSelect",
                    "flxSeparator": "flxSeparator",
                    "flxStatus": "flxStatus",
                    "flxTnC": "flxTnC",
                    "imgSelect": "imgSelect",
                    "imgStatus": "imgStatus",
                    "lblDefaultEntity": "lblDefaultEntity",
                    "lblEntityName": "lblEntityName",
                    "lblEntityStatus": "lblEntityStatus",
                    "lblIAccept": "lblIAccept"
                },
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxListOfEntities.add(segListOfEntities);
            flxListOfEntitiesWrapper.add(flxEntityTitle, flxSelectAll, flxListOfEntities);
            flxListOfEntitiesContainer.add(flxListOfEntitiesWrapper);
            flxEBankingAccessContainer.add(flxEBankingAccessMessageWrapper, flxListOfEntitiesContainer);
            var flxEBankingAccessNotification = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "171dp",
                "id": "flxEBankingAccessNotification",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "19dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEBankingAccessNotification.setDefaultUnit(kony.flex.DP);
            var flxEBankingAccessInfo = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "70dp",
                "id": "flxEBankingAccessInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEBankingAccessInfo.setDefaultUnit(kony.flex.DP);
            var imgEBankingAccessNotification = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgEBankingAccessNotification",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "20dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEBankingAccessNotification = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblEBankingAccessNotification",
                "isVisible": true,
                "left": "20dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profile.eBankingDescription\")",
                "top": "20dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEBankingAccessInfo.add(imgEBankingAccessNotification, lblEBankingAccessNotification);
            var flxEBankingAccessNote = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100dp",
                "id": "flxEBankingAccessNote",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEBankingAccessNote.setDefaultUnit(kony.flex.DP);
            var flxRules = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "30dp",
                "id": "flxRules",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRules.setDefaultUnit(kony.flex.DP);
            var lblRulesEBankingAcces = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblRulesEBankingAcces",
                "isVisible": true,
                "left": "70dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profile.pleaseNote\")",
                "top": 10,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRules.add(lblRulesEBankingAcces);
            var flxSecurityRuleEbankingAccess = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "17dp",
                "id": "flxSecurityRuleEbankingAccess",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "90dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 8,
                "width": "90%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecurityRuleEbankingAccess.setDefaultUnit(kony.flex.DP);
            var imgSecurityRuleEBA1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "8dp",
                "id": "imgSecurityRuleEBA1",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "pageoffdot.png",
                "width": "8dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSecurityRuleEBA1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50.00%",
                "id": "lblSecurityRuleEBA1",
                "isVisible": true,
                "left": "1.08%",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profile.eBankingTandC\")",
                "top": "0dp",
                "width": "75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSecurityRuleEbankingAccess.add(imgSecurityRuleEBA1, lblSecurityRuleEBA1);
            var flxSecurityRuleEBA2 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "17dp",
                "id": "flxSecurityRuleEBA2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "90dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 10,
                "width": "90%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecurityRuleEBA2.setDefaultUnit(kony.flex.DP);
            var imgSecurityRuleEBA2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "8dp",
                "id": "imgSecurityRuleEBA2",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "pageoffdot.png",
                "width": "8dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSecurityRuleEBA2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50.00%",
                "id": "lblSecurityRuleEBA2",
                "isVisible": true,
                "left": "1.08%",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.logout.reachOutBank\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSecurityRuleEBA2.add(imgSecurityRuleEBA2, lblSecurityRuleEBA2);
            flxEBankingAccessNote.add(flxRules, flxSecurityRuleEbankingAccess, flxSecurityRuleEBA2);
            flxEBankingAccessNotification.add(flxEBankingAccessInfo, flxEBankingAccessNote);
            var flxIAgree = new kony.ui.FlexContainer({
                "bottom": "30px",
                "clipBounds": false,
                "height": "25px",
                "id": "flxIAgree",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "90%",
                "zIndex": 2,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIAgree.setDefaultUnit(kony.flex.DP);
            var flxCheckbox = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "30dp",
                "id": "flxCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 2,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxCheckbox.setDefaultUnit(kony.flex.DP);
            var imgChecbox = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20px",
                "id": "imgChecbox",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "0%",
                "skin": "slImage",
                "src": "unchecked_box.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRememberMeIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblRememberMeIcon",
                "isVisible": true,
                "skin": "sknlblOLBFonts0273E420pxOlbFontIcons",
                "text": "D",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckbox.add(imgChecbox, lblRememberMeIcon);
            var lblAgree = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblAgree",
                "isVisible": true,
                "left": "14dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IAccept\")",
                "top": "4px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnTermsAndConditionsEbankingaccess = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "id": "btnTermsAndConditionsEbankingaccess",
                "isVisible": true,
                "left": "0.50%",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "4px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Terms & Conditions"
            });
            flxIAgree.add(flxCheckbox, lblAgree, btnTermsAndConditionsEbankingaccess);
            flxEBankingAccessMainContainer.add(flxEBankingAccessContainer, flxEBankingAccessNotification, flxIAgree);
            var flxAcknowledgementWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcknowledgementWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "minHeight": "570dp",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementWrapper.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgement = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcknowledgement",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "minHeight": "140dp",
                "isModalContainer": false,
                "right": "20dp",
                "top": "20dp",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgement.setDefaultUnit(kony.flex.DP);
            var lblConfirmationMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblConfirmationMessage",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknSSP42424220Px",
                "text": "You have successfully disabled e-banking access for  HSBC Vietnam.",
                "top": "0dp",
                "width": "432dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxConfirmationTick = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxConfirmationTick",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "70dp",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmationTick.setDefaultUnit(kony.flex.DP);
            var imgConfirmationTick = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgConfirmationTick",
                "isVisible": true,
                "left": "0",
                "src": "confirmation_tick.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConfirmationTick.add(imgConfirmationTick);
            var lblConfirmationDescription = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "19dp",
                "id": "lblConfirmationDescription",
                "isVisible": false,
                "left": "0",
                "skin": "ICSknLbl42424215PX",
                "text": " Your default entity has been disabled. Go to entity preference to select default entity.",
                "top": "40dp",
                "width": "533dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAcknowledgement.add(lblConfirmationMessage, flxConfirmationTick, lblConfirmationDescription);
            flxAcknowledgementWrapper.add(flxAcknowledgement);
            var flxEditSeperatorWrapper = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "1dp",
                "id": "flxEditSeperatorWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditSeperatorWrapper.setDefaultUnit(kony.flex.DP);
            var flxEditSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEditSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditSeparator1.setDefaultUnit(kony.flex.DP);
            flxEditSeparator1.add();
            flxEditSeperatorWrapper.add(flxEditSeparator1);
            var flxEBankingAccessButtons = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": true,
                "height": "80px",
                "id": "flxEBankingAccessButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEBankingAccessButtons.setDefaultUnit(kony.flex.DP);
            var btnEBankingAccessSave = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnEBankingAccessSave",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profile.eBankingDisable\")",
                "width": "250dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtn3343a8Border3343a82pxRadius2pxhover"
            });
            flxEBankingAccessButtons.add(btnEBankingAccessSave);
            flxEBankingAccessWrapper.add(flxEBankingAccessMainHeader, flxEBankingAccessHeader, flxEBankingAccessMainContainer, flxAcknowledgementWrapper, flxEditSeperatorWrapper, flxEBankingAccessButtons);
            flxBankingAccessContainer.add(flxEBankingAccessWrapper);
            flxBankingAccess.add(flxBankingAccessContainer);
            flxRight.add(flxBankingAccess);
            flxContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxMainContainer.add(flxContainer);
            flxMain.add(lblHeading, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditions = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "102%",
                "horizontalScrollIndicator": true,
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1001
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "760dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "ICSknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "30dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": false,
                "right": "0%",
                "skin": "sknImgPointer5vs",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            var lblCrossIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span",
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblCrossIcon",
                "isVisible": false,
                "skin": "sknOlbFonts0273e317px",
                "text": "g",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnClose = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "btnClose",
                "isVisible": true,
                "left": "5dp",
                "skin": "btnCloseskn",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgClose, lblCrossIcon, btnClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\n<b>Description of eStatements</b>\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\n<b>Registration for eStatements</b>\n<br/>\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\n<b>Eligible Accounts For eStatements</b>\n<br/>\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\n<br/>\n<b>Enrollment For eStatement Delivery</b>\n<br/>\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\n<b>Change In Terms and Conditions</b>\n<br/>\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\n<b>Termination</b>\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\n<b>Miscellaneous</b>\n<br/>\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC);
            var flxSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator2",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxScrollDetails = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": true,
                "height": "98%",
                "id": "flxScrollDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetails.setDefaultUnit(kony.flex.DP);
            var CopyflxDummy0bd516b5896c94c = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "clipBounds": true,
                "height": "12dp",
                "id": "CopyflxDummy0bd516b5896c94c",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxDummy0bd516b5896c94c.setDefaultUnit(kony.flex.DP);
            CopyflxDummy0bd516b5896c94c.add();
            var flxBody = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": true,
                "height": "98%",
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var brwBodyTnC = new kony.ui.Browser({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "brwBodyTnC",
                "isVisible": true,
                "left": "2%",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxBody.add(brwBodyTnC);
            var flxSpacing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxScrollDetails.add(CopyflxDummy0bd516b5896c94c, flxBody, flxSpacing);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxSeperator2, flxScrollDetails);
            flxTermsAndConditions.add(flxTC);
            var flxDeletePopUp = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1001
            }, {
                "paddingInPixel": false
            }, {});
            flxDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxDelete = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxDelete",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDelete.setDefaultUnit(kony.flex.DP);
            var flxDeleteHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDeleteClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxDeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "30dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteClose.setDefaultUnit(kony.flex.DP);
            var CopyimgDeleteClose0ee315396d8944f = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "CopyimgDeleteClose0ee315396d8944f",
                "isVisible": false,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcross = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "label"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblcross",
                "isVisible": false,
                "skin": "sknOlbFonts0273e317px",
                "text": "g",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDeleteClose = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "btnDeleteClose",
                "isVisible": true,
                "left": "5dp",
                "skin": "btnCloseskn",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeleteClose.add(CopyimgDeleteClose0ee315396d8944f, lblcross, btnDeleteClose);
            flxDeleteHeader.add(lblDeleteHeader, flxDeleteClose);
            var flxDeleteSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxDeleteSeperator.add();
            var flxDeleteContents = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxDeleteContents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteContents.setDefaultUnit(kony.flex.DP);
            var lblConfirmDelete = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblConfirmDelete",
                "isVisible": true,
                "left": "3.38%",
                "skin": "ICSknSSP42424220Px",
                "text": "Are you sure you want to Delete this Phone Number?",
                "top": 0,
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeleteContents.add(lblConfirmDelete);
            var flxDiabledListOfEntities = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDiabledListOfEntities",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3.30%",
                "isModalContainer": false,
                "top": "24dp",
                "width": "85%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDiabledListOfEntities.setDefaultUnit(kony.flex.DP);
            var segDisabledListOfEntities = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgInactive": "greyicon_1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblDisabledEntity": "HSBC BANK OF UK"
                }, {
                    "imgInactive": "greyicon_1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblDisabledEntity": "HSBC BANK OF UK"
                }, {
                    "imgInactive": "greyicon_1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblDisabledEntity": "HSBC BANK OF UK"
                }, {
                    "imgInactive": "greyicon_1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblDisabledEntity": "HSBC BANK OF UK"
                }, {
                    "imgInactive": "greyicon_1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblDisabledEntity": "HSBC BANK OF UK"
                }, {
                    "imgInactive": "greyicon_1.png",
                    "lblDefaultEntity": "Default Entity",
                    "lblDisabledEntity": "HSBC BANK OF UK"
                }],
                "groupCells": false,
                "id": "segDisabledListOfEntities",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ManageProfileMA",
                    "friendlyName": "flxDisabledListOfEntities"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDefaultEntity": "flxDefaultEntity",
                    "flxDisabledEntityName": "flxDisabledEntityName",
                    "flxDisabledListOfEntities": "flxDisabledListOfEntities",
                    "flxInActiveImg": "flxInActiveImg",
                    "flxMain": "flxMain",
                    "flxSeparator": "flxSeparator",
                    "imgInactive": "imgInactive",
                    "lblDefaultEntity": "lblDefaultEntity",
                    "lblDisabledEntity": "lblDisabledEntity"
                },
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDiabledListOfEntities.add(segDisabledListOfEntities);
            var flxDeleteSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxDeleteSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteSeperator2.setDefaultUnit(kony.flex.DP);
            flxDeleteSeperator2.add();
            var flxInfoMsgLogout = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "30dp",
                "id": "flxInfoMsgLogout",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoMsgLogout.setDefaultUnit(kony.flex.DP);
            var imgWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "15dp",
                "id": "imgWarning",
                "isVisible": true,
                "left": "10dp",
                "src": "aa_password_error.png",
                "top": "2dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarningMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblWarningMsg",
                "isVisible": true,
                "left": "0%",
                "skin": "CopysknLblSSP1",
                "text": "For security reasons, selecting \"yes\" will log you out of all sessions",
                "top": 0,
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoMsgLogout.add(imgWarning, lblWarningMsg);
            var flxDeleteButtons = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": true,
                "height": "80px",
                "id": "flxDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnDeleteYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "40dp",
                "id": "btnDeleteYes",
                "isVisible": true,
                "left": "0",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "text": "Yes",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnDeleteNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "40dp",
                "id": "btnDeleteNo",
                "isVisible": true,
                "left": "0",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "text": "NO",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxDeleteButtons.add(btnDeleteYes, btnDeleteNo);
            flxDelete.add(flxDeleteHeader, flxDeleteSeperator, flxDeleteContents, flxDiabledListOfEntities, flxDeleteSeperator2, flxInfoMsgLogout, flxDeleteButtons);
            flxDeletePopUp.add(flxDelete);
            var flxLogout = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "height": "268dp",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "height": "268dp",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxTermsAndConditions, flxDeletePopUp, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmeBankingAccess": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Profile Settings",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "minHeight": {
                            "type": "string",
                            "value": "510dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "minHeight": {
                            "type": "string",
                            "value": "540dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxBankingAccess": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "485dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc3",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBankingAccessContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "485dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "485dp"
                        },
                        "zIndex": 20,
                        "segmentProps": []
                    },
                    "lblEBamkingAccessHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxEBankingAccessMainContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessMessageWrapper": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessInfoMessage": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfoWrapper": {
                        "top": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgInfo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblEBankingInfoMessage": {
                        "left": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxListOfEntitiesWrapper": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblEntityTitle": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "flxSearchWrapper": {
                        "height": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "211dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchIcon": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "tbxSearchBox": {
                        "padding": [35, 8, 35, 8],
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxImgCheckBox": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectAll": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "ICSknLblSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "segListOfEntities": {
                        "data": [{
                            "btnTnC": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Terms and Conditions"
                            },
                            "imgSelect": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "inactivecheckbox.png"
                            },
                            "imgStatus": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bb_user_active1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblEntityName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC Bank India"
                            },
                            "lblEntityStatus": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Active"
                            },
                            "lblIAccept": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "I accept the"
                            }
                        }, {
                            "btnTnC": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Terms and Conditions"
                            },
                            "imgSelect": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "inactivecheckbox.png"
                            },
                            "imgStatus": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bb_user_active1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblEntityName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC Bank India"
                            },
                            "lblEntityStatus": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Active"
                            },
                            "lblIAccept": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "I accept the"
                            }
                        }, {
                            "btnTnC": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Terms and Conditions"
                            },
                            "imgSelect": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "inactivecheckbox.png"
                            },
                            "imgStatus": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bb_user_active1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblEntityName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC Bank India"
                            },
                            "lblEntityStatus": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Active"
                            },
                            "lblIAccept": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "I accept the"
                            }
                        }, {
                            "btnTnC": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Terms and Conditions"
                            },
                            "imgSelect": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "inactivecheckbox.png"
                            },
                            "imgStatus": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bb_user_active1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblEntityName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC Bank India"
                            },
                            "lblEntityStatus": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Active"
                            },
                            "lblIAccept": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "I accept the"
                            }
                        }, {
                            "btnTnC": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Terms and Conditions"
                            },
                            "imgSelect": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "inactivecheckbox.png"
                            },
                            "imgStatus": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bb_user_active1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblEntityName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC Bank India"
                            },
                            "lblEntityStatus": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Active"
                            },
                            "lblIAccept": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "I accept the"
                            }
                        }, {
                            "btnTnC": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Terms and Conditions"
                            },
                            "imgSelect": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "inactivecheckbox.png"
                            },
                            "imgStatus": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "bb_user_active1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblEntityName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC Bank India"
                            },
                            "lblEntityStatus": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Active"
                            },
                            "lblIAccept": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "I accept the"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ManageProfileMA",
                            "friendlyName": "flxEBankingListOfEntitiesMobile"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "btnTnC": "btnTnC",
                            "flxDefaultEntity": "flxDefaultEntity",
                            "flxEBankingListOfEntitiesMobile": "flxEBankingListOfEntitiesMobile",
                            "flxEntity": "flxEntity",
                            "flxImgStatus": "flxImgStatus",
                            "flxMainWrapper": "flxMainWrapper",
                            "flxSelect": "flxSelect",
                            "flxSeparator": "flxSeparator",
                            "flxStatus": "flxStatus",
                            "flxTnC": "flxTnC",
                            "imgSelect": "imgSelect",
                            "imgStatus": "imgStatus",
                            "lblDefaultEntity": "lblDefaultEntity",
                            "lblEntityName": "lblEntityName",
                            "lblEntityStatus": "lblEntityStatus",
                            "lblIAccept": "lblIAccept"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ManageProfileMA"
                    },
                    "flxEBankingAccessNotification": {
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessInfo": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "imgEBankingAccessNotification": {
                        "height": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "lblEBankingAccessNotification": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknlblSSP42424211px",
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessNote": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxRules": {
                        "maxHeight": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "lblRulesEBankingAcces": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknlblSSP42424211pxBold",
                        "segmentProps": []
                    },
                    "flxSecurityRuleEbankingAccess": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgSecurityRuleEBA1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSecurityRuleEBA1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknlblSSP42424211px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSecurityRuleEBA2": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgSecurityRuleEBA2": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSecurityRuleEBA2": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknlblSSP42424211px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxIAgree": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxCheckbox": {
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblAgree": {
                        "skin": "sknLblSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "6px"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditionsEbankingaccess": {
                        "skin": "bbSknBtn4176a4NoBorder13px",
                        "top": {
                            "type": "string",
                            "value": "6px"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementWrapper": {
                        "minHeight": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmationMessage": {
                        "skin": "slLabel424242Regular15px",
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmationTick": {
                        "height": {
                            "type": "string",
                            "value": "64dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "64dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmationDescription": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "skin": "ICSknLblSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditSeperatorWrapper": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditSeparator1": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessButtons": {
                        "segmentProps": []
                    },
                    "btnEBankingAccessSave": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTC": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "80%"
                        },
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsHeader": {
                        "segmentProps": []
                    },
                    "flxScrollDetails": {
                        "height": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxBody": {
                        "height": {
                            "type": "string",
                            "value": "92%"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDeleteHeader": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxDeleteContents": {
                        "segmentProps": []
                    },
                    "lblConfirmDelete": {
                        "segmentProps": []
                    },
                    "segDisabledListOfEntities": {
                        "data": [{
                            "imgInactive": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "greyicon_1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblDisabledEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC BANK OF UK"
                            }
                        }, {
                            "imgInactive": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "greyicon_1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblDisabledEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC BANK OF UK"
                            }
                        }, {
                            "imgInactive": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "greyicon_1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblDisabledEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC BANK OF UK"
                            }
                        }, {
                            "imgInactive": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "greyicon_1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblDisabledEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC BANK OF UK"
                            }
                        }, {
                            "imgInactive": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "greyicon_1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblDisabledEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC BANK OF UK"
                            }
                        }, {
                            "imgInactive": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "greyicon_1.png"
                            },
                            "lblDefaultEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Default Entity"
                            },
                            "lblDisabledEntity": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "HSBC BANK OF UK"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ManageProfileMA",
                            "friendlyName": "flxDisabledListOfEntitiesMobile"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxDefaultEntity": "flxDefaultEntity",
                            "flxDisabledEntityName": "flxDisabledEntityName",
                            "flxDisabledListOfEntitiesMobile": "flxDisabledListOfEntitiesMobile",
                            "flxInActiveImg": "flxInActiveImg",
                            "flxMain": "flxMain",
                            "flxSeparator": "flxSeparator",
                            "imgInactive": "imgInactive",
                            "lblDefaultEntity": "lblDefaultEntity",
                            "lblDisabledEntity": "lblDisabledEntity"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ManageProfileMA"
                    },
                    "flxDeleteSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfoMsgLogout": {
                        "segmentProps": []
                    },
                    "lblWarningMsg": {
                        "text": "For security reasons, selecting \"yes\" will log you out of all sessions",
                        "segmentProps": []
                    },
                    "flxDeleteButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "segmentProps": []
                    },
                    "CustomPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "segmentProps": []
                    },
                    "flxRight": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBankingAccess": {
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBankingAccessContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "lblEBamkingAccessHeader": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxEBankingAccessMainContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "570dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessMessageWrapper": {
                        "segmentProps": []
                    },
                    "flxEBankingAccessInfoMessage": {
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "segmentProps": []
                    },
                    "lblEBankingInfoMessage": {
                        "skin": "ICSknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "gapflxInfoWrapper": {
                        "segmentProps": []
                    },
                    "flxListOfEntitiesWrapper": {
                        "segmentProps": []
                    },
                    "flxEntityTitle": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblEntityTitle": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator1": {
                        "segmentProps": []
                    },
                    "flxSearchWrapper": {
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "tbxSearchBox": {
                        "padding": [35, 10, 13, 10],
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxEBankingAccessNotification": {
                        "height": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessInfo": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "imgEBankingAccessNotification": {
                        "segmentProps": []
                    },
                    "lblEBankingAccessNotification": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxRules": {
                        "segmentProps": []
                    },
                    "lblRulesEBankingAcces": {
                        "left": {
                            "type": "string",
                            "value": "15.50%"
                        },
                        "skin": "sknLblSSP46464615pxbold",
                        "segmentProps": []
                    },
                    "flxSecurityRuleEbankingAccess": {
                        "height": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "segmentProps": []
                    },
                    "imgSecurityRuleEBA1": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblSecurityRuleEBA1": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxSecurityRuleEBA2": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgSecurityRuleEBA2": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblSecurityRuleEBA2": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxIAgree": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxCheckbox": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgChecbox": {
                        "segmentProps": []
                    },
                    "lblAgree": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditionsEbankingaccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblConfirmationDescription": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "428dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditSeparator1": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxEBankingAccessButtons": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTC": {
                        "height": {
                            "type": "string",
                            "value": "80%"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxScrollDetails": {
                        "height": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxBody": {
                        "height": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmDelete": {
                        "segmentProps": []
                    },
                    "lblWarningMsg": {
                        "segmentProps": []
                    },
                    "flxDeleteButtons": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "skin": "sknlblUserName",
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "flxBankingAccess": {
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "flxBankingAccessContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "lblEBamkingAccessHeader": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxEBankingAccessMainContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "570dp"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessMessageWrapper": {
                        "segmentProps": []
                    },
                    "lblEBankingInfoMessage": {
                        "segmentProps": []
                    },
                    "flxListOfEntitiesWrapper": {
                        "segmentProps": []
                    },
                    "tbxSearchBox": {
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxEBankingAccessNotification": {
                        "height": {
                            "type": "string",
                            "value": "171dp"
                        },
                        "segmentProps": []
                    },
                    "lblEBankingAccessNotification": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxRules": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblRulesEBankingAcces": {
                        "skin": "sknLblSSP46464615pxbold",
                        "segmentProps": []
                    },
                    "flxSecurityRuleEbankingAccess": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgSecurityRuleEBA1": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblSecurityRuleEBA1": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "skin": "slLabel0d8a72616b3cc47",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxSecurityRuleEBA2": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgSecurityRuleEBA2": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblSecurityRuleEBA2": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxIAgree": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxCheckbox": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblAgree": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditionsEbankingaccess": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnEBankingAccessSave": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTC": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxScrollDetails": {
                        "height": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxBody": {
                        "height": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxDeleteContents": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmDelete": {
                        "segmentProps": []
                    },
                    "flxInfoMsgLogout": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarningMsg": {
                        "segmentProps": []
                    },
                    "flxDeleteButtons": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmeBankingAccess": {
                        "segmentProps": []
                    },
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "1202dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "segmentProps": []
                    },
                    "flxBankingAccess": {
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBankingAccessContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "lblEBamkingAccessHeader": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxEBankingAccessMainContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "570dp"
                        },
                        "segmentProps": []
                    },
                    "flxEBankingAccessMessageWrapper": {
                        "segmentProps": []
                    },
                    "lblEBankingInfoMessage": {
                        "segmentProps": []
                    },
                    "flxListOfEntitiesWrapper": {
                        "segmentProps": []
                    },
                    "tbxSearchBox": {
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxEBankingAccessNotification": {
                        "height": {
                            "type": "string",
                            "value": "171dp"
                        },
                        "segmentProps": []
                    },
                    "lblEBankingAccessNotification": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxEBankingAccessNote": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxRules": {
                        "segmentProps": []
                    },
                    "lblRulesEBankingAcces": {
                        "skin": "sknLblSSP46464615pxbold",
                        "segmentProps": []
                    },
                    "flxSecurityRuleEbankingAccess": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgSecurityRuleEBA1": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblSecurityRuleEBA1": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxSecurityRuleEBA2": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgSecurityRuleEBA2": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblSecurityRuleEBA2": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxIAgree": {
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxCheckbox": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgChecbox": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblRememberMeIcon": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAgree": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditionsEbankingaccess": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTC": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "80%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxScrollDetails": {
                        "height": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxBody": {
                        "height": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteHeader": {
                        "segmentProps": []
                    },
                    "flxDeleteContents": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmDelete": {
                        "segmentProps": []
                    },
                    "flxInfoMsgLogout": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "imgWarning": {
                        "segmentProps": []
                    },
                    "lblWarningMsg": {
                        "segmentProps": []
                    },
                    "flxDeleteButtons": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "height": "268dp",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmeBankingAccess,
            "enabledForIdleTimeout": true,
            "id": "frmeBankingAccess",
            "init": controller.AS_Form_j41fa4ef3212481ea39754101b76dfbd,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.profilemanagement.DisableeBankingAccess\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ManageProfileMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});