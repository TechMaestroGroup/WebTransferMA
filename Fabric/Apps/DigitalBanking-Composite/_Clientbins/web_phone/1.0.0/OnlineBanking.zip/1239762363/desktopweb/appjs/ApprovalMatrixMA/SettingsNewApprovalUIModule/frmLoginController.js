define("ApprovalMatrixMA/SettingsNewApprovalUIModule/userfrmLoginController", {
    //Type your controller code here 
    updateFormUI: function(obj) {}
});
define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmLoginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnLogin **/
    AS_Button_ad0d15bb20db40088ef4abdb1585c900: function AS_Button_ad0d15bb20db40088ef4abdb1585c900(eventobject) {
        var self = this;
        kony.application.showLoadingScreen("", "Authenticating the user");
        var authParams = {
            "UserName": "7644257870",
            "Password": "Kony@1234",
            "loginOptions": {
                "isOfflineEnabled": false
            }
        };
        authClient = KNYMobileFabric.getIdentityService("DbxUserLogin");
        authClient.login(authParams, successCallback, errorCallback);

        function successCallback(resSuccess) {
            kony.application.dismissLoadingScreen();
            kony.print(resSuccess);
            var settingsModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("SettingsNewUIModule");
            settingsModule.presentationController.enterProfileSettings("approvalMatrix");
        }

        function errorCallback(resError) {
            kony.application.dismissLoadingScreen();
            kony.print(resError);
            alert("login is not working...")
        }
    },
    /** postShow defined for frmLogin **/
    AS_Form_ee655c9068334f69b544b5d1ea5f0122: function AS_Form_ee655c9068334f69b544b5d1ea5f0122(eventobject) {
        var self = this;
        kony.application.showLoadingScreen("", "Authenticating the user");
        var authParams = {
            "UserName": "7465350930",
            "Password": "Kony@1234",
            "loginOptions": {
                "isOfflineEnabled": false
            }
        };
        authClient = KNYMobileFabric.getIdentityService("DbxUserLogin");
        authClient.login(authParams, successCallback, errorCallback);

        function successCallback(resSuccess) {
            kony.application.dismissLoadingScreen();
            kony.print(resSuccess);
            var providerTokenParams = kony.sdk.getCurrentInstance().tokens[applicationManager.getConfigurationManager().constants.IDENTITYSERVICENAME].provider_token.params;
            var securityAttributes = providerTokenParams.security_attributes;
            var userAttributes = providerTokenParams.user_attributes;
            var permissions = JSON.parse(securityAttributes.permissions);
            applicationManager.getConfigurationManager().setUserPermissions(permissions);
            applicationManager.fetchAppProperties();
            applicationManager.getUserPreferencesManager().fetchUser(userSuccess, userError);
        }

        function errorCallback(resError) {
            kony.application.dismissLoadingScreen();
            kony.print(resError);
            alert("login is not working...")
        }

        function userSuccess(res) {
            var settingsModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("SettingsNewUIModule");
            settingsModule.presentationController.enterProfileSettings("approvalMatrix");
        }

        function userError(resError) {
            kony.application.dismissLoadingScreen();
            kony.print(resError);
            alert("fetch user is not working...")
        }
    }
});
define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmLoginController", ["ApprovalMatrixMA/SettingsNewApprovalUIModule/userfrmLoginController", "ApprovalMatrixMA/SettingsNewApprovalUIModule/frmLoginControllerActions"], function() {
    var controller = require("ApprovalMatrixMA/SettingsNewApprovalUIModule/userfrmLoginController");
    var controllerActions = ["ApprovalMatrixMA/SettingsNewApprovalUIModule/frmLoginControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
