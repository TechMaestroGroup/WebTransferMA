define("OpenBankingMA/OpenBankingUIModule/frmPayAuthConsentWarning", function() {
    return function(controller) {
        function addWidgetsfrmPayAuthConsentWarning() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "64dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxHdr = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "64dp",
                "id": "flxHdr",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0dp",
                "width": "728dp",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHdr.setDefaultUnit(kony.flex.DP);
            var flxLogo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "42dp",
                "id": "flxLogo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogo.setDefaultUnit(kony.flex.DP);
            var imgLogo = new kony.ui.Image2({
                "height": "42dp",
                "id": "imgLogo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "0dp",
                "width": "100dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLogo.add(imgLogo);
            flxHdr.add(flxLogo);
            var flxHeaderSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "64dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSeparator.setDefaultUnit(kony.flex.DP);
            flxHeaderSeparator.add();
            flxHeader.add(flxHdr, flxHeaderSeparator);
            var flxFormContent = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "428dp",
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "88dp",
                "width": "728dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "height": "30dp",
                "id": "lblHeader",
                "isVisible": true,
                "left": "0",
                "skin": "sknLbl000d19SSB24px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.component.header.customAcknowledgement\")",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMainContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "374dp",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknffffffBorder1pxE2E9F0",
                "top": "24dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "206dp",
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "48dp",
                "width": "680dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxImgSuccess = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "96dp",
                "id": "flxImgSuccess",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "96dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgSuccess.setDefaultUnit(kony.flex.DP);
            var lblCross = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblCross",
                "isVisible": true,
                "skin": "ICSknFontIconSet3CA491648px",
                "text": "Y",
                "top": "10dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgSuccess.add(lblCross);
            var lblSuccessMessage = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblSuccessMessage",
                "isVisible": true,
                "skin": "sknLbl000d19SSB24px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.rejectError\")",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBackTotppMsg = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblBackTotppMsg",
                "isVisible": true,
                "skin": "sknLbl424242SSP93prSansRegularPro",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.CancelErrorMsg\")",
                "top": "5dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfo = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblInfo",
                "isVisible": true,
                "skin": "bbSknLbl8f99acSSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppconsent.navigationMsg\")",
                "top": "40dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer.add(flxImgSuccess, lblSuccessMessage, lblBackTotppMsg, lblInfo);
            var flxButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "24dp",
                "isModalContainer": false,
                "right": "24dp",
                "skin": "slFbox",
                "top": "32dp",
                "width": "100%",
                "zIndex": 100,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "CONFIRM"
                },
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "100%",
                "id": "btnContinue",
                "isVisible": true,
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.continue\")",
                "width": "250dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px"
            });
            flxButtons.add(btnContinue);
            flxMainContainer.add(flxContainer, flxButtons);
            flxFormContent.add(lblHeader, flxMainContainer);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHdr": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxLogo": {
                        "segmentProps": []
                    },
                    "flxHeaderSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "height": {
                            "type": "string",
                            "value": "460dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "height": {
                            "type": "string",
                            "value": "392dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblBackTotppMsg": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHdr": {
                        "segmentProps": []
                    },
                    "flxLogo": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxLogo": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxLogo": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {}
            this.add(flxHeader, flxFormContent);
        };
        return [{
            "addWidgets": addWidgetsfrmPayAuthConsentWarning,
            "enabledForIdleTimeout": true,
            "id": "frmPayAuthConsentWarning",
            "init": controller.AS_Form_bd0d7b32ad704bbfabf5e5dfefb158da,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "title": "Acknowledgement",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "OpenBankingMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});