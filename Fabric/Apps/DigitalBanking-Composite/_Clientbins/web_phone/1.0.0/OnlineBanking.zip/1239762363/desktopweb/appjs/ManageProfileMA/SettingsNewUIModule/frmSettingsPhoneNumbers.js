define("ManageProfileMA/SettingsNewUIModule/frmSettingsPhoneNumbers", function() {
    return function(controller) {
        function addWidgetsfrmSettingsPhoneNumbers() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheadernew": {
                        "centerX": "viz.val_cleared",
                        "width": "100%"
                    },
                    "flxMyBills": {
                        "isVisible": false
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.profilesettings\")",
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "3.25%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Settingscapson\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxSettingsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxSettingsContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "3.25%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "93.50%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSettingsContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.updateSettingAndPreferences\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Settings"
            });
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3dp",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder0b7491d9b1d7c4e",
                "top": "-1dp",
                "width": "23.70%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxProfileMenu": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "695px",
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "24%",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder0b7491d9b1d7c4e",
                "top": "0dp",
                "width": "76.08%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "bottom": "0px",
                "clipBounds": true,
                "height": "100%",
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.23%",
                "isModalContainer": false,
                "skin": "sknFlxffffffBorder0",
                "top": "0dp",
                "width": "95.62%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxPhoneNumbersWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxPhoneNumbersWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumbersWrapper.setDefaultUnit(kony.flex.DP);
            var flxPhoneNumbers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxPhoneNumbers",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumbers.setDefaultUnit(kony.flex.DP);
            var flxPhoneNumbersHeading = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50px",
                "id": "flxPhoneNumbersHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumbersHeading.setDefaultUnit(kony.flex.DP);
            var flxPhoneNumbersSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPhoneNumbersSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumbersSeparator.setDefaultUnit(kony.flex.DP);
            flxPhoneNumbersSeparator.add();
            var lblPhoneNumbersHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblPhoneNumbersHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Phone Number",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewNumber = new kony.ui.Button({
                "centerY": "50%",
                "height": "42dp",
                "id": "btnAddNewNumber",
                "isVisible": true,
                "right": "3dp",
                "skin": "sknBtnSSP3343A813PxBg0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewPhoneNumber\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhoneNumbersHeading.add(flxPhoneNumbersSeparator, lblPhoneNumbersHeading, btnAddNewNumber);
            var flxErrorContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxErrorContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 20,
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorContainer.setDefaultUnit(kony.flex.DP);
            var lblImageError = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "status",
                        "tabindex": -1
                    },
                    "tagName": "label"
                },
                "centerY": "50%",
                "id": "lblImageError",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknlblff000015px",
                "text": "We couldn't upload your profile picture, as your file does not match with image uplaod criteria, please check again and upload.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgErr = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgErr",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorContainer.add(lblImageError, imgErr);
            var flxPhoneNumbersBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxPhoneNumbersBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxFFFFFFBorderE9E9E9Radius4px",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumbersBody.setDefaultUnit(kony.flex.DP);
            var segPhoneNumbers = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segPhoneNumbers",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "sknSegDefault",
                "rowSkin": "sknSegDefault",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxProfileManagementPhoneNumbers"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnDelete": "btnDelete",
                    "btnViewDetail": "btnViewDetail",
                    "flxEdit": "flxEdit",
                    "flxPhoneNumber": "flxPhoneNumber",
                    "flxPhoneNumberContainer": "flxPhoneNumberContainer",
                    "flxPrimary": "flxPrimary",
                    "flxProfileManagementPhoneNumbers": "flxProfileManagementPhoneNumbers",
                    "flxRow": "flxRow",
                    "flxUsedFor": "flxUsedFor",
                    "lblCountryCode": "lblCountryCode",
                    "lblHome": "lblHome",
                    "lblPhoneNumber": "lblPhoneNumber",
                    "lblPrimary": "lblPrimary",
                    "lblSeperator": "lblSeperator",
                    "lblUsedFor": "lblUsedFor"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewNumberMobile = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "bottom": 20,
                "height": "40dp",
                "id": "btnAddNewNumberMobile",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewPhoneNumber\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxPhoneNumbersBody.add(segPhoneNumbers, btnAddNewNumberMobile);
            var flxNoInfoWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxNoInfoWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoInfoWarning.setDefaultUnit(kony.flex.DP);
            var flxNoInfoWarningWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "id": "flxNoInfoWarningWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoInfoWarningWrapper.setDefaultUnit(kony.flex.DP);
            var lblNoInfoWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "status",
                        "tabindex": -1
                    },
                    "tagName": "label"
                },
                "id": "lblNoInfoWarning",
                "isVisible": true,
                "left": "112dp",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profile.noPhone\")",
                "top": "23dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoInfoWarningImage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.NAO.Info\")"
                },
                "id": "lblNoInfoWarningImage",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknlbl4a90e230OLBFontIconsPx",
                "text": "K",
                "top": "15px",
                "width": "32px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoInfoWarningWrapper.add(lblNoInfoWarning, lblNoInfoWarningImage);
            flxNoInfoWarning.add(flxNoInfoWarningWrapper);
            flxPhoneNumbers.add(flxPhoneNumbersHeading, flxErrorContainer, flxPhoneNumbersBody, flxNoInfoWarning);
            var flxCombinedPhoneNumbers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCombinedPhoneNumbers",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCombinedPhoneNumbers.setDefaultUnit(kony.flex.DP);
            var flxPersonalPhoneNumbers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPersonalPhoneNumbers",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalPhoneNumbers.setDefaultUnit(kony.flex.DP);
            var flxPersonalPhoneNumbersHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxPersonalPhoneNumbersHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalPhoneNumbersHeading.setDefaultUnit(kony.flex.DP);
            var flxPersonalPhoneNumbersSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPersonalPhoneNumbersSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalPhoneNumbersSeparator.setDefaultUnit(kony.flex.DP);
            flxPersonalPhoneNumbersSeparator.add();
            var lblPersonalPhoneNumbersHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"Kony.mb.userdetail.PhoneNumber\")"
                },
                "centerY": "50%",
                "id": "lblPersonalPhoneNumbersHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PersonalBankingPhoneNumberDetail\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewPersonalNumber = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewPhoneNumber\")"
                },
                "centerY": "50%",
                "id": "btnAddNewPersonalNumber",
                "isVisible": true,
                "right": "0%",
                "skin": "sknBtnSSP3343A813PxBg0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewPhoneNumber\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Add new Phone Number"
            });
            flxPersonalPhoneNumbersHeading.add(flxPersonalPhoneNumbersSeparator, lblPersonalPhoneNumbersHeading, btnAddNewPersonalNumber);
            var flxPersonalPhoneNumbersBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPersonalPhoneNumbersBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxe3e3e3e30pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalPhoneNumbersBody.setDefaultUnit(kony.flex.DP);
            var segPersonalPhoneNumbers = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segPersonalPhoneNumbers",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "sknSegDefault",
                "rowSkin": "sknSegDefault",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxProfileManagementPhoneNumbers"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnDelete": "btnDelete",
                    "btnViewDetail": "btnViewDetail",
                    "flxEdit": "flxEdit",
                    "flxPhoneNumber": "flxPhoneNumber",
                    "flxPhoneNumberContainer": "flxPhoneNumberContainer",
                    "flxPrimary": "flxPrimary",
                    "flxProfileManagementPhoneNumbers": "flxProfileManagementPhoneNumbers",
                    "flxRow": "flxRow",
                    "flxUsedFor": "flxUsedFor",
                    "lblCountryCode": "lblCountryCode",
                    "lblHome": "lblHome",
                    "lblPhoneNumber": "lblPhoneNumber",
                    "lblPrimary": "lblPrimary",
                    "lblSeperator": "lblSeperator",
                    "lblUsedFor": "lblUsedFor"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewPersonalNumberMobile = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Cancel\")"
                },
                "bottom": 20,
                "height": "40dp",
                "id": "btnAddNewPersonalNumberMobile",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewPhoneNumber\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxPersonalPhoneNumbersBody.add(segPersonalPhoneNumbers, btnAddNewPersonalNumberMobile);
            flxPersonalPhoneNumbers.add(flxPersonalPhoneNumbersHeading, flxPersonalPhoneNumbersBody);
            var flxPhoneNumbersTypeSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPhoneNumbersTypeSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumbersTypeSeparator.setDefaultUnit(kony.flex.DP);
            flxPhoneNumbersTypeSeparator.add();
            var flxBusinessPhoneNumbers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBusinessPhoneNumbers",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessPhoneNumbers.setDefaultUnit(kony.flex.DP);
            var flxBusinessPhoneNumbersHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxBusinessPhoneNumbersHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessPhoneNumbersHeading.setDefaultUnit(kony.flex.DP);
            var flxBusinessPhoneNumbersSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBusinessPhoneNumbersSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessPhoneNumbersSeparator.setDefaultUnit(kony.flex.DP);
            flxBusinessPhoneNumbersSeparator.add();
            var lblBusinessPhoneNumbersHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"Kony.mb.userdetail.PhoneNumber\")"
                },
                "centerY": "50%",
                "id": "lblBusinessPhoneNumbersHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.BusinessBankingPhoneNumberDetail\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewBusinessNumber = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewPhoneNumber\")"
                },
                "centerY": "50%",
                "id": "btnAddNewBusinessNumber",
                "isVisible": false,
                "right": "0%",
                "skin": "sknBtnSSP3343A813PxBg0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewPhoneNumber\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Add new Phone Number"
            });
            flxBusinessPhoneNumbersHeading.add(flxBusinessPhoneNumbersSeparator, lblBusinessPhoneNumbersHeading, btnAddNewBusinessNumber);
            var flxBusinessPhoneNumbersBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBusinessPhoneNumbersBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxe3e3e3e30pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBusinessPhoneNumbersBody.setDefaultUnit(kony.flex.DP);
            var segBusinessPhoneNumbers = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segBusinessPhoneNumbers",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "sknSegDefault",
                "rowSkin": "sknSegDefault",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxProfileManagementPhoneNumbers"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnDelete": "btnDelete",
                    "btnViewDetail": "btnViewDetail",
                    "flxEdit": "flxEdit",
                    "flxPhoneNumber": "flxPhoneNumber",
                    "flxPhoneNumberContainer": "flxPhoneNumberContainer",
                    "flxPrimary": "flxPrimary",
                    "flxProfileManagementPhoneNumbers": "flxProfileManagementPhoneNumbers",
                    "flxRow": "flxRow",
                    "flxUsedFor": "flxUsedFor",
                    "lblCountryCode": "lblCountryCode",
                    "lblHome": "lblHome",
                    "lblPhoneNumber": "lblPhoneNumber",
                    "lblPrimary": "lblPrimary",
                    "lblSeperator": "lblSeperator",
                    "lblUsedFor": "lblUsedFor"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAddNewBusinessNumberMobile = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Cancel\")"
                },
                "bottom": 20,
                "height": "40dp",
                "id": "btnAddNewBusinessNumberMobile",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddNewPhoneNumber\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxBusinessPhoneNumbersBody.add(segBusinessPhoneNumbers, btnAddNewBusinessNumberMobile);
            flxBusinessPhoneNumbers.add(flxBusinessPhoneNumbersHeading, flxBusinessPhoneNumbersBody);
            flxCombinedPhoneNumbers.add(flxPersonalPhoneNumbers, flxPhoneNumbersTypeSeparator, flxBusinessPhoneNumbers);
            flxPhoneNumbersWrapper.add(flxPhoneNumbers, flxCombinedPhoneNumbers);
            flxContainer.add(flxPhoneNumbersWrapper);
            flxRight.add(flxContainer);
            flxSettingsContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxContent.add(flxSettingsContainer);
            flxMain.add(lblContentHeader, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "left": "0dp",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "140%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Opacity40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1200,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            flxPopup.add();
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxDeletePopUp = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxDelete = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-live": "off",
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "268dp",
                "id": "flxDelete",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDelete.setDefaultUnit(kony.flex.DP);
            var flxDeleteHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDeleteClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteClose.setDefaultUnit(kony.flex.DP);
            var CopyimgDeleteClose0ee315396d8944f = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "CopyimgDeleteClose0ee315396d8944f",
                "isVisible": false,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcross = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblcross",
                "isVisible": true,
                "skin": "sknOlbFonts0273e317px",
                "text": "g",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeleteClose.add(CopyimgDeleteClose0ee315396d8944f, lblcross);
            flxDeleteHeader.add(lblDeleteHeader, flxDeleteClose);
            var flxDeleteSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxDeleteSeperator.add();
            var flxDeleteContents = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "105dp",
                "id": "flxDeleteContents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteContents.setDefaultUnit(kony.flex.DP);
            var lblConfirmDelete = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblConfirmDelete",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknlblUserName",
                "text": "Are you sure you want to Delete this Phone Number?",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeleteContents.add(lblConfirmDelete);
            var flxDeleteSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxDeleteSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteSeperator2.setDefaultUnit(kony.flex.DP);
            flxDeleteSeperator2.add();
            var flxDeleteButtons = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": true,
                "height": "80px",
                "id": "flxDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnDeleteYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.Yes\")"
                },
                "bottom": 30,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnDeleteYes",
                "isVisible": true,
                "left": "51.58%",
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnDeleteNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.No\")"
                },
                "bottom": 30,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnDeleteNo",
                "isVisible": true,
                "left": "3.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxDeleteButtons.add(btnDeleteYes, btnDeleteNo);
            flxDelete.add(flxDeleteHeader, flxDeleteSeperator, flxDeleteContents, flxDeleteSeperator2, flxDeleteButtons);
            var CustomPopup1 = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDeletePopUp.add(flxDelete, CustomPopup1);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxPopup, flxLoading, flxDeletePopUp, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.flxMyBills": {
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSettingsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "profileMenu.flxProfileMenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "skin": "slFbox",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxRight": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "590dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "580px"
                        },
                        "left": {
                            "type": "string",
                            "value": "12px"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc3",
                        "top": {
                            "type": "string",
                            "value": "5px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbersWrapper": {
                        "height": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbers": {
                        "height": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbersHeading": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbersSeparator": {
                        "bottom": {
                            "type": "string",
                            "value": "0px"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblPhoneNumbersHeading": {
                        "i18n_text": "i18n.profilemanagement.phoneNumberDetail",
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "btnAddNewNumber": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "lblImageError": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "sknlblff000011px",
                        "text": "We couldn't upload your profile picture, as your file does not match with image upload criteria, please check again and upload.",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgErr": {
                        "left": {
                            "type": "string",
                            "value": "5px"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbersBody": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "285dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "segPhoneNumbers": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "btnAddNewNumberMobile": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxCombinedPhoneNumbers": {
                        "minHeight": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewPersonalNumber": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnAddNewPersonalNumberMobile": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewBusinessNumberMobile": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteHeader": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "lblDeleteHeader": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteContents": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmDelete": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxDeleteSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "40%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup1": {
                        "segmentProps": [],
                        "instanceId": "CustomPopup1"
                    },
                    "CustomPopup1.lblHeading": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxAccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxContextualMenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxLogoAndActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuLeft": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMyBills": {
                        "segmentProps": []
                    },
                    "customheadernew.flxSeparatorNew": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "padding": [0, 0, 2, 0],
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSettingsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPhoneNumbersWrapper": {
                        "minHeight": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbers": {
                        "minHeight": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumbersHeading": {
                        "i18n_text": "i18n.profilemanagement.phoneNumberDetail",
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknrounded",
                        "segmentProps": []
                    },
                    "lblImageError": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "We couldn't upload your profile picture, as your file does not match with image upload criteria, please check again and upload.",
                        "segmentProps": []
                    },
                    "btnAddNewNumberMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarningWrapper": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarningImage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnAddNewPersonalNumberMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnAddNewBusinessNumberMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "segmentProps": []
                    },
                    "CustomPopup1": {
                        "segmentProps": [],
                        "instanceId": "CustomPopup1"
                    },
                    "flxLogout": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheadernew.flxActionsMenu": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuLeft": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuRight": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMyBills": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "padding": [0, 0, 2, 0],
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSettingsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxPhoneNumbersWrapper": {
                        "minHeight": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbers": {
                        "minHeight": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumbersHeading": {
                        "i18n_text": "i18n.profilemanagement.phoneNumberDetail",
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "skin": "sknrounded",
                        "segmentProps": []
                    },
                    "lblImageError": {
                        "text": "We couldn't upload your profile picture, as your file does not match with image upload criteria, please check again and upload.",
                        "segmentProps": []
                    },
                    "btnAddNewNumberMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarningWrapper": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarningImage": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "text": "K",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddNewPersonalNumberMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnAddNewBusinessNumberMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "bottom": {
                            "type": "number",
                            "value": "30"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "segmentProps": []
                    }
                },
                "1380": {
                    "lblContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [0, 0, 2, 0],
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxSettingsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbersWrapper": {
                        "minHeight": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxPhoneNumbers": {
                        "minHeight": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumbersHeading": {
                        "i18n_text": "i18n.profilemanagement.phoneNumberDetail",
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "isVisible": false,
                        "skin": "sknrounded",
                        "segmentProps": []
                    },
                    "btnAddNewNumberMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoInfoWarningWrapper": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarning": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "We don't have any primary phone number added in our records. Please add your primary phone number.",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoInfoWarningImage": {
                        "skin": "sknlbl4a90e230OLBFontIconsPx",
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxDeletePopUp": {
                        "segmentProps": []
                    },
                    "lblDeleteHeader": {
                        "segmentProps": []
                    },
                    "flxDeleteButtons": {
                        "segmentProps": []
                    },
                    "btnDeleteYes": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": 0
                            }
                        },
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnDeleteNo": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": 0
                            }
                        },
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew": {
                    "centerX": "",
                    "width": "100%"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customfooternew": {
                    "left": "0dp",
                    "top": "0dp"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmSettingsPhoneNumbers,
            "enabledForIdleTimeout": true,
            "id": "frmSettingsPhoneNumbers",
            "init": controller.AS_Form_h25b118b29fb45e9affe730e99731699,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.konybb.manageUser.PhoneNo\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ManageProfileMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});