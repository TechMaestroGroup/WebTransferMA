define("CardsMA/ManageCardsUIModule/frmCardManagement", function() {
    return function(controller) {
        function addWidgetsfrmCardManagement() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheader": {
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "lblName": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Loggedinas\")"
                    },
                    "lblUserEmail1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.usernamekonycom\")"
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxFeedback": {
                        "clipBounds": false
                    },
                    "topmenu.flxHelp": {
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.flxMenusMain": {
                        "height": "51dp"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var breadcrumb = new com.InfinityOLB.Resources.breadcrumb({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "53dp",
                "id": "breadcrumb",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "breadcrumb": {
                        "height": "53dp",
                        "isVisible": false,
                        "left": "-2dp",
                        "top": "0dp"
                    },
                    "btnBreadcrumb1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ManageCard\")"
                    },
                    "btnBreadcrumb2": {
                        "centerY": "51%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.LockCardAcknowledgement\")",
                        "left": "2.46%"
                    },
                    "flxBottomBorder": {
                        "bottom": "0dp"
                    },
                    "flxBreadcrumbcontainer": {
                        "centerX": "50%",
                        "height": "50dp",
                        "top": "1dp",
                        "width": "1366dp"
                    },
                    "flxTopBorder": {
                        "isVisible": true,
                        "top": "0dp"
                    },
                    "imgBreadcrumb": {
                        "src": "breadcrumb_icon.png"
                    },
                    "imgBreadcrumb2": {
                        "isVisible": false,
                        "src": "breadcrumb_icon.png"
                    },
                    "lblBreadcrumb2": {
                        "isVisible": false,
                        "text": "CATEGORIZED MONTHLY SPENDING"
                    },
                    "lblBreadcrumb3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.categorizedMonthlySpending\")",
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            breadcrumb.btnBreadcrumb1.onClick = controller.AS_Button_fb5a0d943cbd487ea26c5488b18a8748;
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.Transfers.ThereisomeerrorintheserverWecouldnotcompleteyourrequestofaddingtheaccount\")"
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSPLightRich42424217Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.ThereisomeerrorintheserverWecouldnotcompleteyourrequestofaddingtheaccount\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxAcknowledgment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "580dp",
                "id": "flxAcknowledgment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgment.setDefaultUnit(kony.flex.DP);
            var lblCardAcknowledgement = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblCardAcknowledgement",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.LockCard\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxPrint = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Print the card details"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPrint",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "9.52%",
                "skin": "slFbox",
                "top": "21dp",
                "width": "50dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknflxF4F4F4"
            });
            flxPrint.setDefaultUnit(kony.flex.DP);
            var imgPrintIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "30dp",
                "id": "imgPrintIcon",
                "isVisible": true,
                "skin": "sknLblFontTypeIcon3343e8",
                "text": "p",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPrint.add(imgPrintIcon);
            var flxAcknowledgementMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcknowledgementMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.08%",
                "minHeight": "370dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "70dp",
                "width": "43.27%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementMain.setDefaultUnit(kony.flex.DP);
            var Acknowledgement = new com.konyolb.CardManagement.Acknowledgement({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "Acknowledgement",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "minHeight": "370dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA",
                "overrides": {
                    "Acknowledgement": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "minHeight": "370dp"
                    },
                    "ImgAcknowledgement": {
                        "src": "success_green.png"
                    },
                    "confirmHeaders.lblHeading": {
                        "left": "20dp"
                    },
                    "lblCardTransactionMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.AckMessage1\")"
                    },
                    "lblRefrenceNumber": {
                        "isVisible": false,
                        "top": "2dp"
                    },
                    "lblRequestID": {
                        "isVisible": false,
                        "top": "20px"
                    },
                    "lblUnlockCardMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.AckMessage2\")",
                        "width": "90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAcknowledgementMain.add(Acknowledgement);
            var flxCardDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "370dp",
                "id": "flxCardDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "50.59%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "70dp",
                "width": "43.27%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardDetails.setDefaultUnit(kony.flex.DP);
            var ConfirmDialog = new com.konyolb.CardManagement.ConfirmDialog({
                "height": "370dp",
                "id": "ConfirmDialog",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA",
                "overrides": {
                    "ConfirmDialog": {
                        "height": "370dp"
                    },
                    "confirmHeaders": {
                        "height": "50dp"
                    },
                    "confirmHeaders.flxHeader": {
                        "height": "50dp"
                    },
                    "confirmHeaders.lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.CardDetails\")",
                        "left": "20dp"
                    },
                    "flxCards": {
                        "left": "30%"
                    },
                    "flxDestination": {
                        "isVisible": false,
                        "left": "0%",
                        "top": "20dp"
                    },
                    "flxHorizontalLine": {
                        "left": "0dp",
                        "right": "30dp"
                    },
                    "flxSelectCards": {
                        "isVisible": false,
                        "left": "0%",
                        "top": "20px"
                    },
                    "flxscrollBody": {
                        "height": "310dp",
                        "left": "20dp",
                        "right": "20dp",
                        "top": "60dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "keyValueAvailableCredit": {
                        "bottom": "viz.val_cleared",
                        "top": "20dp"
                    },
                    "keyValueAvailableCredit.flxContainer": {
                        "left": "0%"
                    },
                    "keyValueAvailableCredit.flxKey": {
                        "left": "0%",
                        "width": "25%"
                    },
                    "keyValueAvailableCredit.flxValue": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "keyValueAvailableCredit.imgWhatIsSSN": {
                        "src": "info_grey.png"
                    },
                    "keyValueAvailableCredit.lblColon": {
                        "isVisible": false
                    },
                    "keyValueAvailableCredit.lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountDetail.availableCredit\")",
                        "width": "100%"
                    },
                    "keyValueAvailableCredit.lblValue": {
                        "text": "$50,000"
                    },
                    "keyValueCardHolder": {
                        "top": "20dp"
                    },
                    "keyValueCardHolder.flxContainer": {
                        "left": "0%"
                    },
                    "keyValueCardHolder.flxKey": {
                        "left": "0%",
                        "width": "25%"
                    },
                    "keyValueCardHolder.flxValue": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "keyValueCardHolder.imgWhatIsSSN": {
                        "src": "info_grey.png"
                    },
                    "keyValueCardHolder.lblColon": {
                        "isVisible": false
                    },
                    "keyValueCardHolder.lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.CardHolder\")",
                        "width": "100%"
                    },
                    "keyValueCardHolder.lblValue": {
                        "text": "John Bailey"
                    },
                    "keyValueCardName": {
                        "top": "20dp"
                    },
                    "keyValueCardName.flxContainer": {
                        "left": "0%"
                    },
                    "keyValueCardName.flxKey": {
                        "left": "0%",
                        "width": "25%"
                    },
                    "keyValueCardName.flxValue": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "keyValueCardName.imgWhatIsSSN": {
                        "src": "info_grey.png"
                    },
                    "keyValueCardName.lblColon": {
                        "isVisible": false,
                        "left": "20.70%"
                    },
                    "keyValueCardName.lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.CardNumber\")",
                        "width": "100%"
                    },
                    "keyValueCardName.lblValue": {
                        "text": "XXXX XXXX XXXX 5404"
                    },
                    "keyValueCreditLimit": {
                        "top": "20dp"
                    },
                    "keyValueCreditLimit.flxContainer": {
                        "left": "0%"
                    },
                    "keyValueCreditLimit.flxKey": {
                        "left": "0%",
                        "width": "25%"
                    },
                    "keyValueCreditLimit.flxValue": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "keyValueCreditLimit.imgWhatIsSSN": {
                        "src": "info_grey.png"
                    },
                    "keyValueCreditLimit.lblColon": {
                        "isVisible": false
                    },
                    "keyValueCreditLimit.lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountDetail.creditLimit\")",
                        "width": "100%"
                    },
                    "keyValueCreditLimit.lblValue": {
                        "text": "$25,000"
                    },
                    "keyValueName": {
                        "top": "20dp"
                    },
                    "keyValueName.flxContainer": {
                        "left": "0%"
                    },
                    "keyValueName.flxIcon": {
                        "left": "37.22%"
                    },
                    "keyValueName.flxKey": {
                        "left": "0%",
                        "width": "25%"
                    },
                    "keyValueName.flxValue": {
                        "left": "30%",
                        "top": "2dp",
                        "width": "70%"
                    },
                    "keyValueName.imgWhatIsSSN": {
                        "src": "info_grey.png"
                    },
                    "keyValueName.lblColon": {
                        "isVisible": false
                    },
                    "keyValueName.lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.cardName\")",
                        "width": "100%"
                    },
                    "keyValueName.lblValue": {
                        "text": "Gold Debit Card"
                    },
                    "keyValueServiceProvider": {
                        "isVisible": true,
                        "top": "20dp"
                    },
                    "keyValueServiceProvider.flxContainer": {
                        "left": "0%"
                    },
                    "keyValueServiceProvider.flxKey": {
                        "left": "0%",
                        "width": "25%"
                    },
                    "keyValueServiceProvider.flxValue": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "keyValueServiceProvider.imgWhatIsSSN": {
                        "src": "info_grey.png"
                    },
                    "keyValueServiceProvider.lblColon": {
                        "isVisible": false
                    },
                    "keyValueServiceProvider.lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ServiceProvider\")",
                        "width": "100%"
                    },
                    "keyValueServiceProvider.lblValue": {
                        "text": "Master Card"
                    },
                    "keyValueValidThrough": {
                        "isVisible": true,
                        "top": "20dp"
                    },
                    "keyValueValidThrough.flxContainer": {
                        "left": "0%"
                    },
                    "keyValueValidThrough.flxKey": {
                        "left": "0%",
                        "width": "25%"
                    },
                    "keyValueValidThrough.flxValue": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "keyValueValidThrough.imgWhatIsSSN": {
                        "src": "info_grey.png"
                    },
                    "keyValueValidThrough.lblColon": {
                        "isVisible": false
                    },
                    "keyValueValidThrough.lblKey": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ValidThrough\")",
                        "width": "100%"
                    },
                    "keyValueValidThrough.lblValue": {
                        "text": "02/20"
                    },
                    "lblDestination1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination1\")",
                        "right": "viz.val_cleared",
                        "width": "25%"
                    },
                    "lblDestination2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination2\")",
                        "right": "viz.val_cleared",
                        "width": "25%"
                    },
                    "lblDestination3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination3\")",
                        "right": "viz.val_cleared",
                        "width": "25%"
                    },
                    "lblDestination4": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination4\")",
                        "right": "viz.val_cleared",
                        "width": "25%"
                    },
                    "lblDestination5": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination5\")",
                        "right": "viz.val_cleared",
                        "width": "25%"
                    },
                    "lblKey6": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedCards\")",
                        "right": "viz.val_cleared",
                        "width": "25%"
                    },
                    "rtxDestination1": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "rtxDestination2": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "rtxDestination3": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "rtxDestination4": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "rtxDestination5": {
                        "left": "30%",
                        "width": "70%"
                    },
                    "rtxValueA": {
                        "left": "30%",
                        "width": "70%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCardDetails.add(ConfirmDialog);
            var flxButtonsCards = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxButtonsCards",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "50.59%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "43.27%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtonsCards.setDefaultUnit(kony.flex.DP);
            var btnBackToCards = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnBackToCards",
                "isVisible": true,
                "left": "0",
                "right": "0dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.BackToCards\")",
                "top": "465dp",
                "width": "47.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnRequestReplacement = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnRequestReplacement",
                "isVisible": true,
                "left": "0%",
                "right": "5%",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RequestReplacement\")",
                "top": "465dp",
                "width": "47.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnBackToCardLimits = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnBackToCardLimits",
                "isVisible": false,
                "right": "0dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.BackToCardLimits\")",
                "top": "465dp",
                "width": "47.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnManageCards = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnManageCards",
                "isVisible": false,
                "left": "0%",
                "right": "5%",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ManageCards\")",
                "top": "465dp",
                "width": "47.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxButtonsCards.add(btnBackToCards, btnRequestReplacement, btnBackToCardLimits, btnManageCards);
            var flxSpace = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "36dp",
                "id": "flxSpace",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "515dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpace.setDefaultUnit(kony.flex.DP);
            flxSpace.add();
            var flxDownload = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxDownload",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "6.29%",
                "skin": "slFbox",
                "top": "21dp",
                "width": "35dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknflxF4F4F4"
            });
            flxDownload.setDefaultUnit(kony.flex.DP);
            var imgDownloadIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "30dp",
                "id": "imgDownloadIcon",
                "isVisible": true,
                "skin": "sknLblFontTypeIcon3343e8",
                "text": "D",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownload.add(imgDownloadIcon);
            flxAcknowledgment.add(lblCardAcknowledgement, flxPrint, flxAcknowledgementMain, flxCardDetails, flxButtonsCards, flxSpace, flxDownload);
            var flxConfirm = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxConfirm",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirm.setDefaultUnit(kony.flex.DP);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "70px",
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "47dp",
                "id": "imgError",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "2.65%",
                "skin": "sknbg2a9e05",
                "src": "error_yellow.png",
                "top": "15dp",
                "width": "47dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "You have already a travel notification for the same dates, destinations and cards. Do you want to edit or delete the previous notification?",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblErrorMsg",
                "isVisible": true,
                "left": "8.33%",
                "skin": "sknlbl424242SSPReg17px",
                "text": "You have already a travel notification for the same dates, destinations and cards. Do you want to edit or delete the previous notification?",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(imgError, lblErrorMsg);
            var flxConfirmHeading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60px",
                "id": "flxConfirmHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmHeading.setDefaultUnit(kony.flex.DP);
            var lblConfirmTravelPlan = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ConfirmTravelPlan\")",
                    "tagName": "h1"
                },
                "id": "lblConfirmTravelPlan",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ConfirmTravelPlan\")",
                "top": "22dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a",
                    "tagName": "span"
                },
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblSeparator5",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConfirmHeading.add(lblConfirmTravelPlan, lblSeparator5);
            var flxConfirmBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "-2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmBody.setDefaultUnit(kony.flex.DP);
            var flxDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "50.53%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetails.setDefaultUnit(kony.flex.DP);
            var flxDetailsRow1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsRow1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsRow1.setDefaultUnit(kony.flex.DP);
            var lblKey1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Selected  Start Date:",
                    "tagName": "span"
                },
                "id": "lblKey1",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedStartDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValue1 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "01/07/2018"
                },
                "id": "rtxValue1",
                "isVisible": true,
                "left": "184dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "01/07/2018",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsRow1.add(lblKey1, rtxValue1);
            var flxDetailsRow2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsRow2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsRow2.setDefaultUnit(kony.flex.DP);
            var lblKey2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedEndDate\")"
                },
                "id": "lblKey2",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedEndDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValue2 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "01/08/2018"
                },
                "id": "rtxValue2",
                "isVisible": true,
                "left": "184dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "01/08/2018",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsRow2.add(lblKey2, rtxValue2);
            var flxDetailsRow3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsRow3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsRow3.setDefaultUnit(kony.flex.DP);
            var flxDestination1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDestination1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDestination1.setDefaultUnit(kony.flex.DP);
            var lblDestination1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination1\")"
                },
                "id": "lblDestination1",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination1\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDestination1 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "California, USA"
                },
                "id": "rtxDestination1",
                "isVisible": true,
                "left": "193dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "California, USA",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDestination1.add(lblDestination1, rtxDestination1);
            var flxDestination2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDestination2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDestination2.setDefaultUnit(kony.flex.DP);
            var lblDestination2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination2\")",
                    "tagName": "span"
                },
                "id": "lblDestination2",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination2\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDestination2 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "United States of America - California\n"
                },
                "id": "rtxDestination2",
                "isVisible": true,
                "left": "193dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "United States of America - California\n",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDestination2.add(lblDestination2, rtxDestination2);
            var flxDestination3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDestination3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDestination3.setDefaultUnit(kony.flex.DP);
            var lblDestination3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination3\")"
                },
                "id": "lblDestination3",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination3\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDestination3 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "United States of America - California\n"
                },
                "id": "rtxDestination3",
                "isVisible": true,
                "left": "193dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "United States of America - California\n",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDestination3.add(lblDestination3, rtxDestination3);
            var flxDestination4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDestination4",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDestination4.setDefaultUnit(kony.flex.DP);
            var lblDestination4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination4\")"
                },
                "id": "lblDestination4",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination4\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDestination4 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "United States of America - California\n"
                },
                "id": "rtxDestination4",
                "isVisible": true,
                "left": "193dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "United States of America - California\n",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDestination4.add(lblDestination4, rtxDestination4);
            var flxDestination5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDestination5",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDestination5.setDefaultUnit(kony.flex.DP);
            var lblDestination5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination5\")",
                    "tagName": "span"
                },
                "id": "lblDestination5",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedDestination5\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDestination5 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "United States of America - California\n"
                },
                "id": "rtxDestination5",
                "isVisible": true,
                "left": "193dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "United States of America - California\n",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDestination5.add(lblDestination5, rtxDestination5);
            flxDetailsRow3.add(flxDestination1, flxDestination2, flxDestination3, flxDestination4, flxDestination5);
            var flxDetailsRow4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsRow4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsRow4.setDefaultUnit(kony.flex.DP);
            var lblKey4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Selected  Cards:",
                    "tagName": "span"
                },
                "id": "lblKey4",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedCards\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValueA = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Gold Debit Card  -  XXXX XXXX XXXX 1234\n\n"
                },
                "id": "rtxValueA",
                "isVisible": true,
                "left": "184dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "Gold Debit Card  -  XXXX XXXX XXXX 1234\n\n",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCards = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCards",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "184dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCards.setDefaultUnit(kony.flex.DP);
            var segSelectedCards = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblIcon": "s",
                    "lblValue": "Weekly Pay "
                }, {
                    "lblIcon": "s",
                    "lblValue": "Weekly Pay "
                }],
                "groupCells": false,
                "id": "segSelectedCards",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "CardsMA",
                    "friendlyName": "flxSelectedCards"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxSelectedCards": "flxSelectedCards",
                    "lblIcon": "lblIcon",
                    "lblValue": "lblValue"
                },
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCards.add(segSelectedCards);
            flxDetailsRow4.add(lblKey4, rtxValueA, flxCards);
            var flxDetailsRow5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsRow5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsRow5.setDefaultUnit(kony.flex.DP);
            var lblKey5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PhoneNumber\")",
                    "tagName": "span"
                },
                "id": "lblKey5",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PhoneNumber\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValue5 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "7760405412\n"
                },
                "id": "rtxValue5",
                "isVisible": true,
                "left": "184dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "7760405412\n",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsRow5.add(lblKey5, rtxValue5);
            var flxDetailsRow6 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": true,
                "id": "flxDetailsRow6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsRow6.setDefaultUnit(kony.flex.DP);
            var lblKey6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.additionalInfo\")",
                    "tagName": "span"
                },
                "id": "lblKey6",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "text": "Additional Information:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValue6 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "rtxValue6",
                "isVisible": true,
                "left": "194dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "None",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsRow6.add(lblKey6, rtxValue6);
            flxDetails.add(flxDetailsRow1, flxDetailsRow2, flxDetailsRow3, flxDetailsRow4, flxDetailsRow5, flxDetailsRow6);
            var flxConfirmButons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "103dp",
                "id": "flxConfirmButons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmButons.setDefaultUnit(kony.flex.DP);
            var btnConfirm = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.confirm\")"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnConfirm",
                "isVisible": true,
                "right": "35dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Confirm\")",
                "width": "258px",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnModify = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.modifiy\")"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnModify",
                "isVisible": true,
                "right": "315dp",
                "skin": "sknBtnSecondarySSP3343a815Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Modify\")",
                "width": "260dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Modify"
            });
            var btnCancelPlan = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Cancel\")"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancelPlan",
                "isVisible": true,
                "right": "595dp",
                "skin": "sknBtnSecondarySSP3343a815Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "260dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a"
                },
                "height": "1dp",
                "id": "lblSeparator6",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConfirmButons.add(btnConfirm, btnModify, btnCancelPlan, lblSeparator6);
            flxConfirmBody.add(flxDetails, flxConfirmButons);
            flxConfirm.add(flxErrorMessage, flxConfirmHeading, flxConfirmBody);
            var flxActivateCard = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxActivateCard",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivateCard.setDefaultUnit(kony.flex.DP);
            var CardActivation = new com.konyolb.CardManagement.CardActivation({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "CardActivation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0df2564a0c1f740",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA",
                "overrides": {
                    "btnCancel": {
                        "height": "40dp"
                    },
                    "btnProceed": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                        "left": "76.8%",
                        "right": "viz.val_cleared"
                    },
                    "btnTermsAndConditions": {
                        "top": "2px"
                    },
                    "flxActions": {
                        "clipBounds": false
                    },
                    "imgChecbox": {
                        "src": "unchecked_box.png"
                    },
                    "imgWarning": {
                        "src": "error_yellow.png"
                    },
                    "lblAgree": {
                        "top": "2px"
                    },
                    "lblHeading2": {
                        "left": "0%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxActivateCard.add(CardActivation);
            var flxSetCardLimits = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxSetCardLimits",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSetCardLimits.setDefaultUnit(kony.flex.DP);
            var flxCardLimits = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCardLimits",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "-10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "57.50%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardLimits.setDefaultUnit(kony.flex.DP);
            var lblSetCardLimitsHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "height": "25dp",
                "id": "lblSetCardLimitsHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SetCardLimits\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCardShadow = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxCardShadow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "18dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardShadow.setDefaultUnit(kony.flex.DP);
            var flxMainSetCardLimits = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainSetCardLimits",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainSetCardLimits.setDefaultUnit(kony.flex.DP);
            var confirmHeaders = new com.InfinityOLB.Transfers.confirmHeaders({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "60dp",
                "id": "confirmHeaders",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "appName": "TransfersMA",
                "overrides": {
                    "confirmHeaders": {
                        "height": "60dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.YourCardDetails\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxHorizontalLine = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine.add();
            var flxCardName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "80dp",
                "id": "flxCardName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardName.setDefaultUnit(kony.flex.DP);
            var flxCardDet = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxCardDet",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardDet.setDefaultUnit(kony.flex.DP);
            var flxCardsName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxCardsName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardsName.setDefaultUnit(kony.flex.DP);
            var lblCardName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "45%",
                "height": "25dp",
                "id": "lblCardName",
                "isVisible": true,
                "left": "2.10%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.cardName\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxCardNr = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "85%",
                "height": "30dp",
                "id": "rtxCardNr",
                "isVisible": true,
                "left": "2.10%",
                "linkSkin": "defRichTextLink",
                "skin": "sknRtxSSPLight42424215Px",
                "text": "XXXX XXXX XXXX 5404",
                "top": "26dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCardsName.add(lblCardName, rtxCardNr);
            flxCardDet.add(flxCardsName);
            var btnRestoreWithdrawlDefaults = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "btnRestoreWithdrawlDefaults",
                "isVisible": false,
                "onClick": controller.AS_Button_aaf843b0c49c417aae66f3b3bb5e698a,
                "right": "2.10%",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.card.restoredefault\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRestorePurchaseDefaults = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "btnRestorePurchaseDefaults",
                "isVisible": false,
                "onClick": controller.AS_Button_aaf843b0c49c417aae66f3b3bb5e698a,
                "right": "2.10%",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.card.restoredefault\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCardName.add(flxCardDet, btnRestoreWithdrawlDefaults, btnRestorePurchaseDefaults);
            var flxSetCardLimitsOverview = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSetCardLimitsOverview",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSetCardLimitsOverview.setDefaultUnit(kony.flex.DP);
            var flxDailyWithdrawalLimitOverview = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDailyWithdrawalLimitOverview",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyWithdrawalLimitOverview.setDefaultUnit(kony.flex.DP);
            var flxDailyWithdrawal = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDailyWithdrawal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyWithdrawal.setDefaultUnit(kony.flex.DP);
            var lblDailyWithdrawalLimitOverview = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDailyWithdrawalLimitOverview",
                "isVisible": true,
                "left": "2.10%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.DailyWithdrawalLimit\")",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWithdrawalLimitValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblWithdrawalLimitValue",
                "isVisible": true,
                "left": "16dp",
                "skin": "bbSknLabelBold",
                "text": "$15,000.00",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyWithdrawal.add(lblDailyWithdrawalLimitOverview, lblWithdrawalLimitValue);
            var btnEditLimitWithdrawal = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "btnEditLimitWithdrawal",
                "isVisible": true,
                "right": "2.10%",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.EditLimit\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyWithdrawalLimitOverview.add(flxDailyWithdrawal, btnEditLimitWithdrawal);
            var flxHorizontalLine1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.10%",
                "isModalContainer": false,
                "right": "2.10%",
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "95.80%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine1.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine1.add();
            var flxDailyPurchaseLimitOverview = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDailyPurchaseLimitOverview",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyPurchaseLimitOverview.setDefaultUnit(kony.flex.DP);
            var flxDailyPurchase = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDailyPurchase",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyPurchase.setDefaultUnit(kony.flex.DP);
            var lblDailyPurchaseLimitOverview = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDailyPurchaseLimitOverview",
                "isVisible": true,
                "left": "2.10%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.DailyPurchaseLimit\")",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPurchaseLimitValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblPurchaseLimitValue",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLabelBold",
                "text": "$15,000.00",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyPurchase.add(lblDailyPurchaseLimitOverview, lblPurchaseLimitValue);
            var btnEditLimitPurchase = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "btnEditLimitPurchase",
                "isVisible": true,
                "right": "2.10%",
                "skin": "sknBtnSSP0dabb3e467ecc44",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.EditLimit\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyPurchaseLimitOverview.add(flxDailyPurchase, btnEditLimitPurchase);
            var flxHorizontalLine2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.10%",
                "isModalContainer": false,
                "right": "2.10%",
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "95.80%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine2.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine2.add();
            var flxIntDailyWithdrawalLimitOverview = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxIntDailyWithdrawalLimitOverview",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIntDailyWithdrawalLimitOverview.setDefaultUnit(kony.flex.DP);
            var flxIntDailyWithdrawal = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxIntDailyWithdrawal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIntDailyWithdrawal.setDefaultUnit(kony.flex.DP);
            var lblIntDailyWithdrawalLimitOverview = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblIntDailyWithdrawalLimitOverview",
                "isVisible": true,
                "left": "2.10%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.InternationalDailyWithdrawalLimit\")",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIntWithdrawalLimitValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblIntWithdrawalLimitValue",
                "isVisible": false,
                "left": "16dp",
                "skin": "bbSknLabelBold",
                "text": "$15,000.00",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIntDailyWithdrawal.add(lblIntDailyWithdrawalLimitOverview, lblIntWithdrawalLimitValue);
            flxIntDailyWithdrawalLimitOverview.add(flxIntDailyWithdrawal);
            var flxHorizontalLine3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLine3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.10%",
                "isModalContainer": false,
                "right": "2.10%",
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "95.80%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLine3.setDefaultUnit(kony.flex.DP);
            flxHorizontalLine3.add();
            var flxIntDailyPurchaseLimitOverview = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxIntDailyPurchaseLimitOverview",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIntDailyPurchaseLimitOverview.setDefaultUnit(kony.flex.DP);
            var flxIntDailyPurchase = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxIntDailyPurchase",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIntDailyPurchase.setDefaultUnit(kony.flex.DP);
            var lblIntDailyPurchaseLimitOverview = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblIntDailyPurchaseLimitOverview",
                "isVisible": true,
                "left": "2.10%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.InternationalDailyPurchaseLimit\")",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblIntPurchaseLimitValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblIntPurchaseLimitValue",
                "isVisible": false,
                "left": "16dp",
                "skin": "bbSknLabelBold",
                "text": "$15,000.00",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIntDailyPurchase.add(lblIntDailyPurchaseLimitOverview, lblIntPurchaseLimitValue);
            flxIntDailyPurchaseLimitOverview.add(flxIntDailyPurchase);
            var flxIncreaseLimits = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxIncreaseLimits",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIncreaseLimits.setDefaultUnit(kony.flex.DP);
            var lblContactUsMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblContactUsMsg",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabel42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.IncreaseLimit\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContactUs1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContactUs1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "15%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContactUs1.setDefaultUnit(kony.flex.DP);
            var lblContactUsLimits = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblContactUsLimits",
                "isVisible": true,
                "skin": "sknLblSSP1a98ff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContactUs1.add(lblContactUsLimits);
            flxIncreaseLimits.add(lblContactUsMsg, flxContactUs1);
            var flxActions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "82dp",
                "id": "flxActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.10%",
                "isModalContainer": false,
                "right": "2.10%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "95.80%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActions.setDefaultUnit(kony.flex.DP);
            var flxHorizontalLineActions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHorizontalLineActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHorizontalLineActions.setDefaultUnit(kony.flex.DP);
            flxHorizontalLineActions.add();
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "top": "0",
                "width": "12.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxActions.add(flxHorizontalLineActions, btnBack);
            flxSetCardLimitsOverview.add(flxDailyWithdrawalLimitOverview, flxHorizontalLine1, flxDailyPurchaseLimitOverview, flxHorizontalLine2, flxIntDailyWithdrawalLimitOverview, flxHorizontalLine3, flxIntDailyPurchaseLimitOverview, flxIncreaseLimits, flxActions);
            var flxSetCardLimitsNew = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSetCardLimitsNew",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSetCardLimitsNew.setDefaultUnit(kony.flex.DP);
            var flxDailyWithdrawalLimit = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDailyWithdrawalLimit",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyWithdrawalLimit.setDefaultUnit(kony.flex.DP);
            var flxDailyWithdrawalWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDailyWithdrawalWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyWithdrawalWrapper.setDefaultUnit(kony.flex.DP);
            var lblDailyWithdrawalLimit = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDailyWithdrawalLimit",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLabel42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.DailyWithdrawalLimit\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSetWithdrawalLimitSlider = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSetWithdrawalLimitSlider",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknLabelBold",
                "text": "$15,000.00",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyWithdrawalWrapper.add(lblDailyWithdrawalLimit, lblSetWithdrawalLimitSlider);
            var flxPrevWithdrawalSlider = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPrevWithdrawalSlider",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "60%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16dp",
                "width": "35.50%",
                "zIndex": 2,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrevWithdrawalSlider.setDefaultUnit(kony.flex.DP);
            var limitWithdrawalSlider = new kony.ui.Slider({
                "id": "limitWithdrawalSlider",
                "isVisible": true,
                "left": "10dp",
                "max": 1000,
                "min": 0,
                "onSlide": controller.AS_Slider_ba78fd68c7a74bf5ac1a71cc692899e0,
                "selectedValue": 1,
                "step": 1,
                "thumbImage": "slider_knob_white_small.png",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {}, {
                "orientation": constants.SLIDER_HORIZONTAL_ORIENTATION,
                "thickness": 2,
                "viewType": constants.SLIDER_VIEW_TYPE_DEFAULT
            });
            flxPrevWithdrawalSlider.add(limitWithdrawalSlider);
            var limitPrevWithdrawalSlider = new kony.ui.Slider({
                "id": "limitPrevWithdrawalSlider",
                "isVisible": true,
                "left": "61.50%",
                "leftSkin": "slSliderLeftBlue",
                "max": 1000,
                "min": 0,
                "rightSkin": "slSliderRightBlue",
                "selectedValue": 1,
                "step": 1,
                "thumbImage": "slider_android.png",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {}, {
                "orientation": constants.SLIDER_HORIZONTAL_ORIENTATION,
                "thickness": 2,
                "viewType": constants.SLIDER_VIEW_TYPE_DEFAULT
            });
            var lblPreviousValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPreviousValue",
                "isVisible": false,
                "left": "550dp",
                "skin": "slLabel",
                "text": "Label",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyWithdrawalLimit.add(flxDailyWithdrawalWrapper, flxPrevWithdrawalSlider, limitPrevWithdrawalSlider, lblPreviousValue);
            var flxDailyPurchaseLimit = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDailyPurchaseLimit",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyPurchaseLimit.setDefaultUnit(kony.flex.DP);
            var lblDailyPurchaseLimit = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDailyPurchaseLimit",
                "isVisible": true,
                "left": "2.10%",
                "skin": "sknLabel42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.DailyPurchaseLimit\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSetPurchaseLimitSlider = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSetPurchaseLimitSlider",
                "isVisible": true,
                "left": "177dp",
                "skin": "bbSknLabelBold",
                "text": "$15,000.00",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPrevPurchaseSlider = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100.54%",
                "id": "flxPrevPurchaseSlider",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "60%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16dp",
                "width": "35.50%",
                "zIndex": 2,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrevPurchaseSlider.setDefaultUnit(kony.flex.DP);
            var limitPurchaseSlider = new kony.ui.Slider({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "id": "limitPurchaseSlider",
                "isVisible": true,
                "left": "10dp",
                "max": 1000,
                "min": 0,
                "onSlide": controller.AS_Slider_c8dbfb620d114a7a87984a6ecf00801a,
                "rightSkin": "slSliderRightBlue",
                "selectedValue": 1,
                "step": 1,
                "thumbImage": "slider_knob_white_small.png",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {}, {
                "orientation": constants.SLIDER_HORIZONTAL_ORIENTATION,
                "thickness": 2,
                "viewType": constants.SLIDER_VIEW_TYPE_DEFAULT
            });
            flxPrevPurchaseSlider.add(limitPurchaseSlider);
            var limitPrevPurchaseSlider = new kony.ui.Slider({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "limitPrevPurchaseSlider",
                "isVisible": true,
                "left": "61.50%",
                "max": 1000,
                "min": 0,
                "rightSkin": "slSliderRightBlue",
                "selectedValue": 1,
                "step": 1,
                "thumbImage": "slider_android.png",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {}, {
                "orientation": constants.SLIDER_HORIZONTAL_ORIENTATION,
                "thickness": 2,
                "viewType": constants.SLIDER_VIEW_TYPE_DEFAULT
            });
            var lblPurchaseValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPurchaseValue",
                "isVisible": false,
                "left": "550dp",
                "skin": "slLabel",
                "text": "Label",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyPurchaseLimit.add(lblDailyPurchaseLimit, lblSetPurchaseLimitSlider, flxPrevPurchaseSlider, limitPrevPurchaseSlider, lblPurchaseValue);
            var flxIncreaseLimit = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxIncreaseLimit",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIncreaseLimit.setDefaultUnit(kony.flex.DP);
            var lblIncreaseLimit = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "45%",
                "centerY": "50%",
                "id": "lblIncreaseLimit",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabel42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.IncreaseLimit\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContactUs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxContactUs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5dp",
                "isModalContainer": false,
                "width": "15%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContactUs.setDefaultUnit(kony.flex.DP);
            var lblContactUs = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblContactUs",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknLblSSP1a98ff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContactUs.add(lblContactUs);
            flxIncreaseLimit.add(lblIncreaseLimit, flxContactUs);
            var confirmButtons = new com.InfinityOLB.Transfers.TransferConfirmButtons({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "82dp",
                "id": "confirmButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffBorderffffff1pxRadius3px",
                "top": "0dp",
                "width": "100%",
                "appName": "TransfersMA",
                "overrides": {
                    "btnCancel": {
                        "right": "16.60%",
                        "width": "12.50%"
                    },
                    "btnConfirm": {
                        "width": "12.50%"
                    },
                    "btnModify": {
                        "isVisible": false,
                        "right": "16.67%",
                        "width": "12.50%"
                    },
                    "confirmButtons": {
                        "height": "82dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            confirmButtons.btnConfirm.onClick = controller.AS_Button_jb5e3299d9824550bfa9de7e2d9636a7;
            flxSetCardLimitsNew.add(flxDailyWithdrawalLimit, flxDailyPurchaseLimit, flxIncreaseLimit, confirmButtons);
            flxMainSetCardLimits.add(confirmHeaders, flxHorizontalLine, flxCardName, flxSetCardLimitsOverview, flxSetCardLimitsNew);
            flxCardShadow.add(flxMainSetCardLimits);
            flxCardLimits.add(lblSetCardLimitsHeader, flxCardShadow);
            var flxRightBarSetCardLimits = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "400dp",
                "id": "flxRightBarSetCardLimits",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "68dp",
                "width": "32.50%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightBarSetCardLimits.setDefaultUnit(kony.flex.DP);
            var flxCardAccountsSetCardLimits = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCardAccountsSetCardLimits",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "98%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardAccountsSetCardLimits.setDefaultUnit(kony.flex.DP);
            var CopyflxMangeTravelPlans0b5921b9abd6445 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "CopyflxMangeTravelPlans0b5921b9abd6445",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_e2b045e73d35448abeb2d332471a96d5,
                "skin": "skncursor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            CopyflxMangeTravelPlans0b5921b9abd6445.setDefaultUnit(kony.flex.DP);
            var CopylblManageTravelPlans0f3b753874c9a4c = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "49dp",
                "id": "CopylblManageTravelPlans0f3b753874c9a4c",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknLblSSP1a98ff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ManageTravelPlans\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Manage Travel Plans"
            });
            var CopylblSeparator0j91be24c747746 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "CopylblSeparator0j91be24c747746",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "59dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxMangeTravelPlans0b5921b9abd6445.add(CopylblManageTravelPlans0f3b753874c9a4c, CopylblSeparator0j91be24c747746);
            var CopyflxActivateNewCard0fc6e20f9d16c4e = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "CopyflxActivateNewCard0fc6e20f9d16c4e",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_e2b045e73d35448abeb2d332471a96d5,
                "skin": "skncursor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            CopyflxActivateNewCard0fc6e20f9d16c4e.setDefaultUnit(kony.flex.DP);
            var CopylblActivateNewCard0ef7ff289d44349 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "49dp",
                "id": "CopylblActivateNewCard0ef7ff289d44349",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknLblSSP1a98ff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "ADD KONY ACCOUNT"
            });
            var CopylblSeparator0a9ebd4a4ae6c4f = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "CopylblSeparator0a9ebd4a4ae6c4f",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "59dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxActivateNewCard0fc6e20f9d16c4e.add(CopylblActivateNewCard0ef7ff289d44349, CopylblSeparator0a9ebd4a4ae6c4f);
            var CopyflxApplyForNewCard0d77194b5449141 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "CopyflxApplyForNewCard0d77194b5449141",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_b2c6e318798440b4a623903db539a40d,
                "skin": "skncursor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            CopyflxApplyForNewCard0d77194b5449141.setDefaultUnit(kony.flex.DP);
            var CopylblSeparator0i6b59358f8cc42 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "0dp",
                "id": "CopylblSeparator0i6b59358f8cc42",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopylblApplyForNewCard0j58e2516ab1a49 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "49dp",
                "id": "CopylblApplyForNewCard0j58e2516ab1a49",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknLblSSP1a98ff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ApplyForNewCard\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "ADD NON KONY ACCOUNT"
            });
            var CopylblSeperator0a4bbb39de0284b = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "1dp",
                "id": "CopylblSeperator0a4bbb39de0284b",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "59dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxApplyForNewCard0d77194b5449141.add(CopylblSeparator0i6b59358f8cc42, CopylblApplyForNewCard0j58e2516ab1a49, CopylblSeperator0a4bbb39de0284b);
            var CopyflxMyPreviousOwnedCards0ia4a39b11e4e44 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "CopyflxMyPreviousOwnedCards0ia4a39b11e4e44",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_gcc2b9b28ad749428d3cf5e950209af1,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            CopyflxMyPreviousOwnedCards0ia4a39b11e4e44.setDefaultUnit(kony.flex.DP);
            var CopylblMyPreviousOwnedCards0c72dd01857364a = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "49dp",
                "id": "CopylblMyPreviousOwnedCards0c72dd01857364a",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegularOld",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.MyPreviousOwnedCards\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "ADD INTERNATIONAL ACCOUNT"
            });
            CopyflxMyPreviousOwnedCards0ia4a39b11e4e44.add(CopylblMyPreviousOwnedCards0c72dd01857364a);
            flxCardAccountsSetCardLimits.add(CopyflxMangeTravelPlans0b5921b9abd6445, CopyflxActivateNewCard0fc6e20f9d16c4e, CopyflxApplyForNewCard0d77194b5449141, CopyflxMyPreviousOwnedCards0ia4a39b11e4e44);
            flxRightBarSetCardLimits.add(flxCardAccountsSetCardLimits);
            flxSetCardLimits.add(flxCardLimits, flxRightBarSetCardLimits);
            var flxCardVerification = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxCardVerification",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardVerification.setDefaultUnit(kony.flex.DP);
            var CardLockVerificationStep = new com.konyolb.CardManagement.CardLockVerificationStep({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "CardLockVerificationStep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA",
                "overrides": {
                    "CardActivation.imgChecbox": {
                        "src": "unchecked_box.png"
                    },
                    "CardActivation.imgWarning": {
                        "src": "error_yellow.png"
                    },
                    "CardActivation.lblHeading2": {
                        "left": "2.80%"
                    },
                    "CardActivation.lblIns3": {
                        "text": "Payment guidline number three."
                    },
                    "CardLockVerificationStep": {
                        "isVisible": true
                    },
                    "Copywarning0b8a8390f76a040": {
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "Copywarning0b8a8390f76a040.imgDot1": {
                        "src": "pageoffdot.png"
                    },
                    "Copywarning0b8a8390f76a040.imgDot2": {
                        "src": "pageoffdot.png"
                    },
                    "Copywarning0b8a8390f76a040.imgDot3": {
                        "src": "pageoffdot.png"
                    },
                    "Copywarning0b8a8390f76a040.imgDot4": {
                        "src": "pageoffdot.png"
                    },
                    "Copywarning0b8a8390f76a040.imgWarning": {
                        "src": "error_yellow.png"
                    },
                    "Copywarning0ba67056c374842.imgDot1": {
                        "src": "pageoffdot.png"
                    },
                    "Copywarning0ba67056c374842.imgDot2": {
                        "src": "pageoffdot.png"
                    },
                    "Copywarning0ba67056c374842.imgDot3": {
                        "src": "pageoffdot.png"
                    },
                    "Copywarning0ba67056c374842.imgDot4": {
                        "src": "pageoffdot.png"
                    },
                    "Copywarning0ba67056c374842.imgWarning": {
                        "src": "error_yellow.png"
                    },
                    "Copywarning0ba67056c374842.rtxWarningText1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RichText\")"
                    },
                    "Copywarning0ba67056c374842.rtxWarningText2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RichText\")"
                    },
                    "Copywarning0ba67056c374842.rtxWarningText3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RichText\")"
                    },
                    "Copywarning0ba67056c374842.rtxWarningText4": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RichText\")"
                    },
                    "WarningMessage": {
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "WarningMessage.flxWarnings": {
                        "right": 80
                    },
                    "WarningMessage.imgChecbox": {
                        "src": "unchecked_box.png"
                    },
                    "WarningMessage.imgDot1": {
                        "src": "pageoffdot.png"
                    },
                    "WarningMessage.imgDot2": {
                        "src": "pageoffdot.png"
                    },
                    "WarningMessage.imgDot3": {
                        "src": "pageoffdot.png"
                    },
                    "WarningMessage.imgDot4": {
                        "src": "pageoffdot.png"
                    },
                    "WarningMessage.imgWarning": {
                        "src": "error_yellow.png"
                    },
                    "WarningMessage.rtxWarningText1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Cardbloackline1\")"
                    },
                    "WarningMessage.rtxWarningText2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Cardbloackline2\")"
                    },
                    "WarningMessage.rtxWarningText3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Cardbloackline3\")"
                    },
                    "WarningMessage.rtxWarningText4": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Cardbloackline4\")"
                    },
                    "btnAddAnother": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ADDANOTHERTRAVELNOTIFICATION\")"
                    },
                    "cardDetails.flxCardDetails": {
                        "left": "36%",
                        "right": "20px"
                    },
                    "cardDetails.imgCard": {
                        "left": "6%",
                        "src": "golden_card.png",
                        "top": "40dp",
                        "width": "125dp"
                    },
                    "cardDetails.imgCardMobile": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "src": "golden_card.png",
                        "top": "30dp"
                    },
                    "cardDetails.lblCardHeader": {
                        "centerY": "viz.val_cleared",
                        "top": "30dp"
                    },
                    "cardDetails.lblCardStatus": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ACTIVE\")"
                    },
                    "cardDetails.lblCardStatusMobile": {
                        "width": "180dp"
                    },
                    "cardDetails.lblKey1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.CardNumber\")"
                    },
                    "cardDetails.lblKey2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ValidThrough\")"
                    },
                    "cardDetails.lblKey3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountDetail.creditLimit\")"
                    },
                    "cardDetails.lblKey4": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountDetail.availableCredit\")"
                    },
                    "cardDetails.rtxValue1": {
                        "right": 0
                    },
                    "cardDetails.rtxValueMobile": {
                        "centerY": "viz.val_cleared",
                        "width": "viz.val_cleared"
                    },
                    "confirmButtons": {
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "confirmButtons.btnCancel": {
                        "left": "30.33%"
                    },
                    "confirmButtons.btnConfirm": {
                        "width": "21.40%"
                    },
                    "confirmButtons.btnModify": {
                        "width": "21.40%"
                    },
                    "confirmButtons.flxHorizontalLine": {
                        "top": "20dp"
                    },
                    "confirmHeaders.lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ChangeCardPin\")"
                    },
                    "flxAddressCheckbox1": {
                        "left": "0dp"
                    },
                    "flxCVV": {
                        "top": "30dp"
                    },
                    "flxCardReplacement": {
                        "isVisible": false
                    },
                    "flxChangeCardPin": {
                        "isVisible": false
                    },
                    "flxConfirmPIN": {
                        "width": "viz.val_cleared"
                    },
                    "flxDeactivateCard": {
                        "isVisible": false
                    },
                    "flxLeft": {
                        "clipBounds": true
                    },
                    "flxMain": {
                        "clipBounds": true
                    },
                    "flxNoteTextBox": {
                        "clipBounds": false
                    },
                    "flxRight": {
                        "isVisible": true,
                        "right": "30px"
                    },
                    "flxTravelNotification": {
                        "isVisible": false
                    },
                    "flxUsernameVerificationAnswerSecQue": {
                        "width": "75%"
                    },
                    "flxUsernameVerificationOption2": {
                        "isVisible": false
                    },
                    "flxUsernameVerificationUsingOTP": {
                        "width": "75%"
                    },
                    "flxUsernameVerificationphone": {
                        "width": "17%"
                    },
                    "flxUsernameVerificationphone2": {
                        "width": "17%"
                    },
                    "flxVerifyByOptions": {
                        "isVisible": false
                    },
                    "flxVerifyBySecureAccessCode": {
                        "isVisible": false
                    },
                    "flxVerifyBySecurityQuestions": {
                        "isVisible": false
                    },
                    "flxWrapper": {
                        "clipBounds": true
                    },
                    "imgConfirmPIN": {
                        "height": "30dp",
                        "width": "22dp"
                    },
                    "imgCurrentPIN": {
                        "height": "30dp",
                        "isVisible": false
                    },
                    "imgInfo": {
                        "src": "info_grey.png"
                    },
                    "imgNewPIN": {
                        "height": "30dp",
                        "isVisible": false
                    },
                    "imgSecureAccessCode": {
                        "src": "mobile_sendpin.png"
                    },
                    "imgSelectCard": {
                        "src": "checked_box.png"
                    },
                    "imgUsernameVerificationcheckedRadio": {
                        "src": "icon_radiobtn_active.png"
                    },
                    "imgUsernameVerificationcheckedRadioOption2": {
                        "src": "icon_radiobtn.png"
                    },
                    "imgUsernameVerificationphone": {
                        "src": "mobile_sendpin.png"
                    },
                    "imgUsernameVerificationphone2": {
                        "src": "security_questions.png"
                    },
                    "imgViewCVV": {
                        "height": "16dp",
                        "right": "10dp",
                        "src": "view.png",
                        "width": "40dp"
                    },
                    "imgWarning": {
                        "src": "error_yellow.png"
                    },
                    "lblAddress": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Addresstoreceivecard\")"
                    },
                    "lblAnswers1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Answer\")"
                    },
                    "lblAnswers2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Answer\")"
                    },
                    "lblConfirmPIN": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ConfirmPIN\")"
                    },
                    "lblCurrentPIN": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.CurrentPIN\")"
                    },
                    "lblDuration1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SetTravelDuration\")"
                    },
                    "lblNewPIN": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.NewPIN\")"
                    },
                    "lblNote": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.Note\")"
                    },
                    "lblNote2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.Note\")"
                    },
                    "lblNotePinChange": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.Note\")"
                    },
                    "lblOption3": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblQuestions1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.MFA.Question1\")"
                    },
                    "lblQuestions2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.MFA.Question2\")"
                    },
                    "lblReason": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ReasonForChangingPIN\")"
                    },
                    "lblReason2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ReasonForChangingPIN\")",
                        "width": "97%"
                    },
                    "lblSelectCard": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelMemo\")"
                    },
                    "lblUsernameVerificationtext2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IfYouHavenotRecievedOTP\")"
                    },
                    "tbxAnswers1": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")"
                    },
                    "tbxAnswers2": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.TypeYourAnswerHere\")"
                    },
                    "tbxCVV": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.MFA.EnterSecureAccessCode\")",
                        "secureTextEntry": false
                    },
                    "tbxConfirmPIN": {
                        "maxTextLength": 4
                    },
                    "tbxNewPIN": {
                        "maxTextLength": 4
                    },
                    "tbxNote": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.transfers.optional\")"
                    },
                    "tbxNoteOptional": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.transfers.optional\")"
                    },
                    "tbxNotePinChange": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.transfers.optional\")"
                    },
                    "warning": {
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "warning.imgChecbox": {
                        "src": "unchecked_box.png"
                    },
                    "warning.imgDot1": {
                        "src": "pageoffdot.png"
                    },
                    "warning.imgDot2": {
                        "src": "pageoffdot.png"
                    },
                    "warning.imgDot3": {
                        "src": "pageoffdot.png"
                    },
                    "warning.imgDot4": {
                        "src": "pageoffdot.png"
                    },
                    "warning.imgWarning": {
                        "src": "error_yellow.png"
                    },
                    "warning.rtxWarningText1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RichText\")"
                    },
                    "warning.rtxWarningText2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RichText\")"
                    },
                    "warning.rtxWarningText3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RichText\")"
                    },
                    "warning.rtxWarningText4": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RichText\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {
                    "cardDetails.imgCard": {
                        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO
                    }
                }
            }, {
                "overrides": {}
            });
            flxCardVerification.add(CardLockVerificationStep);
            var flxCardCVV = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxCardCVV",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "1200dp",
                "zIndex": 1000,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardCVV.setDefaultUnit(kony.flex.DP);
            var lblActivateCardHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblActivateCardHeader",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlblUserName",
                "text": "Activate a Card",
                "top": "22dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxActivateContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxActivateContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "99%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivateContent.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.CVVPIN\")",
                "top": "15dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeperator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "1dp",
                "id": "lblSeperator",
                "isVisible": true,
                "skin": "sknlblBge3e3e3op100",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxIncorrectCVV = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxIncorrectCVV",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "30dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIncorrectCVV.setDefaultUnit(kony.flex.DP);
            var imgIncorrectCVV = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "32dp",
                "id": "imgIncorrectCVV",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "32dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorCVV = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "52%",
                "id": "lblErrorCVV",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.IncorrectCVVcodeEntered\")",
                "top": "32dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIncorrectCVV.add(imgIncorrectCVV, lblErrorCVV);
            var lblCardNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblCardNumber",
                "isVisible": true,
                "left": "44dp",
                "skin": "sknlbl424242SSP18px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.EnterCVV\")",
                "top": "28dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCVV = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "height": "52dp",
                "id": "imgCVV",
                "isVisible": true,
                "left": "621dp",
                "skin": "slImage",
                "src": "cvv_icon.png",
                "top": "21dp",
                "width": "52dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCVV = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "id": "lblCVV",
                "isVisible": true,
                "linkSkin": "defRichTextLink",
                "skin": "sknRtx42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ActivateCVVOnBackOfCard\")",
                "top": "13dp",
                "width": "27%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCVVNumber = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "46dp",
                "id": "flxCVVNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "10dp",
                "width": "298dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCVVNumber.setDefaultUnit(kony.flex.DP);
            var tbxCVVNumber = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "role": "textbox",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknSSP42424215Opacity0Border4a90e2",
                "height": "100%",
                "id": "tbxCVVNumber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "maxTextLength": 3,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.CardManagement.EnterCVVNumber\")",
                "right": 0,
                "secureTextEntry": true,
                "skin": "sknSSP42424215Opacity0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var imgViewCVVWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "16dp",
                "id": "imgViewCVVWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "6.06%",
                "width": "22dp",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            imgViewCVVWrapper.setDefaultUnit(kony.flex.DP);
            var imgViewCVV = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.View\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgViewCVV",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "icon_hide.png",
                "width": "100%",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            imgViewCVVWrapper.add(imgViewCVV);
            flxCVVNumber.add(tbxCVVNumber, imgViewCVVWrapper);
            var flxCVVWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxCVVWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCVVWrapper.setDefaultUnit(kony.flex.DP);
            var btnfindCVV = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerX": "50%",
                "height": "50dp",
                "id": "btnfindCVV",
                "isVisible": true,
                "skin": "sknBtnSSPFont4176a415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.findCVVCode\")",
                "top": "15dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCVVPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxCVVPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCVVPopup.setDefaultUnit(kony.flex.DP);
            var CVVInfo = new com.konyolb.CardManagement.CVVInfo({
                "height": "200dp",
                "id": "CVVInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.20%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA",
                "overrides": {
                    "CVVInfo": {
                        "height": "200dp",
                        "left": "6.20%",
                        "top": "0dp"
                    },
                    "RichTextInfo": {
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.cards.cvv.info\")",
                        "top": "0dp",
                        "width": "70%"
                    },
                    "flxAccountType": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerX": "viz.val_cleared",
                        "top": "115dp",
                        "width": "80%"
                    },
                    "flxCross": {
                        "isVisible": true
                    },
                    "flxInformationText": {
                        "centerX": "viz.val_cleared",
                        "clipBounds": true,
                        "height": "200dp",
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "top": "-2dp",
                        "width": "100%"
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgHighlightCVV": {
                        "height": "70dp",
                        "src": "cardcvv.png",
                        "top": "35dp",
                        "width": "100dp"
                    },
                    "imgToolTip": {
                        "centerX": "50%",
                        "height": "50dp",
                        "left": "viz.val_cleared",
                        "src": "callout.png",
                        "width": "60dp",
                        "zIndex": 1
                    },
                    "lblInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.EnrollCVV.Title\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCVVPopup.add(CVVInfo);
            flxCVVWrapper.add(btnfindCVV, flxCVVPopup);
            var lblButtonSeperator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "1dp",
                "id": "lblButtonSeperator",
                "isVisible": true,
                "skin": "sknlblBge3e3e3op100",
                "top": "20dp",
                "width": "1160dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxCVVButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "110dp",
                "id": "flxCVVButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCVVButtons.setDefaultUnit(kony.flex.DP);
            var btnContinue2 = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnContinue2",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel2 = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel2",
                "isVisible": true,
                "right": "180dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCVVButtons.add(btnContinue2, btnCancel2);
            flxActivateContent.add(lblHeader, lblSeperator, flxIncorrectCVV, lblCardNumber, imgCVV, lblCVV, flxCVVNumber, flxCVVWrapper, lblButtonSeperator, flxCVVButtons);
            var flxDummy1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxDummy1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy1.setDefaultUnit(kony.flex.DP);
            flxDummy1.add();
            flxCardCVV.add(lblActivateCardHeader, flxActivateContent, flxDummy1);
            var flxMyCardsView = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "centerX": "50.50%",
                "clipBounds": false,
                "id": "flxMyCardsView",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyCardsView.setDefaultUnit(kony.flex.DP);
            var flxTravelPlan = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTravelPlan",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "66.16%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTravelPlan.setDefaultUnit(kony.flex.DP);
            var flxHeading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "flxHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeading.setDefaultUnit(kony.flex.DP);
            var lblMyCardsHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "height": "25dp",
                "id": "lblMyCardsHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSPReg17px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.CreateTravelPlan\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBypass = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnBypass",
                "isVisible": true,
                "left": "260dp",
                "skin": "btnSkipNavigation",
                "text": "Skip to card management options",
                "top": "-30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a",
                    "tagName": "span"
                },
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblSeparator2",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeading.add(lblMyCardsHeader, btnBypass, lblSeparator2);
            var flxBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "70dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var lblWarningTravelPlan = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblWarningTravelPlan",
                "isVisible": false,
                "left": "29dp",
                "skin": "sknLabelSSPFF000015Px",
                "text": "Label",
                "top": "15dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRequestID = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.AlertsAndMessages.requestid\")",
                    "tagName": "span"
                },
                "id": "lblRequestID",
                "isVisible": false,
                "left": "30dp",
                "skin": "sknlbla0a0a015px",
                "text": "Request Id",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRequestNo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "REQ123455",
                    "tagName": "span"
                },
                "id": "lblRequestNo",
                "isVisible": false,
                "left": "30dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "REQ123455",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDates = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Select Travel Start & End Dates",
                    "tagName": "span"
                },
                "id": "lblDates",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbla0a0a015px",
                "text": "Select Travel Start & End Dates",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDates = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDates",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDates.setDefaultUnit(kony.flex.DP);
            var lblFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                    "tagName": "span"
                },
                "id": "lblFrom",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.from\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            var flxCalFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxCalFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCalFrom.setDefaultUnit(kony.flex.DP);
            var calFrom = new kony.ui.Calendar({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblFrom",
                        "tabindex": 0
                    }
                },
                "calendarIcon": "calender.png",
                "dateComponents": ["30", "8", "2017"],
                "dateFormat": "dd/MM/yyyy",
                "day": 30,
                "focusSkin": "sknCalBorder003e751px",
                "formattedDate": "30/08/2017",
                "height": "40dp",
                "hour": 0,
                "id": "calFrom",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "month": 8,
                "seconds": 0,
                "skin": "sknCalNormal",
                "top": "10dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "170dp",
                "year": 2017,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxCalFrom.add(calFrom);
            var lblTo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.To\")",
                    "tagName": "span"
                },
                "id": "lblTo",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.To\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            var flxCalTo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxCalTo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCalTo.setDefaultUnit(kony.flex.DP);
            var calTo = new kony.ui.Calendar({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblTo",
                        "tabindex": 0
                    }
                },
                "calendarIcon": "calender.png",
                "dateComponents": ["30", "8", "2017"],
                "dateFormat": "dd/MM/yyyy",
                "day": 30,
                "focusSkin": "sknCalBorder003e751px",
                "formattedDate": "30/08/2017",
                "height": "40dp",
                "hour": 0,
                "id": "calTo",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "month": 8,
                "seconds": 0,
                "skin": "sknCalNormal",
                "top": "10dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "170dp",
                "year": 2017,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxCalTo.add(calTo);
            flxDates.add(lblFrom, flxCalFrom, lblTo, flxCalTo);
            var lblDestination = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Select Destination",
                    "tagName": "span"
                },
                "id": "lblDestination",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbla0a0a015px",
                "text": "Select Destination",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 3, 0],
                "paddingInPixel": false
            }, {});
            var flxDestination = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDestination",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "92%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDestination.setDefaultUnit(kony.flex.DP);
            var txtDestination = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-controls": "segDestinationList",
                        "aria-expanded": false,
                        "aria-haspopup": "true",
                        "aria-labelledby": "lblDestination",
                        "aria-required": true,
                        "role": "combobox",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "txtDestination",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SearchCountry\")",
                "secureTextEntry": false,
                "skin": "skntxt",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "3dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxAddFeatureRequestandimg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": -1
                    },
                    "a11yLabel": "Add Destination"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddFeatureRequestandimg",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "80dp",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverCheckBox"
            });
            flxAddFeatureRequestandimg.setDefaultUnit(kony.flex.DP);
            var lblAnotherDestination = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.ADD\")",
                    "tagName": "span"
                },
                "height": "25dp",
                "id": "lblAnotherDestination",
                "isVisible": true,
                "left": "0px",
                "skin": "sknSSP3343A815PxOpacity80",
                "text": "Add",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Add Another Destination"
            });
            flxAddFeatureRequestandimg.add(lblAnotherDestination);
            flxDestination.add(txtDestination, flxAddFeatureRequestandimg);
            var flxDestinationList = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDestinationList",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "sknBorder727272",
                "top": "0",
                "width": "92%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDestinationList.setDefaultUnit(kony.flex.DP);
            var segDestinationList = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "ul"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgBank": "bank_icon_boa.png",
                    "lblSeparator": "-",
                    "lblUsers": "Bank of America"
                }, {
                    "imgBank": "bank_icon_citi.png",
                    "lblSeparator": "-",
                    "lblUsers": "CITI Bank"
                }, {
                    "imgBank": "bank_icon_chase.png",
                    "lblSeparator": "-",
                    "lblUsers": "Chase Bank"
                }, {
                    "imgBank": "bank_icon_hdfc.png",
                    "lblSeparator": "-",
                    "lblUsers": "HDFC bank"
                }, {
                    "imgBank": "bank_icon_wf.png",
                    "lblSeparator": "-",
                    "lblUsers": "Wells Fargo"
                }],
                "groupCells": false,
                "id": "segDestinationList",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_d43ef915b9634f1b84dfaf1d839333d1,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "CardsMA",
                    "friendlyName": "flxBankNames"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxBankNames": "flxBankNames",
                    "imgBank": "imgBank",
                    "lblSeparator": "lblSeparator",
                    "lblUsers": "lblUsers"
                },
                "width": "100%",
                "zIndex": 100,
                "appName": "CardsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDestinationList.add(segDestinationList);
            var flxOtherDestinations = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxOtherDestinations",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOtherDestinations.setDefaultUnit(kony.flex.DP);
            var segDestinations = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "ul"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segDestinations",
                "isVisible": true,
                "left": "30dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "CardsMA",
                    "friendlyName": "flxSelectDestination"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxClose": "flxClose",
                    "flxSelectDestination": "flxSelectDestination",
                    "imgClose": "imgClose",
                    "lblAnotherDestination": "lblAnotherDestination",
                    "lblDestination": "lblDestination",
                    "lblPlace": "lblPlace",
                    "lblSeparator2": "lblSeparator2"
                },
                "width": "92%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOtherDestinations.add(segDestinations);
            var lblPhoneNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddPhoneNumber\")",
                    "tagName": "span"
                },
                "id": "lblPhoneNumber",
                "isVisible": true,
                "left": "30dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AddPhoneNumber\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtPhoneNumber = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPhoneNumber",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "txtPhoneNumber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30dp",
                "secureTextEntry": false,
                "skin": "skntxt",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.optional\")",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblAdditionalInformation = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.AddInformation\")",
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblAdditionalInformation",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.AddInformation\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtareaUserComments = new kony.ui.TextArea2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblAdditionalInformation",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTxrBorder003e741px",
                "height": "150dp",
                "id": "txtareaUserComments",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "30dp",
                "maxTextLength": 1000,
                "numberOfVisibleLines": 3,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.CardManagement.AdditionalInformationOptionalText\")",
                "skin": "sknlblTextareaBordere3e3e3SSP42424215px",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "92%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "103dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Continue to card selection"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "35dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                "width": "258px",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnCancel1 = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel Travel Plan"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel1",
                "isVisible": true,
                "right": "315dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "260dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a"
                },
                "height": "1dp",
                "id": "lblSeparator3",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(btnContinue, btnCancel1, lblSeparator3);
            flxBody.add(lblWarningTravelPlan, lblRequestID, lblRequestNo, lblDates, flxDates, lblDestination, flxDestination, flxDestinationList, flxOtherDestinations, lblPhoneNumber, txtPhoneNumber, lblAdditionalInformation, txtareaUserComments, flxButtons);
            flxTravelPlan.add(flxHeading, flxBody);
            var flxMyCards = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMyCards",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "66.16%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyCards.setDefaultUnit(kony.flex.DP);
            var myCards = new com.konyolb.manageCards.myCards({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "myCards",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA",
                "overrides": {
                    "btnApplyForCard": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.APPLY\")"
                    },
                    "btnConfirm": {
                        "width": "4%"
                    },
                    "flxAccountName": {
                        "left": "0dp",
                        "width": "100%"
                    },
                    "flxApplyForCards": {
                        "isVisible": true
                    },
                    "flxFiltersList": {
                        "left": "18dp",
                        "right": "viz.val_cleared",
                        "width": "150px"
                    },
                    "flxNoCardsError": {
                        "isVisible": true,
                        "top": "30dp",
                        "width": "95%"
                    },
                    "flxNoError": {
                        "centerX": "50%",
                        "clipBounds": false,
                        "height": "400dp",
                        "isVisible": false,
                        "top": "20dp",
                        "width": "97.70%"
                    },
                    "flxNoResultsSearch": {
                        "height": "100%",
                        "isVisible": false,
                        "top": "5dp"
                    },
                    "flxRequestANewCard": {
                        "centerX": "viz.val_cleared",
                        "isVisible": false,
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "flxSearch": {
                        "centerX": "viz.val_cleared",
                        "isVisible": false,
                        "left": "0dp",
                        "top": "17dp",
                        "width": "100%"
                    },
                    "flxSearchContiner": {
                        "centerY": "50%",
                        "height": "45dp"
                    },
                    "imgNoCardsError": {
                        "src": "error_yellow.png"
                    },
                    "lblMyCardsHeader": {
                        "height": "25dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.MyCards\")",
                        "top": "25dp"
                    },
                    "lblNoCardsError": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Pageleveltransaction\")"
                    },
                    "lblNoResultsSearch": {
                        "centerY": "viz.val_cleared",
                        "top": "40dp"
                    },
                    "lblRequestANewCard": {
                        "left": "7.69%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblSearch": {
                        "bottom": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "myCards": {
                        "isVisible": true,
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "width": "100%"
                    },
                    "segMyCards": {
                        "data": [{
                            "btnAction1": "CHANGE PIN",
                            "btnAction2": "LOCK CARD",
                            "btnAction3": "REPORT LOST",
                            "btnAction4": "CANCEL CARD",
                            "btnAction5": "SET LIMITS",
                            "imgCard": "golden_card.png",
                            "imgCollapse": "arrow_down.png",
                            "imgIcon": "r",
                            "lblCardHeader": "My Platinum Credit Card",
                            "lblCardStatus": "Locked Card",
                            "lblIdentifier": "-$1000000.00",
                            "lblKey1": "Card Number:",
                            "lblKey2": "Valid Through:",
                            "lblKey3": "Daily Withdrawal limit:",
                            "lblKey4": "Available Credit:",
                            "lblSeparator1": "a",
                            "lblSeparator2": "a",
                            "lblTravelNotificationEnabled": "Travel Notification Enabled",
                            "rtxValue1": "XXXX XXXX XXXX 5404",
                            "rtxValue2": "02/20",
                            "rtxValue3": "$50,000",
                            "rtxValue4": "$32,500"
                        }, {
                            "btnAction1": "CHANGE PIN",
                            "btnAction2": "LOCK CARD",
                            "btnAction3": "REPORT LOST",
                            "btnAction4": "CANCEL CARD",
                            "btnAction5": "SET LIMITS",
                            "imgCard": "golden_card.png",
                            "imgCollapse": "arrow_down.png",
                            "imgIcon": "r",
                            "lblCardHeader": "My Platinum Credit Card",
                            "lblCardStatus": "Locked Card",
                            "lblIdentifier": "-$1000000.00",
                            "lblKey1": "Card Number:",
                            "lblKey2": "Valid Through:",
                            "lblKey3": "Daily Withdrawal limit:",
                            "lblKey4": "Available Credit:",
                            "lblSeparator1": "a",
                            "lblSeparator2": "a",
                            "lblTravelNotificationEnabled": "Travel Notification Enabled",
                            "rtxValue1": "XXXX XXXX XXXX 5404",
                            "rtxValue2": "02/20",
                            "rtxValue3": "$50,000",
                            "rtxValue4": "$32,500"
                        }, {
                            "btnAction1": "CHANGE PIN",
                            "btnAction2": "LOCK CARD",
                            "btnAction3": "REPORT LOST",
                            "btnAction4": "CANCEL CARD",
                            "btnAction5": "SET LIMITS",
                            "imgCard": "golden_card.png",
                            "imgCollapse": "arrow_down.png",
                            "imgIcon": "r",
                            "lblCardHeader": "My Platinum Credit Card",
                            "lblCardStatus": "Locked Card",
                            "lblIdentifier": "-$1000000.00",
                            "lblKey1": "Card Number:",
                            "lblKey2": "Valid Through:",
                            "lblKey3": "Daily Withdrawal limit:",
                            "lblKey4": "Available Credit:",
                            "lblSeparator1": "a",
                            "lblSeparator2": "a",
                            "lblTravelNotificationEnabled": "Travel Notification Enabled",
                            "rtxValue1": "XXXX XXXX XXXX 5404",
                            "rtxValue2": "02/20",
                            "rtxValue3": "$50,000",
                            "rtxValue4": "$32,500"
                        }],
                        "isVisible": true,
                        "top": "18dp"
                    },
                    "segSearch": {
                        "isVisible": true
                    },
                    "txtSearch": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.CardsManagement.SearchByAccount\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxEligibleCardsButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "110dp",
                "id": "flxEligibleCardsButtons",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97.58%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEligibleCardsButtons.setDefaultUnit(kony.flex.DP);
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            var btnCardsContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Continue\")"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCardsContinue",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknbtnSSPffffff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Continue"
            });
            var btnCardsCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {},
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Cancel\")"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCardsCancel",
                "isVisible": true,
                "right": "180dp",
                "skin": "sknBtnffffffBorder3343a81pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxEligibleCardsButtons.add(flxSeperator, btnCardsContinue, btnCardsCancel);
            flxMyCards.add(myCards, flxEligibleCardsButtons);
            var flxNewcard = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNewcard",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "66.16%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewcard.setDefaultUnit(kony.flex.DP);
            var flxCardHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "70dp",
                "id": "flxCardHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardHeader.setDefaultUnit(kony.flex.DP);
            var lblNewCardHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "height": "25dp",
                "id": "lblNewCardHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSPReg17px",
                "text": "New Card Request",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCardHeader.add(lblNewCardHeader);
            var flxCardBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCardBody",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "70dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardBody.setDefaultUnit(kony.flex.DP);
            var lblWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblWarning",
                "isVisible": false,
                "left": "22dp",
                "skin": "sknLabelSSPFF000015Px",
                "text": "Label",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "80dp",
                "id": "flxAccount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccount.setDefaultUnit(kony.flex.DP);
            var lblAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccount",
                "isVisible": true,
                "left": "3%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Account\")",
                "top": "10dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAccountValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "10dp",
                "width": "94%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountValue.setDefaultUnit(kony.flex.DP);
            var lblAccountvalue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAccountvalue",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Transfer From",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountValue.add(lblAccountvalue);
            flxAccount.add(lblAccount, flxAccountValue);
            var flxCard = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "80dp",
                "id": "flxCard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 9,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCard.setDefaultUnit(kony.flex.DP);
            var lblCard = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCard",
                "isVisible": true,
                "left": "3%",
                "right": "3%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Card2\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCardValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxCardValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "10dp",
                "width": "94%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardValue.setDefaultUnit(kony.flex.DP);
            var lblCardValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblCardValue",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Transfer From",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCardValue.add(lblCardValue);
            flxCard.add(lblCard, flxCardValue);
            var lblNameOnCard = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNameOnCard",
                "isVisible": true,
                "left": "3%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.NameOnCard2\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxNameOnCard = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-labelledby": "lblNameOnCard",
                        "role": "textbox",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxNameOnCard",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3%",
                "maxTextLength": 25,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.CardManagement.EnterNameOnCard\")",
                "secureTextEntry": false,
                "skin": "skntxt333333SSP15pxborder7272722pxbr",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblEnterCardPIN = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEnterCardPIN",
                "isVisible": true,
                "left": "3%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.EnterCardPin\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxEnterCardPIN = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-labelledby": "lblEnterCardPIN",
                        "role": "textbox",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEnterCardPIN",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3%",
                "maxTextLength": 4,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Enter4digitPIN\")",
                "secureTextEntry": true,
                "skin": "skntxt333333SSP15pxborder7272722pxbr",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblConfirmCardPIN = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblConfirmCardPIN",
                "isVisible": true,
                "left": "3%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ConfirmCardPIN\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxConfirmCardPIN = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-labelledby": "lblConfirmCardPIN",
                        "role": "textbox",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxConfirmCardPIN",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3%",
                "maxTextLength": 4,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Enter4digitPIN\")",
                "secureTextEntry": true,
                "skin": "skntxt333333SSP15pxborder7272722pxbr",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 1, 1, 1],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxNewcardButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "103dp",
                "id": "flxNewcardButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewcardButtons.setDefaultUnit(kony.flex.DP);
            var btnNewCardContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnNewCardContinue",
                "isVisible": true,
                "right": "25dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                "width": "258px",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnNewCardCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnNewCardCancel",
                "isVisible": true,
                "right": "195dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "width": "260dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparatorNew = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSeparatorNew",
                "isVisible": true,
                "left": "3%",
                "right": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewcardButtons.add(btnNewCardContinue, btnNewCardCancel, lblSeparatorNew);
            flxCardBody.add(lblWarning, flxAccount, flxCard, lblNameOnCard, tbxNameOnCard, lblEnterCardPIN, tbxEnterCardPIN, lblConfirmCardPIN, tbxConfirmCardPIN, flxNewcardButtons);
            var flxCardProductsSegments = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxCardProductsSegments",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardProductsSegments.setDefaultUnit(kony.flex.DP);
            var segCardProducts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segCardProducts",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowSkin": "sknSegDefault",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "CardsMA",
                    "friendlyName": "flxCardProducts"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnSelect": "btnSelect",
                    "flxCardDetails": "flxCardDetails",
                    "flxCardImage": "flxCardImage",
                    "flxCardProducts": "flxCardProducts",
                    "flxMyCards": "flxMyCards",
                    "flxProductDetails": "flxProductDetails",
                    "flxRepresentative": "flxRepresentative",
                    "imgCard": "imgCard",
                    "lblCardHeader": "lblCardHeader",
                    "lblRepresentativeheader": "lblRepresentativeheader",
                    "lblSeparator2": "lblSeparator2",
                    "rtxValue": "rtxValue",
                    "rtxValue1": "rtxValue1"
                },
                "width": "99%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancelCard = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "height": "40dp",
                "id": "btnCancelCard",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "top": "20dp",
                "width": "260dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCardProductsSegments.add(segCardProducts, btnCancelCard);
            var flxAccountsSegments = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxAccountsSegments",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsSegments.setDefaultUnit(kony.flex.DP);
            var flxAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "5dp",
                "width": "98%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccounts.setDefaultUnit(kony.flex.DP);
            var flxCardsAccountsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxCardsAccountsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardsAccountsHeader.setDefaultUnit(kony.flex.DP);
            var imgUser = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "imgUser",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "personal_banking_icon.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountsHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAccountsHeader",
                "isVisible": true,
                "left": "55dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.personalAccounts\")",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_g48ecaca2eb14c0a95ffaf490a1306ef,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            flxCardsAccountsHeader.add(imgUser, lblAccountsHeader, flxSeparator);
            var segAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segAccounts",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowSkin": "sknSegDefault",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "CardsMA",
                    "friendlyName": "flxMyCardsAccountListItem"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountNameWrapper": "flxAccountNameWrapper",
                    "flxMyCardsAccountListItem": "flxMyCardsAccountListItem",
                    "lblAccountName": "lblAccountName"
                },
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccounts.add(flxCardsAccountsHeader, segAccounts);
            var btnCancelAccount = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "40dp",
                "id": "btnCancelAccount",
                "isVisible": true,
                "right": "2dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "top": 25,
                "width": "260dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountsSegments.add(flxAccounts, btnCancelAccount);
            var flxDeliveryOption = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxDeliveryOption",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "70dp",
                "width": "99.50%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeliveryOption.setDefaultUnit(kony.flex.DP);
            var flxDeliveryOptionsTabs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDeliveryOptionsTabs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeliveryOptionsTabs.setDefaultUnit(kony.flex.DP);
            var flxNearestBranchHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxNearestBranchHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0",
                "width": "50%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNearestBranchHeader.setDefaultUnit(kony.flex.DP);
            var lblNearestBranchHeader = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblNearestBranchHeader",
                "isVisible": true,
                "skin": "sknlblUserName",
                "text": "Branch",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNearestBranchHeader.add(lblNearestBranchHeader);
            var flxMyLocationHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMyLocationHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyLocationHeader.setDefaultUnit(kony.flex.DP);
            var lblMyLocationHeader = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblMyLocationHeader",
                "isVisible": true,
                "skin": "sknLblSSP72727217px",
                "text": "My Location",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMyLocationHeader.add(lblMyLocationHeader);
            flxDeliveryOptionsTabs.add(flxNearestBranchHeader, flxMyLocationHeader);
            var flxDeliveryOptionsDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDeliveryOptionsDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeliveryOptionsDetails.setDefaultUnit(kony.flex.DP);
            var lblDeliveryOptionWarning = new kony.ui.Label({
                "id": "lblDeliveryOptionWarning",
                "isVisible": false,
                "left": "5%",
                "skin": "sknLabelSSPFF000015Px",
                "text": "Error Occurred!",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNearestBranchDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNearestBranchDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNearestBranchDetails.setDefaultUnit(kony.flex.DP);
            var flxSelectNearbyLocation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxSelectNearbyLocation",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectNearbyLocation.setDefaultUnit(kony.flex.DP);
            var lblSelectNearbyLocation = new kony.ui.Label({
                "id": "lblSelectNearbyLocation",
                "isVisible": true,
                "left": "13dp",
                "skin": "sknlbla0a0a015px",
                "text": "Select nearby location",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxSelectNearbyLocation = new kony.ui.ListBox({
                "bottom": "40dp",
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "lbxSelectNearbyLocation",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "sknLbxSSP42424215PxBorder727272",
                "top": "40dp",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxSelectNearbyLocation.add(lblSelectNearbyLocation, lbxSelectNearbyLocation);
            var flxSelectNearestBranch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxSelectNearestBranch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectNearestBranch.setDefaultUnit(kony.flex.DP);
            var lblSelectNearbyBranch = new kony.ui.Label({
                "id": "lblSelectNearbyBranch",
                "isVisible": true,
                "left": "13dp",
                "skin": "sknlbla0a0a015px",
                "text": "Select nearby branch",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxSelectNearbyBranch = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "40dp",
                "id": "lbxSelectNearbyBranch",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "sknLbxSSP42424215PxBorder727272",
                "top": "40dp",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxSelectNearestBranch.add(lblSelectNearbyBranch, lbxSelectNearbyBranch);
            flxNearestBranchDetails.add(flxSelectNearbyLocation, flxSelectNearestBranch);
            var flxMyLocationDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMyLocationDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyLocationDetails.setDefaultUnit(kony.flex.DP);
            var flxChooseMyLocation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "flxChooseMyLocation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChooseMyLocation.setDefaultUnit(kony.flex.DP);
            var lblDeliverTo = new kony.ui.Label({
                "id": "lblDeliverTo",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbla0a0a015px",
                "text": "Deliver To",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxChooseCurrentLocation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxChooseCurrentLocation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2PxHover",
                "top": "10dp",
                "width": "70%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChooseCurrentLocation.setDefaultUnit(kony.flex.DP);
            var flxLocatorImage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxLocatorImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "60dp",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLocatorImage.setDefaultUnit(kony.flex.DP);
            var imgLocator = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLocator",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "locateusside_30_40.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLocatorImage.add(imgLocator);
            var flxCurrentLocationDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCurrentLocationDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrentLocationDetails.setDefaultUnit(kony.flex.DP);
            var lblCurrentLocation = new kony.ui.Label({
                "id": "lblCurrentLocation",
                "isVisible": true,
                "left": "1%",
                "skin": "sknlbla0a0a015px",
                "text": "Current Location",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxCurrentLocationDetails = new kony.ui.RichText({
                "id": "rtxCurrentLocationDetails",
                "isVisible": true,
                "left": "1%",
                "linkSkin": "defRichTextLink",
                "skin": "sknRtxSSP72727213px",
                "text": "General Abebe Damtew Street, Addis Ababa, Ethiopia",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCurrentLocationDetails.add(lblCurrentLocation, rtxCurrentLocationDetails);
            flxChooseCurrentLocation.add(flxLocatorImage, flxCurrentLocationDetails);
            flxChooseMyLocation.add(lblDeliverTo, flxChooseCurrentLocation);
            var flxLocationNotes = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "110dp",
                "id": "flxLocationNotes",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLocationNotes.setDefaultUnit(kony.flex.DP);
            var lblLocationNote = new kony.ui.Label({
                "id": "lblLocationNote",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "text": "Location Note",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txaLocationNotes = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextAreaFocus",
                "height": "60dp",
                "id": "txaLocationNotes",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "numberOfVisibleLines": 3,
                "placeholder": "Enter Note",
                "skin": "textareaFeedbackcomment",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            flxLocationNotes.add(lblLocationNote, txaLocationNotes);
            flxMyLocationDetails.add(flxChooseMyLocation, flxLocationNotes);
            var flxAcceptCardTermsAndConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAcceptCardTermsAndConditions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcceptCardTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxImageCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "30px",
                "id": "flxImageCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "right": "5dp",
                "skin": "slFbox",
                "top": "0",
                "width": "30px",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageCheckBox.setDefaultUnit(kony.flex.DP);
            var imgCheckBox = new kony.ui.Image2({
                "height": "100%",
                "id": "imgCheckBox",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "uncheckedboxtcmb.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageCheckBox.add(imgCheckBox);
            var flxCardTermsAndConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxCardTermsAndConditions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var lblCardTermsAndCondition1 = new kony.ui.Label({
                "bottom": "0dp",
                "id": "lblCardTermsAndCondition1",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblSSPSB42424215Px",
                "text": " I agree to ",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCardTermsAndCondition2 = new kony.ui.Label({
                "bottom": "0",
                "id": "lblCardTermsAndCondition2",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblSSPSB04A61513Px",
                "text": " Terms & Conditions",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCardTermsAndConditions.add(lblCardTermsAndCondition1, lblCardTermsAndCondition2);
            flxAcceptCardTermsAndConditions.add(flxImageCheckBox, flxCardTermsAndConditions);
            var flxDeliveryDetailsConfirmation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "103dp",
                "id": "flxDeliveryDetailsConfirmation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeliveryDetailsConfirmation.setDefaultUnit(kony.flex.DP);
            var btnDeliveryOptionContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnDeliveryOptionContinue",
                "isVisible": true,
                "right": "25dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.proceed\")",
                "width": "258px",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnDeliveryOptionCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnDeliveryOptionCancel",
                "isVisible": true,
                "right": "195dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "width": "260dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDeliveryOptionConfirmationSeparator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblDeliveryOptionConfirmationSeparator",
                "isVisible": true,
                "left": "3%",
                "right": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeliveryDetailsConfirmation.add(btnDeliveryOptionContinue, btnDeliveryOptionCancel, lblDeliveryOptionConfirmationSeparator);
            flxDeliveryOptionsDetails.add(lblDeliveryOptionWarning, flxNearestBranchDetails, flxMyLocationDetails, flxAcceptCardTermsAndConditions, flxDeliveryDetailsConfirmation);
            var flxViewMap = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "446dp",
                "id": "flxViewMap",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "110dp",
                "width": "80%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewMap.setDefaultUnit(kony.flex.DP);
            var flxCloseWindow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "flxCloseWindow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": "0",
                "width": "10%",
                "zIndex": 5,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseWindow.setDefaultUnit(kony.flex.DP);
            var imgCloseWindow = new kony.ui.Image2({
                "height": "100%",
                "id": "imgCloseWindow",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "closewealth.png",
                "top": "0",
                "width": "100%",
                "zIndex": 5
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseWindow.add(imgCloseWindow);
            var mapCurrentLocation = new kony.ui.Map({
                "calloutWidth": 80,
                "defaultPinImage": "pinb.png",
                "height": "100%",
                "id": "mapCurrentLocation",
                "isVisible": true,
                "left": "0",
                "provider": constants.MAP_PROVIDER_GOOGLE,
                "top": "0",
                "width": "100%",
                "zIndex": 5
            }, {}, {});
            flxViewMap.add(flxCloseWindow, mapCurrentLocation);
            flxDeliveryOption.add(flxDeliveryOptionsTabs, flxDeliveryOptionsDetails, flxViewMap);
            var flxNewCardConfirmation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "49%",
                "clipBounds": false,
                "id": "flxNewCardConfirmation",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "70dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewCardConfirmation.setDefaultUnit(kony.flex.DP);
            var lblWarningCradConfirmation = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblWarningCradConfirmation",
                "isVisible": false,
                "left": "22dp",
                "skin": "sknLabelSSPFF000015Px",
                "text": "Label",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNewCardDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNewCardDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "70%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewCardDetails.setDefaultUnit(kony.flex.DP);
            var flxDetailsLinkedAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsLinkedAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsLinkedAccount.setDefaultUnit(kony.flex.DP);
            var lblKeyLinkedAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Selected  Start Date:",
                    "tagName": "span"
                },
                "id": "lblKeyLinkedAccount",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "text": "Linked Account:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValueLinkedAccount = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "01/07/2018"
                },
                "id": "rtxValueLinkedAccount",
                "isVisible": true,
                "left": "184dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "Almezar Ayana ....0156",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsLinkedAccount.add(lblKeyLinkedAccount, rtxValueLinkedAccount);
            var flxDetailsCardType = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsCardType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsCardType.setDefaultUnit(kony.flex.DP);
            var lblKeyCardType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedEndDate\")"
                },
                "id": "lblKeyCardType",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "text": "Card Type:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValueCardtype = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "01/08/2018"
                },
                "id": "rtxValueCardtype",
                "isVisible": true,
                "left": "184dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "Classic Visa Card",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsCardType.add(lblKeyCardType, rtxValueCardtype);
            var flxDetailsDeliveryOption = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsDeliveryOption",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsDeliveryOption.setDefaultUnit(kony.flex.DP);
            var lblKeyDeliveryOption = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PhoneNumber\")",
                    "tagName": "span"
                },
                "id": "lblKeyDeliveryOption",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "text": "Delivery Option:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValueDeliveryOption = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "7760405412\n"
                },
                "id": "rtxValueDeliveryOption",
                "isVisible": true,
                "left": "184dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "Nearest Branch",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsDeliveryOption.add(lblKeyDeliveryOption, rtxValueDeliveryOption);
            var flxDetailsDeliveryLocation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsDeliveryLocation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsDeliveryLocation.setDefaultUnit(kony.flex.DP);
            var lblKeyDeliveryLocation = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.additionalInfo\")",
                    "tagName": "span"
                },
                "id": "lblKeyDeliveryLocation",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "text": "Deliver To:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValueDeliveryLocation = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "rtxValueDeliveryLocation",
                "isVisible": true,
                "left": "184dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "Legehar Branch",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsDeliveryLocation.add(lblKeyDeliveryLocation, rtxValueDeliveryLocation);
            var flxDetailsCardFee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsCardFee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsCardFee.setDefaultUnit(kony.flex.DP);
            var lblKeyCardFee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedEndDate\")"
                },
                "id": "lblKeyCardFee",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "text": "Card Fee:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValueCardFee = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "01/08/2018"
                },
                "id": "rtxValueCardFee",
                "isVisible": true,
                "left": "184dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "ETB 200.00",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsCardFee.add(lblKeyCardFee, rtxValueCardFee);
            var flxDetailsCardDeliveryFee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDetailsCardDeliveryFee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetailsCardDeliveryFee.setDefaultUnit(kony.flex.DP);
            var lblKeyCardDeliveryFee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.SelectedEndDate\")"
                },
                "id": "lblKeyCardDeliveryFee",
                "isVisible": true,
                "left": "0dp",
                "right": "180px",
                "skin": "sknlbla0a0a015px",
                "text": "Delivery Fee:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxValueCardDeliveryFee = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "01/08/2018"
                },
                "id": "rtxValueCardDeliveryFee",
                "isVisible": true,
                "left": "184dp",
                "right": 0,
                "skin": "sknRtxSSPLight42424215Px",
                "text": "ETB 250.00",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDetailsCardDeliveryFee.add(lblKeyCardDeliveryFee, rtxValueCardDeliveryFee);
            flxNewCardDetails.add(flxDetailsLinkedAccount, flxDetailsCardType, flxDetailsDeliveryOption, flxDetailsDeliveryLocation, flxDetailsCardFee, flxDetailsCardDeliveryFee);
            var flxNewCardConfirmationButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "103dp",
                "id": "flxNewCardConfirmationButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewCardConfirmationButtons.setDefaultUnit(kony.flex.DP);
            var btnNewCardOrder = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnNewCardOrder",
                "isVisible": true,
                "right": "25dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "text": "Order",
                "width": "258px",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnNewCardConfirmationCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnNewCardConfirmationCancel",
                "isVisible": true,
                "right": "195dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "width": "260dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparatorNewCardConfirmation = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSeparatorNewCardConfirmation",
                "isVisible": true,
                "left": "3%",
                "right": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewCardConfirmationButtons.add(btnNewCardOrder, btnNewCardConfirmationCancel, lblSeparatorNewCardConfirmation);
            flxNewCardConfirmation.add(lblWarningCradConfirmation, flxNewCardDetails, flxNewCardConfirmationButtons);
            flxNewcard.add(flxCardHeader, flxCardBody, flxCardProductsSegments, flxAccountsSegments, flxDeliveryOption, flxNewCardConfirmation);
            var flxRightBar = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "400dp",
                "id": "flxRightBar",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "66dp",
                "width": "32.50%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightBar.setDefaultUnit(kony.flex.DP);
            var flxRequestANewCard = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxRequestANewCard",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_b2c6e318798440b4a623903db539a40d,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "98%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxRequestANewCard.setDefaultUnit(kony.flex.DP);
            var lblRequestANewCard = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RequestNewCard\")",
                    "tagName": "span"
                },
                "height": "49dp",
                "id": "lblRequestANewCard",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknLblSSP1a98ff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RequestNewCard\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Request a New Card"
            });
            flxRequestANewCard.add(lblRequestANewCard);
            var flxMyPaymentsAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMyPaymentsAccount",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyPaymentsAccount.setDefaultUnit(kony.flex.DP);
            var mypaymentAccounts = new com.konyolb.BillPay.mypaymentAccounts({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "mypaymentAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "maxHeight": 336,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "99.70%",
                "appName": "CardsMA",
                "overrides": {
                    "flxHeader": {
                        "height": "59dp"
                    },
                    "lblHeading": {
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.MyRecentCardPayments\")",
                        "left": "7.69%",
                        "top": "viz.val_cleared"
                    },
                    "mypaymentAccounts": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "maxHeight": 336,
                        "width": "99.70%"
                    },
                    "segMypaymentAccounts": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "data": [{
                            "lblAccountName": "",
                            "lblAvailableBalance": "",
                            "lblBalance": "",
                            "lblHiddenAccountNumber": "",
                            "lblLeft": ""
                        }, {
                            "lblAccountName": "",
                            "lblAvailableBalance": "",
                            "lblBalance": "",
                            "lblHiddenAccountNumber": "",
                            "lblLeft": ""
                        }, {
                            "lblAccountName": "",
                            "lblAvailableBalance": "",
                            "lblBalance": "",
                            "lblHiddenAccountNumber": "",
                            "lblLeft": ""
                        }, {
                            "lblAccountName": "",
                            "lblAvailableBalance": "",
                            "lblBalance": "",
                            "lblHiddenAccountNumber": "",
                            "lblLeft": ""
                        }],
                        "maxHeight": 275,
                        "top": "60dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxRightBarDummySpace = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxRightBarDummySpace",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_e2b045e73d35448abeb2d332471a96d5,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxRightBarDummySpace.setDefaultUnit(kony.flex.DP);
            flxRightBarDummySpace.add();
            flxMyPaymentsAccount.add(mypaymentAccounts, flxRightBarDummySpace);
            var flxCardAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCardAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "10dp",
                "width": "98%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardAccounts.setDefaultUnit(kony.flex.DP);
            var flxMangeTravelPlans = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxMangeTravelPlans",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_e2b045e73d35448abeb2d332471a96d5,
                "skin": "skncursor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxMangeTravelPlans.setDefaultUnit(kony.flex.DP);
            var lblManageTravelPlans = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ManageTravelPlans\")",
                    "tagName": "span"
                },
                "height": "49dp",
                "id": "lblManageTravelPlans",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknLblSSP1a98ff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ManageTravelPlans\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Manage Travel Plans"
            });
            var lblSeparator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a",
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "49dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMangeTravelPlans.add(lblManageTravelPlans, lblSeparator);
            var flxActivateNewCard = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxActivateNewCard",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_e2b045e73d35448abeb2d332471a96d5,
                "skin": "skncursor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxActivateNewCard.setDefaultUnit(kony.flex.DP);
            var lblActivateNewCard = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.accountDetail.contactUs\")",
                    "tagName": "span"
                },
                "height": "49dp",
                "id": "lblActivateNewCard",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknLblSSP1a98ff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "ADD KONY ACCOUNT"
            });
            var lblSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a",
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSeparator1",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "49dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxActivateNewCard.add(lblActivateNewCard, lblSeparator1);
            var flxApplyForNewCard = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxApplyForNewCard",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_b2c6e318798440b4a623903db539a40d,
                "skin": "skncursor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxApplyForNewCard.setDefaultUnit(kony.flex.DP);
            var lblSeparator4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a",
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblSeparator4",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApplyForNewCard = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ApplyForNewCard\")",
                    "tagName": "span"
                },
                "height": "49dp",
                "id": "lblApplyForNewCard",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknLblSSP1a98ff15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.ApplyForNewCard\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "ADD NON KONY ACCOUNT"
            });
            var lblSeperator2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a"
                },
                "height": "1dp",
                "id": "lblSeperator2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "49dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplyForNewCard.add(lblSeparator4, lblApplyForNewCard, lblSeperator2);
            var flxMyPreviousOwnedCards = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxMyPreviousOwnedCards",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_gcc2b9b28ad749428d3cf5e950209af1,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxMyPreviousOwnedCards.setDefaultUnit(kony.flex.DP);
            var lblMyPreviousOwnedCards = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.MyPreviousOwnedCards\")",
                    "tagName": "span"
                },
                "height": "49dp",
                "id": "lblMyPreviousOwnedCards",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegularOld",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.MyPreviousOwnedCards\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "ADD INTERNATIONAL ACCOUNT"
            });
            flxMyPreviousOwnedCards.add(lblMyPreviousOwnedCards);
            flxCardAccounts.add(flxMangeTravelPlans, flxActivateNewCard, flxApplyForNewCard, flxMyPreviousOwnedCards);
            flxRightBar.add(flxRequestANewCard, flxMyPaymentsAccount, flxCardAccounts);
            flxMyCardsView.add(flxTravelPlan, flxMyCards, flxNewcard, flxRightBar);
            var flxCardDetailsMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCardDetailsMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "18dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "11dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardDetailsMobile.setDefaultUnit(kony.flex.DP);
            var flxBackToCards = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblBackToCards",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "50dp",
                "id": "flxBackToCards",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "18dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "11dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackToCards.setDefaultUnit(kony.flex.DP);
            var lblBackToCards = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblBackToCards",
                "isVisible": false,
                "left": "29dp",
                "skin": "sknSSP4176a415px",
                "text": "Label",
                "top": "15dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackToCards.add(lblBackToCards);
            var flxCardDetailsSegment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCardDetailsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "18dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "11dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCardDetailsSegment.setDefaultUnit(kony.flex.DP);
            var segCardDetails = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgBank": "bank_icon_boa.png",
                    "lblSeparator": "-",
                    "lblUsers": "Bank of America"
                }, {
                    "imgBank": "bank_icon_citi.png",
                    "lblSeparator": "-",
                    "lblUsers": "CITI Bank"
                }, {
                    "imgBank": "bank_icon_chase.png",
                    "lblSeparator": "-",
                    "lblUsers": "Chase Bank"
                }, {
                    "imgBank": "bank_icon_hdfc.png",
                    "lblSeparator": "-",
                    "lblUsers": "HDFC bank"
                }, {
                    "imgBank": "bank_icon_wf.png",
                    "lblSeparator": "-",
                    "lblUsers": "Wells Fargo"
                }],
                "groupCells": false,
                "id": "segCardDetails",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_d43ef915b9634f1b84dfaf1d839333d1,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "CardsMA",
                    "friendlyName": "flxBankNames"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxBankNames": "flxBankNames",
                    "imgBank": "imgBank",
                    "lblSeparator": "lblSeparator",
                    "lblUsers": "lblUsers"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCardDetailsSegment.add(segCardDetails);
            var flxDummySpace = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "30dp",
                "id": "flxDummySpace",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "18dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "11dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummySpace.setDefaultUnit(kony.flex.DP);
            flxDummySpace.add();
            flxCardDetailsMobile.add(flxBackToCards, flxCardDetailsSegment, flxDummySpace);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "90dp",
                "id": "flxTermsAndConditions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var TermsAndConditions = new com.InfinityOLB.WireTransfer.TermsAndConditions({
                "height": "80dp",
                "id": "TermsAndConditions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "WireTransferMA",
                "overrides": {
                    "TermsAndConditions": {
                        "width": "100%"
                    },
                    "lblTermsAndConditions": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.CardsTC\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTermsAndConditions.add(TermsAndConditions);
            flxMain.add(breadcrumb, flxDowntimeWarning, flxAcknowledgment, flxConfirm, flxActivateCard, flxSetCardLimits, flxCardVerification, flxCardCVV, flxMyCardsView, flxCardDetailsMobile, flxTermsAndConditions);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1300dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var CustomFooterMain = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "CustomFooterMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "left": "0dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(CustomFooterMain);
            flxFormContent.add(flxMain, flxFooter);
            var flxLogout = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "text": "No"
                    },
                    "btnYes": {
                        "text": "Yes"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxAlert = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "800dp",
                "id": "flxAlert",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "-1dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlert.setDefaultUnit(kony.flex.DP);
            var CustomAlertPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomAlertPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "lblHeading": {
                        "text": "Alert"
                    },
                    "lblPopupMessage": {
                        "text": "Unable to save the changes. Do you want to try again?"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAlert.add(CustomAlertPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxTermsAndConditionsPopUp = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "155%",
                "id": "flxTermsAndConditionsPopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsPopUp.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "650dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "150dp",
                "width": "58%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxfbfbfbBorder0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon_1.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560dp",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\nDescription of eStatements\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\nRegistration for eStatements\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\nEligible Accounts For eStatements\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\nEnrollment For eStatement Delivery\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\nChange In Terms and Conditions\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\nTermination\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\nMiscellaneous\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC);
            var flxTCCheckBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTCCheckBox",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "sknflxffffffnoborder",
                "top": "15dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCCheckBox.setDefaultUnit(kony.flex.DP);
            var flxTCContentsCheckbox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTCContentsCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContentsCheckbox.setDefaultUnit(kony.flex.DP);
            var imgTCContentsCheckbox = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20dp",
                "id": "imgTCContentsCheckbox",
                "isVisible": false,
                "left": "0dp",
                "skin": "slImage",
                "src": "unchecked_box.png",
                "top": "0px",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Terms & Conditions"
            });
            var lblTCContentsCheckboxIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblTCContentsCheckboxIcon",
                "isVisible": true,
                "skin": "sknlblOLBFontsE3E3E320pxOlbFontIcons",
                "text": "D",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContentsCheckbox.add(imgTCContentsCheckbox, lblTCContentsCheckboxIcon);
            var lblIAccept = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblIAccept",
                "isVisible": true,
                "left": "6%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IAcceptTC\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCCheckBox.add(flxTCContentsCheckbox, lblIAccept);
            var flxSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator2",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxContentsButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "90px",
                "id": "flxContentsButtons",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "-1dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentsButtons.setDefaultUnit(kony.flex.DP);
            var btnSave = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "bottom": 30,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnSave",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Save"
            });
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            flxContentsButtons.add(btnSave, btnCancel);
            var flxScrollDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxScrollDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollDetails.setDefaultUnit(kony.flex.DP);
            var CopyflxDummy0bd516b5896c94c = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "clipBounds": true,
                "height": "20dp",
                "id": "CopyflxDummy0bd516b5896c94c",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxDummy0bd516b5896c94c.setDefaultUnit(kony.flex.DP);
            CopyflxDummy0bd516b5896c94c.add();
            var flxBody1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxBody1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody1.setDefaultUnit(kony.flex.DP);
            var brwBodyTnC = new kony.ui.Browser({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "brwBodyTnC",
                "isVisible": true,
                "left": "2%",
                "setAsContent": false,
                "minHeight": "520dp",
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxBody1.add(brwBodyTnC);
            var flxSpacing = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15px",
                "id": "flxSpacing",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "CardsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpacing.setDefaultUnit(kony.flex.DP);
            flxSpacing.add();
            flxScrollDetails.add(CopyflxDummy0bd516b5896c94c, flxBody1, flxSpacing);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxTCCheckBox, flxSeperator2, flxContentsButtons, flxScrollDetails);
            flxTermsAndConditionsPopUp.add(flxTC);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgment": {
                        "height": {
                            "type": "string",
                            "value": "890dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "102.45%"
                        },
                        "segmentProps": []
                    },
                    "lblCardAcknowledgement": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRefrenceNumber": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRequestID": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCardDetails": {
                        "height": {
                            "type": "string",
                            "value": "370dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog": {
                        "height": {
                            "type": "string",
                            "value": "370dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ConfirmDialog"
                    },
                    "ConfirmDialog.confirmButtons": {
                        "top": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.confirmHeaders.flxHeader": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.confirmHeaders.lblHeading": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.flxDestination": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.flxHorizontalLine": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.flxSelectCards": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.flxscrollBody": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueAvailableCredit.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueAvailableCredit.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardHolder.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardHolder.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardName.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardName.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCreditLimit.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCreditLimit.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueName.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueName.flxIcon": {
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueName.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueName.flxValue": {
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueServiceProvider.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueServiceProvider.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueValidThrough.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueValidThrough.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.lblDestination1": {
                        "segmentProps": []
                    },
                    "flxButtonsCards": {
                        "height": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToCards": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnRequestReplacement": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToCardLimits": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnManageCards": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSpace": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "850dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "segmentProps": []
                    },
                    "flxConfirm": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmBody": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmButons": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "btnCancelPlan": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxActivateCard": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.btnProceed": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.btnTermsAndConditions": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxSeparator2": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxone": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblAgree": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblHeading2": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxSetCardLimits": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCardLimits": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSetCardLimitsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxCardShadow": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxCardName": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardDet": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCardsName": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCardName": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "rtxCardNr": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnRestoreWithdrawlDefaults": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnRestorePurchaseDefaults": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnEditLimitWithdrawal": {
                        "segmentProps": []
                    },
                    "btnEditLimitPurchase": {
                        "segmentProps": []
                    },
                    "flxIncreaseLimits": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblContactUsMsg": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxContactUs1": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblContactUsLimits": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "segmentProps": []
                    },
                    "lblDailyWithdrawalLimit": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblSetWithdrawalLimitSlider": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxPrevWithdrawalSlider": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "36%"
                        },
                        "segmentProps": []
                    },
                    "limitWithdrawalSlider": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "limitPrevWithdrawalSlider": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "lblDailyPurchaseLimit": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblSetPurchaseLimitSlider": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "flxPrevPurchaseSlider": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "36%"
                        },
                        "segmentProps": []
                    },
                    "limitPurchaseSlider": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "limitPrevPurchaseSlider": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "flxIncreaseLimit": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblIncreaseLimit": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxContactUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblContactUs": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "confirmButtons.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "25%"
                        },
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "confirmButtons.btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "confirmButtons.btnModify": {
                        "right": {
                            "type": "string",
                            "value": "25%"
                        },
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "flxRightBarSetCardLimits": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "110%"
                        },
                        "segmentProps": []
                    },
                    "flxCardVerification": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxCheckbox": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "-2dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxFour": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxIAgree": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxThree": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxWarning": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxone": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxtwo": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.lblIns3": {
                        "right": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CopyflxWarning0ha1824a2c6f54d": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.WarningMessage.flxWarnings": {
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.flxCardDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.flxCardHeader": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.flxDetailsRow2": {
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.flxDetailsRow3": {
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.flxDetailsRow4": {
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.imgCard": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.imgCardMobile": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.lblCardHeader": {
                        "text": "My Platinum Credit Card",
                        "top": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.lblCardName": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.lblCardStatus": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.lblCardStatusMobile": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.lblKey1": {
                        "width": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.lblKey2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.lblKey4": {
                        "width": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue1": {
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue2": {
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue3": {
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue4": {
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValueMobile": {
                        "bottom": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnModify": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.flxHorizontalLine": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmHeaders": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmHeaders.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flexConfirmPIN": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress": {
                        "left": {
                            "type": "string",
                            "value": "-0.70%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress3": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox1": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox2": {
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox3": {
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCardReplacement": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxChangeCardPin": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxConfirmPIN": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCurrentPIN": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxDeactivateCard": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxHorizontalLine": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxLeft": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxNewPIN": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxNote": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxNoteTextBox": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxRight": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxTravelNotification": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxUsernameVerification2Phone": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxUsernameVerification2SendingyoutheOTP": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxUsernameVerificationAnswerSecQue": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxUsernameVerificationOption2": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxUsernameVerificationphone": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxUsernameVerificationphone2": {
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxVerifyByOptions": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxVerifyBySecureAccessCode": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxVerifyBySecurityQuestions": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxWarning2": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxWarningMessage": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxWarningPinChange": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxWrapper": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.imgConfirmPIN": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.imgCurrentPIN": {
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.imgNewPIN": {
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.imgUsernameVerificationphone": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblAddressCheckBox1": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblAddressCheckBox2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblOption3": {
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblUpgrade": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblUsernameVerificationAnsweryourSecurityQue": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblUsernameVerificationYouAreSending": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "We are sending you the code on your registered mobile.  You will not be charged for the same.",
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lbxReason": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lbxReason2": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lbxReasonPinChange": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.warning.flxDummy": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblActivateCardHeader": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivateContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "segmentProps": []
                    },
                    "flxIncorrectCVV": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblCardNumber": {
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "imgCVV": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblCVV": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxCVVNumber": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "tbxCVVNumber": {
                        "segmentProps": []
                    },
                    "btnfindCVV": {
                        "skin": "bbSknBtn4176a4NoBorder",
                        "segmentProps": []
                    },
                    "flxCVVPopup": {
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "CVVInfo": {
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "segmentProps": [],
                        "instanceId": "CVVInfo"
                    },
                    "CVVInfo.RichTextInfo": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.flxAccountType": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "86%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "CVVInfo.flxInformationText": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.imgHighlightCVV": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.imgToolTip": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "lblButtonSeperator": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxCVVButtons": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "btnCancel2": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxDummy1": {
                        "height": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxMyCardsView": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTravelPlan": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxBody": {
                        "bottom": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "flxMyCards": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "myCards.btnApplyForCard": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "myCards.btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "8%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxAccountName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxFiltersList": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "29%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxNoCardsError": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxNoError": {
                        "width": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxRequestANewCard": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxSearch": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblMyCardsHeader": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblRequestANewCard": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblSearch": {
                        "bottom": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblType": {
                        "text": "All",
                        "segmentProps": []
                    },
                    "myCards.segMyCards": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxNewcard": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxCardBody": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccount": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccount": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountValue": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountvalue": {
                        "text": "Checking Account Nickname….2365",
                        "segmentProps": []
                    },
                    "flxCard": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblCard": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxCardValue": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblCardValue": {
                        "text": "Platinum Card",
                        "segmentProps": []
                    },
                    "lblNameOnCard": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewcardButtons": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardContinue": {
                        "bottom": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxCardProductsSegments": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelCard": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsSegments": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelAccount": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDeliveryOption": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxNearestBranchDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lbxSelectNearbyLocation": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lbxSelectNearbyBranch": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxMyLocationDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxChooseCurrentLocation": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "txaLocationNotes": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDeliveryDetailsConfirmation": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeliveryOptionContinue": {
                        "bottom": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "btnDeliveryOptionCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxNewCardConfirmation": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "lblWarningCradConfirmation": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxNewCardDetails": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxNewCardConfirmationButtons": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardOrder": {
                        "bottom": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardConfirmationCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxRightBar": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCardDetailsMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxBackToCards": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxffffffnoborderThree",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblBackToCards": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "text": "Back to My Cards",
                        "segmentProps": []
                    },
                    "flxCardDetailsSegment": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "segCardDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDummySpace": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditions": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "TermsAndConditions"
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopup"
                    },
                    "flxAlert": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomAlertPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomAlertPopup"
                    },
                    "flxTermsAndConditionsPopUp": {
                        "height": {
                            "type": "string",
                            "value": "155%"
                        },
                        "segmentProps": []
                    },
                    "flxTC": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxTCContents": {
                        "segmentProps": []
                    },
                    "lblIAccept": {
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "btnSave": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxBody1": {
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblFeedback": {
                        "right": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgment": {
                        "height": {
                            "type": "string",
                            "value": "940dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCardAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "Acknowledgement": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "instanceId": "Acknowledgement"
                    },
                    "Acknowledgement.lblRefrenceNumber": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRequestID": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCardDetails": {
                        "height": {
                            "type": "string",
                            "value": "370dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog": {
                        "height": {
                            "type": "string",
                            "value": "370dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ConfirmDialog"
                    },
                    "ConfirmDialog.confirmHeaders.lblHeading": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.flxHorizontalLine": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.flxscrollBody": {
                        "height": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueAvailableCredit.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueAvailableCredit.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueAvailableCredit.flxValue": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardHolder.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardHolder.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardHolder.flxValue": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardName.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardName.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardName.flxValue": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCreditLimit.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCreditLimit.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCreditLimit.flxValue": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueName.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueName.flxIcon": {
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueName.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueName.flxValue": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueServiceProvider.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueServiceProvider.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueServiceProvider.flxValue": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueValidThrough.flxContainer": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueValidThrough.flxKey": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueValidThrough.flxValue": {
                        "segmentProps": []
                    },
                    "flxButtonsCards": {
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToCards": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnRequestReplacement": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToCardLimits": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnManageCards": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSpace": {
                        "top": {
                            "type": "string",
                            "value": "880dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "right": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxConfirm": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmHeading": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmBody": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "btnModify": {
                        "right": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelPlan": {
                        "right": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivateCard": {
                        "layoutType": kony.flex.FREE_FORM,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "instanceId": "CardActivation"
                    },
                    "CardActivation.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "25.80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "21.40%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.btnProceed": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "21.40%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.btnTermsAndConditions": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxCheckbox": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxIAgree": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxone": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblAgree": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblHeading2": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblIns1": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblIns2": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblIns3": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblIns4": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxSetCardLimits": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCardLimits": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSetCardLimitsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxCardShadow": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxCardName": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardDet": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCardName": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "rtxCardNr": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnRestoreWithdrawlDefaults": {
                        "segmentProps": []
                    },
                    "btnRestorePurchaseDefaults": {
                        "segmentProps": []
                    },
                    "btnEditLimitWithdrawal": {
                        "segmentProps": []
                    },
                    "btnEditLimitPurchase": {
                        "segmentProps": []
                    },
                    "flxIncreaseLimits": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblContactUsMsg": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblContactUsLimits": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "segmentProps": []
                    },
                    "flxRightBarSetCardLimits": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "110%"
                        },
                        "segmentProps": []
                    },
                    "flxCardVerification": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxCheckbox": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "-5dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxFour": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxThree": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxWarning": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxone": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxtwo": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.lblIns1": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.lblIns2": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.lblIns3": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.lblIns4": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.lblWarning": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CardLockVerificationStep"
                    },
                    "CardLockVerificationStep.CopyflxWarning0ha1824a2c6f54d": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.flxCardDetails": {
                        "left": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.imgCard": {
                        "height": {
                            "type": "string",
                            "value": "102dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue1": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue2": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue3": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue4": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnCancel": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "54.40%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20.50%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnConfirm": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20.50%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnModify": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20.50%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.flxHorizontalLine": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmHeaders.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress3": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox1": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox2": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox3": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCardReplacement": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxChangeCardPin": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBox1": {
                        "height": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBox2": {
                        "height": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBox3": {
                        "height": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBoxes": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxConfirmPIN": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxDeactivateCard": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxHorizontalLine": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxLeft": {
                        "left": {
                            "type": "string",
                            "value": "-1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "102%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxNote": {
                        "width": {
                            "type": "string",
                            "value": "550dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxNoteTextBox": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxRight": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxTravelNotification": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxVerifyByOptions": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxVerifyBySecureAccessCode": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxVerifyBySecurityQuestions": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxWarning": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxWarning2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxWarningPinChange": {
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxWrapper": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblAddressCheckBox1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblAddressCheckBox2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblAddressCheckBox3": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblCheckBox1": {
                        "height": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblCheckBox2": {
                        "height": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblCheckBox3": {
                        "height": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblWarningSecureAccessCode": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.warning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCardCVV": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblActivateCardHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.25%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivateContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxIncorrectCVV": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblCardNumber": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxCVVNumber": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "298dp"
                        },
                        "segmentProps": []
                    },
                    "btnfindCVV": {
                        "skin": "bbSknBtn4176a4NoBorder",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxCVVPopup": {
                        "height": {
                            "type": "string",
                            "value": "218dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "26%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "CVVInfo": {
                        "height": {
                            "type": "string",
                            "value": "225dp"
                        },
                        "segmentProps": [],
                        "instanceId": "CVVInfo"
                    },
                    "CVVInfo.RichTextInfo": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.flxAccountType": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "48dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "86%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "CVVInfo.flxInformationText": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.imgHighlightCVV": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.imgToolTip": {
                        "top": {
                            "type": "string",
                            "value": "182dp"
                        },
                        "segmentProps": []
                    },
                    "lblButtonSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxCVVButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue2": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel2": {
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "flxDummy1": {
                        "height": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxMyCardsView": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTravelPlan": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBody": {
                        "bottom": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "flxMyCards": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "myCards.flxAccountName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxFiltersList": {
                        "width": {
                            "type": "string",
                            "value": "130px"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxNoCardsError": {
                        "segmentProps": []
                    },
                    "myCards.flxNoError": {
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxRequestANewCard": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "21.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblMyCardsHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblRequestANewCard": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblType": {
                        "text": "All Accounts",
                        "segmentProps": []
                    },
                    "myCards.segMyCards": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxNewcard": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCardHeader": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardBody": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccount": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccountvalue": {
                        "text": "Checking Account Nickname….2365",
                        "segmentProps": []
                    },
                    "flxCard": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblCard": {
                        "segmentProps": []
                    },
                    "lblCardValue": {
                        "text": "Platinum Card",
                        "segmentProps": []
                    },
                    "lblNameOnCard": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblEnterCardPIN": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblConfirmCardPIN": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewcardButtons": {
                        "height": {
                            "type": "string",
                            "value": "73dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardContinue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardCancel": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardProductsSegments": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelCard": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsSegments": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelAccount": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeliveryOption": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxNearestBranchDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lbxSelectNearbyLocation": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "lbxSelectNearbyBranch": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxMyLocationDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxChooseCurrentLocation": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "txaLocationNotes": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxDeliveryDetailsConfirmation": {
                        "height": {
                            "type": "string",
                            "value": "73dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeliveryOptionContinue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeliveryOptionCancel": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewCardConfirmation": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "lblWarningCradConfirmation": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewCardDetails": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxNewCardConfirmationButtons": {
                        "height": {
                            "type": "string",
                            "value": "73dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardOrder": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardConfirmationCancel": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxRightBar": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCardDetailsMobile": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBackToCards": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardDetailsSegment": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDummySpace": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomPopup"
                    },
                    "CustomAlertPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomAlertPopup"
                    },
                    "flxTermsAndConditionsPopUp": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTC": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgment": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCardAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "right": {
                            "type": "string",
                            "value": "6.29%"
                        },
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRefrenceNumber": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRequestID": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "ConfirmDialog.confirmHeaders": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.confirmHeaders.flxHeader": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.confirmHeaders.lblHeading": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.flxHorizontalLine": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.flxscrollBody": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueName.flxIcon": {
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "segmentProps": []
                    },
                    "flxButtonsCards": {
                        "height": {
                            "type": "string",
                            "value": "167dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToCards": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnRequestReplacement": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToCardLimits": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnManageCards": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxConfirm": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxActivateCard": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "CardActivation": {
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "CardActivation"
                    },
                    "CardActivation.btnTermsAndConditions": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxone": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblAgree": {
                        "top": {
                            "type": "string",
                            "value": "5px"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxSetCardLimits": {
                        "bottom": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCardLimits": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "61.60%"
                        },
                        "segmentProps": []
                    },
                    "lblSetCardLimitsHeader": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardShadow": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "flxCardName": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardDet": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "2.10%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxCardsName": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblCardName": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "rtxCardNr": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSknRtx424242SSP20Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnRestoreWithdrawlDefaults": {
                        "segmentProps": []
                    },
                    "btnRestorePurchaseDefaults": {
                        "segmentProps": []
                    },
                    "btnEditLimitWithdrawal": {
                        "segmentProps": []
                    },
                    "btnEditLimitPurchase": {
                        "segmentProps": []
                    },
                    "flxIncreaseLimits": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblContactUsMsg": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblContactUsLimits": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "segmentProps": []
                    },
                    "flxRightBarSetCardLimits": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "26.70%"
                        },
                        "segmentProps": []
                    },
                    "flxCardAccountsSetCardLimits": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxCardVerification": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxCheckbox": {
                        "top": {
                            "type": "string",
                            "value": "-5dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.lblIns3": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnCancel": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "48%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnConfirm": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnModify": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "16.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.flxHorizontalLine": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flexConfirmPIN": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress": {
                        "left": {
                            "type": "string",
                            "value": "-0.70%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress3": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox1": {
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox2": {
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox3": {
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCardReplacement": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxChangeCardPin": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBox1": {
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBox2": {
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBox3": {
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBoxes": {
                        "height": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxConfirmPIN": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCurrentPIN": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxDeactivateCard": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxNewPIN": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxNote": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxVerifyByOptions": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxVerifyBySecureAccessCode": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblAddressCheckBox2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "1"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblWarningSecureAccessCode": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCardCVV": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "5.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblActivateCardHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivateContent": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "segmentProps": []
                    },
                    "flxIncorrectCVV": {
                        "segmentProps": []
                    },
                    "lblCardNumber": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblCVV": {
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxCVVNumber": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "tbxCVVNumber": {
                        "segmentProps": []
                    },
                    "btnfindCVV": {
                        "skin": "bbSknBtn4176a4NoBorder",
                        "segmentProps": []
                    },
                    "flxCVVPopup": {
                        "height": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo": {
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "segmentProps": [],
                        "instanceId": "CVVInfo"
                    },
                    "CVVInfo.RichTextInfo": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.flxAccountType": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "134dp"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.flxInformationText": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "18%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.imgHighlightCVV": {
                        "height": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.imgToolTip": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "28.50%"
                        },
                        "segmentProps": []
                    },
                    "lblButtonSeperator": {
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxCVVButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue2": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel2": {
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "flxDummy1": {
                        "height": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMyCardsView": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxTravelPlan": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "66%"
                        },
                        "segmentProps": []
                    },
                    "lblSeparator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblDates": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxDates": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "lblFrom": {
                        "accessibilityConfig": {
                            "a11yLabel": "From:"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [0, 0, 2, 0],
                        "segmentProps": []
                    },
                    "flxCalFrom": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "42.40%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "calFrom": {
                        "padding": [5, 1, 1, 1],
                        "paddingLocked": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblTo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "padding": [0, 0, 2, 0],
                        "segmentProps": []
                    },
                    "flxCalTo": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "42.40%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "calTo": {
                        "padding": [5, 1, 1, 1],
                        "paddingLocked": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblDestination": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxDestination": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxAddFeatureRequestandimg": {
                        "segmentProps": []
                    },
                    "flxOtherDestinations": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "segDestinations": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumber": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "skin": "sknlbla0a0a015px",
                        "segmentProps": []
                    },
                    "txtPhoneNumber": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "lblAdditionalInformation": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "txtareaUserComments": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxMyCards": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxAccountName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxNoCardsError": {
                        "segmentProps": []
                    },
                    "myCards.flxNoError": {
                        "segmentProps": []
                    },
                    "myCards.flxNoResultsSearch": {
                        "segmentProps": []
                    },
                    "myCards.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblMyCardsHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblType": {
                        "text": "All Accounts",
                        "segmentProps": []
                    },
                    "myCards": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "myCards"
                    },
                    "myCards.segMyCards": {
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "myCards.segSearch": {
                        "segmentProps": []
                    },
                    "flxEligibleCardsButtons": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxNewcard": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "66%"
                        },
                        "segmentProps": []
                    },
                    "flxCardBody": {
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccount": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccount": {
                        "segmentProps": []
                    },
                    "lblAccountvalue": {
                        "text": "Checking Account Nickname….2365",
                        "segmentProps": []
                    },
                    "lblCard": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblCardValue": {
                        "text": "Platinum Card",
                        "segmentProps": []
                    },
                    "btnNewCardContinue": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardCancel": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardProductsSegments": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelCard": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsSegments": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelAccount": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeliveryOptionContinue": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeliveryOptionCancel": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewCardConfirmation": {
                        "segmentProps": []
                    },
                    "lblWarningCradConfirmation": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardOrder": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardConfirmationCancel": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxRightBar": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxCardAccounts": {
                        "segmentProps": []
                    },
                    "flxCardDetailsMobile": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBackToCards": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardDetailsSegment": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDummySpace": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "width": {
                            "type": "string",
                            "value": "86.50%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFooterMain"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "CustomFooterMain.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "segmentProps": []
                    },
                    "flxTC": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxTopmenu": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "86dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgment": {
                        "segmentProps": []
                    },
                    "lblCardAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "right": {
                            "type": "string",
                            "value": "6.29%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementMain": {
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRefrenceNumber": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "Acknowledgement.lblRequestID": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "ConfirmDialog.confirmHeaders.lblHeading": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.flxHorizontalLine": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.flxscrollBody": {
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueCardName.lblColon": {
                        "left": {
                            "type": "string",
                            "value": "20.70%"
                        },
                        "segmentProps": []
                    },
                    "ConfirmDialog.keyValueName.flxIcon": {
                        "left": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "segmentProps": []
                    },
                    "flxButtonsCards": {
                        "height": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "470dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToCards": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnRequestReplacement": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnBackToCardLimits": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnManageCards": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnModify": {
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelPlan": {
                        "right": {
                            "type": "string",
                            "value": "370dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.btnProceed": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.btnTermsAndConditions": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.flxone": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblAgree": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "CardActivation.lblHeading2": {
                        "left": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "flxSetCardLimits": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "1386dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardLimits": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "59%"
                        },
                        "segmentProps": []
                    },
                    "lblSetCardLimitsHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardShadow": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "flxCardName": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardDet": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "2.10%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxCardsName": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblCardName": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "rtxCardNr": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSknRtx424242SSP20Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnRestoreWithdrawlDefaults": {
                        "segmentProps": []
                    },
                    "btnRestorePurchaseDefaults": {
                        "centerY": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "btnEditLimitWithdrawal": {
                        "segmentProps": []
                    },
                    "btnEditLimitPurchase": {
                        "segmentProps": []
                    },
                    "flxIncreaseLimits": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblContactUsMsg": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblContactUsLimits": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "segmentProps": []
                    },
                    "flxIncreaseLimit": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblIncreaseLimit": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblContactUs": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxRightBarSetCardLimits": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "flxCardAccountsSetCardLimits": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxCardVerification": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.flxCheckbox": {
                        "top": {
                            "type": "string",
                            "value": "-5dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.CardActivation.lblIns3": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Scheduled transactions for upcoming dates will not be executed until you unlock the card.",
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep": {
                        "segmentProps": [],
                        "instanceId": "CardLockVerificationStep"
                    },
                    "CardLockVerificationStep.cardDetails.flxCardDetails": {
                        "left": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.imgCard": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.lblCardName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue1": {
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue2": {
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue3": {
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.cardDetails.rtxValue4": {
                        "left": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnCancel": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "48%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnConfirm": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "16.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.confirmButtons.flxHorizontalLine": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flexConfirmPIN": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress": {
                        "left": {
                            "type": "string",
                            "value": "-0.70%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddress3": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox1": {
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox2": {
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxAddressCheckbox3": {
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCVV": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCardReplacement": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxChangeCardPin": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBox1": {
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBox2": {
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBox3": {
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCheckBoxes": {
                        "height": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxConfirmPIN": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxCurrentPIN": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxNewPIN": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxNote": {
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.flxRight": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.imgConfirmPIN": {
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.imgCurrentPIN": {
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.imgNewPIN": {
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.imgViewCVV": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblAddressCheckBox2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblCheckBox2": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CardLockVerificationStep.lblWarningSecureAccessCode": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblActivateCardHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxActivateContent": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxIncorrectCVV": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgIncorrectCVV": {
                        "segmentProps": []
                    },
                    "lblErrorCVV": {
                        "i18n_text": "i18n.CardManagement.IncorrectCVVcodeEntered",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblCardNumber": {
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgCVV": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxCVVNumber": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "tbxCVVNumber": {
                        "i18n_placeholder": "i18n.CardManagement.EnterCVVNumber",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnfindCVV": {
                        "skin": "bbSknBtn4176a4NoBorder",
                        "segmentProps": []
                    },
                    "flxCVVPopup": {
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CVVInfo": {
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "segmentProps": [],
                        "instanceId": "CVVInfo"
                    },
                    "CVVInfo.RichTextInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.flxAccountType": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.flxInformationText": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "18%"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.imgHighlightCVV": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CVVInfo.imgToolTip": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "28.50%"
                        },
                        "segmentProps": []
                    },
                    "lblButtonSeperator": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxCVVButtons": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue2": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel2": {
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxDummy1": {
                        "height": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMyCardsView": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxTravelPlan": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "66%"
                        },
                        "segmentProps": []
                    },
                    "lblMyCardsHeader": {
                        "skin": "sknlblUserName",
                        "segmentProps": []
                    },
                    "flxDates": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "lblFrom": {
                        "accessibilityConfig": {
                            "a11yLabel": "From:"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [0, 0, 2, 0],
                        "segmentProps": []
                    },
                    "flxCalFrom": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "43.50%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "calFrom": {
                        "padding": [5, 1, 1, 1],
                        "paddingLocked": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblTo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "padding": [0, 0, 2, 0],
                        "segmentProps": []
                    },
                    "flxCalTo": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "43.50%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "calTo": {
                        "padding": [5, 1, 1, 1],
                        "paddingLocked": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "txtDestination": {
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "flxDestinationList": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "82.7%"
                        },
                        "segmentProps": []
                    },
                    "txtPhoneNumber": {
                        "width": {
                            "type": "string",
                            "value": "46%"
                        },
                        "segmentProps": []
                    },
                    "flxMyCards": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "59%"
                        },
                        "segmentProps": []
                    },
                    "myCards.btnApplyForCard": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxAccountName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxNoCardsError": {
                        "segmentProps": []
                    },
                    "myCards.flxNoError": {
                        "segmentProps": []
                    },
                    "myCards.flxNoResultsSearch": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "myCards.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97.50%"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblMyCardsHeader": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "myCards.lblNoResultsSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "myCards.lblType": {
                        "text": "All Accounts",
                        "segmentProps": []
                    },
                    "myCards": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "myCards"
                    },
                    "myCards.segMyCards": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "flxEligibleCardsButtons": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxNewcard": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "58.10%"
                        },
                        "segmentProps": []
                    },
                    "flxCardHeader": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblNewCardHeader": {
                        "skin": "sknlblUserName",
                        "segmentProps": []
                    },
                    "flxCardBody": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccount": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccount": {
                        "i18n_text": "i18n.CardManagement.Account",
                        "segmentProps": []
                    },
                    "lblAccountvalue": {
                        "text": "Checking Account Nickname….2365",
                        "segmentProps": []
                    },
                    "flxCard": {
                        "segmentProps": []
                    },
                    "lblCard": {
                        "i18n_text": "i18n.CardManagement.Card2",
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblCardValue": {
                        "text": "Platinum Card",
                        "segmentProps": []
                    },
                    "lblNameOnCard": {
                        "i18n_text": "i18n.CardManagement.NameOnCard2",
                        "segmentProps": []
                    },
                    "tbxNameOnCard": {
                        "i18n_placeholder": "i18n.CardManagement.EnterNameOnCard",
                        "segmentProps": []
                    },
                    "lblEnterCardPIN": {
                        "i18n_text": "i18n.CardManagement.EnterCardPin",
                        "segmentProps": []
                    },
                    "tbxEnterCardPIN": {
                        "i18n_placeholder": "i18n.CardManagement.Enter4digitPIN",
                        "segmentProps": []
                    },
                    "lblConfirmCardPIN": {
                        "i18n_text": "i18n.CardManagement.ConfirmCardPIN",
                        "segmentProps": []
                    },
                    "tbxConfirmCardPIN": {
                        "i18n_placeholder": "i18n.CardManagement.Enter4digitPIN",
                        "segmentProps": []
                    },
                    "btnNewCardContinue": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardCancel": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxCardProductsSegments": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "segCardProducts": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnCancelCard": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsSegments": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "segAccounts": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnCancelAccount": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeliveryOptionContinue": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeliveryOptionCancel": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxNewCardConfirmation": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "99.50%"
                        },
                        "segmentProps": []
                    },
                    "lblWarningCradConfirmation": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardOrder": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnNewCardConfirmationCancel": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxRightBar": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "flxRequestANewCard": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": 0
                            }
                        },
                        "segmentProps": []
                    },
                    "lblRequestANewCard": {
                        "i18n_text": "i18n.CardManagement.RequestNewCard",
                        "text": "Request a New Card",
                        "segmentProps": []
                    },
                    "flxCardAccounts": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxMangeTravelPlans": {
                        "segmentProps": []
                    },
                    "flxCardDetailsMobile": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBackToCards": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToCards": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxCardDetailsSegment": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxDummySpace": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxTermsAndConditions": {
                        "width": {
                            "type": "string",
                            "value": "1180dp"
                        },
                        "segmentProps": []
                    },
                    "TermsAndConditions": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "TermsAndConditions"
                    },
                    "CustomFooterMain.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "segmentProps": []
                    },
                    "flxTermsAndConditionsPopUp": {
                        "segmentProps": []
                    },
                    "flxTC": {
                        "width": {
                            "type": "string",
                            "value": "765dp"
                        },
                        "segmentProps": []
                    },
                    "brwBodyTnC": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.flxMenusMain": {
                    "height": "51dp"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "breadcrumb": {
                    "height": "53dp",
                    "left": "-2dp",
                    "top": "0dp"
                },
                "breadcrumb.btnBreadcrumb2": {
                    "centerY": "51%",
                    "left": "2.46%"
                },
                "breadcrumb.flxBottomBorder": {
                    "bottom": "0dp"
                },
                "breadcrumb.flxBreadcrumbcontainer": {
                    "centerX": "50%",
                    "height": "50dp",
                    "top": "1dp",
                    "width": "1366dp"
                },
                "breadcrumb.flxTopBorder": {
                    "top": "0dp"
                },
                "breadcrumb.imgBreadcrumb": {
                    "src": "breadcrumb_icon.png"
                },
                "breadcrumb.imgBreadcrumb2": {
                    "src": "breadcrumb_icon.png"
                },
                "breadcrumb.lblBreadcrumb2": {
                    "text": "CATEGORIZED MONTHLY SPENDING"
                },
                "Acknowledgement": {
                    "minHeight": "370dp"
                },
                "Acknowledgement.ImgAcknowledgement": {
                    "src": "success_green.png"
                },
                "Acknowledgement.confirmHeaders.lblHeading": {
                    "left": "20dp"
                },
                "Acknowledgement.lblRefrenceNumber": {
                    "top": "2dp"
                },
                "Acknowledgement.lblRequestID": {
                    "top": "20px"
                },
                "Acknowledgement.lblUnlockCardMessage": {
                    "width": "90%"
                },
                "ConfirmDialog": {
                    "height": "370dp"
                },
                "ConfirmDialog.confirmHeaders": {
                    "height": "50dp"
                },
                "ConfirmDialog.confirmHeaders.flxHeader": {
                    "height": "50dp"
                },
                "ConfirmDialog.confirmHeaders.lblHeading": {
                    "left": "20dp"
                },
                "ConfirmDialog.flxCards": {
                    "left": "30%"
                },
                "ConfirmDialog.flxDestination": {
                    "left": "0%",
                    "top": "20dp"
                },
                "ConfirmDialog.flxHorizontalLine": {
                    "left": "0dp",
                    "right": "30dp"
                },
                "ConfirmDialog.flxSelectCards": {
                    "left": "0%",
                    "top": "20px"
                },
                "ConfirmDialog.flxscrollBody": {
                    "height": "310dp",
                    "left": "20dp",
                    "right": "20dp",
                    "top": "60dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "ConfirmDialog.keyValueAvailableCredit": {
                    "bottom": "",
                    "top": "20dp"
                },
                "ConfirmDialog.keyValueAvailableCredit.flxContainer": {
                    "left": "0%"
                },
                "ConfirmDialog.keyValueAvailableCredit.flxKey": {
                    "left": "0%",
                    "width": "25%"
                },
                "ConfirmDialog.keyValueAvailableCredit.flxValue": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.keyValueAvailableCredit.imgWhatIsSSN": {
                    "src": "info_grey.png"
                },
                "ConfirmDialog.keyValueAvailableCredit.lblKey": {
                    "width": "100%"
                },
                "ConfirmDialog.keyValueAvailableCredit.lblValue": {
                    "text": "$50,000"
                },
                "ConfirmDialog.keyValueCardHolder": {
                    "top": "20dp"
                },
                "ConfirmDialog.keyValueCardHolder.flxContainer": {
                    "left": "0%"
                },
                "ConfirmDialog.keyValueCardHolder.flxKey": {
                    "left": "0%",
                    "width": "25%"
                },
                "ConfirmDialog.keyValueCardHolder.flxValue": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.keyValueCardHolder.imgWhatIsSSN": {
                    "src": "info_grey.png"
                },
                "ConfirmDialog.keyValueCardHolder.lblKey": {
                    "width": "100%"
                },
                "ConfirmDialog.keyValueCardHolder.lblValue": {
                    "text": "John Bailey"
                },
                "ConfirmDialog.keyValueCardName": {
                    "top": "20dp"
                },
                "ConfirmDialog.keyValueCardName.flxContainer": {
                    "left": "0%"
                },
                "ConfirmDialog.keyValueCardName.flxKey": {
                    "left": "0%",
                    "width": "25%"
                },
                "ConfirmDialog.keyValueCardName.flxValue": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.keyValueCardName.imgWhatIsSSN": {
                    "src": "info_grey.png"
                },
                "ConfirmDialog.keyValueCardName.lblColon": {
                    "left": "20.70%"
                },
                "ConfirmDialog.keyValueCardName.lblKey": {
                    "width": "100%"
                },
                "ConfirmDialog.keyValueCardName.lblValue": {
                    "text": "XXXX XXXX XXXX 5404"
                },
                "ConfirmDialog.keyValueCreditLimit": {
                    "top": "20dp"
                },
                "ConfirmDialog.keyValueCreditLimit.flxContainer": {
                    "left": "0%"
                },
                "ConfirmDialog.keyValueCreditLimit.flxKey": {
                    "left": "0%",
                    "width": "25%"
                },
                "ConfirmDialog.keyValueCreditLimit.flxValue": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.keyValueCreditLimit.imgWhatIsSSN": {
                    "src": "info_grey.png"
                },
                "ConfirmDialog.keyValueCreditLimit.lblKey": {
                    "width": "100%"
                },
                "ConfirmDialog.keyValueCreditLimit.lblValue": {
                    "text": "$25,000"
                },
                "ConfirmDialog.keyValueName": {
                    "top": "20dp"
                },
                "ConfirmDialog.keyValueName.flxContainer": {
                    "left": "0%"
                },
                "ConfirmDialog.keyValueName.flxIcon": {
                    "left": "37.22%"
                },
                "ConfirmDialog.keyValueName.flxKey": {
                    "left": "0%",
                    "width": "25%"
                },
                "ConfirmDialog.keyValueName.flxValue": {
                    "left": "30%",
                    "top": "2dp",
                    "width": "70%"
                },
                "ConfirmDialog.keyValueName.imgWhatIsSSN": {
                    "src": "info_grey.png"
                },
                "ConfirmDialog.keyValueName.lblKey": {
                    "width": "100%"
                },
                "ConfirmDialog.keyValueName.lblValue": {
                    "text": "Gold Debit Card"
                },
                "ConfirmDialog.keyValueServiceProvider": {
                    "top": "20dp"
                },
                "ConfirmDialog.keyValueServiceProvider.flxContainer": {
                    "left": "0%"
                },
                "ConfirmDialog.keyValueServiceProvider.flxKey": {
                    "left": "0%",
                    "width": "25%"
                },
                "ConfirmDialog.keyValueServiceProvider.flxValue": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.keyValueServiceProvider.imgWhatIsSSN": {
                    "src": "info_grey.png"
                },
                "ConfirmDialog.keyValueServiceProvider.lblKey": {
                    "width": "100%"
                },
                "ConfirmDialog.keyValueServiceProvider.lblValue": {
                    "text": "Master Card"
                },
                "ConfirmDialog.keyValueValidThrough": {
                    "top": "20dp"
                },
                "ConfirmDialog.keyValueValidThrough.flxContainer": {
                    "left": "0%"
                },
                "ConfirmDialog.keyValueValidThrough.flxKey": {
                    "left": "0%",
                    "width": "25%"
                },
                "ConfirmDialog.keyValueValidThrough.flxValue": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.keyValueValidThrough.imgWhatIsSSN": {
                    "src": "info_grey.png"
                },
                "ConfirmDialog.keyValueValidThrough.lblKey": {
                    "width": "100%"
                },
                "ConfirmDialog.keyValueValidThrough.lblValue": {
                    "text": "02/20"
                },
                "ConfirmDialog.lblDestination1": {
                    "right": "",
                    "width": "25%"
                },
                "ConfirmDialog.lblDestination2": {
                    "right": "",
                    "width": "25%"
                },
                "ConfirmDialog.lblDestination3": {
                    "right": "",
                    "width": "25%"
                },
                "ConfirmDialog.lblDestination4": {
                    "right": "",
                    "width": "25%"
                },
                "ConfirmDialog.lblDestination5": {
                    "right": "",
                    "width": "25%"
                },
                "ConfirmDialog.lblKey6": {
                    "right": "",
                    "width": "25%"
                },
                "ConfirmDialog.rtxDestination1": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.rtxDestination2": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.rtxDestination3": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.rtxDestination4": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.rtxDestination5": {
                    "left": "30%",
                    "width": "70%"
                },
                "ConfirmDialog.rtxValueA": {
                    "left": "30%",
                    "width": "70%"
                },
                "CardActivation.btnCancel": {
                    "height": "40dp"
                },
                "CardActivation.btnProceed": {
                    "height": "40dp",
                    "left": "76.8%",
                    "right": ""
                },
                "CardActivation.btnTermsAndConditions": {
                    "top": "2px"
                },
                "CardActivation.imgChecbox": {
                    "src": "unchecked_box.png"
                },
                "CardActivation.imgWarning": {
                    "src": "error_yellow.png"
                },
                "CardActivation.lblAgree": {
                    "top": "2px"
                },
                "CardActivation.lblHeading2": {
                    "left": "0%"
                },
                "confirmHeaders": {
                    "height": "60dp"
                },
                "confirmButtons.btnCancel": {
                    "right": "16.60%",
                    "width": "12.50%"
                },
                "confirmButtons.btnConfirm": {
                    "width": "12.50%"
                },
                "confirmButtons.btnModify": {
                    "right": "16.67%",
                    "width": "12.50%"
                },
                "confirmButtons": {
                    "height": "82dp"
                },
                "CardLockVerificationStep.CardActivation.imgChecbox": {
                    "src": "unchecked_box.png"
                },
                "CardLockVerificationStep.CardActivation.imgWarning": {
                    "src": "error_yellow.png"
                },
                "CardLockVerificationStep.CardActivation.lblHeading2": {
                    "left": "2.80%"
                },
                "CardLockVerificationStep.CardActivation.lblIns3": {
                    "text": "Payment guidline number three."
                },
                "CardLockVerificationStep.Copywarning0b8a8390f76a040": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "CardLockVerificationStep.Copywarning0b8a8390f76a040.imgDot1": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.Copywarning0b8a8390f76a040.imgDot2": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.Copywarning0b8a8390f76a040.imgDot3": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.Copywarning0b8a8390f76a040.imgDot4": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.Copywarning0b8a8390f76a040.imgWarning": {
                    "src": "error_yellow.png"
                },
                "CardLockVerificationStep.Copywarning0ba67056c374842.imgDot1": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.Copywarning0ba67056c374842.imgDot2": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.Copywarning0ba67056c374842.imgDot3": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.Copywarning0ba67056c374842.imgDot4": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.Copywarning0ba67056c374842.imgWarning": {
                    "src": "error_yellow.png"
                },
                "CardLockVerificationStep.WarningMessage": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "CardLockVerificationStep.WarningMessage.flxWarnings": {
                    "right": 80
                },
                "CardLockVerificationStep.WarningMessage.imgChecbox": {
                    "src": "unchecked_box.png"
                },
                "CardLockVerificationStep.WarningMessage.imgDot1": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.WarningMessage.imgDot2": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.WarningMessage.imgDot3": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.WarningMessage.imgDot4": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.WarningMessage.imgWarning": {
                    "src": "error_yellow.png"
                },
                "CardLockVerificationStep.cardDetails.flxCardDetails": {
                    "left": "36%",
                    "right": "20px"
                },
                "CardLockVerificationStep.cardDetails.imgCard": {
                    "left": "6%",
                    "src": "golden_card.png",
                    "top": "40dp",
                    "width": "125dp"
                },
                "CardLockVerificationStep.cardDetails.imgCardMobile": {
                    "centerX": "",
                    "centerY": "",
                    "src": "golden_card.png",
                    "top": "30dp"
                },
                "CardLockVerificationStep.cardDetails.lblCardHeader": {
                    "centerY": "",
                    "top": "30dp"
                },
                "CardLockVerificationStep.cardDetails.lblCardStatusMobile": {
                    "width": "180dp"
                },
                "CardLockVerificationStep.cardDetails.rtxValue1": {
                    "right": 0
                },
                "CardLockVerificationStep.cardDetails.rtxValueMobile": {
                    "centerY": "",
                    "width": ""
                },
                "CardLockVerificationStep.confirmButtons": {
                    "layoutType": kony.flex.FREE_FORM
                },
                "CardLockVerificationStep.confirmButtons.btnCancel": {
                    "left": "30.33%"
                },
                "CardLockVerificationStep.confirmButtons.btnConfirm": {
                    "width": "21.40%"
                },
                "CardLockVerificationStep.confirmButtons.btnModify": {
                    "width": "21.40%"
                },
                "CardLockVerificationStep.confirmButtons.flxHorizontalLine": {
                    "top": "20dp"
                },
                "CardLockVerificationStep.flxAddressCheckbox1": {
                    "left": "0dp"
                },
                "CardLockVerificationStep.flxCVV": {
                    "top": "30dp"
                },
                "CardLockVerificationStep.flxConfirmPIN": {
                    "width": ""
                },
                "CardLockVerificationStep.flxRight": {
                    "right": "30px"
                },
                "CardLockVerificationStep.flxUsernameVerificationAnswerSecQue": {
                    "width": "75%"
                },
                "CardLockVerificationStep.flxUsernameVerificationUsingOTP": {
                    "width": "75%"
                },
                "CardLockVerificationStep.flxUsernameVerificationphone": {
                    "width": "17%"
                },
                "CardLockVerificationStep.flxUsernameVerificationphone2": {
                    "width": "17%"
                },
                "CardLockVerificationStep.imgConfirmPIN": {
                    "height": "30dp",
                    "width": "22dp"
                },
                "CardLockVerificationStep.imgCurrentPIN": {
                    "height": "30dp"
                },
                "CardLockVerificationStep.imgInfo": {
                    "src": "info_grey.png"
                },
                "CardLockVerificationStep.imgNewPIN": {
                    "height": "30dp"
                },
                "CardLockVerificationStep.imgSecureAccessCode": {
                    "src": "mobile_sendpin.png"
                },
                "CardLockVerificationStep.imgSelectCard": {
                    "src": "checked_box.png"
                },
                "CardLockVerificationStep.imgUsernameVerificationcheckedRadio": {
                    "src": "icon_radiobtn_active.png"
                },
                "CardLockVerificationStep.imgUsernameVerificationcheckedRadioOption2": {
                    "src": "icon_radiobtn.png"
                },
                "CardLockVerificationStep.imgUsernameVerificationphone": {
                    "src": "mobile_sendpin.png"
                },
                "CardLockVerificationStep.imgUsernameVerificationphone2": {
                    "src": "security_questions.png"
                },
                "CardLockVerificationStep.imgViewCVV": {
                    "height": "16dp",
                    "right": "10dp",
                    "src": "view.png",
                    "width": "40dp"
                },
                "CardLockVerificationStep.imgWarning": {
                    "src": "error_yellow.png"
                },
                "CardLockVerificationStep.lblOption3": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CardLockVerificationStep.lblReason2": {
                    "width": "97%"
                },
                "CardLockVerificationStep.warning": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "CardLockVerificationStep.warning.imgChecbox": {
                    "src": "unchecked_box.png"
                },
                "CardLockVerificationStep.warning.imgDot1": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.warning.imgDot2": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.warning.imgDot3": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.warning.imgDot4": {
                    "src": "pageoffdot.png"
                },
                "CardLockVerificationStep.warning.imgWarning": {
                    "src": "error_yellow.png"
                },
                "CVVInfo": {
                    "height": "200dp",
                    "left": "6.20%",
                    "top": "0dp"
                },
                "CVVInfo.RichTextInfo": {
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "top": "0dp",
                    "width": "70%"
                },
                "CVVInfo.flxAccountType": {
                    "centerX": "",
                    "top": "115dp",
                    "width": "80%"
                },
                "CVVInfo.flxInformationText": {
                    "centerX": "",
                    "height": "200dp",
                    "left": "0dp",
                    "right": "",
                    "top": "-2dp",
                    "width": "100%"
                },
                "CVVInfo.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "CVVInfo.imgHighlightCVV": {
                    "height": "70dp",
                    "src": "cardcvv.png",
                    "top": "35dp",
                    "width": "100dp"
                },
                "CVVInfo.imgToolTip": {
                    "centerX": "50%",
                    "height": "50dp",
                    "left": "",
                    "src": "callout.png",
                    "width": "60dp",
                    "zIndex": 1
                },
                "myCards.btnApplyForCard": {
                    "height": "40dp"
                },
                "myCards.btnConfirm": {
                    "width": "4%"
                },
                "myCards.flxAccountName": {
                    "left": "0dp",
                    "width": "100%"
                },
                "myCards.flxFiltersList": {
                    "left": "18dp",
                    "right": "",
                    "width": "150px"
                },
                "myCards.flxNoCardsError": {
                    "top": "30dp",
                    "width": "95%"
                },
                "myCards.flxNoError": {
                    "centerX": "50%",
                    "height": "400dp",
                    "top": "20dp",
                    "width": "97.70%"
                },
                "myCards.flxNoResultsSearch": {
                    "height": "100%",
                    "top": "5dp"
                },
                "myCards.flxRequestANewCard": {
                    "centerX": "",
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%"
                },
                "myCards.flxSearch": {
                    "centerX": "",
                    "left": "0dp",
                    "top": "17dp",
                    "width": "100%"
                },
                "myCards.flxSearchContiner": {
                    "centerY": "50%",
                    "height": "45dp"
                },
                "myCards.imgNoCardsError": {
                    "src": "error_yellow.png"
                },
                "myCards.lblMyCardsHeader": {
                    "height": "25dp",
                    "top": "25dp"
                },
                "myCards.lblNoResultsSearch": {
                    "centerY": "",
                    "top": "40dp"
                },
                "myCards.lblRequestANewCard": {
                    "left": "7.69%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "myCards.lblSearch": {
                    "bottom": "",
                    "left": "",
                    "top": "",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "myCards": {
                    "left": "0dp",
                    "right": "",
                    "width": "100%"
                },
                "myCards.segMyCards": {
                    "data": [{
                        "btnAction1": "CHANGE PIN",
                        "btnAction2": "LOCK CARD",
                        "btnAction3": "REPORT LOST",
                        "btnAction4": "CANCEL CARD",
                        "btnAction5": "SET LIMITS",
                        "imgCard": "golden_card.png",
                        "imgCollapse": "arrow_down.png",
                        "imgIcon": "r",
                        "lblCardHeader": "My Platinum Credit Card",
                        "lblCardStatus": "Locked Card",
                        "lblIdentifier": "-$1000000.00",
                        "lblKey1": "Card Number:",
                        "lblKey2": "Valid Through:",
                        "lblKey3": "Daily Withdrawal limit:",
                        "lblKey4": "Available Credit:",
                        "lblSeparator1": "a",
                        "lblSeparator2": "a",
                        "lblTravelNotificationEnabled": "Travel Notification Enabled",
                        "rtxValue1": "XXXX XXXX XXXX 5404",
                        "rtxValue2": "02/20",
                        "rtxValue3": "$50,000",
                        "rtxValue4": "$32,500"
                    }, {
                        "btnAction1": "CHANGE PIN",
                        "btnAction2": "LOCK CARD",
                        "btnAction3": "REPORT LOST",
                        "btnAction4": "CANCEL CARD",
                        "btnAction5": "SET LIMITS",
                        "imgCard": "golden_card.png",
                        "imgCollapse": "arrow_down.png",
                        "imgIcon": "r",
                        "lblCardHeader": "My Platinum Credit Card",
                        "lblCardStatus": "Locked Card",
                        "lblIdentifier": "-$1000000.00",
                        "lblKey1": "Card Number:",
                        "lblKey2": "Valid Through:",
                        "lblKey3": "Daily Withdrawal limit:",
                        "lblKey4": "Available Credit:",
                        "lblSeparator1": "a",
                        "lblSeparator2": "a",
                        "lblTravelNotificationEnabled": "Travel Notification Enabled",
                        "rtxValue1": "XXXX XXXX XXXX 5404",
                        "rtxValue2": "02/20",
                        "rtxValue3": "$50,000",
                        "rtxValue4": "$32,500"
                    }, {
                        "btnAction1": "CHANGE PIN",
                        "btnAction2": "LOCK CARD",
                        "btnAction3": "REPORT LOST",
                        "btnAction4": "CANCEL CARD",
                        "btnAction5": "SET LIMITS",
                        "imgCard": "golden_card.png",
                        "imgCollapse": "arrow_down.png",
                        "imgIcon": "r",
                        "lblCardHeader": "My Platinum Credit Card",
                        "lblCardStatus": "Locked Card",
                        "lblIdentifier": "-$1000000.00",
                        "lblKey1": "Card Number:",
                        "lblKey2": "Valid Through:",
                        "lblKey3": "Daily Withdrawal limit:",
                        "lblKey4": "Available Credit:",
                        "lblSeparator1": "a",
                        "lblSeparator2": "a",
                        "lblTravelNotificationEnabled": "Travel Notification Enabled",
                        "rtxValue1": "XXXX XXXX XXXX 5404",
                        "rtxValue2": "02/20",
                        "rtxValue3": "$50,000",
                        "rtxValue4": "$32,500"
                    }],
                    "top": "18dp"
                },
                "mypaymentAccounts.flxHeader": {
                    "height": "59dp"
                },
                "mypaymentAccounts.lblHeading": {
                    "centerY": "50%",
                    "left": "7.69%",
                    "top": ""
                },
                "mypaymentAccounts": {
                    "maxHeight": 336,
                    "width": "99.70%"
                },
                "mypaymentAccounts.segMypaymentAccounts": {
                    "data": [{
                        "lblAccountName": "",
                        "lblAvailableBalance": "",
                        "lblBalance": "",
                        "lblHiddenAccountNumber": "",
                        "lblLeft": ""
                    }, {
                        "lblAccountName": "",
                        "lblAvailableBalance": "",
                        "lblBalance": "",
                        "lblHiddenAccountNumber": "",
                        "lblLeft": ""
                    }, {
                        "lblAccountName": "",
                        "lblAvailableBalance": "",
                        "lblBalance": "",
                        "lblHiddenAccountNumber": "",
                        "lblLeft": ""
                    }, {
                        "lblAccountName": "",
                        "lblAvailableBalance": "",
                        "lblBalance": "",
                        "lblHiddenAccountNumber": "",
                        "lblLeft": ""
                    }],
                    "maxHeight": 275,
                    "top": "60dp"
                },
                "TermsAndConditions": {
                    "width": "100%"
                },
                "CustomFooterMain": {
                    "centerX": "50%",
                    "left": "0dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "CustomFooterMain.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "CustomFooterMain.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "text": "No"
                },
                "CustomPopup.btnYes": {
                    "text": "Yes"
                },
                "CustomAlertPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomAlertPopup.lblHeading": {
                    "text": "Alert"
                },
                "CustomAlertPopup.lblPopupMessage": {
                    "text": "Unable to save the changes. Do you want to try again?"
                }
            }
            this.add(flxHeader, flxFormContent, flxLogout, flxAlert, flxLoading, flxTermsAndConditionsPopUp);
        };
        return [{
            "addWidgets": addWidgetsfrmCardManagement,
            "enabledForIdleTimeout": true,
            "id": "frmCardManagement",
            "init": controller.AS_Form_jeea1b6f492642399617bfdf6d3fe509,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_gd108bb6da8042b7b4ec54ad6ed88408,
            "postShow": controller.AS_Form_cf48919e45714f268daa73ee7b928732,
            "preShow": function(eventobject) {
                controller.AS_Form_e6c0940ed634451a841fe1815961cbfa(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "My Cards",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "CardsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_bd9d54643e8e4dbea529d79f89d9f901,
            "retainScrollPosition": false
        }]
    }
});