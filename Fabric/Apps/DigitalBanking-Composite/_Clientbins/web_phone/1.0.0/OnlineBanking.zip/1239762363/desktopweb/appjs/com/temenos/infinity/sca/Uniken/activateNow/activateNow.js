define(function() {
    return function(controller) {
        var activateNow = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "isMaster": true,
            "id": "activateNow",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "postShow": controller.AS_FlexContainer_e69f32c9c55c41409661bbbd1daaaf49,
            "preShow": function(eventobject) {
                controller.AS_FlexContainer_eebe43a3e1704cbbaf21355571b61e35(eventobject);
            },
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1400],
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "activateNow"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "activateNow"), extendConfig({}, controller.args[2], "activateNow"));
        activateNow.setDefaultUnit(kony.flex.DP);
        var flxClose = new kony.ui.FlexContainer(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "button"
                },
                "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
            },
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "0dp",
            "clipBounds": true,
            "height": "25dp",
            "id": "flxClose",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "20px",
            "skin": "slFbox",
            "width": "25dp",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxClose"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxClose"), extendConfig({
            "hoverSkin": "sknFlxHover"
        }, controller.args[2], "flxClose"));
        flxClose.setDefaultUnit(kony.flex.DP);
        var lblCloseFontIconCommon = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                },
                "a11yHidden": true
            },
            "height": "100%",
            "id": "lblCloseFontIconCommon",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknOlbFonts0273e315px",
            "text": "g",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblCloseFontIconCommon"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCloseFontIconCommon"), extendConfig({
            "toolTip": "Close"
        }, controller.args[2], "lblCloseFontIconCommon"));
        flxClose.add(lblCloseFontIconCommon);
        var flxContainer = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxContainer",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "15%",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "35dp",
            "width": "85%",
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxContainer"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxContainer"), extendConfig({}, controller.args[2], "flxContainer"));
        flxContainer.setDefaultUnit(kony.flex.DP);
        var flxActivateUserContent = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxActivateUserContent",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxActivateUserContent"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxActivateUserContent"), extendConfig({}, controller.args[2], "flxActivateUserContent"));
        flxActivateUserContent.setDefaultUnit(kony.flex.DP);
        var flximgrtx = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flximgrtx",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "20dp",
            "width": "98%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flximgrtx"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flximgrtx"), extendConfig({}, controller.args[2], "flximgrtx"));
        flximgrtx.setDefaultUnit(kony.flex.DP);
        var lblIcon = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                },
                "a11yHidden": true
            },
            "height": "52dp",
            "id": "lblIcon",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknOlbFontIcons00000040px",
            "text": "b",
            "top": "50dp",
            "width": "52dp",
            "zIndex": 1
        }, controller.args[0], "lblIcon"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblIcon"), extendConfig({}, controller.args[2], "lblIcon"));
        var lblTitle = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                },
                "tagName": "h1"
            },
            "id": "lblTitle",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknSupportedFileTypes",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.ActivateYourAccount\")",
            "top": "0dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblTitle"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblTitle"), extendConfig({}, controller.args[2], "lblTitle"));
        var lblMsg = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                }
            },
            "bottom": "5dp",
            "id": "lblMsg",
            "isVisible": true,
            "left": "65dp",
            "right": "0dp",
            "skin": "bbSknLbl424242SSP17Px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.ActivateMsg\")",
            "zIndex": 1
        }, controller.args[0], "lblMsg"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblMsg"), extendConfig({}, controller.args[2], "lblMsg"));
        flximgrtx.add(lblIcon, lblTitle, lblMsg);
        var lblErrorMsg = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "alert",
                    "tabindex": -1
                }
            },
            "centerX": "50%",
            "id": "lblErrorMsg",
            "isVisible": false,
            "left": "0dp",
            "skin": "sknlblff000015px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.activateProfile.errorMsg\")",
            "top": "30dp",
            "width": "98%",
            "zIndex": 1
        }, controller.args[0], "lblErrorMsg"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblErrorMsg"), extendConfig({}, controller.args[2], "lblErrorMsg"));
        var lblUsername = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                }
            },
            "id": "lblUsername",
            "isVisible": true,
            "left": "1%",
            "skin": "sknlbl727272SSPReg15px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.username\")",
            "top": "15dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblUsername"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblUsername"), extendConfig({}, controller.args[2], "lblUsername"));
        var flxUserName = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": false,
            "focusSkin": "sknFocusBorder4A90E2",
            "height": "40dp",
            "id": "flxUserName",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorderE3E3E3",
            "top": "5px",
            "width": "98%",
            "zIndex": 50,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxUserName"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxUserName"), extendConfig({}, controller.args[2], "flxUserName"));
        flxUserName.setDefaultUnit(kony.flex.DP);
        var tbxUserName = new kony.ui.TextBox2(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "aria-labelledby": "lblUsername",
                    "aria-required": true
                }
            },
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "centerY": "50%",
            "height": "84%",
            "id": "tbxUserName",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "15px",
            "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.EnterUsername\")",
            "right": "2px",
            "secureTextEntry": false,
            "skin": "skntbxSSP42424215pxnoborder",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "tbxUserName"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "tbxUserName"), extendConfig({
            "autoCorrect": false,
            "autoComplete": "off",
            "placeholderSkin": "sknTbxUsername"
        }, controller.args[2], "tbxUserName"));
        flxUserName.add(tbxUserName);
        var lblActivationCode = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                }
            },
            "id": "lblActivationCode",
            "isVisible": true,
            "left": "1%",
            "skin": "sknlbl727272SSPReg15px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.Activationcode\")",
            "top": "15px",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblActivationCode"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblActivationCode"), extendConfig({}, controller.args[2], "lblActivationCode"));
        var flxActivationCode = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "focusSkin": "sknFocusBorder4A90E2",
            "height": "40dp",
            "id": "flxActivationCode",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0",
            "isModalContainer": false,
            "skin": "sknBorderE3E3E3",
            "top": "5px",
            "width": "98%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxActivationCode"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxActivationCode"), extendConfig({}, controller.args[2], "flxActivationCode"));
        flxActivationCode.setDefaultUnit(kony.flex.DP);
        var txtActivationCode = new kony.ui.TextBox2(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "aria-labelledby": "lblActivationCode",
                    "aria-required": true
                }
            },
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "centerY": "50%",
            "height": "84%",
            "id": "txtActivationCode",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "15px",
            "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.EnterActivationCode\")",
            "right": "40dp",
            "secureTextEntry": true,
            "skin": "skntbxSSP42424215pxnoborder",
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "zIndex": 1
        }, controller.args[0], "txtActivationCode"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "txtActivationCode"), extendConfig({
            "autoCorrect": false,
            "autoComplete": "off",
            "placeholderSkin": "sknTbxUsername"
        }, controller.args[2], "txtActivationCode"));
        var flxImgViewCode = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "16dp",
            "id": "flxImgViewCode",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "isModalContainer": false,
            "right": "10dp",
            "top": "30%",
            "width": "22dp",
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxImgViewCode"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxImgViewCode"), extendConfig({}, controller.args[2], "flxImgViewCode"));
        flxImgViewCode.setDefaultUnit(kony.flex.DP);
        var imgViewCode = new kony.ui.Image2(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                },
                "a11yHidden": true
            },
            "height": "16dp",
            "id": "imgViewCode",
            "imageWhileDownloading": "img_transparent.png",
            "isVisible": true,
            "right": "0dp",
            "skin": "sknImgPointer",
            "src": "eye_hide.png",
            "top": "0dp",
            "width": "22dp",
            "zIndex": 1
        }, controller.args[0], "imgViewCode"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgViewCode"), extendConfig({}, controller.args[2], "imgViewCode"));
        flxImgViewCode.add(imgViewCode);
        flxActivationCode.add(txtActivationCode, flxImgViewCode);
        var btnVerify = new kony.ui.Button(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {}
            },
            "centerX": "50%",
            "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
            "height": "40dp",
            "id": "btnVerify",
            "isVisible": true,
            "left": "0",
            "skin": "sknBtnBlockedSSP00000015Px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.Verify\")",
            "top": "30px",
            "width": "98%",
            "zIndex": 1
        }, controller.args[0], "btnVerify"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnVerify"), extendConfig({
            "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
            "toolTip": "Verify"
        }, controller.args[2], "btnVerify"));
        var flxOtherOptions = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "centerX": "50%",
            "clipBounds": true,
            "id": "flxOtherOptions",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "98%",
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxOtherOptions"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxOtherOptions"), extendConfig({}, controller.args[2], "flxOtherOptions"));
        flxOtherOptions.setDefaultUnit(kony.flex.DP);
        var btnForgotPassword = new kony.ui.Button(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {}
            },
            "centerX": "50%",
            "focusSkin": "sknBtnSSP0273E314Px",
            "id": "btnForgotPassword",
            "isVisible": true,
            "skin": "sknBtnSSP0273E314Px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Login.CantLogin\")",
            "top": "20px",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "btnForgotPassword"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnForgotPassword"), extendConfig({
            "hoverSkin": "sknBtnSSP0273E314Px",
            "toolTip": "Cant Sign in"
        }, controller.args[2], "btnForgotPassword"));
        var lblCallUs = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                },
                "tagName": "span"
            },
            "bottom": "30dp",
            "centerX": "50.00%",
            "id": "lblCallUs",
            "isVisible": true,
            "skin": "sknSSP42424215Px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.CallSupportTeam\")",
            "top": "20px",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblCallUs"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCallUs"), extendConfig({}, controller.args[2], "lblCallUs"));
        flxOtherOptions.add(btnForgotPassword, lblCallUs);
        var flxSpace = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": false,
            "height": "30dp",
            "id": "flxSpace",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "top": "0dp",
            "width": "98%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxSpace"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxSpace"), extendConfig({}, controller.args[2], "flxSpace"));
        flxSpace.setDefaultUnit(kony.flex.DP);
        flxSpace.add();
        flxActivateUserContent.add(flximgrtx, lblErrorMsg, lblUsername, flxUserName, lblActivationCode, flxActivationCode, btnVerify, flxOtherOptions, flxSpace);
        var flxPasswordContent = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxPasswordContent",
            "isVisible": false,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxPasswordContent"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxPasswordContent"), extendConfig({}, controller.args[2], "flxPasswordContent"));
        flxPasswordContent.setDefaultUnit(kony.flex.DP);
        var flxImgContent = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxImgContent",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "40dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxImgContent"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxImgContent"), extendConfig({}, controller.args[2], "flxImgContent"));
        flxImgContent.setDefaultUnit(kony.flex.DP);
        var lblPwdTitleIcon = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                },
                "a11yHidden": true
            },
            "height": "52dp",
            "id": "lblPwdTitleIcon",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknOlbFontIcons00000040px",
            "text": "b",
            "top": "0dp",
            "width": "52dp",
            "zIndex": 1
        }, controller.args[0], "lblPwdTitleIcon"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPwdTitleIcon"), extendConfig({}, controller.args[2], "lblPwdTitleIcon"));
        var lblPwdMsg = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                }
            },
            "id": "lblPwdMsg",
            "isVisible": true,
            "left": "15dp",
            "skin": "bbSknLbl424242SSP17Px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.CreatePasswordMsg\")",
            "top": "25dp",
            "width": "77%",
            "zIndex": 1
        }, controller.args[0], "lblPwdMsg"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPwdMsg"), extendConfig({}, controller.args[2], "lblPwdMsg"));
        flxImgContent.add(lblPwdTitleIcon, lblPwdMsg);
        var lblPwdErrorMsg = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "role": "alert",
                    "tabindex": -1
                }
            },
            "id": "lblPwdErrorMsg",
            "isVisible": false,
            "left": "0dp",
            "skin": "sknlblff000015px",
            "text": "password not within the password rules",
            "top": "30dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "lblPwdErrorMsg"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPwdErrorMsg"), extendConfig({}, controller.args[2], "lblPwdErrorMsg"));
        var lblEnterNewPassword = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                }
            },
            "id": "lblEnterNewPassword",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknlbl727272SSPReg15px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.EnterNewPassword\")",
            "top": "30dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblEnterNewPassword"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblEnterNewPassword"), extendConfig({}, controller.args[2], "lblEnterNewPassword"));
        var flxPassword = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "focusSkin": "sknFocusBorder4A90E2",
            "height": "40dp",
            "id": "flxPassword",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorderE3E3E3",
            "top": "10dp",
            "width": "100%",
            "zIndex": 50,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxPassword"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxPassword"), extendConfig({}, controller.args[2], "flxPassword"));
        flxPassword.setDefaultUnit(kony.flex.DP);
        var tbxPassword = new kony.ui.TextBox2(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "aria-labelledby": "lblEnterNewPassword",
                    "aria-required": true
                }
            },
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "centerY": "50%",
            "height": "84%",
            "id": "tbxPassword",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "2%",
            "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.EnterNewPassword\")",
            "right": "40dp",
            "secureTextEntry": true,
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "zIndex": 1
        }, controller.args[0], "tbxPassword"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "tbxPassword"), extendConfig({
            "autoCorrect": false,
            "autoComplete": "off"
        }, controller.args[2], "tbxPassword"));
        var lblPwdIcon = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                },
                "a11yHidden": true
            },
            "centerY": "50%",
            "height": "18dp",
            "id": "lblPwdIcon",
            "isVisible": false,
            "right": "9dp",
            "skin": "sknFontIconffa909Bgffffont18pxOlbFontIcon",
            "text": "K",
            "width": "18dp",
            "zIndex": 1
        }, controller.args[0], "lblPwdIcon"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblPwdIcon"), extendConfig({}, controller.args[2], "lblPwdIcon"));
        flxPassword.add(tbxPassword, lblPwdIcon);
        var lblReEnterNewPassword = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                }
            },
            "id": "lblReEnterNewPassword",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknlbl727272SSPReg15px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.ReEnterNewPassword\")",
            "top": "20dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblReEnterNewPassword"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblReEnterNewPassword"), extendConfig({}, controller.args[2], "lblReEnterNewPassword"));
        var flxConfirmPassword = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "focusSkin": "sknFocusBorder4A90E2",
            "height": "40dp",
            "id": "flxConfirmPassword",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorderE3E3E3",
            "top": "10dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxConfirmPassword"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxConfirmPassword"), extendConfig({}, controller.args[2], "flxConfirmPassword"));
        flxConfirmPassword.setDefaultUnit(kony.flex.DP);
        var tbxConfirmPassword = new kony.ui.TextBox2(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "aria-labelledby": "lblReEnterNewPassword",
                    "aria-required": true
                }
            },
            "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
            "centerY": "50%",
            "height": "84%",
            "id": "tbxConfirmPassword",
            "isVisible": true,
            "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
            "left": "2%",
            "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.ReEnterNewPassword\")",
            "right": "40dp",
            "secureTextEntry": true,
            "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
            "zIndex": 1
        }, controller.args[0], "tbxConfirmPassword"), extendConfig({
            "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "tbxConfirmPassword"), extendConfig({
            "autoCorrect": false,
            "autoComplete": "off"
        }, controller.args[2], "tbxConfirmPassword"));
        var lblCnfInfoIcon = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                },
                "a11yHidden": true
            },
            "centerY": "50%",
            "height": "18dp",
            "id": "lblCnfInfoIcon",
            "isVisible": false,
            "right": "9dp",
            "skin": "sknFontIcon2a9e07Bgffffont18pxOlbFontIcon",
            "text": "N",
            "width": "18dp",
            "zIndex": 1
        }, controller.args[0], "lblCnfInfoIcon"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCnfInfoIcon"), extendConfig({}, controller.args[2], "lblCnfInfoIcon"));
        flxConfirmPassword.add(tbxConfirmPassword, lblCnfInfoIcon);
        var flxRulesPassword = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxRulesPassword",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "sknBorderE3E3E3",
            "top": "20dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxRulesPassword"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxRulesPassword"), extendConfig({}, controller.args[2], "flxRulesPassword"));
        flxRulesPassword.setDefaultUnit(kony.flex.DP);
        var flxPasswordRules = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "43%",
            "clipBounds": true,
            "height": "20dp",
            "id": "flxPasswordRules",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "3dp",
            "width": "85%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxPasswordRules"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxPasswordRules"), extendConfig({}, controller.args[2], "flxPasswordRules"));
        flxPasswordRules.setDefaultUnit(kony.flex.DP);
        var lblRulesIcon = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                },
                "a11yHidden": true
            },
            "centerY": "50%",
            "height": "18dp",
            "id": "lblRulesIcon",
            "isVisible": true,
            "left": "0.90%",
            "skin": "sknFontIconffa909Bgffffont18pxOlbFontIcon",
            "text": "K",
            "width": "18dp",
            "zIndex": 1
        }, controller.args[0], "lblRulesIcon"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblRulesIcon"), extendConfig({}, controller.args[2], "lblRulesIcon"));
        var lblRules = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                }
            },
            "centerY": "50%",
            "id": "lblRules",
            "isVisible": true,
            "left": "1.2999999999999998%",
            "skin": "sknlblSSP42424212px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.PasswordRules\")",
            "top": "4dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblRules"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblRules"), extendConfig({}, controller.args[2], "lblRules"));
        flxPasswordRules.add(lblRulesIcon, lblRules);
        var rtxRulesPassword = new kony.ui.RichText(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                }
            },
            "bottom": "10dp",
            "id": "rtxRulesPassword",
            "isVisible": false,
            "left": "3%",
            "linkSkin": "defRichTextLink",
            "skin": "sknrtSSP56565611px",
            "text": "<ul>\n<li>It should be between 8-16 characters Length.</li>\n<li>It should be a combination of alpha numeric.</li>\n<li>No Special characters & spaces are allowed.</li>\n<ii>You can not choose username as password.</li>\n<li>We can also put more rules here as per the requirement.</li>\n</ul>",
            "top": "8dp",
            "width": "83%",
            "zIndex": 1
        }, controller.args[0], "rtxRulesPassword"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "rtxRulesPassword"), extendConfig({}, controller.args[2], "rtxRulesPassword"));
        var brwRulesPassword = new kony.ui.Browser(extendConfig({
            "detectTelNumber": true,
            "enableZoom": false,
            "height": "180px",
            "htmlString": "Browser",
            "id": "brwRulesPassword",
            "isVisible": true,
            "left": "8%",
            "setAsContent": false,
            "top": "10dp",
            "width": "92%"
        }, controller.args[0], "brwRulesPassword"), extendConfig({}, controller.args[1], "brwRulesPassword"), extendConfig({}, controller.args[2], "brwRulesPassword"));
        flxRulesPassword.add(flxPasswordRules, rtxRulesPassword, brwRulesPassword);
        var btnSetPassword = new kony.ui.Button(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {}
            },
            "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
            "height": "40dp",
            "id": "btnSetPassword",
            "isVisible": true,
            "left": "0",
            "skin": "sknBtnBlockedSSP00000015Px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.SetPassword\")",
            "top": "35dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "btnSetPassword"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnSetPassword"), extendConfig({
            "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
            "toolTip": "Set Password"
        }, controller.args[2], "btnSetPassword"));
        flxPasswordContent.add(flxImgContent, lblPwdErrorMsg, lblEnterNewPassword, flxPassword, lblReEnterNewPassword, flxConfirmPassword, flxRulesPassword, btnSetPassword);
        var flxShowQRCodeGenerator = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "bottom": "0dp",
            "clipBounds": true,
            "height": "530px",
            "id": "flxShowQRCodeGenerator",
            "isVisible": false,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "50px",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxShowQRCodeGenerator"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxShowQRCodeGenerator"), extendConfig({}, controller.args[2], "flxShowQRCodeGenerator"));
        flxShowQRCodeGenerator.setDefaultUnit(kony.flex.DP);
        var QRCodeGenerator = new com.temenos.infinity.sca.uniken.QRCodeGenerator(extendConfig({
            "height": "100%",
            "id": "QRCodeGenerator",
            "isVisible": true,
            "left": "0dp",
            "masterType": constants.MASTER_TYPE_USERWIDGET,
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA",
            "viewType": "QRCodeGenerator",
            "overrides": {
                "QRCodeGenerator": {
                    "right": "viz.val_cleared",
                    "bottom": "viz.val_cleared",
                    "minWidth": "viz.val_cleared",
                    "minHeight": "viz.val_cleared",
                    "maxWidth": "viz.val_cleared",
                    "maxHeight": "viz.val_cleared",
                    "centerX": "viz.val_cleared",
                    "centerY": "viz.val_cleared"
                }
            }
        }, controller.args[0], "QRCodeGenerator"), extendConfig({
            "paddingInPixel": false,
            "overrides": {}
        }, controller.args[1], "QRCodeGenerator"), extendConfig({
            "overrides": {}
        }, controller.args[2], "QRCodeGenerator"));
        var QRCodeGenerator_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesUnikenMA"] && appConfig.componentMetadata["ResourcesUnikenMA"]["com.temenos.infinity.sca.uniken.activateNow"] && appConfig.componentMetadata["ResourcesUnikenMA"]["com.temenos.infinity.sca.uniken.activateNow"]["QRCodeGenerator"]) || {};
        QRCodeGenerator.renderMode = QRCodeGenerator_data.renderMode || "Properties";
        QRCodeGenerator.codeText = QRCodeGenerator_data.codeText || "QRCode";
        QRCodeGenerator.codeWidth = QRCodeGenerator_data.codeWidth || 250;
        QRCodeGenerator.codeHeight = QRCodeGenerator_data.codeHeight || 250;
        QRCodeGenerator.colorDark = QRCodeGenerator_data.colorDark || "000000";
        QRCodeGenerator.colorLight = QRCodeGenerator_data.colorLight || "FFFFFF";
        QRCodeGenerator.correctLevel = QRCodeGenerator_data.correctLevel || 0;
        flxShowQRCodeGenerator.add(QRCodeGenerator);
        var flxCongratulations = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxCongratulations",
            "isVisible": false,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "100%",
            "zIndex": 1,
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxCongratulations"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxCongratulations"), extendConfig({}, controller.args[2], "flxCongratulations"));
        flxCongratulations.setDefaultUnit(kony.flex.DP);
        var flxCongratulationLogo = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": true,
            "id": "flxCongratulationLogo",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "70dp",
            "width": "100%",
            "appName": "ResourcesUnikenMA"
        }, controller.args[0], "flxCongratulationLogo"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxCongratulationLogo"), extendConfig({}, controller.args[2], "flxCongratulationLogo"));
        flxCongratulationLogo.setDefaultUnit(kony.flex.DP);
        var lblCongtsIcon = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                },
                "a11yHidden": true
            },
            "centerX": "50%",
            "height": "40dp",
            "id": "lblCongtsIcon",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknGreenBgWhite40pxOLBFontIcon",
            "text": "N",
            "top": "0dp",
            "width": "40dp",
            "zIndex": 1
        }, controller.args[0], "lblCongtsIcon"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCongtsIcon"), extendConfig({}, controller.args[2], "lblCongtsIcon"));
        var lblCngts = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                }
            },
            "centerX": "50%",
            "id": "lblCngts",
            "isVisible": true,
            "skin": "sknLabel42424240px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.Congratulations\")",
            "top": "20dp",
            "width": kony.flex.USE_PREFFERED_SIZE,
            "zIndex": 1
        }, controller.args[0], "lblCngts"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCngts"), extendConfig({}, controller.args[2], "lblCngts"));
        flxCongratulationLogo.add(lblCongtsIcon, lblCngts);
        var lblCngtsMsg = new kony.ui.Label(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {
                    "tabindex": -1
                }
            },
            "id": "lblCngtsMsg",
            "isVisible": true,
            "left": "15dp",
            "skin": "bbSknLbl424242SSP17Px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.SuccessMsg\")",
            "top": "25dp",
            "width": "84%",
            "zIndex": 1
        }, controller.args[0], "lblCngtsMsg"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "lblCngtsMsg"), extendConfig({}, controller.args[2], "lblCngtsMsg"));
        var btnGetStarted = new kony.ui.Button(extendConfig({
            "accessibilityConfig": {
                "a11yARIA": {}
            },
            "focusSkin": "sknBtnFocusSSPFFFFFF15Px",
            "height": "40dp",
            "id": "btnGetStarted",
            "isVisible": true,
            "left": "0",
            "skin": "sknBtnNormalSSPFFFFFF15Px",
            "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginActivation.GetStarted\")",
            "top": "50dp",
            "width": "100%",
            "zIndex": 1
        }, controller.args[0], "btnGetStarted"), extendConfig({
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "displayText": true,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "btnGetStarted"), extendConfig({
            "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
            "toolTip": "Let's get started"
        }, controller.args[2], "btnGetStarted"));
        flxCongratulations.add(flxCongratulationLogo, lblCngtsMsg, btnGetStarted);
        flxContainer.add(flxActivateUserContent, flxPasswordContent, flxShowQRCodeGenerator, flxCongratulations);
        activateNow.add(flxClose, flxContainer);
        activateNow.breakpointResetData = {};
        activateNow.breakpointData = {
            maxBreakpointWidth: 1400,
            "640": {
                "rtxRulesPassword": {
                    "segmentProps": []
                },
                "brwRulesPassword": {
                    "segmentProps": []
                }
            }
        }
        activateNow.compInstData = {
            "QRCodeGenerator": {
                "right": "",
                "bottom": "",
                "minWidth": "",
                "minHeight": "",
                "maxWidth": "",
                "maxHeight": "",
                "centerX": "",
                "centerY": ""
            }
        }
        return activateNow;
    }
})