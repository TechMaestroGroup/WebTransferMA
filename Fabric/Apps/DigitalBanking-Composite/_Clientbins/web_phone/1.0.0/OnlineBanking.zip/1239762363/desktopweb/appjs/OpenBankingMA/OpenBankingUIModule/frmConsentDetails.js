define("OpenBankingMA/OpenBankingUIModule/frmConsentDetails", function() {
    return function(controller) {
        function addWidgetsfrmConsentDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMainScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMainScroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainScroll.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "64dp",
                "id": "flxHeaderContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.setDefaultUnit(kony.flex.DP);
            var openBankingHeader = new com.temenos.openBankingHeader({
                "height": "64dp",
                "id": "openBankingHeader",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA",
                "viewType": "openBankingHeader",
                "overrides": {
                    "openBankingHeader": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var openBankingHeader_data = (appConfig.componentMetadata && appConfig.componentMetadata["OpenBankingMA"] && appConfig.componentMetadata["OpenBankingMA"]["frmConsentDetails"] && appConfig.componentMetadata["OpenBankingMA"]["frmConsentDetails"]["openBankingHeader"]) || {};
            flxHeaderContainer.add(openBankingHeader);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxConsentDetailsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConsentDetailsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentDetailsContainer.setDefaultUnit(kony.flex.DP);
            var flxConsentDetail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxConsentDetail",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "0dp",
                "width": "728dp",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentDetail.setDefaultUnit(kony.flex.DP);
            var flxConsentHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConsentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentHeader.setDefaultUnit(kony.flex.DP);
            var lblConsentHeader = new kony.ui.Label({
                "id": "lblConsentHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLabel42424224pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.authoriseConsent\")",
                "top": "24dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConsentHeader.add(lblConsentHeader);
            var flxErrorSingle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "48px",
                "id": "flxErrorSingle",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "sknFlxffffffBordere3e3e3shadyellow",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorSingle.setDefaultUnit(kony.flex.DP);
            var imgAlert = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgAlert",
                "isVisible": true,
                "left": "25dp",
                "skin": "slImage",
                "src": "warning_yellow.png",
                "top": "10dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError = new kony.ui.Label({
                "height": "35dp",
                "id": "lblError",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "This payment will take your account in to an un arranged overdraft.",
                "textStyle": {},
                "top": "5dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorSingle.add(imgAlert, lblError);
            var flxErrorMultiple = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxErrorMultiple",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffBordere3e3e3shadyellow",
                "top": "20dp",
                "width": "99%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMultiple.setDefaultUnit(kony.flex.DP);
            var flxErrorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxErrorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorHeader.setDefaultUnit(kony.flex.DP);
            var imgAlert1 = new kony.ui.Image2({
                "height": "24dp",
                "id": "imgAlert1",
                "isVisible": true,
                "left": "3%",
                "skin": "slImage",
                "src": "warning_yellow.png",
                "top": "18dp",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorHeader = new kony.ui.Label({
                "id": "lblErrorHeader",
                "isVisible": true,
                "left": "7.50%",
                "skin": "sknLbl000d19SSB16px",
                "text": "Please note the following details",
                "textStyle": {},
                "top": "20dp",
                "width": "92%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorHeader.add(imgAlert1, lblErrorHeader);
            var SegError = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "data": [{
                    "lblDot": "Label",
                    "lblErrorText": "This payment will take your account in to an un arranged overdraft"
                }, {
                    "lblDot": "Label",
                    "lblErrorText": "This payment will take your account in to an un arranged overdraft"
                }],
                "groupCells": false,
                "id": "SegError",
                "isVisible": true,
                "left": "4.50%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "OpenBankingMA",
                    "friendlyName": "flexWarningMessages"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flexWarningMessages": "flexWarningMessages",
                    "lblDot": "lblDot",
                    "lblErrorText": "lblErrorText"
                },
                "width": "96.06%",
                "appName": "OpenBankingMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMultiple.add(flxErrorHeader, SegError);
            var flxConsentInfo = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "96dp",
                "id": "flxConsentInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffWithBorderAndRadius16px",
                "top": "22dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentInfo.setDefaultUnit(kony.flex.DP);
            var flxConsentImg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "47dp",
                "id": "flxConsentImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "24dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "46dp",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentImg.setDefaultUnit(kony.flex.DP);
            var imgConsent = new kony.ui.Image2({
                "height": "42dp",
                "id": "imgConsent",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "authorise.png",
                "top": "0dp",
                "width": "45dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConsentImg.add(imgConsent);
            var flxConsentInfoDesc = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "47dp",
                "id": "flxConsentInfoDesc",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "22dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentInfoDesc.setDefaultUnit(kony.flex.DP);
            var rtxInfo = new kony.ui.RichText({
                "height": "220dp",
                "id": "rtxInfo",
                "isVisible": true,
                "left": "0",
                "linkSkin": "defRichTextLink",
                "skin": "sknRtx000d19SSP18px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLink = new kony.ui.Label({
                "id": "lblLink",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP004BB115Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppconsent.whatInfoWillIShare\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConsentInfoDesc.add(rtxInfo, lblLink);
            flxConsentInfo.add(flxConsentImg, flxConsentInfoDesc);
            var flxConsentDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConsentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffWithBorderAndRadius16px",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentDetails.setDefaultUnit(kony.flex.DP);
            var flxConsentSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConsentSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentSegment.setDefaultUnit(kony.flex.DP);
            var segConsentDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }, {
                    "lblAccountType": "Checking Account",
                    "lblBalance": "€198,00",
                    "lblID": "DE685001051780001240028",
                    "lblName": "Tyler Stephenson"
                }],
                "groupCells": false,
                "id": "segConsentDetails",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "segTransparant",
                "rowSkin": "segTransparant",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "OpenBankingMA",
                    "friendlyName": "flxGlobalConsent"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDetail1": "flxDetail1",
                    "flxDetail2": "flxDetail2",
                    "flxGlobalConsent": "flxGlobalConsent",
                    "flxMain": "flxMain",
                    "flxSeparator": "flxSeparator",
                    "lblAccountType": "lblAccountType",
                    "lblBalance": "lblBalance",
                    "lblID": "lblID",
                    "lblName": "lblName"
                },
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConsentSegment.add(segConsentDetails);
            var flxConsentEligibility = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100dp",
                "id": "flxConsentEligibility",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "24dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentEligibility.setDefaultUnit(kony.flex.DP);
            var flxConstentEligibilityBlock1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "43dp",
                "id": "flxConstentEligibilityBlock1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConstentEligibilityBlock1.setDefaultUnit(kony.flex.DP);
            var lblAccountMissing = new kony.ui.Label({
                "id": "lblAccountMissing",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbl000D1915pxSSPSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppconsent.accountMissing\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEligibility = new kony.ui.Label({
                "id": "lblEligibility",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl000d19SSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppconsent.accountMissingMsg\")",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConstentEligibilityBlock1.add(lblAccountMissing, lblEligibility);
            var flxConstentEligibilityBlock2 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "40dp",
                "id": "flxConstentEligibilityBlock2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknF2F5F8Radius8px",
                "top": "22dp",
                "width": "680dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConstentEligibilityBlock2.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfo = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblInfo",
                "isVisible": true,
                "left": "6dp",
                "skin": "sknlbl000d19SS13px",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConstentEligibilityBlock2.add(imgInfo, lblInfo);
            flxConsentEligibility.add(flxConstentEligibilityBlock1, flxConstentEligibilityBlock2);
            var flxConsentButtons = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "88dp",
                "id": "flxConsentButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConsentButtons.setDefaultUnit(kony.flex.DP);
            var btnApprove = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknbtnSSPffffff0278ee15pxbr3px",
                "height": "40dp",
                "id": "btnApprove",
                "isVisible": true,
                "left": "0",
                "right": "24dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.Approve\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px"
            });
            var btnReject = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "ICSknBtnSSPRegular003E7515Px",
                "height": "40dp",
                "id": "btnReject",
                "isVisible": true,
                "right": "16dp",
                "skin": "ICSknBtnSSPRegular003E7515Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18.termsandconditions\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxConsentButtons.add(btnApprove, btnReject);
            flxConsentDetails.add(flxConsentSegment, flxConsentEligibility, flxConsentButtons);
            flxConsentDetail.add(flxConsentHeader, flxErrorSingle, flxErrorMultiple, flxConsentInfo, flxConsentDetails);
            flxConsentDetailsContainer.add(flxConsentDetail);
            flxMainContainer.add(flxConsentDetailsContainer);
            flxMainScroll.add(flxHeaderContainer, flxMainContainer);
            var flxRejectPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxRejectPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectPopup.setDefaultUnit(kony.flex.DP);
            var rejectPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "rejectPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0%",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "height": "268px",
                        "left": "0%",
                        "top": "0%",
                        "width": "500px"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRejectPopup.add(rejectPopup);
            var flxInfoPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxInfoPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoPopup.setDefaultUnit(kony.flex.DP);
            var flxInfoPopupContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "id": "flxInfoPopupContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "maxHeight": "90%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "700dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoPopupContainer.setDefaultUnit(kony.flex.DP);
            var flxInfoPopupHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxInfoPopupHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "98%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoPopupHeader.setDefaultUnit(kony.flex.DP);
            var lbInfoPopupHeader = new kony.ui.Label({
                "id": "lbInfoPopupHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbl000D1918pxSSPSemibold",
                "text": "What info will I share?",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInfoPopupClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInfoPopupClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "top": "0dp",
                "width": "50dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoPopupClose.setDefaultUnit(kony.flex.DP);
            var btnInfoPopupClose = new kony.ui.Button({
                "height": "0dp",
                "id": "btnInfoPopupClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "btnClose",
                "top": "0dp",
                "width": "5dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoPopupClose.add(btnInfoPopupClose);
            flxInfoPopupHeader.add(lbInfoPopupHeader, flxInfoPopupClose);
            var flxInfoPopupComp = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxInfoPopupComp",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoPopupComp.setDefaultUnit(kony.flex.DP);
            flxInfoPopupComp.add();
            var flxSpace = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSpace",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpace.setDefaultUnit(kony.flex.DP);
            flxSpace.add();
            flxInfoPopupContainer.add(flxInfoPopupHeader, flxInfoPopupComp, flxSpace);
            flxInfoPopup.add(flxInfoPopupContainer);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "openBankingHeader": {
                        "segmentProps": []
                    },
                    "flxConsentDetailsContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentDetail": {
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxErrorSingle": {
                        "isVisible": false,
                        "skin": "sknFlxffffffBordere3e3e3shadred",
                        "segmentProps": []
                    },
                    "imgAlert": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "src": "roadmap_failure.png",
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxErrorMultiple": {
                        "isVisible": false,
                        "skin": "sknFlxffffffBordere3e3e3shadred",
                        "segmentProps": []
                    },
                    "imgAlert1": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "src": "roadmap_failure.png",
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "SegError": {
                        "data": [{
                            "lblDot": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblErrorText": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Your account balance isn’t sufficient to make this payment "
                            }
                        }, {
                            "lblDot": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblErrorText": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Your account balance isn’t sufficient to make this payment "
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "OpenBankingMA",
                            "friendlyName": "flexErrorMessage"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flexErrorMessage": "flexErrorMessage",
                            "lblDot": "lblDot",
                            "lblErrorText": "lblErrorText"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "OpenBankingMA"
                    },
                    "flxConsentInfo": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentImg": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentInfoDesc": {
                        "left": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "rtxInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "73%"
                        },
                        "segmentProps": []
                    },
                    "lblLink": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentEligibility": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxConstentEligibilityBlock1": {
                        "bottom": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "lblEligibility": {
                        "text": "If your account is not listed, then it is not eligible for this service.",
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxConstentEligibilityBlock2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "38%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxConsentButtons": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "btnApprove": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "58dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "btnReject": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Reject",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxInfoPopupContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "49.50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "53%"
                        },
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "flxInfoPopupClose": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnInfoPopupClose": {
                        "segmentProps": []
                    },
                    "flxInfoPopupComp": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxConsentDetailsContainer": {
                        "skin": "sknFlxf8f7f8",
                        "segmentProps": []
                    },
                    "flxConsentDetail": {
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "71.30%"
                        },
                        "segmentProps": []
                    },
                    "flxErrorSingle": {
                        "isVisible": false,
                        "skin": "sknFlxffffffBordere3e3e3shadred",
                        "segmentProps": []
                    },
                    "imgAlert": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "src": "roadmap_failure.png",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxErrorMultiple": {
                        "isVisible": false,
                        "skin": "sknFlxffffffBordere3e3e3shadred",
                        "segmentProps": []
                    },
                    "imgAlert1": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "src": "roadmap_failure.png",
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "SegError": {
                        "data": [{
                            "lblDot": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblErrorText": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Your account balance isn’t sufficient to make this payment "
                            }
                        }, {
                            "lblDot": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblErrorText": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Your account balance isn’t sufficient to make this payment "
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "OpenBankingMA",
                            "friendlyName": "flexErrorMessage"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flexErrorMessage": "flexErrorMessage",
                            "lblDot": "lblDot",
                            "lblErrorText": "lblErrorText"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "OpenBankingMA"
                    },
                    "flxConsentInfo": {
                        "height": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentInfoDesc": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "segmentProps": []
                    },
                    "rtxInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblLink": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentEligibility": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxConstentEligibilityBlock1": {
                        "bottom": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxConstentEligibilityBlock2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.30%"
                        },
                        "segmentProps": []
                    },
                    "flxConsentButtons": {
                        "reverseLayoutDirection": true,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxRejectPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "rejectPopup": {
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": [],
                        "instanceId": "rejectPopup"
                    },
                    "flxInfoPopupContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "49.80%"
                        },
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "68.40%"
                        },
                        "segmentProps": []
                    },
                    "flxInfoPopupClose": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnInfoPopupClose": {
                        "segmentProps": []
                    },
                    "flxInfoPopupComp": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMainContainer": {
                        "segmentProps": []
                    },
                    "flxConsentDetailsContainer": {
                        "skin": "sknFlxf8f7f8",
                        "segmentProps": []
                    },
                    "flxConsentDetail": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "728dp"
                        },
                        "segmentProps": []
                    },
                    "flxErrorSingle": {
                        "isVisible": false,
                        "skin": "sknFlxffffffBordere3e3e3shadred",
                        "segmentProps": []
                    },
                    "imgAlert": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "src": "roadmap_failure.png",
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "lblError": {
                        "skin": "sknlbl000d19SSP18px",
                        "segmentProps": []
                    },
                    "flxErrorMultiple": {
                        "isVisible": false,
                        "skin": "sknFlxffffffBordere3e3e3shadred",
                        "segmentProps": []
                    },
                    "imgAlert1": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "src": "roadmap_failure.png",
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "lblErrorHeader": {
                        "segmentProps": []
                    },
                    "SegError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "data": [{
                            "lblDot": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblErrorText": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Your account balance isn’t sufficient to make this payment "
                            }
                        }, {
                            "lblDot": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblErrorText": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Your account balance isn’t sufficient to make this payment "
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "OpenBankingMA",
                            "friendlyName": "flexErrorMessage"
                        }),
                        "sectionHeaderTemplate": "",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "widgetDataMap": {
                            "flexErrorMessage": "flexErrorMessage",
                            "lblDot": "lblDot",
                            "lblErrorText": "lblErrorText"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "OpenBankingMA"
                    },
                    "flxConsentInfoDesc": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "rtxInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblLink": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentEligibility": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxConstentEligibilityBlock1": {
                        "bottom": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxConstentEligibilityBlock2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.30%"
                        },
                        "segmentProps": []
                    },
                    "flxConsentButtons": {
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnApprove": {
                        "segmentProps": []
                    },
                    "flxInfoPopupContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "49.80%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfoPopupClose": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnInfoPopupClose": {
                        "segmentProps": []
                    },
                    "flxInfoPopupComp": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "openBankingHeader": {
                        "segmentProps": []
                    },
                    "flxConsentDetailsContainer": {
                        "skin": "sknFlxf8f7f8",
                        "segmentProps": []
                    },
                    "flxConsentDetail": {
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "728dp"
                        },
                        "segmentProps": []
                    },
                    "flxErrorSingle": {
                        "isVisible": false,
                        "skin": "sknFlxffffffBordere3e3e3shadred",
                        "segmentProps": []
                    },
                    "imgAlert": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "src": "roadmap_failure.png",
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "flxErrorMultiple": {
                        "isVisible": false,
                        "skin": "sknFlxffffffBordere3e3e3shadred",
                        "segmentProps": []
                    },
                    "imgAlert1": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "src": "roadmap_failure.png",
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "SegError": {
                        "data": [{
                            "lblDot": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblErrorText": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Your account balance isn’t sufficient to make this payment "
                            }
                        }, {
                            "lblDot": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            },
                            "lblErrorText": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Your account balance isn’t sufficient to make this payment "
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "OpenBankingMA",
                            "friendlyName": "flexErrorMessage"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flexErrorMessage": "flexErrorMessage",
                            "lblDot": "lblDot",
                            "lblErrorText": "lblErrorText"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "OpenBankingMA"
                    },
                    "flxConsentInfoDesc": {
                        "left": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "rtxInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblLink": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "flxConsentEligibility": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxConstentEligibilityBlock1": {
                        "bottom": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxConstentEligibilityBlock2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.30%"
                        },
                        "segmentProps": []
                    },
                    "flxConsentButtons": {
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "flxInfoPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxInfoPopupContainer": {
                        "accessibilityConfig": {},
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfoPopupClose": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnInfoPopupClose": {
                        "segmentProps": []
                    },
                    "flxInfoPopupComp": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "openBankingHeader": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "rejectPopup": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "height": "268px",
                    "left": "0%",
                    "top": "0%",
                    "width": "500px"
                }
            }
            this.add(flxMainScroll, flxRejectPopup, flxInfoPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmConsentDetails,
            "enabledForIdleTimeout": false,
            "id": "frmConsentDetails",
            "init": controller.AS_Form_d4094691f9ae4ca5982c37b65cb92a66,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "OpenBankingMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});