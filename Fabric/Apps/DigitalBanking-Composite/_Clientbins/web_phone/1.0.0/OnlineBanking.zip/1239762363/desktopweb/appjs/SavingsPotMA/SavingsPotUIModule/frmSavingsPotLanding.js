define("SavingsPotMA/SavingsPotUIModule/frmSavingsPotLanding", function() {
    return function(controller) {
        function addWidgetsfrmSavingsPotLanding() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgMenu": {
                        "left": "6.07%",
                        "src": "menu_icon.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxSubMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSubMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubMain.setDefaultUnit(kony.flex.DP);
            var flxSavingsPotHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "52px",
                "id": "flxSavingsPotHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSavingsPotHeader.setDefaultUnit(kony.flex.DP);
            var lblMySavingsPot = new kony.ui.Label({
                "id": "lblMySavingsPot",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.mySavingsPot\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountTypes = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "clipBounds": true,
                "focusSkin": "flxHoverSkinPointer",
                "height": "100%",
                "id": "flxAccountTypes",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "15px",
                "width": "340px",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxAccountTypes.setDefaultUnit(kony.flex.DP);
            var flxImgAccountTypeIcon = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "20px",
                "id": "flxImgAccountTypeIcon",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0px",
                "isModalContainer": false,
                "right": "20px",
                "skin": "slFbox",
                "top": "0dp",
                "width": "20px",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgAccountTypeIcon.setDefaultUnit(kony.flex.DP);
            var imgAccountTypeIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgAccountTypeIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblOLBFontIconsvs",
                "text": "s",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            flxImgAccountTypeIcon.add(imgAccountTypeIcon);
            var lblAccountTypes = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.MyCheckingAccount3254\")"
                },
                "centerY": "50%",
                "id": "lblAccountTypes",
                "isVisible": true,
                "left": "0px",
                "skin": "sknLabelSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.MyCheckingAccount3254\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            var imgAccountTypes = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Account Types"
                },
                "centerY": "50%",
                "height": "7dp",
                "id": "imgAccountTypes",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "14dp",
                "skin": "sknImgPointer5vs",
                "src": "arrow_down.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            flxAccountTypes.add(flxImgAccountTypeIcon, lblAccountTypes, imgAccountTypes);
            flxSavingsPotHeader.add(lblMySavingsPot, flxAccountTypes);
            var flxGoalCreationWarning = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxGoalCreationWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "103dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "145dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGoalCreationWarning.setDefaultUnit(kony.flex.DP);
            var imgGoalCreationWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgGoalCreationWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblGoalCreationWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")"
                },
                "bottom": "8dp",
                "id": "lblGoalCreationWarning",
                "isVisible": true,
                "left": "80dp",
                "right": "50dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.goalCreationFailedMessage\")",
                "top": "8dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseGoalCreationWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "height": "40dp",
                "id": "imgCloseGoalCreationWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknImgPointer5vs",
                "src": "bbcloseicon.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxGoalCreationWarning.add(imgGoalCreationWarning, lblGoalCreationWarning, imgCloseGoalCreationWarning);
            var flxSavingsPotLanding = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "5dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxSavingsPotLanding",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSavingsPotLanding.setDefaultUnit(kony.flex.DP);
            var flxLeftContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "85dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "58%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContainer.setDefaultUnit(kony.flex.DP);
            var flxSavingsPotClosedSuccess = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": false,
                "height": "90px",
                "id": "flxSavingsPotClosedSuccess",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "20px",
                "width": "100%",
                "zIndex": 2,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSavingsPotClosedSuccess.setDefaultUnit(kony.flex.DP);
            var imgGoalClosedSuccess = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgGoalClosedSuccess",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblGoalClosedSuccess = new kony.ui.Label({
                "id": "lblGoalClosedSuccess",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.goalClosed\")",
                "top": "0dp",
                "width": "90px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgGoalSuccessClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "imgGoalSuccessClose",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "60%",
                "right": "0%",
                "skin": "sknImgPointer5vs",
                "src": "bbcloseicon.png",
                "top": "10dp",
                "width": "2%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxSavingsPotClosedSuccess.add(imgGoalClosedSuccess, lblGoalClosedSuccess, imgGoalSuccessClose);
            var flxSavingsPotBalanceDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxSavingsPotBalanceDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSavingsPotBalanceDetails.setDefaultUnit(kony.flex.DP);
            var flxTotalBalance = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": true,
                "id": "flxTotalBalance",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "22%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalBalance.setDefaultUnit(kony.flex.DP);
            var lblTotalBalance = new kony.ui.Label({
                "id": "lblTotalBalance",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.totalBalanceHeader\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalBalanceValue = new kony.ui.Label({
                "id": "lblTotalBalanceValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP42424224Px",
                "text": "$72,500.00",
                "top": "4dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalBalance.add(lblTotalBalance, lblTotalBalanceValue);
            var flxHSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxHSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHSeperator.setDefaultUnit(kony.flex.DP);
            flxHSeperator.add();
            var flxMyGoals = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": true,
                "id": "flxMyGoals",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "22%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyGoals.setDefaultUnit(kony.flex.DP);
            var lblMyGoals = new kony.ui.Label({
                "id": "lblMyGoals",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.myGoals\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMyGoalsValue = new kony.ui.Label({
                "id": "lblMyGoalsValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP42424224Px",
                "text": "$72,500.00",
                "top": "4dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMyGoals.add(lblMyGoals, lblMyGoalsValue);
            var flxHSeparatorMobile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxHSeparatorMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "1dp",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHSeparatorMobile.setDefaultUnit(kony.flex.DP);
            flxHSeparatorMobile.add();
            var flxMyBudgets = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": true,
                "id": "flxMyBudgets",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "30%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMyBudgets.setDefaultUnit(kony.flex.DP);
            var lblMyBudgets = new kony.ui.Label({
                "id": "lblMyBudgets",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.myBudgets\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMyBudgetsValue = new kony.ui.Label({
                "id": "lblMyBudgetsValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP42424224Px",
                "text": "$72,500.00",
                "top": "4dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMyBudgets.add(lblMyBudgets, lblMyBudgetsValue);
            flxSavingsPotBalanceDetails.add(flxTotalBalance, flxHSeperator, flxMyGoals, flxHSeparatorMobile, flxMyBudgets);
            var flxCreateNewSavingsPotTablet = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCreateNewSavingsPotTablet",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "72px",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateNewSavingsPotTablet.setDefaultUnit(kony.flex.DP);
            var flxActionTablet = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "clipBounds": true,
                "height": "50dp",
                "id": "flxActionTablet",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActionTablet.setDefaultUnit(kony.flex.DP);
            var lblCreateNewSavingsPot = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddExternalAccount\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblCreateNewSavingsPot",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.createNewSavingsPot\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxSeperator0ebca344f74b949 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "CopyflxSeperator0ebca344f74b949",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSeperator0ebca344f74b949.setDefaultUnit(kony.flex.DP);
            CopyflxSeperator0ebca344f74b949.add();
            flxActionTablet.add(lblCreateNewSavingsPot, CopyflxSeperator0ebca344f74b949);
            flxCreateNewSavingsPotTablet.add(flxActionTablet);
            var flxNoGoals = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "1dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxNoGoals",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30px",
                "width": "98%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoGoals.setDefaultUnit(kony.flex.DP);
            var lblNoGoalTitle = new kony.ui.Label({
                "id": "lblNoGoalTitle",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbl424242SSPReg17px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.myGoals\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCreateGoal = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": false,
                "height": "213dp",
                "id": "flxCreateGoal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateGoal.setDefaultUnit(kony.flex.DP);
            var flxCreateInfo = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "150dp",
                "id": "flxCreateInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateInfo.setDefaultUnit(kony.flex.DP);
            var imgPotType1 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "100dp",
                "id": "imgPotType1",
                "isVisible": true,
                "left": "40dp",
                "skin": "slImage",
                "src": "goal_icon.png",
                "top": "20dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPotType1Name = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddInternationalAccount\")"
                },
                "id": "lblPotType1Name",
                "isVisible": true,
                "left": "190dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.savingsGoal\")",
                "top": "20dp",
                "width": "55%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblPotType1Description = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddInternationalAccount\")"
                },
                "height": "60dp",
                "id": "lblPotType1Description",
                "isVisible": true,
                "left": "190dp",
                "right": "24%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.savingsGoalDescrition\")",
                "top": "50dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparatorLine = new kony.ui.Label({
                "height": "70%",
                "id": "lblSeparatorLine",
                "isVisible": true,
                "right": "22.60%",
                "skin": "sknSeparatore3e3e3",
                "text": ".",
                "top": "20dp",
                "width": "2px",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCreateGoal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddInternationalAccount\")"
                },
                "centerY": "50%",
                "height": "60dp",
                "id": "lblCreateGoal",
                "isVisible": true,
                "right": "10dp",
                "skin": "sknSSP4176a415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18.SavingsPot.createGoal\")",
                "top": "50dp",
                "width": "17%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxCreateInfo.add(imgPotType1, lblPotType1Name, lblPotType1Description, lblSeparatorLine, lblCreateGoal);
            flxCreateGoal.add(flxCreateInfo);
            flxNoGoals.add(lblNoGoalTitle, flxCreateGoal);
            var flxNoGoalNoPermission = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "1dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxNoGoalNoPermission",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30px",
                "width": "98%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoGoalNoPermission.setDefaultUnit(kony.flex.DP);
            var lblNoGoalTitlePermission = new kony.ui.Label({
                "id": "lblNoGoalTitlePermission",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbl424242SSPReg17px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.myGoals\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCreateGoalPermission = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": false,
                "height": "213dp",
                "id": "flxCreateGoalPermission",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateGoalPermission.setDefaultUnit(kony.flex.DP);
            var flxCreateGoalInfoPermission = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "150dp",
                "id": "flxCreateGoalInfoPermission",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateGoalInfoPermission.setDefaultUnit(kony.flex.DP);
            var imgGoalTypePermission = new kony.ui.Image2({
                "centerY": "50%",
                "height": "100dp",
                "id": "imgGoalTypePermission",
                "isVisible": true,
                "left": "40dp",
                "skin": "slImage",
                "src": "goal_icon.png",
                "top": "20dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoGoalPermission = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxNoGoalPermission",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "200dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "9dp",
                "width": "60%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoGoalPermission.setDefaultUnit(kony.flex.DP);
            var imgGoalInfo = new kony.ui.Image2({
                "centerY": "50%",
                "height": "35dp",
                "id": "imgGoalInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0dp",
                "width": "35dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblGoalTypePermission = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddInternationalAccount\")"
                },
                "height": "60dp",
                "id": "lblGoalTypePermission",
                "isVisible": true,
                "left": "50dp",
                "right": 24,
                "skin": "sknlblUserName",
                "text": "No Savings Goal created on this account. You don’t have permissions to create one.",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxNoGoalPermission.add(imgGoalInfo, lblGoalTypePermission);
            flxCreateGoalInfoPermission.add(imgGoalTypePermission, flxNoGoalPermission);
            flxCreateGoalPermission.add(flxCreateGoalInfoPermission);
            flxNoGoalNoPermission.add(lblNoGoalTitlePermission, flxCreateGoalPermission);
            var flxSavingsPotSegmentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSavingsPotSegmentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30px",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSavingsPotSegmentContainer.setDefaultUnit(kony.flex.DP);
            var goalsAndBudgets = new com.InfinityOLB.SavingsPotMA.savingspot({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "goalsAndBudgets",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SavingsPotMA",
                "overrides": {
                    "CopyLabel0abe0e6915db543": {
                        "text": "$90,000.00"
                    },
                    "CopyLabel0ce9f275e077042": {
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "flxRow": {
                        "bottom": "0dp",
                        "top": "60dp",
                        "width": "98%"
                    },
                    "flxRowMobile": {
                        "centerX": "49.97%",
                        "width": "98%"
                    },
                    "imgStatusIcon": {
                        "left": "10dp",
                        "src": "aa_password_error.png"
                    },
                    "imgStatusMobile": {
                        "src": "aa_password_error.png"
                    },
                    "lblComponentTitle": {
                        "left": "0%",
                        "top": "20dp"
                    },
                    "lblTitle": {
                        "left": "40dp"
                    },
                    "savingspot": {
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSavingsPotSegmentContainer.add(goalsAndBudgets);
            var flxNoBudgets = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "1dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxNoBudgets",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "98%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoBudgets.setDefaultUnit(kony.flex.DP);
            var lblNoBudgetTitle = new kony.ui.Label({
                "id": "lblNoBudgetTitle",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbl424242SSPReg17px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.myBudgets\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoBudget = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "213dp",
                "id": "flxNoBudget",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoBudget.setDefaultUnit(kony.flex.DP);
            var flxCreateBudgetInfo = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "150dp",
                "id": "flxCreateBudgetInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateBudgetInfo.setDefaultUnit(kony.flex.DP);
            var imgPotType = new kony.ui.Image2({
                "centerY": "50%",
                "height": "100dp",
                "id": "imgPotType",
                "isVisible": true,
                "left": "40dp",
                "skin": "slImage",
                "src": "wallet_icon.png",
                "top": "20dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPotType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddInternationalAccount\")"
                },
                "id": "lblPotType",
                "isVisible": true,
                "left": "190dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.savingsGoal\")",
                "top": "20dp",
                "width": "55%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblPotTypeDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddInternationalAccount\")"
                },
                "height": "60dp",
                "id": "lblPotTypeDetails",
                "isVisible": true,
                "left": "190dp",
                "right": "24%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.savingsGoalDescrition\")",
                "top": "50dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblBudgetSeparatorLine = new kony.ui.Label({
                "height": "70%",
                "id": "lblBudgetSeparatorLine",
                "isVisible": true,
                "right": "22.60%",
                "skin": "sknSeparatore3e3e3",
                "text": ".",
                "top": "20dp",
                "width": "2px",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCreateBudget = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddInternationalAccount\")"
                },
                "centerY": "50%",
                "height": "60dp",
                "id": "lblCreateBudget",
                "isVisible": true,
                "right": "10dp",
                "skin": "sknSSP4176a415px",
                "text": "Create Goal",
                "top": "50dp",
                "width": "17%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxCreateBudgetInfo.add(imgPotType, lblPotType, lblPotTypeDetails, lblBudgetSeparatorLine, lblCreateBudget);
            flxNoBudget.add(flxCreateBudgetInfo);
            flxNoBudgets.add(lblNoBudgetTitle, flxNoBudget);
            var flxNoBudgetsPermission = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "1dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxNoBudgetsPermission",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30px",
                "width": "98%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoBudgetsPermission.setDefaultUnit(kony.flex.DP);
            var lblNoBudgetTitlePermission = new kony.ui.Label({
                "id": "lblNoBudgetTitlePermission",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbl424242SSPReg17px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.myGoals\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCreateBudgetPermission = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": false,
                "height": "213dp",
                "id": "flxCreateBudgetPermission",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateBudgetPermission.setDefaultUnit(kony.flex.DP);
            var flxCreateBudgetInfoPermission = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "150dp",
                "id": "flxCreateBudgetInfoPermission",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateBudgetInfoPermission.setDefaultUnit(kony.flex.DP);
            var imgPotTypeBudgetPermission = new kony.ui.Image2({
                "centerY": "50%",
                "height": "100dp",
                "id": "imgPotTypeBudgetPermission",
                "isVisible": true,
                "left": "40dp",
                "skin": "slImage",
                "src": "wallet_icon.png",
                "top": "20dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoBudgetPermission = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxNoBudgetPermission",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "200dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "9dp",
                "width": "60%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoBudgetPermission.setDefaultUnit(kony.flex.DP);
            var imgBudgetInfo = new kony.ui.Image2({
                "centerY": "50%",
                "height": "35dp",
                "id": "imgBudgetInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0dp",
                "width": "35dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPotTypeBudgetPermission = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddInternationalAccount\")"
                },
                "height": "60dp",
                "id": "lblPotTypeBudgetPermission",
                "isVisible": true,
                "left": "50dp",
                "right": 24,
                "skin": "sknlblUserName",
                "text": "No Savings Budget created on this account. You don’t have permissions to create a one.",
                "top": "0dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxNoBudgetPermission.add(imgBudgetInfo, lblPotTypeBudgetPermission);
            flxCreateBudgetInfoPermission.add(imgPotTypeBudgetPermission, flxNoBudgetPermission);
            flxCreateBudgetPermission.add(flxCreateBudgetInfoPermission);
            flxNoBudgetsPermission.add(lblNoBudgetTitlePermission, flxCreateBudgetPermission);
            flxLeftContainer.add(flxSavingsPotClosedSuccess, flxSavingsPotBalanceDetails, flxCreateNewSavingsPotTablet, flxNoGoals, flxNoGoalNoPermission, flxSavingsPotSegmentContainer, flxNoBudgets, flxNoBudgetsPermission);
            var flxRightContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "6.04%",
                "skin": "slFbox",
                "top": "0px",
                "width": "28.40%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainer.setDefaultUnit(kony.flex.DP);
            var flxCreateNewSavingsPot = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCreateNewSavingsPot",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "72px",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateNewSavingsPot.setDefaultUnit(kony.flex.DP);
            var flxAction = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxAction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAction.setDefaultUnit(kony.flex.DP);
            var lblCreateNewSavingsPotDesktop = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddExternalAccount\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblCreateNewSavingsPotDesktop",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.createNewSavingsPot\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator3",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator3.setDefaultUnit(kony.flex.DP);
            flxSeperator3.add();
            flxAction.add(lblCreateNewSavingsPotDesktop, flxSeperator3);
            flxCreateNewSavingsPot.add(flxAction);
            var flxAdWrapper = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxAdWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "100%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdWrapper.setDefaultUnit(kony.flex.DP);
            var flxBannerWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxBannerWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBannerWrapper.setDefaultUnit(kony.flex.DP);
            var flxBannerImage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "90%",
                "id": "flxBannerImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10dp",
                "skin": "sknFlx727272Opacity70",
                "width": "95%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBannerImage.setDefaultUnit(kony.flex.DP);
            var imgBanner = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Marketing Image"
                },
                "height": "100%",
                "id": "imgBanner",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "nuo_banner_1.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBannerImage.add(imgBanner);
            var flxPagination = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "8%",
                "id": "flxPagination",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPagination.setDefaultUnit(kony.flex.DP);
            var imgPaginationOne = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Slider"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "4dp",
                "id": "imgPaginationOne",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "slider.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPagination.add(imgPaginationOne);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            flxBannerWrapper.add(flxBannerImage, flxPagination, flxSeparator);
            flxAdWrapper.add(flxBannerWrapper);
            flxRightContainer.add(flxCreateNewSavingsPot, flxAdWrapper);
            flxSavingsPotLanding.add(flxLeftContainer, flxRightContainer);
            flxSubMain.add(flxSavingsPotHeader, flxGoalCreationWarning, flxSavingsPotLanding);
            var flxAccountList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "80dp",
                "width": "320dp",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountList.setDefaultUnit(kony.flex.DP);
            var accountTypes = new com.InfinityOLB.WireTransfer.accountTypes({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountTypes",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 200,
                "appName": "WireTransferMA",
                "overrides": {
                    "accountTypes": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": true,
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%",
                        "zIndex": 200
                    },
                    "flxAccountTypesSegment": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "left": "0dp",
                        "top": "-18dp"
                    },
                    "imgToolTip": {
                        "isVisible": true,
                        "left": "200dp",
                        "right": "viz.val_cleared",
                        "src": "tool_tip.png"
                    },
                    "segAccountTypes": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "data": [{
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }, {
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }, {
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }, {
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }, {
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }, {
                            "lblSeparator": "Label",
                            "lblUsers": "Label"
                        }],
                        "maxHeight": "255dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAccountList.add(accountTypes);
            flxMain.add(flxSubMain, flxAccountList);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "16dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 800,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "isVisible": true
                    },
                    "lblCopyright": {
                        "left": "viz.val_cleared",
                        "top": "75dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50.00%",
                "height": "268dp",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "height": "268dp",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "imgCross": {
                        "height": "15dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxCloseSavingsGoalConfirmation = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "800dp",
                "id": "flxCloseSavingsGoalConfirmation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseSavingsGoalConfirmation.setDefaultUnit(kony.flex.DP);
            var deletePopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "deletePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "47%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "height": "268px",
                        "isVisible": true,
                        "minWidth": "viz.val_cleared",
                        "top": "300dp",
                        "width": "47%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "top": "viz.val_cleared"
                    },
                    "btnYes": {
                        "left": "viz.val_cleared",
                        "top": "viz.val_cleared"
                    },
                    "flxCross": {
                        "right": "23dp"
                    },
                    "imgCross": {
                        "bottom": "viz.val_cleared",
                        "centerX": "50%",
                        "centerY": "50%",
                        "height": "15dp",
                        "isVisible": false,
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "src": "bbcloseicon_1.png",
                        "top": "0dp"
                    },
                    "lblHeading": {
                        "left": "30dp",
                        "text": "Close Savings Goal"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")",
                        "left": "30dp"
                    },
                    "lblcross": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCloseSavingsGoalConfirmation.add(deletePopup);
            var flxCloseSavingsGoal = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "800dp",
                "id": "flxCloseSavingsGoal",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseSavingsGoal.setDefaultUnit(kony.flex.DP);
            var CustomPopupCancel = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopupCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "width": "40%"
                    },
                    "btnYes": {
                        "width": "40%"
                    },
                    "flxCross": {
                        "right": "20dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "left": "20dp"
                    },
                    "lblPopupMessage": {
                        "left": "20dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCloseSavingsGoal.add(CustomPopupCancel);
            flxDialogs.add(flxLogout, flxCloseSavingsGoalConfirmation, flxCloseSavingsGoal);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.imgMenu": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "My Savings Pot",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotHeader": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "8px"
                        },
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "lblMySavingsPot": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "s018b592f2be4ccf98f6e95b092c9c4c",
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxImgAccountTypeIcon": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "imgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "lblAccountTypes": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "imgAccountTypes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxGoalCreationWarning": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "left": {
                            "type": "string",
                            "value": "8px"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "imgGoalCreationWarning": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30px"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "lblGoalCreationWarning": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "sknLabelSSPFF000015Px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgCloseGoalCreationWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotLanding": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "8px"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotClosedSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "imgGoalClosedSuccess": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30px"
                        },
                        "src": "bulk_billpay_success_2.png",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "lblGoalClosedSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgGoalSuccessClose": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotBalanceDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalBalance": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalBalance": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalBalanceValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknLabel42424224pxSemiBold",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxHSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "32.80%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMyGoals": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "reverseLayoutDirection": false,
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "lblMyGoals": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblMyGoalsValue": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknLabel42424224pxSemiBold",
                        "text": "$723,500.00",
                        "segmentProps": []
                    },
                    "flxHSeparatorMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxMyBudgets": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "51%"
                        },
                        "right": {
                            "type": "string",
                            "value": "15px"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "lblMyBudgets": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "lblMyBudgetsValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknLabel42424224pxSemiBold",
                        "segmentProps": []
                    },
                    "flxCreateNewSavingsPotTablet": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxActionTablet": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "lblCreateNewSavingsPot": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a415px",
                        "segmentProps": []
                    },
                    "flxNoGoals": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "lblNoGoalTitle": {
                        "segmentProps": []
                    },
                    "flxCreateGoal": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreateInfo": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgPotType1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblPotType1Name": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblPotType1Description": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblSeparatorLine": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCreateGoal": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxNoGoalNoPermission": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "lblNoGoalTitlePermission": {
                        "segmentProps": []
                    },
                    "flxCreateGoalPermission": {
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreateGoalInfoPermission": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgGoalTypePermission": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoGoalPermission": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgGoalInfo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblGoalTypePermission": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotSegmentContainer": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "goalsAndBudgets.flxRowMobile": {
                        "centerX": {
                            "type": "string",
                            "value": "49.97%"
                        },
                        "segmentProps": []
                    },
                    "goalsAndBudgets.lblComponentTitle": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoBudgets": {
                        "centerX": {
                            "type": "string",
                            "value": "49.97%"
                        },
                        "segmentProps": []
                    },
                    "lblNoBudgetTitle": {
                        "segmentProps": []
                    },
                    "flxNoBudget": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreateBudgetInfo": {
                        "height": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgPotType": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblPotType": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblPotTypeDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblBudgetSeparatorLine": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCreateBudget": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxNoBudgetsPermission": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "49.97%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoBudgetTitlePermission": {
                        "segmentProps": []
                    },
                    "flxCreateBudgetPermission": {
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreateBudgetInfoPermission": {
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgPotTypeBudgetPermission": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoBudgetPermission": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgBudgetInfo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblPotTypeBudgetPermission": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "accountTypes": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "accountTypes.flxAccountTypesSegment": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "accountTypes.segAccountTypes": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "top": {
                            "type": "string",
                            "value": "198px"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "198px"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup.imgCross": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxCloseSavingsGoalConfirmation": {
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup.btnNo": {
                        "left": {
                            "type": "string",
                            "value": "52%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "43%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "43%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup.flxCross": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletePopup.imgCross": {
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "deletePopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup.lblcross": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxCloseSavingsGoal": {
                        "height": {
                            "type": "string",
                            "value": "2000dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "178dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "178dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.flxCross": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "flxSavingsPotHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "segmentProps": []
                    },
                    "flxImgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "imgAccountTypeIcon": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxGoalCreationWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgGoalCreationWarning": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblGoalCreationWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "sknLabelSSPFF000015Px",
                        "segmentProps": []
                    },
                    "imgCloseGoalCreationWarning": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotLanding": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotClosedSuccess": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgGoalClosedSuccess": {
                        "height": {
                            "type": "string",
                            "value": "30px"
                        },
                        "src": "bulk_billpay_success_2.png",
                        "width": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "lblGoalClosedSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "imgGoalSuccessClose": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalBalance": {
                        "segmentProps": []
                    },
                    "lblTotalBalanceValue": {
                        "skin": "sknLabel42424224pxSemiBold",
                        "segmentProps": []
                    },
                    "lblMyGoalsValue": {
                        "skin": "sknLabel42424224pxSemiBold",
                        "segmentProps": []
                    },
                    "flxHSeparatorMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblMyBudgetsValue": {
                        "skin": "sknLabel42424224pxSemiBold",
                        "text": "$72,500.00",
                        "segmentProps": []
                    },
                    "flxCreateNewSavingsPotTablet": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "230px"
                        },
                        "segmentProps": []
                    },
                    "lblCreateNewSavingsPot": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    },
                    "flxNoGoals": {
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoGoalTitle": {
                        "segmentProps": []
                    },
                    "flxCreateGoal": {
                        "segmentProps": []
                    },
                    "lblPotType1Name": {
                        "segmentProps": []
                    },
                    "lblPotType1Description": {
                        "segmentProps": []
                    },
                    "lblCreateGoal": {
                        "segmentProps": []
                    },
                    "flxNoGoalNoPermission": {
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoGoalTitlePermission": {
                        "segmentProps": []
                    },
                    "flxCreateGoalPermission": {
                        "segmentProps": []
                    },
                    "lblGoalTypePermission": {
                        "segmentProps": []
                    },
                    "flxSavingsPotSegmentContainer": {
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "goalsAndBudgets.flxRow": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "goalsAndBudgets.flxRowMobile": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "goalsAndBudgets.lblComponentTitle": {
                        "segmentProps": []
                    },
                    "flxNoBudgets": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoBudgetTitle": {
                        "segmentProps": []
                    },
                    "flxNoBudget": {
                        "segmentProps": []
                    },
                    "lblPotType": {
                        "width": {
                            "type": "string",
                            "value": "48%"
                        },
                        "segmentProps": []
                    },
                    "lblPotTypeDetails": {
                        "segmentProps": []
                    },
                    "lblCreateBudget": {
                        "segmentProps": []
                    },
                    "flxNoBudgetsPermission": {
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoBudgetTitlePermission": {
                        "segmentProps": []
                    },
                    "flxCreateBudgetPermission": {
                        "segmentProps": []
                    },
                    "lblPotTypeBudgetPermission": {
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "accountTypes": {
                        "segmentProps": []
                    },
                    "accountTypes.segAccountTypes": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "8.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "130%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseSavingsGoalConfirmation": {
                        "height": {
                            "type": "string",
                            "value": "130%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "segmentProps": []
                    },
                    "flxCloseSavingsGoal": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.flxCross": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.imgCross": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotHeader": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "24px"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "segmentProps": [],
                        "focusSkin": "",
                        "hoverSkin": ""
                    },
                    "flxImgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "imgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "flxGoalCreationWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "imgGoalCreationWarning": {
                        "height": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "lblGoalCreationWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "string",
                            "value": "18px"
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "skin": "sknLabelSSPFF000015Px",
                        "segmentProps": []
                    },
                    "flxSavingsPotLanding": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "58.10%"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotClosedSuccess": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgGoalClosedSuccess": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "src": "bulk_billpay_success_2.png",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblGoalClosedSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "imgGoalSuccessClose": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotBalanceDetails": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxHSeparatorMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblMyBudgetsValue": {
                        "skin": "sknSSP42424224Px",
                        "segmentProps": []
                    },
                    "flxCreateNewSavingsPotTablet": {
                        "isVisible": false,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopyflxSeperator0ebca344f74b949": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoGoals": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoGoalTitle": {
                        "segmentProps": []
                    },
                    "lblPotType1Name": {
                        "segmentProps": []
                    },
                    "lblPotType1Description": {
                        "segmentProps": []
                    },
                    "lblCreateGoal": {
                        "segmentProps": []
                    },
                    "flxNoGoalNoPermission": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoGoalTitlePermission": {
                        "segmentProps": []
                    },
                    "lblGoalTypePermission": {
                        "segmentProps": []
                    },
                    "flxSavingsPotSegmentContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "goalsAndBudgets.CopyLabel0abe0e6915db543": {
                        "text": "$90,000.00",
                        "segmentProps": []
                    },
                    "goalsAndBudgets.flxRow": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxNoBudgets": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxNoBudget": {
                        "segmentProps": []
                    },
                    "lblPotType": {
                        "segmentProps": []
                    },
                    "lblPotTypeDetails": {
                        "segmentProps": []
                    },
                    "lblCreateBudget": {
                        "segmentProps": []
                    },
                    "flxNoBudgetsPermission": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoBudgetTitlePermission": {
                        "segmentProps": []
                    },
                    "lblPotTypeBudgetPermission": {
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxCreateNewSavingsPot": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator3": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxAdWrapper": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "accountTypes": {
                        "segmentProps": []
                    },
                    "accountTypes.flxAccountTypesSegment": {
                        "segmentProps": []
                    },
                    "accountTypes.segAccountTypes": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "8.06%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "top": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseSavingsGoalConfirmation": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "deletePopup.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "top": {
                            "type": "string",
                            "value": "170px"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "170px"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseSavingsGoal": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotHeader": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "26px"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "segmentProps": []
                    },
                    "flxGoalCreationWarning": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200px"
                        },
                        "segmentProps": []
                    },
                    "imgGoalCreationWarning": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblGoalCreationWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "sknLabelSSPFF000015Px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgCloseGoalCreationWarning": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSavingsPotLanding": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotClosedSuccess": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgGoalClosedSuccess": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "src": "bulk_billpay_success_2.png",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblGoalClosedSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20px"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "imgGoalSuccessClose": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSavingsPotBalanceDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxHSeperator": {
                        "segmentProps": []
                    },
                    "flxMyGoals": {
                        "segmentProps": []
                    },
                    "flxHSeparatorMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCreateNewSavingsPotTablet": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxNoGoals": {
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoGoalTitle": {
                        "segmentProps": []
                    },
                    "flxCreateGoal": {
                        "segmentProps": []
                    },
                    "lblPotType1Name": {
                        "segmentProps": []
                    },
                    "lblPotType1Description": {
                        "segmentProps": []
                    },
                    "lblSeparatorLine": {
                        "segmentProps": []
                    },
                    "lblCreateGoal": {
                        "segmentProps": []
                    },
                    "flxNoGoalNoPermission": {
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoGoalTitlePermission": {
                        "segmentProps": []
                    },
                    "flxCreateGoalPermission": {
                        "segmentProps": []
                    },
                    "lblGoalTypePermission": {
                        "segmentProps": []
                    },
                    "flxSavingsPotSegmentContainer": {
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "goalsAndBudgets.flxRow": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxNoBudgets": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoBudgetTitle": {
                        "segmentProps": []
                    },
                    "flxNoBudget": {
                        "segmentProps": []
                    },
                    "lblPotType": {
                        "segmentProps": []
                    },
                    "lblPotTypeDetails": {
                        "segmentProps": []
                    },
                    "lblBudgetSeparatorLine": {
                        "segmentProps": []
                    },
                    "lblCreateBudget": {
                        "segmentProps": []
                    },
                    "flxNoBudgetsPermission": {
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblNoBudgetTitlePermission": {
                        "segmentProps": []
                    },
                    "flxCreateBudgetPermission": {
                        "segmentProps": []
                    },
                    "lblPotTypeBudgetPermission": {
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxCreateNewSavingsPot": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxAdWrapper": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "accountTypes": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "8.07%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "top": {
                            "type": "string",
                            "value": "170px"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "top": {
                            "type": "string",
                            "value": "170px"
                        },
                        "segmentProps": []
                    },
                    "flxCloseSavingsGoalConfirmation": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "height": {
                            "type": "string",
                            "value": "268dp"
                        },
                        "segmentProps": []
                    },
                    "deletePopup.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "top": {
                            "type": "string",
                            "value": "198px"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "198px"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseSavingsGoal": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgMenu": {
                    "left": "6.07%",
                    "src": "menu_icon.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "goalsAndBudgets.CopyLabel0abe0e6915db543": {
                    "text": "$90,000.00"
                },
                "goalsAndBudgets.CopyLabel0ce9f275e077042": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "goalsAndBudgets.flxRow": {
                    "bottom": "0dp",
                    "top": "60dp",
                    "width": "98%"
                },
                "goalsAndBudgets.flxRowMobile": {
                    "centerX": "49.97%",
                    "width": "98%"
                },
                "goalsAndBudgets.imgStatusIcon": {
                    "left": "10dp",
                    "src": "aa_password_error.png"
                },
                "goalsAndBudgets.imgStatusMobile": {
                    "src": "aa_password_error.png"
                },
                "goalsAndBudgets.lblComponentTitle": {
                    "left": "0%",
                    "top": "20dp"
                },
                "goalsAndBudgets.lblTitle": {
                    "left": "40dp"
                },
                "goalsAndBudgets": {
                    "top": "0dp"
                },
                "accountTypes": {
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%",
                    "zIndex": 200
                },
                "accountTypes.flxAccountTypesSegment": {
                    "left": "0dp",
                    "top": "-18dp"
                },
                "accountTypes.imgToolTip": {
                    "left": "200dp",
                    "right": "",
                    "src": "tool_tip.png"
                },
                "accountTypes.segAccountTypes": {
                    "data": [{
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }, {
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }, {
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }, {
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }, {
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }, {
                        "lblSeparator": "Label",
                        "lblUsers": "Label"
                    }],
                    "maxHeight": "255dp"
                },
                "customfooter.lblCopyright": {
                    "left": "",
                    "top": "75dp"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "height": "268dp",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.imgCross": {
                    "height": "15dp"
                },
                "deletePopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "height": "268px",
                    "minWidth": "",
                    "top": "300dp",
                    "width": "47%",
                    "zIndex": 1100
                },
                "deletePopup.btnNo": {
                    "top": ""
                },
                "deletePopup.btnYes": {
                    "left": "",
                    "top": ""
                },
                "deletePopup.flxCross": {
                    "right": "23dp"
                },
                "deletePopup.imgCross": {
                    "bottom": "",
                    "centerX": "50%",
                    "centerY": "50%",
                    "height": "15dp",
                    "left": "0dp",
                    "right": "",
                    "src": "bbcloseicon_1.png",
                    "top": "0dp"
                },
                "deletePopup.lblHeading": {
                    "left": "30dp",
                    "text": "Close Savings Goal"
                },
                "deletePopup.lblPopupMessage": {
                    "left": "30dp"
                },
                "deletePopup.lblcross": {
                    "centerX": "50%",
                    "left": "",
                    "right": ""
                },
                "CustomPopupCancel": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopupCancel.btnNo": {
                    "width": "40%"
                },
                "CustomPopupCancel.btnYes": {
                    "width": "40%"
                },
                "CustomPopupCancel.flxCross": {
                    "right": "20dp"
                },
                "CustomPopupCancel.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                },
                "CustomPopupCancel.lblHeading": {
                    "left": "20dp"
                },
                "CustomPopupCancel.lblPopupMessage": {
                    "left": "20dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmSavingsPotLanding,
            "enabledForIdleTimeout": true,
            "id": "frmSavingsPotLanding",
            "init": controller.AS_Form_def892fd5fa1408585ef4f5b71a9b850,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "SavingsPotMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": true
        }]
    }
});