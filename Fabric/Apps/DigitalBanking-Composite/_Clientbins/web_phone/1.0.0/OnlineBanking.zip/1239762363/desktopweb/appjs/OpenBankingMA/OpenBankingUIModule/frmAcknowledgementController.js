define("OpenBankingMA/OpenBankingUIModule/userfrmAcknowledgementController", ['CommonUtilities', 'OLBConstants', 'FormControllerUtility', 'ViewConstants', 'CampaignUtility'], function(CommonUtilities, OLBConstants, FormControllerUtility, ViewConstants, CampaignUtility) {
    return {
        navigationData: "",
        tppConstants: {
            SERVERERROR: "ServerError",
            APPROVED: "Approved",
            DENIED: "Denied",
            ONCE: "Once"
        },
        /**
         * @function : onNavigate
         * @description : gets invoked as soon as the control comes to the form
         * @return : NA
         */
        onNavigate: function(param) {
            this.navigationData = param;
        },
        /**
         * @function : preShowAuthConsentAck
         * @description : Gets invoked on frmAcknowledgement form preshow event
         */
        preShowAuthConsentAck: function() {
            this.view.btnContinue.onClick = this.onClickContinue;
            if (this.navigationData && this.navigationData.consentStatus && this.navigationData.consentStatus === this.tppConstants.APPROVED) {
                this.view.imgGreenTick.src = "successful.png";
                this.view.lblSuccessMessage.text = this.navigationData.message ? this.navigationData.message : "";
                this.view.lblRedirectInfo.text = "Redirecting back to TeePee";
            } else if (this.navigationData && this.navigationData.consentStatus && this.navigationData.consentStatus === this.tppConstants.DENIED) {
                this.view.imgGreenTick.src = "alert_new.png";
                this.view.lblSuccessMessage.text = this.navigationData.message ? this.navigationData.message : "";
                this.view.lblRedirectInfo.text = "No information will be shared with TeePee";
            } else if (this.navigationData && this.navigationData.consentStatus && this.navigationData.consentStatus === this.tppConstants.SERVERERROR) {
                this.view.imgGreenTick.src = "failure.png";
                this.view.lblSuccessMessage.text = this.navigationData.message ? this.navigationData.message : "";
                this.view.lblRedirectInfo.text = "No information will be shared with TeePee";
            }
            const configManager = applicationManager.getConfigurationManager();
            var timer = configManager.getTppNavigationTimer();
            if (timer === "" || kony.sdk.isNullOrUndefined(timer)) timer = 5;
            this.view.lblBackTotppMsg.text = kony.i18n.getLocalizedString("i18n.tppconsent.navigationMsg") + " " + timer + " " + kony.i18n.getLocalizedString("i18n.wealth.seconds");
            this.navigateToThirdPartyWebapp();
        },
        /** 
         * This method is to navigate back to the third party url.
         */
        navigateToThirdPartyWebapp: function() {
            const configManager = applicationManager.getConfigurationManager();
            var timer = configManager.getTppNavigationTimer();
            if (timer === "" || kony.sdk.isNullOrUndefined(timer)) timer = 5;
            let timerInMilliseconds = timer * 1000;
            setTimeout(this.onClickContinue, timerInMilliseconds);
            //kony.timer.schedule("timer3", this.onClickContinue, timer, false);
        },
        /**
         * @function : onClickContinue
         * @description : Gets invoked on click of continue
         */
        onClickContinue: function() {
            let openBankingModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                "moduleName": "OpenBankingUIModule",
                "appName": "OpenBankingMA"
            });
            openBankingModule.presentationController.redirectToPostConsentURL(this.navigationData.consentStatus, "AISP");
        }
    };
});
define("OpenBankingMA/OpenBankingUIModule/frmAcknowledgementControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for frmAcknowledgement **/
    AS_Form_eb1f947653e845ac96f227cb4f4c68ca: function AS_Form_eb1f947653e845ac96f227cb4f4c68ca(eventobject) {
        var self = this;
        return self.preShowAuthConsentAck.call(this);
    }
});
define("OpenBankingMA/OpenBankingUIModule/frmAcknowledgementController", ["OpenBankingMA/OpenBankingUIModule/userfrmAcknowledgementController", "OpenBankingMA/OpenBankingUIModule/frmAcknowledgementControllerActions"], function() {
    var controller = require("OpenBankingMA/OpenBankingUIModule/userfrmAcknowledgementController");
    var controllerActions = ["OpenBankingMA/OpenBankingUIModule/frmAcknowledgementControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
