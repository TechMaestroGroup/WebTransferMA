define("AuthenticationMA/AuthUIModule/frmEmbedOrigination", function() {
    return function(controller) {
        function addWidgetsfrmEmbedOrigination() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "120px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheader": {
                        "height": "120px"
                    },
                    "flxTopmenu": {
                        "isVisible": true
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader);
            var flxScrollContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "70%",
                "horizontalScrollIndicator": true,
                "id": "flxScrollContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollContent.setDefaultUnit(kony.flex.DP);
            var customIframe = new com.temenos.Resources.customIframe({
                "height": "100%",
                "id": "customIframe",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "customIframe",
                "overrides": {
                    "customIframe": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {
                    "custmIframe": {
                        "webURL": "https://teminfinityqa3.temenos-cloud.net/apps/OnlineBanking/#/AuthenticationMA/frmLogin"
                    }
                }
            });
            var customIframe_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmEmbedOrigination"] && appConfig.componentMetadata["ResourcesMA"]["frmEmbedOrigination"]["customIframe"]) || {};
            flxScrollContent.add(customIframe);
            var flxFooterContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooterContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterContainer.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            customfooter.btnContactUs.onClick = controller.AS_Button_i7b1e630e0df45a18290b104341db3ea;
            customfooter.btnFaqs.onClick = controller.AS_Button_eb139130b0d2447eb99688b53295cced;
            customfooter.btnLocateUs.onClick = controller.AS_Button_e8d5d3b5b5884ff79d83dcd8118c5dfc;
            customfooter.btnPrivacy.onClick = controller.AS_Button_e368251b7681494d88096a1a3c1622ef;
            customfooter.btnTermsAndConditions.onClick = controller.AS_Button_a60336b951bd4ae98578fdd1fa9e4a26;
            flxFooterContainer.add(customfooter);
            flxMainContainer.add(flxHeader, flxScrollContent, flxFooterContainer);
            var flxConfirmationpopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxConfirmationpopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmationpopup.setDefaultUnit(kony.flex.DP);
            var confirmationPopUp = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "confirmationPopUp",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "70%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "70%",
                        "zIndex": 1100
                    },
                    "btnYes": {
                        "isVisible": true,
                        "left": "viz.val_cleared"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                    },
                    "lblPopupMessage": {
                        "text": "Are you sure you want to close this application process?"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            confirmationPopUp.btnNo.onClick = controller.AS_Button_fb1c16e39b5d4b85a5256d0d34551247;
            confirmationPopUp.btnYes.onClick = controller.AS_Button_c15eade7c6934d27876cb93d586bfe6f;
            confirmationPopUp.flxCross.onClick = controller.AS_Button_eb919f04ae7f4b9a876e57a05fe8901a;
            flxConfirmationpopup.add(confirmationPopUp);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheader": {
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxTopmenu": {
                        "segmentProps": []
                    },
                    "confirmationPopUp": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "confirmationPopUp.btnNo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.no",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "confirmationPopUp.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.yes",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "confirmationPopUp.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "confirmationPopUp.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader": {
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "confirmationPopUp": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "confirmationPopUp.btnNo": {
                        "i18n_text": "i18n.common.no",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "text": "No",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmationPopUp.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.common.yes",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Yes",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader": {
                        "segmentProps": [],
                        "instanceId": "customheader"
                    }
                }
            }
            this.compInstData = {
                "customheader": {
                    "height": "120px"
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customIframe": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "confirmationPopUp": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "70%",
                    "zIndex": 1100
                },
                "confirmationPopUp.btnYes": {
                    "left": ""
                },
                "confirmationPopUp.lblPopupMessage": {
                    "text": "Are you sure you want to close this application process?"
                }
            }
            this.add(flxMainContainer, flxConfirmationpopup);
        };
        return [{
            "addWidgets": addWidgetsfrmEmbedOrigination,
            "enabledForIdleTimeout": false,
            "id": "frmEmbedOrigination",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_h0526d3bfff34533980caa363a5c04d0,
            "preShow": function(eventobject) {
                controller.AS_Form_id14bf33104c4a1d95f1210ae1f15fe2(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AuthenticationMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});