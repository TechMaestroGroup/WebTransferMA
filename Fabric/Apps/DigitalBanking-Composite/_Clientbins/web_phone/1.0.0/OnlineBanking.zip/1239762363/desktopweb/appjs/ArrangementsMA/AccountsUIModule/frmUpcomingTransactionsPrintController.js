define("ArrangementsMA/AccountsUIModule/userfrmUpcomingTransactionsPrintController", [], function() {
    let previousForm;
    let printData;
    let navMan;
    let NA = kony.i18n.getLocalizedString("i18n.payments.nA");
    return {
        /** 
         * @api : onNavigate 
         * Will trigger when navigating from other form to this form 
         * @return : NA 
         */
        onNavigate: function() {
            var scope = this;
            try {
                navMan = applicationManager.getNavigationManager();
                printData = navMan.getCustomInfo("frmUpcomingTransactionsPrintData");
                previousForm = printData.previousFormName;
                scope.view.preShow = scope.preShow;
                scope.view.postShow = scope.postShow;
            } catch (err) {
                var errorObj = {
                    "method": "onNavigate",
                    "error": err
                };
                scope.onError(errorObj);
            }
        },
        /** 
         * @api : preShow 
         * Will trigger before loading UI 
         * @return : NA 
         */
        preShow: function() {
            var scope = this;
            try {
                var userDetails = applicationManager.getUserPreferencesManager().userObj[0];
                var addressDetails = (userDetails && userDetails.Addresses && userDetails.Addresses[0]) || NA;
                scope.view.lblAccNameValue.text = printData.AccountName || NA;
                scope.view.lblPhoneNumberValue.text = userDetails.phone.replace("-", " ") || NA;
                scope.view.lblAccNumberValue.text = printData.AccountNumber || NA;
                scope.view.lblEmailValue.text = userDetails.email || NA;
                scope.view.lblCurrencyValue.text = printData.currency || NA;
                scope.view.lblBranchValue.text = printData.previousFormData.bankName || NA;
                scope.view.lblNote.text = `${kony.i18n.getLocalizedString("i18n.PayAPerson.Note")} ${kony.i18n.getLocalizedString("i18n.Accounts.upcomingTransactionsPrintNote")}`;
                scope.view.lblAddressValue.text = addressDetails == NA ? NA : `${addressDetails.AddressLine1},${addressDetails.CityName}, ${addressDetails.ZipCode}`;
                scope.view.lblPhoneNumber.text = `${kony.i18n.getLocalizedString("kony.mb.consent.phone")}:`;
                scope.view.lblDateRangeValue.text = printData.dateRange || NA;
                scope.setSegTransactionsListData(printData.listingData);
            } catch (err) {
                var errorObj = {
                    "method": "preShow",
                    "error": err
                };
                scope.onError(errorObj);
            }
        },
        /** 
         * @api : postShow 
         * Will trigger when UI is loaded 
         * @return : NA 
         */
        postShow: function() {
            var scope = this;
            try {
                kony.os.print();
                //timeout is required to allow print popup to be visible. 
                setTimeout(function() {
                    scope.afterPrintCallback();
                }, "17ms");
            } catch (err) {
                var errorObj = {
                    "method": "postShow",
                    "error": err
                };
                scope.onError(errorObj);
            }
        },
        /** 
         * @api : afterPrintCallback 
         * It will help user to navigate back from print 
         * @return : NA 
         */
        afterPrintCallback: function() {
            var scope = this;
            try {
                new kony.mvc.Navigation({
                    "appName": "ArrangementsMA",
                    "friendlyName": `AccountsUIModule/${previousForm}`
                }).navigate(printData.previousFormData);
            } catch (err) {
                var errorObj = {
                    "method": "afterPrintCallback",
                    "error": err
                };
                scope.onError(errorObj);
            }
        },
        /** 
         * @api : setSegTransactionsListData 
         * method to add upcoming transactions data to the segment
         * @return : NA 
         */
        setSegTransactionsListData: function(upcomingTransactions) {
            var scope = this;
            try {
                var formatUtil = applicationManager.getFormatUtilManager();
                var dataMap = {
                    "flxPrintTransaction": "flxPrintTransaction",
                    "lblAmount": "lblAmount",
                    "lblBalance": "lblBalance",
                    "lblCategory": "lblCategory",
                    "lblDate": "lblDate",
                    "lblDescription": "lblDescription",
                    "lblSeparator": "lblSeparator",
                    "lblType": "lblType"
                };
                scope.view.segUpcomingTransactions.widgetDataMap = dataMap;
                var data = upcomingTransactions.map(function(res) {
                    var amount = formatUtil.formatAmountandAppendCurrencySymbol(res.amount, res.transactionCurrency ? res.transactionCurrency : printData.currency);
                    var scheduledDate = formatUtil.getDMYFormattedSelectedDate(formatUtil.getDateObjectfromString(res.scheduledDate));
                    return {
                        "lblDate": {
                            "text": scheduledDate,
                            "skin": "ICSknLbl42424218PX",
                            "width": "12%",
                            "left": "0%"
                        },
                        "lblDescription": {
                            "text": res.toAccountName,
                            "skin": "ICSknLbl42424218PX",
                            "width": "50%",
                            "contentAlignment": "middleleft"
                        },
                        "lblType": {
                            "text": res.transactionType,
                            "skin": "ICSknLbl42424218PX",
                            "width": "10%"
                        },
                        "lblAmount": {
                            "text": amount,
                            "skin": "ICSknLbl42424218PX",
                            "right": "16.5%",
                            "isVisible": true
                        },
                        "lblCategory": {
                            "isVisible": false
                        },
                        "lblBalance": {
                            "isVisible": false
                        },
                        "lblSeparator": {
                            "isVisible": false
                        },
                        "flxPrintTransaction": {
                            "skin": "slFbox"
                        }
                    }
                });
                this.view.segUpcomingTransactions.setData(data);
            } catch (err) {
                var errorObj = {
                    "method": "setSegTransactionsListData",
                    "error": err
                };
                scope.onError(errorObj);
            }
        },
        /**
         * @api : onError
         * Error thrown from catch block in component and shown on the form
         * @return : NA
         */
        onError: function(err) {
            var errMsg = JSON.stringify(err);
            // kony.ui.Alert(errMsg);
        }
    };
});
define("ArrangementsMA/AccountsUIModule/frmUpcomingTransactionsPrintControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("ArrangementsMA/AccountsUIModule/frmUpcomingTransactionsPrintController", ["ArrangementsMA/AccountsUIModule/userfrmUpcomingTransactionsPrintController", "ArrangementsMA/AccountsUIModule/frmUpcomingTransactionsPrintControllerActions"], function() {
    var controller = require("ArrangementsMA/AccountsUIModule/userfrmUpcomingTransactionsPrintController");
    var controllerActions = ["ArrangementsMA/AccountsUIModule/frmUpcomingTransactionsPrintControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
