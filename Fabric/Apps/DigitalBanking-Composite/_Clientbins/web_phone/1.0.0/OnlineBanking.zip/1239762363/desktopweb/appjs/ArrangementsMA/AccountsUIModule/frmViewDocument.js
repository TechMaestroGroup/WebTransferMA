define("ArrangementsMA/AccountsUIModule/frmViewDocument", function() {
    return function(controller) {
        function addWidgetsfrmViewDocument() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMainScroll = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMainScroll",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainScroll.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121dp",
                "id": "customheader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "FlexContainer0e2898aa93bca45": {
                        "isVisible": true
                    },
                    "customheader": {
                        "isVisible": false,
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxTopmenu": {
                        "height": "51dp",
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "headermenu": {
                        "isVisible": true
                    },
                    "imgKony": {
                        "isVisible": true
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "lblName": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Loggedinas\")"
                    },
                    "lblUserEmail1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.usernamekonycom\")"
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxFeedbackimg": {
                        "left": "viz.val_cleared"
                    },
                    "topmenu.flxHelp": {
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.lblFeedback": {
                        "right": "20dp"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "text": "Account Details"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader, customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "120dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxDocument = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxDocument",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "23dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocument.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "focusSkin": "flxHoverSkinPointer",
                "height": "100%",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "360dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblDocumentTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "View Documents",
                    "tagName": "h1"
                },
                "centerY": "50%",
                "id": "lblDocumentTitle",
                "isVisible": true,
                "left": "0px",
                "skin": "bblblskn424242Bold",
                "text": "View Documents",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitle.add(lblDocumentTitle);
            flxDocument.add(flxTitle);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90px",
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "87.84%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgFailedIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "50dp",
                "id": "imgFailedIcon",
                "isVisible": true,
                "left": "0dp",
                "src": "failed_icon.png",
                "top": "20px",
                "width": "8%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblErrorMessage",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLabel42424224px",
                "text": "Unable to download “Registration Certificate.pdf” at the moment. Please try again after sometime.",
                "top": "30px",
                "width": "84.04%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCrossIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "20px",
                "id": "lblCrossIcon",
                "isVisible": true,
                "left": "50px",
                "skin": "sknOlbFonts0273e3",
                "text": "g",
                "top": "18px",
                "width": "20px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(imgFailedIcon, lblErrorMessage, lblCrossIcon);
            var flxDocumentsList = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentsList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "24dp",
                "width": "90%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentsList.setDefaultUnit(kony.flex.DP);
            var flxSelectAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "65dp",
                "id": "flxSelectAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "top": "30dp",
                "width": "60%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAccount.setDefaultUnit(kony.flex.DP);
            var lblSelectAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblSelectAccount",
                "isVisible": true,
                "left": 0,
                "skin": "ICSknLblSSP72727215px",
                "text": "Select Account:",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxListOfAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxListOfAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "25dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListOfAccounts.setDefaultUnit(kony.flex.DP);
            var lblChooseAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblChooseAccount",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknBBLabelSSPSB42424216px",
                "text": "Select Account",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": true
            }, {});
            var flxDropDown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "clipBounds": false,
                "height": "22dp",
                "id": "flxDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "16dp",
                "top": "0dp",
                "width": "22dp",
                "zIndex": 10,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDown.setDefaultUnit(kony.flex.DP);
            var lblDropDown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblDropDown",
                "isVisible": true,
                "left": "0",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "top": "0",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDown.add(lblDropDown);
            flxListOfAccounts.add(lblChooseAccount, flxDropDown);
            var lstSelectAccount = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "40dp",
                "id": "lstSelectAccount",
                "isVisible": false,
                "left": 0,
                "masterData": [
                    ["Key2433609295", "Mortagage Facility 1...345"],
                    ["Key303735171", "Mortagage Facility 1...345"]
                ],
                "selectedKey": "Key2433609295",
                "top": "25dp",
                "width": "59.74%",
                "zIndex": 5,
                "blur": {
                    "enabled": false,
                    "value": 0
                }
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var flxMortagageAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMortagageAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopysknFlxscrollffffffShadowdddcdc0hba5bd51174f43",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortagageAccounts.setDefaultUnit(kony.flex.DP);
            var segMortgageAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "data": [
                    [{
                            "lblTransactionHeader": "kony.i18n.getLocalizedString(\"i18n.NUO.SavingsAccount\")"
                        },
                        [{}, {}, {}, {}]
                    ]
                ],
                "groupCells": false,
                "id": "segMortgageAccounts",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxTransfersFrom"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxTransfersFromHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 5,
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMortagageAccounts.add(segMortgageAccounts);
            flxSelectAccount.add(lblSelectAccount, flxListOfAccounts, lstSelectAccount, flxMortagageAccounts);
            var flxSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSearch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "83%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var flxSearchBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSearchBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchBox.setDefaultUnit(kony.flex.DP);
            var lblSearchIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "25dp",
                "id": "lblSearchIcon",
                "isVisible": true,
                "left": "1.03%",
                "skin": "ICSknlblSearchfonticon19px0273e3",
                "text": "e",
                "top": "13dp",
                "width": "25dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchBox.add(lblSearchIcon);
            var txtSearchBox = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "autocomplete": "off",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "height": "50dp",
                "id": "txtSearchBox",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": 0,
                "placeholder": "Search by Keywords",
                "secureTextEntry": false,
                "skin": "tbxPlaceholderskna0a0a015px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [45, 15, 10, 16],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxClearSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Clear text"
                },
                "centerY": "50%",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxClearSearch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "top": "0",
                "width": "5%",
                "zIndex": 2,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClearSearch.setDefaultUnit(kony.flex.DP);
            var lblClearSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblClearSearch",
                "isVisible": true,
                "left": "3%",
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClearSearch.add(lblClearSearch);
            flxSearch.add(flxSearchBox, txtSearchBox, flxClearSearch);
            var flxSelectionInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "70dp",
                "id": "flxSelectionInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.20%",
                "isModalContainer": false,
                "skin": "ICSknFlxE3E3E3Border",
                "top": "20dp",
                "width": "83%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectionInfo.setDefaultUnit(kony.flex.DP);
            var flxMessageInfo = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "80%",
                "id": "flxMessageInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "88.29%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageInfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "1.46%",
                "src": "info_blue.png",
                "top": "15dp",
                "width": "3.23%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMessageInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblMessageInfo",
                "isVisible": true,
                "left": "1.46%",
                "skin": "sknBBLabelSSPSB42424216px",
                "text": "Please bear in mind that your documents may contain personal information, please keep them safe if you chose to open or download any of them.",
                "top": "19dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMessageInfo.add(imgInfo, lblMessageInfo);
            flxSelectionInfo.add(flxMessageInfo);
            var flxListOfDocuments = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxListOfDocuments",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "20dp",
                "width": "83%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListOfDocuments.setDefaultUnit(kony.flex.DP);
            var segListOfDocuments = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgDownload": "download.png",
                    "imgFileType": "pdf_image.png",
                    "lblDownload": "kony.i18n.getLocalizedString(\"i18n.olb.ViewStatementDownload\")",
                    "lblGeneratedOnDate": "Label",
                    "lbnFileName": "Registration Certificate.pdf"
                }, {
                    "imgDownload": "download.png",
                    "imgFileType": "pdf_image.png",
                    "lblDownload": "kony.i18n.getLocalizedString(\"i18n.olb.ViewStatementDownload\")",
                    "lblGeneratedOnDate": "Label",
                    "lbnFileName": "Registration Certificate.pdf"
                }, {
                    "imgDownload": "download.png",
                    "imgFileType": "pdf_image.png",
                    "lblDownload": "kony.i18n.getLocalizedString(\"i18n.olb.ViewStatementDownload\")",
                    "lblGeneratedOnDate": "Label",
                    "lbnFileName": "Registration Certificate.pdf"
                }, {
                    "imgDownload": "download.png",
                    "imgFileType": "pdf_image.png",
                    "lblDownload": "kony.i18n.getLocalizedString(\"i18n.olb.ViewStatementDownload\")",
                    "lblGeneratedOnDate": "Label",
                    "lbnFileName": "Registration Certificate.pdf"
                }],
                "groupCells": false,
                "id": "segListOfDocuments",
                "isVisible": true,
                "left": 0,
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxFileDownload"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": 0,
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDownload": "flxDownload",
                    "flxFileDownload": "flxFileDownload",
                    "flxFileType": "flxFileType",
                    "flxMainWrapper": "flxMainWrapper",
                    "flxSeparator": "flxSeparator",
                    "imgDownload": "imgDownload",
                    "imgFileType": "imgFileType",
                    "lblDownload": "lblDownload",
                    "lblGeneratedOnDate": "lblGeneratedOnDate",
                    "lbnFileName": "lbnFileName"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxListOfDocuments.add(segListOfDocuments);
            var flxNoDocuments = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxNoDocuments",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoDocuments.setDefaultUnit(kony.flex.DP);
            var imgNodocumentInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "150dp",
                "id": "imgNodocumentInfo",
                "isVisible": true,
                "left": "0dp",
                "src": "info_large.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoDocument = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblNoDocument",
                "isVisible": true,
                "left": "0dp",
                "text": "No Documents Found",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoDocuments.add(imgNodocumentInfo, lblNoDocument);
            flxDocumentsList.add(flxSelectAccount, flxSearch, flxSelectionInfo, flxListOfDocuments, flxNoDocuments);
            flxMain.add(flxDocument, flxErrorMessage, flxDocumentsList);
            var flxFooter = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "800dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "height": "150dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxMainScroll.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxCross1": {
                        "right": "11dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon_1.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.customhamburger": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.customhamburger.flxMenuWrapper": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.imgMenu": {
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Documents",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDocument": {
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "s018b592f2be4ccf98f6e95b092c9c4c",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblDocumentTitle": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "segmentProps": []
                    },
                    "flxDocumentsList": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "407dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.74%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectAccount": {
                        "height": {
                            "type": "string",
                            "value": "63px"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "top": {
                            "type": "string",
                            "value": "16px"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.74%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "skin": "ICSknLblSSP72727213px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "32.49%"
                        },
                        "segmentProps": []
                    },
                    "flxListOfAccounts": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblChooseAccount": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "11px"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxDropDown": {
                        "right": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "flxMortagageAccounts": {
                        "segmentProps": []
                    },
                    "segMortgageAccounts": {
                        "data": [
                            [{
                                    "lblTransactionHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.NUO.SavingsAccount",
                                        "text": "SAVINGS ACCOUNTS"
                                    }
                                },
                                [{
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "isVisible": true,
                        "maxHeight": {
                            "type": "string",
                            "value": "252dp"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxAccNumberTypeMobile"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxTransfersFromHeader"
                        }),
                        "widgetDataMap": {
                            "flxAccNumberTypeMobile": "flxAccNumberTypeMobile",
                            "flxAccountDetails": "flxAccountDetails",
                            "flxAccountType": "flxAccountType",
                            "flxAccountsRowWrapper": "flxAccountsRowWrapper",
                            "flxAccountsWrapper": "flxAccountsWrapper",
                            "flxAvailableBalance": "flxAvailableBalance",
                            "flxBalance": "flxBalance",
                            "flxContent": "flxContent",
                            "flxCurrentBalance": "flxCurrentBalance",
                            "flxGroupLower": "flxGroupLower",
                            "flxIcons": "flxIcons",
                            "flxLower": "flxLower",
                            "flxMenu": "flxMenu",
                            "flxNoResultsFound": "flxNoResultsFound",
                            "flxSeparator": "flxSeparator",
                            "flxTransfersFromHeader": "flxTransfersFromHeader",
                            "imgExternalAlert": "imgExternalAlert",
                            "imgNoResultsFound": "imgNoResultsFound",
                            "imgThreeDotIcon": "imgThreeDotIcon",
                            "lblAccountName": "lblAccountName",
                            "lblAccountType": "lblAccountType",
                            "lblAvailableBalanceTitle": "lblAvailableBalanceTitle",
                            "lblAvailableBalanceValue": "lblAvailableBalanceValue",
                            "lblBankIcon": "lblBankIcon",
                            "lblCurrentBalanceTitle": "lblCurrentBalanceTitle",
                            "lblCurrentBalanceValue": "lblCurrentBalanceValue",
                            "lblNoResultsFound": "lblNoResultsFound",
                            "lblRoleIcon": "lblRoleIcon",
                            "lblSeperator": "lblSeperator",
                            "lblTransactionHeader": "lblTransactionHeader"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ArrangementsMA"
                    },
                    "flxSearch": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.74%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchBox": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "lblSearchIcon": {
                        "left": {
                            "type": "string",
                            "value": "14px"
                        },
                        "top": {
                            "type": "string",
                            "value": "8px"
                        },
                        "segmentProps": []
                    },
                    "txtSearchBox": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxClearSearch": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "7%"
                        },
                        "segmentProps": []
                    },
                    "lblClearSearch": {
                        "left": {
                            "type": "string",
                            "value": "17%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectionInfo": {
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.74%"
                        },
                        "segmentProps": []
                    },
                    "flxMessageInfo": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "19px"
                        },
                        "width": {
                            "type": "string",
                            "value": "14.06%"
                        },
                        "segmentProps": []
                    },
                    "lblMessageInfo": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "76.88%"
                        },
                        "segmentProps": []
                    },
                    "flxListOfDocuments": {
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.74%"
                        },
                        "segmentProps": []
                    },
                    "segListOfDocuments": {
                        "data": [{
                            "imgDownload": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "download.png"
                            },
                            "imgFileType": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "pdf_image.png"
                            },
                            "lblDownload": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.olb.ViewStatementDownload",
                                "text": "Download"
                            },
                            "lblFileName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Registration Certificate.pdf"
                            },
                            "lblGeneratedOnDate": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "imgDownload": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "download.png"
                            },
                            "imgFileType": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "pdf_image.png"
                            },
                            "lblDownload": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.olb.ViewStatementDownload",
                                "text": "Download"
                            },
                            "lblFileName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Registration Certificate.pdf"
                            },
                            "lblGeneratedOnDate": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "imgDownload": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "download.png"
                            },
                            "imgFileType": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "pdf_image.png"
                            },
                            "lblDownload": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.olb.ViewStatementDownload",
                                "text": "Download"
                            },
                            "lblFileName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Registration Certificate.pdf"
                            },
                            "lblGeneratedOnDate": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }, {
                            "imgDownload": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "download.png"
                            },
                            "imgFileType": {
                                "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                "src": "pdf_image.png"
                            },
                            "lblDownload": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.olb.ViewStatementDownload",
                                "text": "Download"
                            },
                            "lblFileName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Registration Certificate.pdf"
                            },
                            "lblGeneratedOnDate": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Label"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxFileDownloadMobile"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxDownload": "flxDownload",
                            "flxFileDownloadMobile": "flxFileDownloadMobile",
                            "flxFileType": "flxFileType",
                            "flxMainWrapper": "flxMainWrapper",
                            "flxSeparator": "flxSeparator",
                            "imgDownload": "imgDownload",
                            "imgFileType": "imgFileType",
                            "lblDownload": "lblDownload",
                            "lblFileName": "lblFileName",
                            "lblGeneratedOnDate": "lblGeneratedOnDate"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ArrangementsMA"
                    },
                    "flxNoDocuments": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.74%"
                        },
                        "segmentProps": []
                    },
                    "imgNodocumentInfo": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "19px"
                        },
                        "width": {
                            "type": "string",
                            "value": "14.08%"
                        },
                        "segmentProps": []
                    },
                    "lblNoDocument": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknBBLabelSSP42424220px",
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "800dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxverseperator2": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDocument": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "lblDocumentTitle": {
                        "skin": "bbSknLbl424242SSP20Px",
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "segmentProps": []
                    },
                    "flxDocumentsList": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.74%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectAccount": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50.66%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxListOfAccounts": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblChooseAccount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "1.95%"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "segmentProps": []
                    },
                    "flxDropDown": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "lblDropDown": {
                        "height": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "segmentProps": []
                    },
                    "lstSelectAccount": {
                        "top": {
                            "type": "string",
                            "value": "64dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "segMortgageAccounts": {
                        "data": [
                            [{
                                    "lblTransactionHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.NUO.SavingsAccount",
                                        "text": "SAVINGS ACCOUNTS"
                                    }
                                },
                                [{
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "maxHeight": {
                            "type": "string",
                            "value": "254dp"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxAccNumberType"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxTransfersFromHeader"
                        }),
                        "widgetDataMap": {
                            "flxAccNumberType": "flxAccNumberType",
                            "flxAccountDetails": "flxAccountDetails",
                            "flxAccountType": "flxAccountType",
                            "flxAccountsRowWrapper": "flxAccountsRowWrapper",
                            "flxAccountsWrapper": "flxAccountsWrapper",
                            "flxAvailableBalance": "flxAvailableBalance",
                            "flxBalance": "flxBalance",
                            "flxContent": "flxContent",
                            "flxCurrentBalance": "flxCurrentBalance",
                            "flxGroupLower": "flxGroupLower",
                            "flxIcons": "flxIcons",
                            "flxLower": "flxLower",
                            "flxMenu": "flxMenu",
                            "flxNoResultsFound": "flxNoResultsFound",
                            "flxSeparator": "flxSeparator",
                            "flxTransfersFromHeader": "flxTransfersFromHeader",
                            "imgExternalAlert": "imgExternalAlert",
                            "imgNoResultsFound": "imgNoResultsFound",
                            "imgThreeDotIcon": "imgThreeDotIcon",
                            "lblAccountName": "lblAccountName",
                            "lblAccountType": "lblAccountType",
                            "lblAvailableBalanceTitle": "lblAvailableBalanceTitle",
                            "lblAvailableBalanceValue": "lblAvailableBalanceValue",
                            "lblBankIcon": "lblBankIcon",
                            "lblCurrentBalanceTitle": "lblCurrentBalanceTitle",
                            "lblCurrentBalanceValue": "lblCurrentBalanceValue",
                            "lblNoResultsFound": "lblNoResultsFound",
                            "lblRoleIcon": "lblRoleIcon",
                            "lblSeperator": "lblSeperator",
                            "lblTransactionHeader": "lblTransactionHeader"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ArrangementsMA"
                    },
                    "flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "lblSearchIcon": {
                        "left": {
                            "type": "string",
                            "value": "1.83%"
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "txtSearchBox": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxClearSearch": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "lblClearSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelectionInfo": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "2.69%"
                        },
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": []
                    },
                    "lblMessageInfo": {
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "flxListOfDocuments": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxNoDocuments": {
                        "height": {
                            "type": "string",
                            "value": "68dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "imgNodocumentInfo": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.69%"
                        },
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "3.23%"
                        },
                        "segmentProps": []
                    },
                    "lblNoDocument": {
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "skin": "ICSknBBLabelSSP42424220px",
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "850dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMainScroll": {
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "customheader.FlexContainer0e2898aa93bca45": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDocument": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "22px"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "segmentProps": []
                    },
                    "lblDocumentTitle": {
                        "skin": "bbSknLbl424242SSP20Px",
                        "segmentProps": []
                    },
                    "flxDocumentsList": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "557dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectAccount": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "52.78%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxListOfAccounts": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblChooseAccount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.10%"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxDropDown": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblDropDown": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "lstSelectAccount": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "64dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "59.74%"
                        },
                        "segmentProps": []
                    },
                    "segMortgageAccounts": {
                        "data": [
                            [{
                                    "lblTransactionHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.NUO.SavingsAccount",
                                        "text": "SAVINGS ACCOUNTS"
                                    }
                                },
                                [{
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "maxHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxAccNumberType"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxTransfersFromHeader"
                        }),
                        "widgetDataMap": {
                            "flxAccNumberType": "flxAccNumberType",
                            "flxAccountDetails": "flxAccountDetails",
                            "flxAccountType": "flxAccountType",
                            "flxAccountsRowWrapper": "flxAccountsRowWrapper",
                            "flxAccountsWrapper": "flxAccountsWrapper",
                            "flxAvailableBalance": "flxAvailableBalance",
                            "flxBalance": "flxBalance",
                            "flxContent": "flxContent",
                            "flxCurrentBalance": "flxCurrentBalance",
                            "flxGroupLower": "flxGroupLower",
                            "flxIcons": "flxIcons",
                            "flxLower": "flxLower",
                            "flxMenu": "flxMenu",
                            "flxNoResultsFound": "flxNoResultsFound",
                            "flxSeparator": "flxSeparator",
                            "flxTransfersFromHeader": "flxTransfersFromHeader",
                            "imgExternalAlert": "imgExternalAlert",
                            "imgNoResultsFound": "imgNoResultsFound",
                            "imgThreeDotIcon": "imgThreeDotIcon",
                            "lblAccountName": "lblAccountName",
                            "lblAccountType": "lblAccountType",
                            "lblAvailableBalanceTitle": "lblAvailableBalanceTitle",
                            "lblAvailableBalanceValue": "lblAvailableBalanceValue",
                            "lblBankIcon": "lblBankIcon",
                            "lblCurrentBalanceTitle": "lblCurrentBalanceTitle",
                            "lblCurrentBalanceValue": "lblCurrentBalanceValue",
                            "lblNoResultsFound": "lblNoResultsFound",
                            "lblRoleIcon": "lblRoleIcon",
                            "lblSeperator": "lblSeperator",
                            "lblTransactionHeader": "lblTransactionHeader"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ArrangementsMA"
                    },
                    "flxSearch": {
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "txtSearchBox": {
                        "segmentProps": []
                    },
                    "flxClearSearch": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "lblClearSearch": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxSelectionInfo": {
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "lblMessageInfo": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "skin": "sknBBLabelSSPSB42424216px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxListOfDocuments": {
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "flxNoDocuments": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "imgNodocumentInfo": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "3.23%"
                        },
                        "segmentProps": []
                    },
                    "lblNoDocument": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "skin": "ICSknBBLabelSSP42424220px",
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "top": {
                            "type": "string",
                            "value": "950dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customheader"
                    },
                    "customheader.headermenu": {
                        "right": {
                            "type": "string",
                            "value": "5.70%"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxNotifications": {
                        "right": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxResetUserImg": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.headermenu.flxUserId": {
                        "right": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenu": {
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDocument": {
                        "top": {
                            "type": "string",
                            "value": "22px"
                        },
                        "segmentProps": []
                    },
                    "flxTitle": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "segmentProps": []
                    },
                    "lblDocumentTitle": {
                        "skin": "bbSknLbl424242SSP20Px",
                        "segmentProps": []
                    },
                    "flxDocumentsList": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "557dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectAccount": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "52.78%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxListOfAccounts": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblChooseAccount": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "1.10%"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxDropDown": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblDropDown": {
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "lstSelectAccount": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "64dp"
                        },
                        "segmentProps": []
                    },
                    "segMortgageAccounts": {
                        "data": [
                            [{
                                    "lblTransactionHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.NUO.SavingsAccount",
                                        "text": "SAVINGS ACCOUNTS"
                                    }
                                },
                                [{
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "imgExternalAlert": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey_2.png"
                                    },
                                    "imgNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgThreeDotIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "O"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage Facility 1...123"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Mortgage"
                                    },
                                    "lblAvailableBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblAvailableBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblBankIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "c"
                                    },
                                    "lblCurrentBalanceTitle": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblCurrentBalanceValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "test"
                                    },
                                    "lblNoResultsFound": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.FastTransfers.NoResultsFound",
                                        "text": "No Results Found"
                                    },
                                    "lblRoleIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "r"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "isVisible": true,
                        "maxHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxAccNumberType"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxTransfersFromHeader"
                        }),
                        "widgetDataMap": {
                            "flxAccNumberType": "flxAccNumberType",
                            "flxAccountDetails": "flxAccountDetails",
                            "flxAccountType": "flxAccountType",
                            "flxAccountsRowWrapper": "flxAccountsRowWrapper",
                            "flxAccountsWrapper": "flxAccountsWrapper",
                            "flxAvailableBalance": "flxAvailableBalance",
                            "flxBalance": "flxBalance",
                            "flxContent": "flxContent",
                            "flxCurrentBalance": "flxCurrentBalance",
                            "flxGroupLower": "flxGroupLower",
                            "flxIcons": "flxIcons",
                            "flxLower": "flxLower",
                            "flxMenu": "flxMenu",
                            "flxNoResultsFound": "flxNoResultsFound",
                            "flxSeparator": "flxSeparator",
                            "flxTransfersFromHeader": "flxTransfersFromHeader",
                            "imgExternalAlert": "imgExternalAlert",
                            "imgNoResultsFound": "imgNoResultsFound",
                            "imgThreeDotIcon": "imgThreeDotIcon",
                            "lblAccountName": "lblAccountName",
                            "lblAccountType": "lblAccountType",
                            "lblAvailableBalanceTitle": "lblAvailableBalanceTitle",
                            "lblAvailableBalanceValue": "lblAvailableBalanceValue",
                            "lblBankIcon": "lblBankIcon",
                            "lblCurrentBalanceTitle": "lblCurrentBalanceTitle",
                            "lblCurrentBalanceValue": "lblCurrentBalanceValue",
                            "lblNoResultsFound": "lblNoResultsFound",
                            "lblRoleIcon": "lblRoleIcon",
                            "lblSeperator": "lblSeperator",
                            "lblTransactionHeader": "lblTransactionHeader"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ArrangementsMA"
                    },
                    "flxSearch": {
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "txtSearchBox": {
                        "segmentProps": []
                    },
                    "flxClearSearch": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectionInfo": {
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "lblMessageInfo": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknBBLabelSSPSB42424216px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxListOfDocuments": {
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "flxNoDocuments": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "imgNodocumentInfo": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "3.23%"
                        },
                        "segmentProps": []
                    },
                    "lblNoDocument": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "1.46%"
                        },
                        "skin": "ICSknBBLabelSSP42424220px",
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "top": {
                            "type": "string",
                            "value": "950dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.flxTopmenu": {
                    "height": "51dp"
                },
                "customheader.topmenu.flxFeedbackimg": {
                    "left": ""
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.lblFeedback": {
                    "right": "20dp"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customheadernew.lblHeaderMobile": {
                    "text": "Account Details"
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "150dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "left": "0dp",
                    "right": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup.flxCross1": {
                    "right": "11dp"
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon_1.png"
                }
            }
            this.add(flxMainScroll, flxDialogs, flxLoading);
        };
        return [{
            "addWidgets": addWidgetsfrmViewDocument,
            "enabledForIdleTimeout": true,
            "id": "frmViewDocument",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_fa63e5e0e5ca49feb642553ae076d368,
            "preShow": function(eventobject) {
                controller.AS_Form_dc2130b69a8649da8fd4d91f0b480a4a(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "View Documents",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_d190586c0de9439aa0cf7ef1e0a5ebbd,
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": true
        }]
    }
});