define("CommonsMA/AppGroup/userForm1Controller", {
    //Type your controller code here 
});
define("CommonsMA/AppGroup/Form1ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("CommonsMA/AppGroup/Form1Controller", ["CommonsMA/AppGroup/userForm1Controller", "CommonsMA/AppGroup/Form1ControllerActions"], function() {
    var controller = require("CommonsMA/AppGroup/userForm1Controller");
    var controllerActions = ["CommonsMA/AppGroup/Form1ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
