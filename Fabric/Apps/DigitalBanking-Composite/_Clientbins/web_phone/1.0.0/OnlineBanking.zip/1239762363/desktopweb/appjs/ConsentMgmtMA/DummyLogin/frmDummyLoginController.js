define("ConsentMgmtMA/DummyLogin/userfrmDummyLoginController", {
    //Type your controller code here 
});
define("ConsentMgmtMA/DummyLogin/frmDummyLoginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnPSD2Consent **/
    AS_Button_c8681d058b174104bab2e86d025e24b4: function AS_Button_c8681d058b174104bab2e86d025e24b4(eventobject) {
        var self = this;
        //  new kony.mvc.Navigation({
        //                 "appName": "ConsentMgmtMA",
        //                 "friendlyName": "PSD2ConsentModule/frmManageAccountAccess"
        //             }).navigate();
        kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
            "moduleName": "PSD2ConsentUIModule",
            "appName": "ConsentMgmtMA"
        }).presentationController.showManageAccountAccess();
    },
    /** onClick defined for btnCDPConsent **/
    AS_Button_dc9f2a1b25574d19a464b42e5ce5784b: function AS_Button_dc9f2a1b25574d19a464b42e5ce5784b(eventobject) {
        var self = this;
        //  new kony.mvc.Navigation({
        //                 "appName": "ConsentMgmtMA",
        //                 "friendlyName": "CDPConsentModule/frmConsentManagement"
        //             }).navigate();
        kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
            "moduleName": "CDPConsentUIModule",
            "appName": "ConsentMgmtMA"
        }).presentationController.showConsentManagement();
    },
    /** preShow defined for frmDummyLogin **/
    AS_Form_h2d15769d3444974a6afecfe1223b127: function AS_Form_h2d15769d3444974a6afecfe1223b127(eventobject) {
        var self = this;
        kony.application.showLoadingScreen("", "Authenticating the user");
        var authParams = {
            "UserName": "9861936207",
            "Password": "Kony@1234",
            "loginOptions": {
                "isOfflineEnabled": false
            }
        };
        authClient = KNYMobileFabric.getIdentityService("DbxUserLogin");
        authClient.login(authParams, successCallback, errorCallback);
        //var ntf = new kony.mvc.Navigation("frmLogin2");
        //  ntf.navigate();
        //new kony.mvc.Navigation({
        //                "appName": "ServiceRequestsModule",
        ////                "friendlyName": "frmServiceRequests"
        //            }).navigate();
        function successCallback(resSuccess) {
            kony.application.dismissLoadingScreen();
            kony.print(resSuccess);
            // var ntf = new kony.mvc.Navigation("frmServiceRequests");
            //   var ntf = new kony.mvc.Navigation("frmLogin2");
            //  ntf.navigate();
            alert("Login OK!");
            // new kony.mvc.Navigation({
            //                "appName": "ConsentMgmtMA",
            //                "friendlyName": "SettingsNew/frmConsentManagement"
            //            }).navigate();
        }

        function errorCallback(resError) {
            kony.application.dismissLoadingScreen();
            kony.print(resError);
            alert("login is not working...");
        }
    }
});
define("ConsentMgmtMA/DummyLogin/frmDummyLoginController", ["ConsentMgmtMA/DummyLogin/userfrmDummyLoginController", "ConsentMgmtMA/DummyLogin/frmDummyLoginControllerActions"], function() {
    var controller = require("ConsentMgmtMA/DummyLogin/userfrmDummyLoginController");
    var controllerActions = ["ConsentMgmtMA/DummyLogin/frmDummyLoginControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
