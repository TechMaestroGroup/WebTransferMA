define("AuthenticationMA/AuthUIModule/frmLogout", function() {
    return function(controller) {
        function addWidgetsfrmLogout() {
            this.setDefaultUnit(kony.flex.DP);
            var tbxAutopopulateIssueFix = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "tbxAutopopulateIssueFix",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "175dp",
                "secureTextEntry": false,
                "skin": "tbxInvisible",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "98dp",
                "width": "300dp",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxMain = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main"
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "580dp",
                "horizontalScrollIndicator": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopysknscrollFlxffffffShadownoradius0fc8334c81bb140",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 2
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxImgKony = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxImgKony",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgKony.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "presentation",
                        "tabindex": -1
                    },
                    "a11yLabel": "Infinity Digital Banking"
                },
                "centerX": "14%",
                "height": "100%",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "80dp",
                "skin": "slImage",
                "src": "digital_banking.png",
                "top": "13dp",
                "width": "100%",
                "zIndex": 6
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgKony.add(imgKony);
            var flxCloseFontIconParent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "45dp",
                "id": "flxCloseFontIconParent",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "456dp",
                "isModalContainer": false,
                "right": "16%",
                "skin": "slFbox",
                "top": "59dp",
                "width": "45dp",
                "zIndex": 20,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseFontIconParent.setDefaultUnit(kony.flex.DP);
            var flxCloseFontIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "25dp",
                "id": "flxCloseFontIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseFontIcon.setDefaultUnit(kony.flex.DP);
            var lblCloseFontIconCommon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "height": "100%",
                "id": "lblCloseFontIconCommon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseFontIcon.add(lblCloseFontIconCommon);
            flxCloseFontIconParent.add(flxCloseFontIcon);
            var flxWelcomeBack = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxWelcomeBack",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWelcomeBack.setDefaultUnit(kony.flex.DP);
            var flxCloseWelcomeBack = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseWelcomeBack",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseWelcomeBack.setDefaultUnit(kony.flex.DP);
            var imgCloseWelcomeBack = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "height": "100%",
                "id": "imgCloseWelcomeBack",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "icon_close_grey.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseWelcomeBack.add(imgCloseWelcomeBack);
            var LblVerifiedUserWelcome = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.WelcomeBackLabel\")"
                },
                "id": "LblVerifiedUserWelcome",
                "isVisible": true,
                "left": "63dp",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.WelcomeBackLabel\")",
                "top": "18.64%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var flxUserContent = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "220dp",
                "id": "flxUserContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "147dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserContent.setDefaultUnit(kony.flex.DP);
            var flxWelcomeUserImage = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "54dp",
                "id": "flxWelcomeUserImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5.28%",
                "width": "54dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWelcomeUserImage.setDefaultUnit(kony.flex.DP);
            var imgVerifiedUser = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "imgVerifiedUser",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "default_username.png",
                "width": "44dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgVerifiedUserGreenFrame = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "54dp",
                "id": "imgVerifiedUserGreenFrame",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "user_verify_success.png",
                "width": "54dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWelcomeUserImage.add(imgVerifiedUser, imgVerifiedUserGreenFrame);
            var lblYourUsername = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.UserName\")"
                },
                "centerX": "50%",
                "id": "lblYourUsername",
                "isVisible": true,
                "left": "59dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.UserName\")",
                "top": "5.16%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [1, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var lblVerifiedUsername = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WelcomeBack.JohnBailey\")"
                },
                "id": "lblVerifiedUsername",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknSSP42424230Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.WelcomeBack.JohnBailey\")",
                "top": "25.50%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserContent.add(flxWelcomeUserImage, lblYourUsername, lblVerifiedUsername);
            var flxWelcomeBackBtns = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxWelcomeBackBtns",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "46dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWelcomeBackBtns.setDefaultUnit(kony.flex.DP);
            var AlterneteActionsSignIn = new com.InfinityOLB.AuthenticationMA.AlterneteActions({
                "centerX": "50.00%",
                "focusSkin": "sknBgE3E3E3Op20Border4A90E2",
                "height": "10.66%",
                "id": "AlterneteActionsSignIn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_je608273a6454f06a4d2f35db01cc151,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "7.04%",
                "width": "85%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "10.66%",
                        "top": "7.04%"
                    },
                    "flxImgContainer": {
                        "height": "100%",
                        "left": "1dp"
                    },
                    "imgOptionKA": {
                        "height": "32dp",
                        "src": "login_signin.png",
                        "width": "33dp"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.SignInAs\")",
                        "top": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            AlterneteActionsSignIn.onTouchStart = controller.AS_UWI_febaf38267ab420ea10a7175c9a77888;
            var orlineWelcomeBack = new com.InfinityOLB.AuthenticationMA.orline({
                "height": "35dp",
                "id": "orlineWelcomeBack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "imgOr": {
                        "src": "or_circle.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var AlterneteActionsResetPassword = new com.InfinityOLB.AuthenticationMA.AlterneteActions({
                "centerX": "50.00%",
                "focusSkin": "sknBgE3E3E3Op20Border4A90E2",
                "height": "10.66%",
                "id": "AlterneteActionsResetPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "onTouchStart": controller.AS_UWI_ca0c9310a1aa47c38fc7ccf76469ece5,
                "skin": "sknBGFFFFFBdrE3E3E3BdrRadius2Px",
                "top": "5.28%",
                "width": "85%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActions": {
                        "height": "10.66%",
                        "top": "5.28%"
                    },
                    "flxImgContainer": {
                        "height": "100%",
                        "left": "1dp"
                    },
                    "imgOptionKA": {
                        "src": "reset_password.png"
                    },
                    "imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "rtxCVV": {
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.ResetMyPassword\")",
                        "top": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            AlterneteActionsResetPassword.onTouchStart = controller.AS_UWI_g49f33dc26c54fb5af2ced556a943d58;
            flxWelcomeBackBtns.add(AlterneteActionsSignIn, orlineWelcomeBack, AlterneteActionsResetPassword);
            flxWelcomeBack.add(flxCloseWelcomeBack, LblVerifiedUserWelcome, flxUserContent, flxWelcomeBackBtns);
            var flxBlocked = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "568dp",
                "id": "flxBlocked",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "53%",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "100dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBlocked.setDefaultUnit(kony.flex.DP);
            var blocked = new com.InfinityOLB.AuthenticationMA.blocked({
                "height": "568dp",
                "id": "blocked",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "imgTakeHelpTime": {
                        "src": "help_large.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            blocked.btnProceed.onClick = controller.AS_Button_jd5c081d37894791b4928aedb8beaa5f;
            var flxCloseBlocked = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15dp",
                "id": "flxCloseBlocked",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "30dp",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxCloseBlocked.setDefaultUnit(kony.flex.DP);
            var imgCloseBlocked = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "height": "100%",
                "id": "imgCloseBlocked",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseBlocked.add(imgCloseBlocked);
            flxBlocked.add(blocked, flxCloseBlocked);
            var flxLogoutMsg = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100dp",
                "id": "flxLogoutMsg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxBgFFFFFFBdr6pxShadow104c7d",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogoutMsg.setDefaultUnit(kony.flex.DP);
            var logOutMsg = new com.InfinityOLB.AuthenticationMA.logOutMsg({
                "height": "100%",
                "id": "logOutMsg",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA",
                "overrides": {
                    "AlterneteActionsLoginNow": {
                        "left": "75dp",
                        "top": "36dp"
                    },
                    "AlterneteActionsLoginNow.flcVerticalBar": {
                        "height": "98%",
                        "top": "1%"
                    },
                    "AlterneteActionsLoginNow.fontIconOption": {
                        "text": "V"
                    },
                    "AlterneteActionsLoginNow.imgOptionKA": {
                        "src": "login_signin.png"
                    },
                    "AlterneteActionsLoginNow.imgRightTip": {
                        "src": "lefy_arrow_white.png"
                    },
                    "AlterneteActionsLoginNow.rtxCVV": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.loginNow\")"
                    },
                    "flxLogoutSuccess": {
                        "clipBounds": false
                    },
                    "imgLogoutSuccess": {
                        "centerY": "30.560000000000002%",
                        "height": "40dp",
                        "src": "success_green.png",
                        "top": "1dp",
                        "width": "40dp"
                    },
                    "lblLoggedOut": {
                        "centerY": "30.560000000000002%",
                        "left": "52px",
                        "right": "0dp",
                        "width": "viz.val_cleared"
                    },
                    "lblSuccessIcon": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.LogOutSuccess\")",
                        "left": "76dp",
                        "top": "59dp",
                        "width": "74.49%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogoutMsg.add(logOutMsg);
            var flxEnrollOrServerError = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "451dp",
                "id": "flxEnrollOrServerError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "147dp",
                "width": "399dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEnrollOrServerError.setDefaultUnit(kony.flex.DP);
            var EnrollAlert = new com.InfinityOLB.AuthenticationMA.EnrollAlert({
                "height": "400dp",
                "id": "EnrollAlert",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFFFFFFnoshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA",
                "overrides": {
                    "btnBackToLogin": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.backToLoginCaps\")"
                    },
                    "imgEnroll": {
                        "src": "server_error.png"
                    },
                    "rtxServerError": {
                        "height": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            EnrollAlert.btnBackToLogin.onClick = controller.AS_Button_hb4e02e809db4e1bae0ba4b9556b99ea;
            EnrollAlert.btnEnroll.onClick = controller.AS_Button_e5560a494d924458bc9240c27758a826;
            EnrollAlert.lblHowToEnroll.onTouchStart = controller.AS_Label_hbeccaed576f4fe2b9a931795bd748aa;
            flxEnrollOrServerError.add(EnrollAlert);
            var flxDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "51dp",
                "skin": "flxHoverSkinPointer",
                "top": "31dp",
                "width": "299dp",
                "zIndex": 4,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var lblCheckBox = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Language dropdown"
                },
                "centerY": "52.00%",
                "id": "lblCheckBox",
                "isVisible": true,
                "right": "25dp",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": "17dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Product"
            });
            var imgDropdown = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Language Dropdown"
                },
                "centerY": "50%",
                "height": "7dp",
                "id": "imgDropdown",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "right": "0%",
                "skin": "slImage",
                "src": "arrow_down.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLanguage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.English\")"
                },
                "centerY": "50.00%",
                "height": "25dp",
                "id": "lblLanguage",
                "isVisible": true,
                "right": "50dp",
                "skin": "sknLabelSSP0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.English\")",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "English"
            });
            flxDropdown.add(lblCheckBox, imgDropdown, lblLanguage);
            var flxLanguagePicker = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLanguagePicker",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "73dp",
                "skin": "sknflxMenuTransprent",
                "top": "65dp",
                "width": "13.61%",
                "zIndex": 50,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLanguagePicker.setDefaultUnit(kony.flex.DP);
            var imgToolTip = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "10dp",
                "id": "imgToolTip",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "0.50%",
                "skin": "slImage",
                "src": "tool_tip.png",
                "top": "0dp",
                "width": "17dp",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDifferentLanguagesSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "blur": {
                    "enabled": false,
                    "value": 0
                },
                "clipBounds": false,
                "id": "flxDifferentLanguagesSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "sknflxShdwLangPopWeb104c7d",
                "top": "-3dp",
                "width": "100%",
                "zIndex": 50,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDifferentLanguagesSegment.setDefaultUnit(kony.flex.DP);
            var segLanguagesList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segLanguagesList",
                "isVisible": true,
                "left": "0%",
                "needPageIndicator": true,
                "onRowClick": controller.AS_Segment_e35327828272483cb069075c61b9360a,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxLangList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxLangList": "flxLangList",
                    "lblLang": "lblLang",
                    "lblSeparator": "lblSeparator"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDifferentLanguagesSegment.add(segLanguagesList);
            flxLanguagePicker.add(imgToolTip, flxDifferentLanguagesSegment);
            var btnVeiwMore = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Learn more about our Bank's offerings. Opens in a new tab",
                    "allyARIA": {
                        "role": "link",
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknbtn0a78d1viewmoreFocus",
                "height": "40dp",
                "id": "btnVeiwMore",
                "isVisible": true,
                "left": "595dp",
                "skin": "sknbtn0273e3Viewmore",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.viewMore\")",
                "top": "344dp",
                "width": "130dp",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnUseMobileApp = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.login.DownloadApp\")"
                },
                "focusSkin": "slButtonGlossRed",
                "height": "50dp",
                "id": "btnUseMobileApp",
                "isVisible": true,
                "left": "83dp",
                "skin": "sknBtnSecondarySSPsknBtnSecondarySSP0273e315Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.DownloadApp\")",
                "top": "553dp",
                "width": "260dp",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFooterMenu = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "25dp",
                "id": "flxFooterMenu",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "42.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "84%",
                "width": "148dp",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterMenu.setDefaultUnit(kony.flex.DP);
            var flxFooterContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxFooterContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterContainer.setDefaultUnit(kony.flex.DP);
            var btnLocateUs = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnLocateUs",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Locate Us"
            });
            var flxVBar1 = new kony.ui.FlexContainer({
                "centerY": "55%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar1.setDefaultUnit(kony.flex.DP);
            flxVBar1.add();
            var btnContactUs = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.accountDetail.contactUs\")"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSSP3343A817PxBg0",
                "id": "btnContactUs",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Contact Us"
            });
            var flxVBar2 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar2.setDefaultUnit(kony.flex.DP);
            flxVBar2.add();
            var btnPrivacy = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SBAdvisory.privacyPolicy\")"
                },
                "centerY": "50%",
                "focusSkin": "sknSSPBtnFFFFFF13px",
                "id": "btnPrivacy",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.privacy\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknSSPBtnFFFFFF13px",
                "toolTip": "Privacy Policy"
            });
            var flxVBar3 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 35,
                "isModalContainer": false,
                "right": 1,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar3.setDefaultUnit(kony.flex.DP);
            flxVBar3.add();
            var btnTermsAndConditions = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.Transfers.Terms&Conditions\")"
                },
                "centerY": "50%",
                "focusSkin": "sknSSPBtnFFFFFF13px",
                "id": "btnTermsAndConditions",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknSSPBtnFFFFFF13px",
                "toolTip": "Terms & Conditions"
            });
            var flxVBar4 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60%",
                "id": "flxVBar4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35dp",
                "isModalContainer": false,
                "skin": "sknFlxd8d8d8",
                "width": "1px",
                "zIndex": 1,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxVBar4.setDefaultUnit(kony.flex.DP);
            flxVBar4.add();
            var btnFaqs = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.footer.faqs\")"
                },
                "centerY": "50%",
                "focusSkin": "sknSSPBtnFFFFFF13px",
                "id": "btnFaqs",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknSSPBtnFFFFFF13px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.faqs\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknSSPBtnFFFFFF13px",
                "toolTip": "FAQ"
            });
            flxFooterContainer.add(btnLocateUs, flxVBar1, btnContactUs, flxVBar2, btnPrivacy, flxVBar3, btnTermsAndConditions, flxVBar4, btnFaqs);
            flxFooterMenu.add(flxFooterContainer);
            var flxBeyond = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBeyond",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "565dp",
                "isModalContainer": false,
                "top": "180dp",
                "width": "60%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeyond.setDefaultUnit(kony.flex.DP);
            var lblBeyondBanking = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.login.BeyondBanking\")",
                    "tagName": "h2"
                },
                "id": "lblBeyondBanking",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSPLblFFFFFF30Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.LogOutSuccess\")",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBeyondBankingDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Integrated, easy-to-use web and mobile applications – built on the leading digital banking platform – to accelerate digital transformation, embrace rapid innovation, drive a frictionless customer experience and take control of your future.",
                    "tagName": "span"
                },
                "id": "lblBeyondBankingDesc",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSPLblFFFFFF15Px",
                "text": "We look forward to serving you again soon.",
                "top": "20dp",
                "width": "100%",
                "zIndex": 20
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBeyond.add(lblBeyondBanking, lblBeyondBankingDesc);
            var flxCopyRight = new kony.ui.FlexContainer({
                "bottom": "20dp",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxCopyRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "564dp",
                "isModalContainer": false,
                "right": "25dp",
                "skin": "slFbox",
                "zIndex": 50,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCopyRight.setDefaultUnit(kony.flex.DP);
            var imgTemenos = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "presentation",
                        "tabindex": -1
                    },
                    "a11yLabel": "temenos"
                },
                "centerX": "14%",
                "height": "18dp",
                "id": "imgTemenos",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "0dp",
                "skin": "slImage",
                "src": "temenos_logo_white.png",
                "top": "0%",
                "width": "80px",
                "zIndex": 6
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCopyright = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "\\u00a9 Copyright Kony Retail Banking. All rights reserved. Your savings are federally insured to at least $250,000 and backed by the full faith and credit of the Government.",
                    "tagName": "span"
                },
                "id": "lblCopyright",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknSSPLblB6D7F212Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyright\")",
                "width": "75%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCopyRight.add(imgTemenos, lblCopyright);
            var lblCopyrightTab1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "\\u00a9 Copyright Kony Retail Banking. All rights reserved."
                },
                "id": "lblCopyrightTab1",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknSSPLblFFFFFF12px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab1\")",
                "top": "505dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCopyrightTab2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab2\")"
                },
                "id": "lblCopyrightTab2",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknSSPLblB6D7F212Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab2\")",
                "top": "505dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMain.add(flxImgKony, flxCloseFontIconParent, flxWelcomeBack, flxBlocked, flxLogoutMsg, flxEnrollOrServerError, flxDropdown, flxLanguagePicker, btnVeiwMore, btnUseMobileApp, flxFooterMenu, flxBeyond, flxCopyRight, lblCopyrightTab1, lblCopyrightTab2);
            var flxLoading = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxLoadingChangeLanguage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoadingChangeLanguage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingChangeLanguage.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapperChangeLang = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapperChangeLang",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapperChangeLang.setDefaultUnit(kony.flex.DP);
            var flxImageContainerChangeLang = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainerChangeLang",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainerChangeLang.setDefaultUnit(kony.flex.DP);
            var imgLoadingChangeLang = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoadingChangeLang",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainerChangeLang.add(imgLoadingChangeLang);
            flxLoadingWrapperChangeLang.add(flxImageContainerChangeLang);
            var lblChangeLang = new kony.ui.Label({
                "id": "lblChangeLang",
                "isVisible": true,
                "left": "670dp",
                "skin": "sknLabelSSPffffff13",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.login.lblChangeLang\")",
                "top": "421dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1000
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoadingChangeLanguage.add(flxLoadingWrapperChangeLang, lblChangeLang);
            var flxFeedbackTakeSurvey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxFeedbackTakeSurvey",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackTakeSurvey.setDefaultUnit(kony.flex.DP);
            var flxScrollFeedback = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxScrollFeedback",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopysknscrollFlxffffffShadownoradius0fc8334c81bb140",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollFeedback.setDefaultUnit(kony.flex.DP);
            var CustomFeedbackPopup = new com.InfinityOLB.SelfServiceEnrolmentMA.CustomFeedbackPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "height": "260px",
                "id": "CustomFeedbackPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "width": "60%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "CustomFeedbackPopup": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "top": "viz.val_cleared",
                        "width": "60%"
                    },
                    "lblPopupMessage": {
                        "width": "90%"
                    },
                    "lblPopupmsg": {
                        "width": "90%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            CustomFeedbackPopup.btnNo.onClick = controller.AS_Button_fa0c887a1cb1471cbd4cf406d78c0655;
            CustomFeedbackPopup.btnYes.onClick = controller.AS_Button_c226fb7b57314d28894f20c40ee1ff1b;
            CustomFeedbackPopup.flxCross.onClick = controller.AS_Button_hd8353e0f2864247ad1de7e3de3de681;
            flxScrollFeedback.add(CustomFeedbackPopup);
            flxFeedbackTakeSurvey.add(flxScrollFeedback);
            var flxChangeLanguage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxChangeLanguage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChangeLanguage.setDefaultUnit(kony.flex.DP);
            var CustomChangeLanguagePopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomChangeLanguagePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "70%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "70%",
                        "zIndex": 1100
                    },
                    "lblHeading": {
                        "text": "Language"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.changeLanguagePopup\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxChangeLanguage.add(CustomChangeLanguagePopup);
            var BrowserCheckPopup = new com.InfinityOLB.AuthenticationMA.BrowserCheckPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "BrowserCheckPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AuthenticationMA",
                "overrides": {
                    "BrowserCheckPopup": {
                        "isVisible": false,
                        "left": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxBG = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxBG",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBG.setDefaultUnit(kony.flex.DP);
            var flxLoginBG = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxLoginBG",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginBG.setDefaultUnit(kony.flex.DP);
            var imgLoginBg = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgLoginBg",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "skin": "slImage",
                "src": "loginbackground.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImg = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxImg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknLoginflxGradient",
                "top": "0dp",
                "width": "100%",
                "appName": "AuthenticationMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImg.setDefaultUnit(kony.flex.DP);
            flxImg.add();
            flxLoginBG.add(imgLoginBg, flxImg);
            flxBG.add(flxLoginBG);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1400,
                "640": {
                    "frmLogout": {
                        "segmentProps": []
                    },
                    "tbxAutopopulateIssueFix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "LblVerifiedUserWelcome": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxUserContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImage": {
                        "top": {
                            "type": "string",
                            "value": "1.2800000000000002%"
                        },
                        "segmentProps": []
                    },
                    "lblYourUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "skin": "s1479fa717444db6b49648e6b8b80f1a",
                        "top": {
                            "type": "string",
                            "value": "44.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP42424230Px",
                        "top": {
                            "type": "string",
                            "value": "56.5%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBackBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1.5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsSignIn"
                    },
                    "AlterneteActionsSignIn.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn.imgOptionKA": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn.imgRightTip": {
                        "left": {
                            "type": "string",
                            "value": "-2px"
                        },
                        "segmentProps": []
                    },
                    "orlineWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "45%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "orlineWelcomeBack"
                    },
                    "AlterneteActionsResetPassword": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "72%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsResetPassword"
                    },
                    "AlterneteActionsResetPassword.flxImgMain": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsResetPassword.imgRightTip": {
                        "height": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "-2px"
                        },
                        "width": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "flxBlocked": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "blocked": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "blocked"
                    },
                    "blocked.btnProceed": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "blocked.imgTakeHelpTime": {
                        "top": {
                            "type": "string",
                            "value": "21.32%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseBlocked": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "flxLogoutMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFFFFFFnoshadow",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.flxLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.imgLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblLoggedOut": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblSuccessIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "106dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollOrServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.btnBackToLogin": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.rtxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "77.21%"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "right": {
                            "type": "string",
                            "value": "13.88%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": []
                    },
                    "lblCheckBox": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "skn0273e315pxolbfonticons",
                        "segmentProps": []
                    },
                    "lblLanguage": {
                        "right": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "skin": "sknLabelSSP0273e315px",
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "right": {
                            "type": "string",
                            "value": "61dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "92dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "flxDifferentLanguagesSegment": {
                        "skin": "sknflxShdwLangPopMB696969",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnSecondarySSPsknBtnSecondarySSP0273e315Px",
                        "top": {
                            "type": "string",
                            "value": "80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "72.30%"
                        },
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "715dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "skin": "sknSSPBtnFFFFFF13px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "centerY": {
                            "type": "string",
                            "value": "52%"
                        },
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCopyRight": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "752dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgTemenos": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": "90%"
                        },
                        "skin": "sknSSPLblFFFFFF12px",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "Updating your preferred Language",
                        "top": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackTakeSurvey": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFeedbackPopup"
                    },
                    "CustomFeedbackPopup.btnNo": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupMessage": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupmsg": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "240px"
                        },
                        "top": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnYes": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBG": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "imgLoginBg": {
                        "isVisible": true,
                        "segmentProps": []
                    }
                },
                "768": {
                    "tbxAutopopulateIssueFix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "17%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "15%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "LblVerifiedUserWelcome": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxUserContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImage": {
                        "top": {
                            "type": "string",
                            "value": "1.2800000000000002%"
                        },
                        "segmentProps": []
                    },
                    "lblYourUsername": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "41.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "52.5%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBackBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0.040000000000000036%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsSignIn"
                    },
                    "orlineWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "42.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": [],
                        "instanceId": "orlineWelcomeBack"
                    },
                    "AlterneteActionsResetPassword": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "72.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsResetPassword"
                    },
                    "flxBlocked": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "blocked.imgTakeHelpTime": {
                        "top": {
                            "type": "string",
                            "value": "22.32%"
                        },
                        "segmentProps": []
                    },
                    "flxLogoutMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFFFFFFnoshadow",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.flxLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.imgLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblLoggedOut": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblSuccessIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxEnrollOrServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.btnBackToLogin": {
                        "top": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "right": {
                            "type": "string",
                            "value": "20.25%"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "lblCheckBox": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "skn0273e315pxolbfonticons",
                        "segmentProps": []
                    },
                    "lblLanguage": {
                        "right": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "skin": "sknLabelSSP0273e315px",
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "right": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    },
                    "flxDifferentLanguagesSegment": {
                        "skin": "sknflxShdwLangPopTab696969",
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "centerX": {
                            "type": "string",
                            "value": "49.94%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "202dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "552dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "59.40%"
                        },
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "820dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "left": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCopyRight": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "855dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "imgTemenos": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "126dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknSSPLblFFFFFF12px",
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "855dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "Updating your preferred Language",
                        "top": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackTakeSurvey": {
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFeedbackPopup"
                    },
                    "CustomFeedbackPopup.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupMessage": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupmsg": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.lblPopupMessage": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "imgLoginBg": {
                        "isVisible": true,
                        "segmentProps": []
                    }
                },
                "1024": {
                    "tbxAutopopulateIssueFix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "22%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "LblVerifiedUserWelcome": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [1, 0, 1, 0],
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxUserContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImage": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUser": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUserGreenFrame": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblYourUsername": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "49.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedUsername": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "63.5%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBackBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsSignIn"
                    },
                    "orlineWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "19.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "orlineWelcomeBack"
                    },
                    "AlterneteActionsResetPassword": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "16.28%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsResetPassword"
                    },
                    "flxBlocked": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "blocked.imgTakeHelpTime": {
                        "top": {
                            "type": "string",
                            "value": "25.32%"
                        },
                        "segmentProps": []
                    },
                    "flxLogoutMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "sknFFFFFFnoshadow",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow.fontIconOption": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.flxLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.imgLogoutSuccess": {
                        "centerX": {
                            "type": "string",
                            "value": "47.43%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblLoggedOut": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblSuccessIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg": {
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "logOutMsg"
                    },
                    "flxEnrollOrServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.btnBackToLogin": {
                        "top": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.rtxServerError": {
                        "top": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "right": {
                            "type": "string",
                            "value": "24.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "lblCheckBox": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "skn0273e315pxolbfonticons",
                        "segmentProps": []
                    },
                    "lblLanguage": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "sknLabelSSP0273e315px",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "right": {
                            "type": "string",
                            "value": "245dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "flxDifferentLanguagesSegment": {
                        "skin": "sknflxShdwLangPopTab696969",
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "625dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "51%"
                        },
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "820dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCopyRight": {
                        "bottom": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "857dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "imgTemenos": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "126dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknLblSSPNormalB5D7F412px",
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSPLblB6D7F212Px",
                        "top": {
                            "type": "string",
                            "value": "850dp"
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "95.5%"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "updating your preferred language",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedbackTakeSurvey": {
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup": {
                        "segmentProps": [],
                        "instanceId": "CustomFeedbackPopup"
                    },
                    "CustomFeedbackPopup.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupmsg": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "imgLoginBg": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxImg": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1400": {
                    "tbxAutopopulateIssueFix": {
                        "height": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "skin": "tbxInvisible",
                        "text": "test",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "focusSkin": ""
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgKony": {
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "imgKony": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCloseFontIconParent": {
                        "left": {
                            "type": "string",
                            "value": "455dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxCloseFontIcon": {
                        "segmentProps": []
                    },
                    "lblCloseFontIconCommon": {
                        "segmentProps": []
                    },
                    "flxWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxf1ab15",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseWelcomeBack": {
                        "segmentProps": []
                    },
                    "LblVerifiedUserWelcome": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSupportedFileTypes",
                        "top": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "segmentProps": []
                    },
                    "flxUserContent": {
                        "height": {
                            "type": "string",
                            "value": "82dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84.00%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeUserImage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUser": {
                        "height": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54dp"
                        },
                        "segmentProps": []
                    },
                    "imgVerifiedUserGreenFrame": {
                        "height": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "lblYourUsername": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "63dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "12.16%"
                        },
                        "segmentProps": []
                    },
                    "lblVerifiedUsername": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "32.5%"
                        },
                        "segmentProps": []
                    },
                    "flxWelcomeBackBtns": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "height": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "7.04%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsSignIn"
                    },
                    "AlterneteActionsSignIn.fontIconOption": {
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "AlterneteActionsSignIn.imgOptionKA": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "orlineWelcomeBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "43.63%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "instanceId": "orlineWelcomeBack"
                    },
                    "AlterneteActionsResetPassword": {
                        "centerX": {
                            "type": "string",
                            "value": "51%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "69%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "instanceId": "AlterneteActionsResetPassword"
                    },
                    "flxBlocked": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSKnFlxf1ab15",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "blocked": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "blocked"
                    },
                    "flxLogoutMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "bbSKnFlxf1ab15",
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow": {
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "99px"
                        },
                        "top": {
                            "type": "string",
                            "value": "76dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow.flxImgMain": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.AlterneteActionsLoginNow.fontIconOption": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.flxLogoutSuccess": {
                        "height": {
                            "type": "string",
                            "value": "53px"
                        },
                        "left": {
                            "type": "string",
                            "value": "76dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "78%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.imgLogoutSuccess": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblLoggedOut": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg.lblSuccessIcon": {
                        "left": {
                            "type": "string",
                            "value": "76dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "74.49%"
                        },
                        "segmentProps": []
                    },
                    "logOutMsg": {
                        "zIndex": 1,
                        "segmentProps": [],
                        "instanceId": "logOutMsg"
                    },
                    "flxEnrollOrServerError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "bbSKnFlxf1ab15",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.btnBackToLogin": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.btnEnroll": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.flxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.imgEnroll": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblAppTitle": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "74"
                        },
                        "top": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "EnrollAlert.lblNotYetEnrolledOrError": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "EnrollAlert.rtxServerError": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "right": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "lblCheckBox": {
                        "skin": "sknffffff15pxolbfonticons",
                        "text": "O",
                        "segmentProps": []
                    },
                    "lblLanguage": {
                        "skin": "sknSSPLblFFFFFF15Px",
                        "segmentProps": []
                    },
                    "flxLanguagePicker": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "sknflxMenuTransprent",
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    },
                    "flxDifferentLanguagesSegment": {
                        "skin": "sknflxShdwLangPopWeb104c7d",
                        "top": {
                            "type": "string",
                            "value": "-3dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "segLanguagesList": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "btnVeiwMore": {
                        "focusSkin": "sknbtn0a78d1viewmoreFocus",
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "380dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "zIndex": 20,
                        "hoverSkin": "sknbtn41a0edviewmoreHover",
                        "segmentProps": []
                    },
                    "btnUseMobileApp": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "583dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "341dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterMenu": {
                        "bottom": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "565dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooterContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "focusSkin": "sknSSPBtnFFFFFF13px",
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar1": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "focusSkin": "sknSSPBtnFFFFFF13px",
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "hoverSkin": "sknSSPBtnFFFFFF13px",
                        "segmentProps": []
                    },
                    "flxVBar2": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnPrivacy": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "text": "Privacy Policy",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar3": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnTermsAndConditions": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "text": "Terms & Conditions",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxVBar4": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "13px"
                        },
                        "left": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnFaqs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "left": {
                            "type": "string",
                            "value": "13px"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPBtnFFFFFF13px",
                        "text": "FAQ",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblBeyondBanking": {
                        "skin": "sknSSPLblFFFFFF58px",
                        "segmentProps": []
                    },
                    "lblBeyondBankingDesc": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "isVisible": true,
                        "skin": "sknSSPLblFFFFFF24px",
                        "segmentProps": []
                    },
                    "flxCopyRight": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgTemenos": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblCopyright": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "padding": [0, 0, 0, 0],
                        "skin": "sknLblSSPNormalB5D7F412px",
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCopyrightTab1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblCopyrightTab2": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLoading": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingChangeLanguage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoadingWrapperChangeLang": {
                        "layoutType": kony.flex.FREE_FORM,
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxImageContainerChangeLang": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblChangeLang": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSPffffff13",
                        "text": "Updating your preferred language",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxFeedbackTakeSurvey": {
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup": {
                        "width": {
                            "type": "string",
                            "value": "36.60%"
                        },
                        "segmentProps": [],
                        "instanceId": "CustomFeedbackPopup"
                    },
                    "CustomFeedbackPopup.btnNo": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.btnYes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblHeading": {
                        "width": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupMessage": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CustomFeedbackPopup.lblPopupmsg": {
                        "isVisible": false,
                        "text": "Are you sure you want to cancel this transaction?",
                        "segmentProps": []
                    },
                    "flxChangeLanguage": {
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "CustomChangeLanguagePopup.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "BrowserCheckPopup": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "BrowserCheckPopup"
                    },
                    "flxBG": {
                        "left": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLoginBG": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "900dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1014dp"
                        },
                        "segmentProps": []
                    },
                    "imgLoginBg": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "a11yLabel": "Infinity Digital Banking"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "AlterneteActionsSignIn": {
                    "height": "10.66%",
                    "top": "7.04%"
                },
                "AlterneteActionsSignIn.flxImgContainer": {
                    "height": "100%",
                    "left": "1dp"
                },
                "AlterneteActionsSignIn.imgOptionKA": {
                    "height": "32dp",
                    "src": "login_signin.png",
                    "width": "33dp"
                },
                "AlterneteActionsSignIn.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "AlterneteActionsSignIn.rtxCVV": {
                    "centerY": "50%",
                    "top": ""
                },
                "orlineWelcomeBack.imgOr": {
                    "src": "or_circle.png"
                },
                "AlterneteActionsResetPassword": {
                    "height": "10.66%",
                    "top": "5.28%"
                },
                "AlterneteActionsResetPassword.flxImgContainer": {
                    "height": "100%",
                    "left": "1dp"
                },
                "AlterneteActionsResetPassword.imgOptionKA": {
                    "src": "reset_password.png"
                },
                "AlterneteActionsResetPassword.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "AlterneteActionsResetPassword.rtxCVV": {
                    "centerX": "",
                    "centerY": "50%",
                    "top": ""
                },
                "blocked.imgTakeHelpTime": {
                    "src": "help_large.png"
                },
                "logOutMsg.AlterneteActionsLoginNow": {
                    "left": "75dp",
                    "top": "36dp"
                },
                "logOutMsg.AlterneteActionsLoginNow.flcVerticalBar": {
                    "height": "98%",
                    "top": "1%"
                },
                "logOutMsg.AlterneteActionsLoginNow.fontIconOption": {
                    "text": "V"
                },
                "logOutMsg.AlterneteActionsLoginNow.imgOptionKA": {
                    "src": "login_signin.png"
                },
                "logOutMsg.AlterneteActionsLoginNow.imgRightTip": {
                    "src": "lefy_arrow_white.png"
                },
                "logOutMsg.imgLogoutSuccess": {
                    "centerY": "30.560000000000002%",
                    "height": "40dp",
                    "src": "success_green.png",
                    "top": "1dp",
                    "width": "40dp"
                },
                "logOutMsg.lblLoggedOut": {
                    "centerY": "30.560000000000002%",
                    "left": "52px",
                    "right": "0dp",
                    "width": ""
                },
                "logOutMsg.lblSuccessIcon": {
                    "left": "76dp",
                    "top": "59dp",
                    "width": "74.49%"
                },
                "EnrollAlert.imgEnroll": {
                    "src": "server_error.png"
                },
                "EnrollAlert.rtxServerError": {
                    "height": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomFeedbackPopup": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "top": "",
                    "width": "60%"
                },
                "CustomFeedbackPopup.lblPopupMessage": {
                    "width": "90%"
                },
                "CustomFeedbackPopup.lblPopupmsg": {
                    "width": "90%"
                },
                "CustomChangeLanguagePopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "70%",
                    "zIndex": 1100
                },
                "CustomChangeLanguagePopup.lblHeading": {
                    "text": "Language"
                },
                "BrowserCheckPopup": {
                    "left": "0dp"
                }
            }
            this.add(tbxAutopopulateIssueFix, flxMain, flxLoading, flxLoadingChangeLanguage, flxFeedbackTakeSurvey, flxChangeLanguage, BrowserCheckPopup, flxBG);
        };
        return [{
            "addWidgets": addWidgetsfrmLogout,
            "enabledForIdleTimeout": false,
            "id": "frmLogout",
            "init": controller.AS_Form_b7812fe2d9234913a9f7aa9e8775f40e,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_ja6a1c95eec5449aad1834e0f47bfc18,
            "postShow": controller.AS_Form_fdde57133c1e42fcb2459cab9b31c488,
            "preShow": function(eventobject) {
                controller.AS_Form_fe0db28461124300ba070ab83648aec3(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "title": "Logout",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 768, 1024, 1400],
            "onBreakpointChange": controller.AS_Form_j13c2775b263479a9a1d152b0d608c0d,
            "appName": "AuthenticationMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_df9059e362b6444a82d194b315dc1526,
            "retainScrollPosition": false
        }]
    }
});