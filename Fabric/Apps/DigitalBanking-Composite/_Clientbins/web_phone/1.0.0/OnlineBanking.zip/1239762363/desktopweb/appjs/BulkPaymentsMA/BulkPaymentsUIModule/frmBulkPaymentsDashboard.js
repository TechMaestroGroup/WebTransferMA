define("BulkPaymentsMA/BulkPaymentsUIModule/frmBulkPaymentsDashboard", function() {
    return function(controller) {
        function addWidgetsfrmBulkPaymentsDashboard() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderMain.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxSeperatorHor2": {
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.lblFeedback": {
                        "text": "Feedback"
                    },
                    "topmenu.lblHelp": {
                        "text": "Help"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderMain.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "pagingEnabled": false,
                "right": "6.07%",
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopyslFSbox0d3cb8c582bf146",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "96%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "Copybbsknf0ed23e6160bbb45",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            var flxOverdraftWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxOverdraftWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverdraftWarning.setDefaultUnit(kony.flex.DP);
            var imgOverDraft = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgOverDraft",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverdraftWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOverdraftWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.OverDraftWarning\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOverdraftWarning.add(imgOverDraft, lblOverdraftWarning, imgCloseWarning);
            var flxOutageWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxOutageWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOutageWarning.setDefaultUnit(kony.flex.DP);
            var imgInfoIconWarning = new kony.ui.Image2({
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgInfoIconWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutageWarning = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblOutageWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "13dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseOutageWarning = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgCloseOutageWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOutageWarning.add(imgInfoIconWarning, lblOutageWarning, imgCloseOutageWarning);
            flxMainWrapper.add(flxDowntimeWarning, flxOverdraftWarning, flxOutageWarning);
            var flxskncontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "width": "50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            var flxContentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxContentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "1366dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgementContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "19dp",
                "clipBounds": false,
                "height": "90dp",
                "id": "flxAcknowledgementContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5.70%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "30dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgement = new com.InfinityOLB.Resources.flxAcknowledgement({
                "centerY": "50%",
                "height": "100%",
                "id": "flxAcknowledgement",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ResourcesMA",
                "viewType": "flxAcknowledgement",
                "overrides": {
                    "flxTickImage": {
                        "width": "4.44%"
                    },
                    "rTextSuccess": {
                        "text": "Your transaction has been successfully submitted\nReference Number 45423792753"
                    },
                    "flxAcknowledgement": {
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAcknowledgement_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmBulkPaymentsDashboard"] && appConfig.componentMetadata["ResourcesMA"]["frmBulkPaymentsDashboard"]["flxAcknowledgement"]) || {};
            var flxAcknowledgementNew = new com.InfinityOLB.Resources.flxAcknowledgementNew({
                "height": "100%",
                "id": "flxAcknowledgementNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxAckContainer": {
                        "height": "85dp"
                    },
                    "flxAcknowledgementNew": {
                        "isVisible": true,
                        "left": "0dp",
                        "width": "100%"
                    },
                    "flxImgPrint": {
                        "isVisible": false
                    },
                    "flxImgdownload": {
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "height": "22dp",
                        "isVisible": true,
                        "left": "95%",
                        "width": "22dp"
                    },
                    "imgDownload": {
                        "height": "100%",
                        "imageWhenFailed": "bbcloseicon_1.png",
                        "imageWhileDownloading": "bbcloseicon_1.png",
                        "src": "bbcloseicon_1.png",
                        "width": "100%"
                    },
                    "imgPrint": {
                        "src": "bbprint.png"
                    },
                    "imgTick": {
                        "src": "bulk_billpay_success.png"
                    },
                    "rTextSuccess": {
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "left": "8.80%",
                        "text": "User has been Successfully Added ."
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAcknowledgementContainer.add(flxAcknowledgement, flxAcknowledgementNew);
            var flxContentHeader = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "centerY": "55%",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "-2dp",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.bulkPaymentHeader\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgDownloadAch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImgDownloadAch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "2%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgDownloadAch.setDefaultUnit(kony.flex.DP);
            var imgDownloadAchTransaction = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgDownloadAchTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbdownloadicon.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgDownloadAch.add(imgDownloadAchTransaction);
            var flxImgPrintAch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImgPrintAch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "93.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "3%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgPrintAch.setDefaultUnit(kony.flex.DP);
            var imgPrintAchTransaction = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgPrintAchTransaction",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "bbprint.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgPrintAch.add(imgPrintAchTransaction);
            flxContentHeader.add(lblContentHeader, flxImgDownloadAch, flxImgPrintAch);
            var flxDisplayErrorMessage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "66dp",
                "id": "flxDisplayErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgDisplayError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgDisplayError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDisplayError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblDisplayError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblee0005SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.add(imgDisplayError, lblDisplayError);
            var flxContentDashBoard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContentDashBoard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentDashBoard.setDefaultUnit(kony.flex.DP);
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "4dp",
                "width": "58.19%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var flxTabPaneContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTabPaneContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabPaneContainer.setDefaultUnit(kony.flex.DP);
            var TabPaneNew = new com.InfinityOLB.Resources.TabPaneNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TabPaneNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "-5px",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "MobileCustomDropdown": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": false,
                        "isVisible": false,
                        "zIndex": 1
                    },
                    "MobileCustomDropdown.btnApplyFilter": {
                        "bottom": 10,
                        "width": "40%"
                    },
                    "MobileCustomDropdown.btnCancelFilter": {
                        "bottom": 10,
                        "left": "5%",
                        "width": "20%"
                    },
                    "MobileCustomDropdown.flxButtons": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "bottom": "viz.val_cleared",
                        "top": 10
                    },
                    "MobileCustomDropdown.flxDropdown": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": false,
                        "isVisible": true
                    },
                    "MobileCustomDropdown.flxImage": {
                        "left": "91%"
                    },
                    "MobileCustomDropdown.flxIphoneDropdown": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "4%"
                    },
                    "MobileCustomDropdown.flxProcessingType": {
                        "isVisible": false
                    },
                    "MobileCustomDropdown.imgDropdown": {
                        "imageWhenFailed": "blue_downarrow.png",
                        "imageWhileDownloading": "blue_downarrow.png",
                        "src": "listboxarw.png"
                    },
                    "MobileCustomDropdown.lblTimeperiodContent": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.TimePeriod\")"
                    },
                    "MobileCustomDropdown.lblView": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.View\")",
                        "width": "100%"
                    },
                    "MobileCustomDropdown.lblViewType": {
                        "left": "0%",
                        "width": "85%"
                    },
                    "MobileCustomDropdown.segViewTypes": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": true,
                        "zIndex": 15
                    },
                    "PaginationContainer": {
                        "centerX": "viz.val_cleared",
                        "left": "8px",
                        "right": "0dp",
                        "top": "10dp"
                    },
                    "PaginationContainer.imgPaginationNext": {
                        "src": "pagination_next_active.png"
                    },
                    "PaginationContainer.imgPaginationPrevious": {
                        "src": "pagination_back_inactive.png"
                    },
                    "TabBodyNew": {
                        "isVisible": true,
                        "top": "0dp"
                    },
                    "TabBodyNew.segTemplates": {
                        "bottom": "-2dp",
                        "isVisible": true,
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "TabPaneNew": {
                        "left": "-5px",
                        "right": "viz.val_cleared"
                    },
                    "TabSearchBarNew": {
                        "centerY": "viz.val_cleared",
                        "clipBounds": false,
                        "isVisible": true,
                        "zIndex": 5,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "TabSearchBarNew.MobileCustomDropdown": {
                        "height": "50dp",
                        "isVisible": true,
                        "zIndex": 5
                    },
                    "TabSearchBarNew.MobileCustomDropdown.btnApplyFilter": {
                        "bottom": "10dp",
                        "left": "50%",
                        "top": 0
                    },
                    "TabSearchBarNew.MobileCustomDropdown.btnCancelFilter": {
                        "bottom": "10dp",
                        "left": "5%",
                        "top": 0
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxButtons": {
                        "height": "50dp",
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": false,
                        "isVisible": false,
                        "left": "0%",
                        "top": "100%",
                        "width": "100%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxImage": {
                        "left": "viz.val_cleared",
                        "right": "2%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "height": "50dp",
                        "left": "0%",
                        "top": "0%",
                        "width": "100%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.imgDropdown": {
                        "src": "listboxuparrow.png"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.lblProcessingTypeContent": {
                        "text": "Processing type"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.lblTimeperiodContent": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.TimePeriod\")"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.View\")",
                        "left": "viz.val_cleared",
                        "right": "72%",
                        "width": "20%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                        "left": "viz.val_cleared",
                        "right": "12%",
                        "text": "All",
                        "width": "60%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.segViewTypes": {
                        "data": [{
                            "lblViewTypeName": "All Payments"
                        }, {
                            "lblViewTypeName": "Review In Progress"
                        }, {
                            "lblViewTypeName": "Under Approval"
                        }, {
                            "lblViewTypeName": "Rejected"
                        }, {
                            "lblViewTypeName": "Cancelled"
                        }],
                        "height": "240dp"
                    },
                    "TabSearchBarNew.flxBoxSearch": {
                        "height": "40dp",
                        "left": "0%",
                        "width": "95%"
                    },
                    "TabSearchBarNew.flxDropDown": {
                        "centerY": "47.50%",
                        "height": "50dp",
                        "isVisible": true,
                        "left": "0%",
                        "top": "viz.val_cleared"
                    },
                    "TabSearchBarNew.flxOptions": {
                        "height": "100%",
                        "isVisible": false
                    },
                    "TabSearchBarNew.flxSearch": {
                        "isVisible": true,
                        "left": "20dp",
                        "width": "68%"
                    },
                    "TabSearchBarNew.lblView": {
                        "isVisible": false
                    },
                    "TabSearchBarNew.listBoxViewType": {
                        "isVisible": false,
                        "masterData": [
                            ["lb1", "All Payments"],
                            ["lb2", "Review In Progress"],
                            ["lb3", "Under Approval"],
                            ["Key1459587351", "Rejected"],
                            ["Key2016235284", "Cancelled"]
                        ],
                        "right": "10dp",
                        "width": "67.74%"
                    },
                    "TabSearchBarNew.tbxSearch": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                    },
                    "TabsHeaderNew": {
                        "isVisible": true
                    },
                    "TabsHeaderNew.btnTab1": {
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.viewUploadedfiles\")",
                        "left": "10dp",
                        "right": "viz.val_cleared",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "TabsHeaderNew.btnTab2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.PaymentsStatus\")",
                        "left": "0px",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "TabsHeaderNew.btnTab3": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.paymentHistory\")",
                        "left": "0px",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "TabsHeaderNew.btnTab4": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.viewTemplates\")",
                        "isVisible": true,
                        "left": "0px",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "TabsHeaderNew.btnTab5": {
                        "isVisible": false
                    },
                    "TabsHeaderNew.btnTab6": {
                        "isVisible": false
                    },
                    "flxContentContainer": {
                        "zIndex": 1
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTabPaneContainer.add(TabPaneNew);
            flxDashboard.add(flxTabPaneContainer);
            var flxRightContainers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightContainers",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.10%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "28.60%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainers.setDefaultUnit(kony.flex.DP);
            var dbRightContainerNew = new com.InfinityOLB.Resources.dbRightContainerNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "dbRightContainerNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnAction1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.uploadFilesAndMakePayment\")"
                    },
                    "btnAction2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.DownloadCSVTemplate\")"
                    },
                    "btnAction3": {
                        "text": " "
                    },
                    "dbRightContainerNew": {
                        "left": "0%",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "imgBanner": {
                        "src": "nuo_banner_1.png"
                    },
                    "lblActionHeader": {
                        "text": " "
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCampaigns = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxCampaigns",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "96%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCampaigns.setDefaultUnit(kony.flex.DP);
            var carousel = new com.InfinityOLB.Resources.carousel({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "170px",
                "id": "carousel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "carousel": {
                        "centerY": "viz.val_cleared",
                        "height": "170px",
                        "isVisible": true,
                        "left": "0%",
                        "top": "0dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCampaigns.add(carousel);
            flxRightContainers.add(dbRightContainerNew, flxCampaigns);
            flxContentDashBoard.add(flxDashboard, flxRightContainers);
            var flxTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTerms",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "87.85%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTerms.setDefaultUnit(kony.flex.DP);
            var lblTitleTerms = new kony.ui.Label({
                "id": "lblTitleTerms",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var browserTnC = new kony.ui.Browser({
                "bottom": "10dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "browserTnC",
                "isVisible": true,
                "left": "20dp",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxTerms.add(lblTitleTerms, browserTnC);
            flxContentContainer.add(flxAcknowledgementContainer, flxContentHeader, flxDisplayErrorMessage, flxContentDashBoard, flxTerms);
            flxMain.add(flxMainWrapper, flxskncontainer, flxContentContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var PopupHeaderUM = new com.InfinityOLB.SelfServiceEnrolmentMA.CustomFeedbackPopup({
                "height": "260px",
                "id": "PopupHeaderUM",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "appName": "SelfServiceEnrolmentMA",
                "overrides": {
                    "btnNo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")"
                    },
                    "btnYes": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userMgmt.CancelUserCreation\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            PopupHeaderUM.btnNo.onClick = controller.AS_Button_i806e35651e04b1cbdbad15322d6e745;
            PopupHeaderUM.btnYes.onClick = controller.AS_Button_e6227a89fd5e4389bab3617b7c421105;
            flxCancelPopup.add(PopupHeaderUM);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgPrint": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgdownload": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "isVisible": true,
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.btnApplyFilter": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.btnCancelFilter": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxButtons": {
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxDropdown": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxImage": {
                        "left": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.00%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.lblTimeperiodContent": {
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.lblView": {
                        "width": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.lblViewType": {
                        "left": {
                            "type": "string",
                            "value": "13%"
                        },
                        "width": {
                            "type": "string",
                            "value": "77%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.segViewTypes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabBodyNew": {
                        "isVisible": true,
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabBodyNew.segTemplates": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.btnApplyFilter": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.btnCancelFilter": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxButtons": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblTimeperiodContent": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxOptions": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "-96%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblView": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.tbxSearch": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "76%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.flxContentContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRightContainers": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "dbRightContainerNew": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "text": "© Copyright Infinity Retail Banking. All rights reserved.",
                        "segmentProps": []
                    },
                    "customfooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupmsg": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PopupHeaderUM": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "56%"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.btnApplyFilter": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.btnCancelFilter": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxButtons": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.imgDropdown": {
                        "src": "blue_downarrow.png",
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.lblTimeperiodContent": {
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxImage": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblTimeperiodContent": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "76%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                        "right": {
                            "type": "string",
                            "value": "12%"
                        },
                        "width": {
                            "type": "string",
                            "value": "57%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "left": {
                            "type": "string",
                            "value": "70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxOptions": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab1": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab2": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab3": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab4": {
                        "segmentProps": []
                    },
                    "TabPaneNew.flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxRightContainers": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "dbRightContainerNew": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblTitleTerms": {
                        "left": {
                            "type": "string",
                            "value": "27px"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupmsg": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "PopupHeaderUM": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentDashBoard": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxProcessingType": {
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.lblTimeperiodContent": {
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabBodyNew.segTemplates": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblTimeperiodContent": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "left": {
                            "type": "string",
                            "value": "65%"
                        },
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxOptions": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "63%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab1": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab2": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab3": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab4": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab5": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab6": {
                        "segmentProps": []
                    },
                    "TabPaneNew.flxContentContainer": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "dbRightContainerNew.btnAction1": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366px"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "54%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.85%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentDashBoard": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTabPaneContainer": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "65%"
                        },
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "63%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblOption0": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblOption1": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab1": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab2": {
                        "text": "Payment Status",
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab3": {
                        "text": "Payment History",
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab5": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab6": {
                        "segmentProps": []
                    },
                    "TabPaneNew.flxContentContainer": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "customfooter": {
                        "segmentProps": []
                    },
                    "flxLoading": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblHeading": {
                        "text": "",
                        "segmentProps": []
                    },
                    "PopupHeaderUM.lblPopupMessage": {
                        "text": "",
                        "segmentProps": []
                    },
                    "PopupHeaderUM": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.topmenu.lblFeedback": {
                    "text": "Feedback"
                },
                "customheader.topmenu.lblHelp": {
                    "text": "Help"
                },
                "flxAcknowledgement": {
                    "successImgWidth": "4.44%",
                    "successMsg": "Your transaction has been successfully submitted\nReference Number 45423792753",
                    "right": "",
                    "top": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": ""
                },
                "flxAcknowledgementNew.flxAckContainer": {
                    "height": "85dp"
                },
                "flxAcknowledgementNew": {
                    "left": "0dp",
                    "width": "100%"
                },
                "flxAcknowledgementNew.flxImgdownload": {
                    "centerX": "",
                    "centerY": "50%",
                    "height": "22dp",
                    "left": "95%",
                    "width": "22dp"
                },
                "flxAcknowledgementNew.imgDownload": {
                    "height": "100%",
                    "src": "bbcloseicon_1.png",
                    "width": "100%"
                },
                "flxAcknowledgementNew.imgPrint": {
                    "src": "bbprint.png"
                },
                "flxAcknowledgementNew.imgTick": {
                    "src": "bulk_billpay_success.png"
                },
                "flxAcknowledgementNew.rTextSuccess": {
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "8.80%",
                    "text": "User has been Successfully Added ."
                },
                "TabPaneNew.MobileCustomDropdown": {
                    "zIndex": 1
                },
                "TabPaneNew.MobileCustomDropdown.btnApplyFilter": {
                    "bottom": 10,
                    "width": "40%"
                },
                "TabPaneNew.MobileCustomDropdown.btnCancelFilter": {
                    "bottom": 10,
                    "left": "5%",
                    "width": "20%"
                },
                "TabPaneNew.MobileCustomDropdown.flxButtons": {
                    "bottom": "",
                    "top": 10
                },
                "TabPaneNew.MobileCustomDropdown.flxImage": {
                    "left": "91%"
                },
                "TabPaneNew.MobileCustomDropdown.flxIphoneDropdown": {
                    "centerX": "",
                    "centerY": "",
                    "left": "4%"
                },
                "TabPaneNew.MobileCustomDropdown.imgDropdown": {
                    "src": "listboxarw.png"
                },
                "TabPaneNew.MobileCustomDropdown.lblView": {
                    "width": "100%"
                },
                "TabPaneNew.MobileCustomDropdown.lblViewType": {
                    "left": "0%",
                    "width": "85%"
                },
                "TabPaneNew.MobileCustomDropdown.segViewTypes": {
                    "zIndex": 15
                },
                "TabPaneNew.PaginationContainer": {
                    "centerX": "",
                    "left": "8px",
                    "right": "0dp",
                    "top": "10dp"
                },
                "TabPaneNew.PaginationContainer.imgPaginationNext": {
                    "src": "pagination_next_active.png"
                },
                "TabPaneNew.PaginationContainer.imgPaginationPrevious": {
                    "src": "pagination_back_inactive.png"
                },
                "TabPaneNew.TabBodyNew": {
                    "top": "0dp"
                },
                "TabPaneNew.TabBodyNew.segTemplates": {
                    "bottom": "-2dp",
                    "left": "0dp",
                    "top": "0dp"
                },
                "TabPaneNew": {
                    "left": "-5px",
                    "right": ""
                },
                "TabPaneNew.TabSearchBarNew": {
                    "centerY": "",
                    "zIndex": 5,
                    "layoutType": kony.flex.FREE_FORM
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown": {
                    "height": "50dp",
                    "zIndex": 5
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.btnApplyFilter": {
                    "bottom": "10dp",
                    "left": "50%",
                    "top": 0
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.btnCancelFilter": {
                    "bottom": "10dp",
                    "left": "5%",
                    "top": 0
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxButtons": {
                    "height": "50dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                    "left": "0%",
                    "top": "100%",
                    "width": "100%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxImage": {
                    "left": "",
                    "right": "2%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                    "height": "50dp",
                    "left": "0%",
                    "top": "0%",
                    "width": "100%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.imgDropdown": {
                    "src": "listboxuparrow.png"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblProcessingTypeContent": {
                    "text": "Processing type"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                    "left": "",
                    "right": "72%",
                    "width": "20%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                    "left": "",
                    "right": "12%",
                    "text": "All",
                    "width": "60%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.segViewTypes": {
                    "data": [{
                        "lblViewTypeName": "All Payments"
                    }, {
                        "lblViewTypeName": "Review In Progress"
                    }, {
                        "lblViewTypeName": "Under Approval"
                    }, {
                        "lblViewTypeName": "Rejected"
                    }, {
                        "lblViewTypeName": "Cancelled"
                    }],
                    "height": "240dp"
                },
                "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                    "height": "40dp",
                    "left": "0%",
                    "width": "95%"
                },
                "TabPaneNew.TabSearchBarNew.flxDropDown": {
                    "centerY": "47.50%",
                    "height": "50dp",
                    "left": "0%",
                    "top": ""
                },
                "TabPaneNew.TabSearchBarNew.flxOptions": {
                    "height": "100%"
                },
                "TabPaneNew.TabSearchBarNew.flxSearch": {
                    "left": "20dp",
                    "width": "68%"
                },
                "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                    "right": "10dp",
                    "width": "67.74%"
                },
                "TabPaneNew.TabsHeaderNew.btnTab1": {
                    "centerY": "50%",
                    "left": "10dp",
                    "right": "",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "TabPaneNew.TabsHeaderNew.btnTab2": {
                    "left": "0px",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "TabPaneNew.TabsHeaderNew.btnTab3": {
                    "left": "0px",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "TabPaneNew.TabsHeaderNew.btnTab4": {
                    "left": "0px",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "TabPaneNew.flxContentContainer": {
                    "zIndex": 1
                },
                "dbRightContainerNew.btnAction3": {
                    "text": " "
                },
                "dbRightContainerNew": {
                    "left": "0%",
                    "top": "0dp",
                    "width": "100%"
                },
                "dbRightContainerNew.imgBanner": {
                    "src": "nuo_banner_1.png"
                },
                "dbRightContainerNew.lblActionHeader": {
                    "text": " "
                },
                "carousel": {
                    "centerY": "",
                    "height": "170px",
                    "left": "0%",
                    "top": "0dp",
                    "width": "100%"
                }
            }
            this.add(flxHeaderMain, flxFormContent, flxLogout, flxLoading, flxCancelPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmBulkPaymentsDashboard,
            "enabledForIdleTimeout": true,
            "id": "frmBulkPaymentsDashboard",
            "init": controller.AS_Form_cd46a142022b49b7806ae44e9938c720,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_h3b597790b1d433aaf598000f1ce5617,
            "postShow": controller.AS_Form_c6caedd2f16c41898fac709fcb86790e,
            "preShow": function(eventobject) {
                controller.AS_Form_dc483c4888974b7399d675773163e055(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "BulkPaymentsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_he4b41b8533547eeaa9fad84d541b03c,
            "retainScrollPosition": true
        }]
    }
});