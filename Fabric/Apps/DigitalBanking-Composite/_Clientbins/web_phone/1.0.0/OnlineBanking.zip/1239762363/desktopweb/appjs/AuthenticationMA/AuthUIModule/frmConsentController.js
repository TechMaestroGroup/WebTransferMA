define("AuthenticationMA/AuthUIModule/userfrmConsentController", ['Deeplinking', 'ViewConstants', 'CommonUtilities', 'OLBConstants'], function(FormControllerUtility, Deeplinking, ViewConstants, CommonUtilities, OLBConstants) {
    return {
        /**
         * Sets the initial actions for form.
         */
        init: function() {
            this.view.preShow = this.preShow;
            this.view.postShow = this.postShow
            this.view.onBreakpointChange = this.onBreakpointChange;
            this.initformActions();
        },
        preShow: function() {
            this.view.loginComponent.closePopups = this.hidePopupsFunction;
            this.view.btnAuthoriseCancelKA.onClick = this.onClickOfAuthoriseCancel;
            this.view.btnAuthoriseContinue.onClick = this.onClickOfAuthoriseContinue;
        },
        postShow: function() {
            this.setContext();
            let authModule = this.loadAuthModule();
            if (authModule.presentationController.isNewLogintobeShown) {
                if (applicationManager.consentType === "AISP") {
                    this.setAISPConsentUI();
                } else if (applicationManager.consentType === "PISP") {
                    this.setPISPConsentUI();
                }
            } else {
                this.view.flxAuthoriseConsent.setVisibility(false);
                this.view.flxLogin.setVisibility(true);
            }
        },
        initformActions: function() {
            var scopeObj = this;
            scopeObj.view.loginComponent.onSuccessCallback = function(response) {
                var langObj = applicationManager.getStorageManager().getStoredItem("langObj");
                var sessionlanguage = (langObj !== null) ? langObj.language : kony.i18n.getCurrentLocale();
                var loginLanguage = null;
                if (response.defaultLanguage != undefined && response.defaultLanguage != null && response.defaultLanguage != "") {
                    loginLanguage = response.defaultLanguage;
                }
                applicationManager.getStorageManager().setStoredItem("loginLangObj", {
                    language: loginLanguage
                });
                if (response.defaultLanguage != undefined && response.defaultLanguage != null && response.defaultLanguage != "" && response.defaultLanguage != sessionlanguage) scopeObj.showDifferentLanguagePopUp(response);
                else scopeObj.postLoginSuccess(response);
            };
            scopeObj.view.loginComponent.onFailureCallback = function(response) {
                scopeObj.showLoginError(response);
            };
            this.view.btnCancel.onClick = () => this.toggleCancelPopup(true);
            this.view.CancelPopup.btnYes.onClick = () => this.cancelFlow();
            this.view.CancelPopup.flxCross.onClick = () => this.toggleCancelPopup(false);
            this.view.CancelPopup.btnNo.onClick = () => this.toggleCancelPopup(false);
        },
        /**
         * Handles breakpoint change.
         * @param {object} formHandle - Specifies the handle of form.
         * @param {number} breakpoint - Specifies the current breakpoint value.
         */
        onBreakpointChange: function(formHandle, breakpoint) {
            var scope = this;
            breakpoint = kony.application.getCurrentBreakpoint();
            this.view.CancelPopup.onBreakpointChangeComponent(scope.view.CancelPopup, breakpoint);
            if (applicationManager.getConfigurationManager().isMicroAppPresent("CampaignMA")) this.loadAuthModule().presentationController.getPreLoginCampaignsOnBreakpointChange();
            else if (!this.isOriginationFlow) this.loadAuthModule().presentationController.getAllClientAppProperties();
        },
        /**
         * Toggles the Cancel popup.
         * @param {boolean} visibility - Specfies whether to show/hide Cancel popup.
         * @returns {void} - Returns nothing if visibility is false.
         */
        toggleCancelPopup: function(visibility) {
            this.view.flxCancel.setVisibility(visibility);
        },
        cancelFlow: function() {
            let openBankingModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                "moduleName": "OpenBankingUIModule",
                "appName": "OpenBankingMA"
            });
            if (applicationManager.consentType === "PISP") {
                openBankingModule.presentationController.denyPaymentConsentPreLogin();
            } else if (applicationManager.consentType === "AISP") {
                openBankingModule.presentationController.denyConsentPreLogin();
            } else if (applicationManager.consentType === "CBP") {
                openBankingModule.presentationController.denyCBPConsentPreLogin();
            }
        },
        /**
         * Method to load and return Auth Module
         * @returns {object} Auth Module object.
         */
        loadAuthModule: function() {
            return kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("AuthUIModule");
        },
        postLoginSuccess: function(response) {
            this.loadAuthModule().presentationController.onLoginSuccess(response);
        },
        setContext: function() {
            var authModule = this.loadAuthModule();
            let context = {
                "riskScore": "1",
                "rememberme": "true",
                "successCallback": authModule.presentationController.onLoginSuccess,
                "failureCallback": authModule.presentationController.onLoginFailure
            };
            this.view.loginComponent.setContext(context);
        },
        hidePopupsFunction: function() {},
        onClickAuthoriseYes: function() {
            try {
                kony.application.exit();
            } catch (Error) {
                kony.print("Exception While getting exiting the application  : " + Error);
            }
        },
        /**
         * @function: setAISPConsentUI
         * @description: This function is invoked to set UI for AISP consent flow
         * @private
         */
        setAISPConsentUI: function() {
            this.view.imgAuthorise.src = 'authorise_large.png';
            this.view.lblAuthoriseConsentHeaderKA.text = kony.i18n.getLocalizedString("i18n.login.authoriseConsent");
            let thirdPartyWebsiteName = applicationManager.deeplinkAppName;
            this.view.rtxAuthConsentMsg.text = kony.i18n.getLocalizedString("i18n.login.authorise") + " <b> " + thirdPartyWebsiteName + "</b> " + kony.i18n.getLocalizedString("i18n.login.authoriseAcc");
            this.view.lblAuthConsentMsg1.text = kony.i18n.getLocalizedString("i18n.login.authoriseConsentMsg1");
        },
        /**
         * @function: setPISPConsentUI
         * @description: This function is invoked to set UI for PISP consent flow
         * @private
         */
        setPISPConsentUI: function() {
            this.view.imgAuthorise.src = 'payment_large.png';
            this.view.lblAuthoriseConsentHeaderKA.text = kony.i18n.getLocalizedString("i18n.tppConsent.paymentInitiation");
            let thirdPartyWebsiteName = applicationManager.deeplinkAppName;
            this.view.rtxAuthConsentMsg.text = kony.i18n.getLocalizedString("i18n.tppConsent.authPaymentMsg") + " <b> " + thirdPartyWebsiteName + "</b> ";
            this.view.lblAuthConsentMsg1.text = kony.i18n.getLocalizedString("i18n.tppConsent.paymentConsentRedirectionMsg");
        },
        /**
         * @function: onClickOfAuthoriseCancel
         * @description: This function is invoked on click of Cancel button in Autorise Consent screen
         * @private
         */
        onClickOfAuthoriseCancel: function() {
            this.toggleCancelPopup(true);
        },
        /**
         * @function: onClickOfAuthoriseContinue
         * @description: This function is invoked on click of Continue button
         * @private
         */
        onClickOfAuthoriseContinue: function() {
            this.view.flxAuthoriseConsent.setVisibility(false);
            this.view.flxLogin.setVisibility(true);
        },
    }
});
define("AuthenticationMA/AuthUIModule/frmConsentControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for frmConsent **/
    AS_Form_b4e31cb65068430699615ca83f1acad0: function AS_Form_b4e31cb65068430699615ca83f1acad0(eventobject) {
        var self = this;
        this.init();
    }
});
define("AuthenticationMA/AuthUIModule/frmConsentController", ["AuthenticationMA/AuthUIModule/userfrmConsentController", "AuthenticationMA/AuthUIModule/frmConsentControllerActions"], function() {
    var controller = require("AuthenticationMA/AuthUIModule/userfrmConsentController");
    var controllerActions = ["AuthenticationMA/AuthUIModule/frmConsentControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
