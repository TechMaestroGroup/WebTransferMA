define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmViewPermissionSignatoryGroups", function() {
    return function(controller) {
        function addWidgetsfrmViewPermissionSignatoryGroups() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxMenuContainer": {
                        "width": "100%"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxAckHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "90px",
                "id": "flxAckHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "30dp",
                "width": "95%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckHeader.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxImgContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxImgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgContainer.setDefaultUnit(kony.flex.DP);
            var imgCheck = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgCheck",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "success_green_2.png",
                "top": "5dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgContainer.add(imgCheck);
            var lblSuccessMessage = new kony.ui.Label({
                "id": "lblSuccessMessage",
                "isVisible": true,
                "left": "33dp",
                "skin": "sknLabel42424224pxlight",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.Signatory.GroupDelete\")",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeft.add(flxImgContainer, lblSuccessMessage);
            var flxImgClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxImgClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "92%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "50dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "height": "100%",
                "id": "imgClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgClose.add(imgClose);
            flxAckHeader.add(flxLeft, flxImgClose);
            var lblApprovalMatrixHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Foreign Exchange"
                },
                "centerX": "50%",
                "id": "lblApprovalMatrixHeader",
                "isVisible": true,
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.signatory.viewUserPermission\")",
                "top": "20dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxContractContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "80px",
                "id": "flxContractContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "95%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContractContainer.setDefaultUnit(kony.flex.DP);
            var flxAccountName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountName.setDefaultUnit(kony.flex.DP);
            var lblAccountNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.groupName\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNameValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Checking Account….6737",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountName.add(lblAccountNameHeader, lblAccountNameValue);
            var flxCustomerName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerName.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.customer\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerHeaderValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerHeaderValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Kony India Pvt Limited-kalyani1SB",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerName.add(lblCustomerNameHeader, lblCustomerHeaderValue);
            var flxCustomerID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerID",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerID.setDefaultUnit(kony.flex.DP);
            var lblCustomerIDHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.lblCustomerID\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerIDValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "34256452388",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerID.add(lblCustomerIDHeader, lblCustomerIDValue);
            var flxContract = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxContract",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContract.setDefaultUnit(kony.flex.DP);
            var lblContractHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.contract\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblContractValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Corp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContract.add(lblContractHeader, lblContractValue);
            flxContractContainer.add(flxAccountName, flxCustomerName, flxCustomerID, flxContract);
            var flxApprovalMatrixContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "1400dp",
                "id": "flxApprovalMatrixContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "95%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixContainer.setDefaultUnit(kony.flex.DP);
            var flxUserDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxUserDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserDetails.setDefaultUnit(kony.flex.DP);
            var flxHeaderUserDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxHeaderUserDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderUserDetails.setDefaultUnit(kony.flex.DP);
            var lblUserDetails = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUserDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.UserDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderUserSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderUserSeparator",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "98.50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderUserDetails.add(lblUserDetails, lblHeaderUserSeparator);
            var flxUserDetailsView = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxUserDetailsView",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserDetailsView.setDefaultUnit(kony.flex.DP);
            var flxGroupNameVerify = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20dp",
                "id": "flxGroupNameVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6%",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupNameVerify.setDefaultUnit(kony.flex.DP);
            var flxGroupNameKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxGroupNameKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupNameKey.setDefaultUnit(kony.flex.DP);
            var lblGroupNameKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.bankName\")"
                },
                "id": "lblGroupNameKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.username\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblsemicolonGroupName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.CM.semicolon\")"
                },
                "id": "lblsemicolonGroupName",
                "isVisible": false,
                "left": "5dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGroupNameKey.add(lblGroupNameKey, lblsemicolonGroupName);
            var flxGroupNameVerifyValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxGroupNameVerifyValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupNameVerifyValue.setDefaultUnit(kony.flex.DP);
            var lblGroupNameValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "American Express Credit Card"
                },
                "id": "lblGroupNameValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Senior Managers",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxGroupNameVerifyValue.add(lblGroupNameValue);
            flxGroupNameVerify.add(flxGroupNameKey, flxGroupNameVerifyValue);
            var flxTotalSelectedUsersVerify = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTotalSelectedUsersVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6%",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalSelectedUsersVerify.setDefaultUnit(kony.flex.DP);
            var flxTotalSeelectedUsersKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTotalSeelectedUsersKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalSeelectedUsersKey.setDefaultUnit(kony.flex.DP);
            var lblTotalSeelectedUsersKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.accountType\")"
                },
                "id": "lblTotalSeelectedUsersKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.signatory.userRole\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxTotalSeelectedUsersKey.add(lblTotalSeelectedUsersKey);
            var flxTotalSeelectedUsersValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTotalSeelectedUsersValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalSeelectedUsersValue.setDefaultUnit(kony.flex.DP);
            var lblTotalSeelectedUsersVerifyKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Personal Savings"
                },
                "id": "lblTotalSeelectedUsersVerifyKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "21",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxTotalSeelectedUsersValue.add(lblTotalSeelectedUsersVerifyKey);
            flxTotalSelectedUsersVerify.add(flxTotalSeelectedUsersKey, flxTotalSeelectedUsersValue);
            var flxCustomerNameVerify = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCustomerNameVerify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6%",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerNameVerify.setDefaultUnit(kony.flex.DP);
            var flxCustomerNameVerifyKey = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCustomerNameVerifyKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerNameVerifyKey.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameVerifyKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ACH.accountNumber\")"
                },
                "id": "lblCustomerNameVerifyKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.signatory.approvalPermission\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblsemicolon4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.CM.semicolon\")"
                },
                "id": "lblsemicolon4",
                "isVisible": false,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerNameVerifyKey.add(lblCustomerNameVerifyKey, lblsemicolon4);
            var flxCustomerNameValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCustomerNameValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerNameValue.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameVerifyValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "773663272624427"
                },
                "id": "lblCustomerNameVerifyValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Temenos Ind",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerNameValue.add(lblCustomerNameVerifyValue);
            flxCustomerNameVerify.add(flxCustomerNameVerifyKey, flxCustomerNameValue);
            flxUserDetailsView.add(flxGroupNameVerify, flxTotalSelectedUsersVerify, flxCustomerNameVerify);
            flxUserDetails.add(flxHeaderUserDetails, flxUserDetailsView);
            var flxHeaderContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxHeaderContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "180dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.setDefaultUnit(kony.flex.DP);
            var lblCustomerLevelHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerLevelHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.signatory.viewpermission\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAccountLevelMatrix = new kony.ui.Button({
                "centerY": "50%",
                "height": "30dp",
                "id": "btnAccountLevelMatrix",
                "isVisible": false,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.accountLevelbtn\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTopSepator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblTopSepator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "1dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.add(lblCustomerLevelHeader, lblHeaderSeparator, btnAccountLevelMatrix, lblTopSepator);
            var flxFeatuersContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "77%",
                "id": "flxFeatuersContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "225dp",
                "width": "35%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeatuersContainer.setDefaultUnit(kony.flex.DP);
            var lblFeaturesHeader = new kony.ui.Label({
                "id": "lblFeaturesHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.features\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFeatureSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblFeatureSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "15dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBoxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBoxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "20dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoxSearch.setDefaultUnit(kony.flex.DP);
            var flxSearchimg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSearchimg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15px",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "width": "17px",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchimg.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgSearch",
                "isVisible": true,
                "skin": "slImage",
                "src": "search.png",
                "width": "40dp",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchimg.add(imgSearch);
            var tbxSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxa0a0a0Ssp15px",
                "height": "100%",
                "id": "tbxSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "42px",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.approvals.searchfeaturename\")",
                "right": "40px",
                "secureTextEntry": false,
                "skin": "bbSknTbx949494SSP15pxNormal",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.searchfeaturename\")",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "bbSknTbx949494SSP15pxNormal"
            });
            flxBoxSearch.add(flxSearchimg, tbxSearch);
            var lblSearchSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblSearchSeparator",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "20dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Features = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "88%",
                "id": "Features",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "height": "88%",
                        "top": "10dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFeatuersContainer.add(lblFeaturesHeader, lblFeatureSeparator, flxBoxSearch, lblSearchSeparator, Features);
            var flxApprovalRulesContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "77%",
                "id": "flxApprovalRulesContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "35.10%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "225dp",
                "width": "65%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalRulesContainer.setDefaultUnit(kony.flex.DP);
            var lblViewEditHeader = new kony.ui.Label({
                "id": "lblViewEditHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.signatory.approvalsaccounts\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblViewEditHeaderSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblViewEditHeaderSeparator",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "54dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApprovalMatrixAccountWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxApprovalMatrixAccountWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "49dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixAccountWrapper.setDefaultUnit(kony.flex.DP);
            var segApprovalMatrix = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "groupCells": false,
                "height": "95%",
                "id": "segApprovalMatrix",
                "isVisible": false,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixRow"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixSection"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnEditMatrix": "btnEditMatrix",
                    "flxApprovalMatrixRow": "flxApprovalMatrixRow",
                    "flxApprovalMatrixSection": "flxApprovalMatrixSection",
                    "flxHeaderLowerHalf": "flxHeaderLowerHalf",
                    "flxHeaderUpperHalf": "flxHeaderUpperHalf",
                    "flxLimit1": "flxLimit1",
                    "flxNoRecords": "flxNoRecords",
                    "imgNoRecordsIcon": "imgNoRecordsIcon",
                    "lblApprovalLimits": "lblApprovalLimits",
                    "lblApprovalLimitsValue": "lblApprovalLimitsValue",
                    "lblApprovalNumbers": "lblApprovalNumbers",
                    "lblApprovalRule": "lblApprovalRule",
                    "lblApprovalRuleValue": "lblApprovalRuleValue",
                    "lblApprovers": "lblApprovers",
                    "lblApproversValue": "lblApproversValue",
                    "lblFeatureAction": "lblFeatureAction",
                    "lblNoApprovalRulesDefined": "lblNoApprovalRulesDefined",
                    "lblNumOfApprovers": "lblNumOfApprovers",
                    "lblSeparator1": "lblSeparator1",
                    "lblSeparator2": "lblSeparator2",
                    "lblSeparator3": "lblSeparator3"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoApprovalMatrixData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxNoApprovalMatrixData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "53dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoApprovalMatrixData.setDefaultUnit(kony.flex.DP);
            var lblNoApprovalMatrixData = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblNoApprovalMatrixData",
                "isVisible": true,
                "left": "151dp",
                "skin": "bbSknLbl424242SSP20PxBold",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoApprovalMatrixData.add(lblNoApprovalMatrixData);
            flxApprovalMatrixAccountWrapper.add(segApprovalMatrix, flxNoApprovalMatrixData);
            flxApprovalRulesContainer.add(lblViewEditHeader, lblViewEditHeaderSeparator, flxApprovalMatrixAccountWrapper);
            var lblFeatuesSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "77%",
                "id": "lblFeatuesSeparator",
                "isVisible": true,
                "left": "35%",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "225dp",
                "width": "1dp",
                "zIndex": 15
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBackContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBackContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainer.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "50dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.signatory.BacktoSignatory\")",
                "top": "0",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainer.add(lblBottomSeparator, btnBack);
            flxApprovalMatrixContainer.add(flxUserDetails, flxHeaderContainer, flxFeatuersContainer, flxApprovalRulesContainer, lblFeatuesSeparator, flxBackContainer);
            flxContent.add(flxAckHeader, lblApprovalMatrixHeader, flxDowntimeWarning, flxContractContainer, flxApprovalMatrixContainer);
            flxMain.add(flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "103%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "centerX": "viz.val_cleared",
                        "left": "6dp",
                        "width": "103%"
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxCross": {
                        "right": "11dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "segmentProps": []
                    },
                    "flxGroupNameVerify": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblsemicolonGroupName": {
                        "segmentProps": []
                    },
                    "flxGroupNameVerifyValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblGroupNameValue": {
                        "segmentProps": []
                    },
                    "flxTotalSelectedUsersVerify": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalSeelectedUsersVerifyKey": {
                        "segmentProps": []
                    },
                    "flxCustomerNameVerify": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerifyKey": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCustomerNameVerifyKey": {
                        "text": "Email Address",
                        "segmentProps": []
                    },
                    "lblsemicolon4": {
                        "segmentProps": []
                    },
                    "flxCustomerNameValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerNameVerifyValue": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxImgContainer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "left": {
                            "type": "string",
                            "value": "21px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "40px"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "21px"
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "segmentProps": []
                    },
                    "flxGroupNameVerify": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblsemicolonGroupName": {
                        "segmentProps": []
                    },
                    "flxGroupNameVerifyValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalSelectedUsersVerify": {
                        "bottom": {
                            "type": "number",
                            "value": "15"
                        },
                        "top": {
                            "type": "number",
                            "value": "15"
                        },
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerify": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerifyKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblsemicolon4": {
                        "segmentProps": []
                    },
                    "flxCustomerNameValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "115%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxContent": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxAckHeader": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMatrixContainer": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameVerify": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxGroupNameKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "lblsemicolonGroupName": {
                        "segmentProps": []
                    },
                    "flxTotalSelectedUsersVerify": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxTotalSeelectedUsersKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerify": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerNameVerifyKey": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "lblsemicolon4": {
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "-47dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "104%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.flxMenuContainer": {
                    "width": "100%"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "Features": {
                    "height": "88%",
                    "top": "10dp"
                },
                "customfooternew": {
                    "centerX": "",
                    "left": "6dp",
                    "width": "103%"
                },
                "customfooternew.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup.flxCross": {
                    "right": "11dp"
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmViewPermissionSignatoryGroups,
            "enabledForIdleTimeout": true,
            "id": "frmViewPermissionSignatoryGroups",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_bcc3f4437dfd4def88f75bcbcfa27c97,
            "preShow": function(eventobject) {
                controller.AS_Form_d44a9cb90c76457bbb86931028322813(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ApprovalMatrixMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});