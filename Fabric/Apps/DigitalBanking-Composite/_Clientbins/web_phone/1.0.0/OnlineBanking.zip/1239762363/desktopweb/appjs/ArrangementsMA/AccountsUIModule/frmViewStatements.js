define("ArrangementsMA/AccountsUIModule/frmViewStatements", function() {
    return function(controller) {
        function addWidgetsfrmViewStatements() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var moreActionsDup = new com.InfinityOLB.BillPay.account.accountTypes({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "moreActionsDup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "65%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "350dp",
                "width": "28.48%",
                "zIndex": 10,
                "appName": "BillPayMA",
                "overrides": {
                    "accountTypes": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": false,
                        "left": "65%",
                        "top": "350dp",
                        "width": "28.48%",
                        "zIndex": 10
                    },
                    "flxAccountTypesSegment": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "imgToolTip": {
                        "left": "86.50%",
                        "src": "tool_tip.png"
                    },
                    "segAccountTypes": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "data": [{
                            "lblSeparator": "Separator",
                            "lblUsers": "Pay a Person from"
                        }, {
                            "lblSeparator": "Separator",
                            "lblUsers": "Order Check"
                        }, {
                            "lblSeparator": "Separator",
                            "lblUsers": "Edit Account"
                        }, {
                            "lblSeparator": "Separator",
                            "lblUsers": "Download Statement"
                        }, {
                            "lblSeparator": "Separator",
                            "lblUsers": "Settings & Alerts"
                        }],
                        "maxHeight": "viz.val_cleared",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var breadcrumb = new com.InfinityOLB.Resources.breadcrumb({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "53dp",
                "id": "breadcrumb",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "breadcrumb": {
                        "height": "53dp",
                        "isVisible": false,
                        "top": "0dp"
                    },
                    "btnBreadcrumb1": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.AccountSummary\")"
                    },
                    "btnBreadcrumb2": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountDetails.MAKETRANSFER\")"
                    },
                    "flxBottomBorder": {
                        "bottom": "0dp"
                    },
                    "flxBreadcrumbcontainer": {
                        "centerX": "50%",
                        "height": "50dp",
                        "top": "1dp",
                        "width": "1366dp"
                    },
                    "flxTopBorder": {
                        "isVisible": true,
                        "top": "0dp"
                    },
                    "imgBreadcrumb": {
                        "src": "breadcrumb_icon.png"
                    },
                    "imgBreadcrumb2": {
                        "src": "breadcrumb_icon.png"
                    },
                    "lblBreadcrumb3": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxskncontainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "0",
                "width": "50%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "50%",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            var AllForms = new com.InfinityOLB.BillPay.InfoIcon.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "AllForms",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "51.60%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "290dp",
                "width": "270dp",
                "zIndex": 10,
                "appName": "BillPayMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": false,
                        "left": "51.60%",
                        "top": "290dp",
                        "width": "270dp",
                        "zIndex": 10
                    },
                    "RichTextInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.availableBalance\")"
                    },
                    "flxAccountType": {
                        "top": "-2dp"
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgToolTip": {
                        "left": "125px",
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var moreActions = new com.InfinityOLB.ArrangementsMA.accountTypesMoreActions({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "moreActions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "6%",
                "skin": "slFbox",
                "top": "290dp",
                "width": "28.50%",
                "zIndex": 10,
                "appName": "ArrangementsMA",
                "overrides": {
                    "accountTypesMoreActions": {
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "6%",
                        "top": "290dp",
                        "width": "28.50%",
                        "zIndex": 10
                    },
                    "imgToolTip": {
                        "left": "viz.val_cleared",
                        "right": "22dp",
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var accountActionsMobile = new com.InfinityOLB.ArrangementsMA.accountTypesMoreActions({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountActionsMobile",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "6%",
                "skin": "slFbox",
                "top": "290dp",
                "width": "28.50%",
                "zIndex": 200,
                "appName": "ArrangementsMA",
                "overrides": {
                    "accountTypesMoreActions": {
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "6%",
                        "top": "290dp",
                        "width": "28.50%",
                        "zIndex": 200
                    },
                    "imgToolTip": {
                        "left": "viz.val_cleared",
                        "right": "22dp",
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var quicklinksMobile = new com.InfinityOLB.ArrangementsMA.quicklinks({
                "height": "100%",
                "id": "quicklinksMobile",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 203,
                "appName": "ArrangementsMA",
                "viewType": "quicklinksMobile",
                "overrides": {
                    "quicklinks": {
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var quicklinksMobile_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmViewStatements"] && appConfig.componentMetadata["ArrangementsMA"]["frmViewStatements"]["quicklinksMobile"]) || {};
            quicklinksMobile.link1CTA = quicklinksMobile_data.link1CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinksMobile.sknRow = quicklinksMobile_data.sknRow || "";
            quicklinksMobile.link1Text = quicklinksMobile_data.link1Text || "";
            quicklinksMobile.link2CTA = quicklinksMobile_data.link2CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinksMobile.sknRowSeperator = quicklinksMobile_data.sknRowSeperator || "sknFlxe3e3e3bg";
            quicklinksMobile.link2Text = quicklinksMobile_data.link2Text || "";
            quicklinksMobile.link3CTA = quicklinksMobile_data.link3CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinksMobile.sknLink = quicklinksMobile_data.sknLink || "btnskn4176a415px";
            quicklinksMobile.link3Text = quicklinksMobile_data.link3Text || "";
            quicklinksMobile.link4CTA = quicklinksMobile_data.link4CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinksMobile.sknContainer = quicklinksMobile_data.sknContainer || "sknFlxFFFFFF10Blur4R";
            quicklinksMobile.link4Text = quicklinksMobile_data.link4Text || "";
            quicklinksMobile.link5CTA = quicklinksMobile_data.link5CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinksMobile.link5Text = quicklinksMobile_data.link5Text || "";
            quicklinksMobile.link6CTA = quicklinksMobile_data.link6CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinksMobile.link6Text = quicklinksMobile_data.link6Text || "";
            quicklinksMobile.link7CTA = quicklinksMobile_data.link7CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinksMobile.link7Text = quicklinksMobile_data.link7Text || "";
            quicklinksMobile.link8CTA = quicklinksMobile_data.link8CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinksMobile.link8Text = quicklinksMobile_data.link8Text || "";
            quicklinksMobile.link9CTA = quicklinksMobile_data.link9CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinksMobile.link9Text = quicklinksMobile_data.link9Text || "";
            quicklinksMobile.link10CTA = quicklinksMobile_data.link10CTA || "{   \"level\": \"Parent/Component\",   \"method\": \"\",   \"context\": \"\" }";
            quicklinksMobile.link10Text = quicklinksMobile_data.link10Text || "";
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeading.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblHeader",
                "isVisible": true,
                "left": "6%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.olb.AccountStatements\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnByPass = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "30dp",
                "id": "btnByPass",
                "isVisible": false,
                "left": "320dp",
                "skin": "btnSkipNavigation",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Skiptotransactions\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeading.add(lblHeader, btnByPass);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "bottom": "-10dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "status",
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Our online banking application will be unavailable on 13/04/2017 between 12:00 AM to 4:00 AM while we upgrade our system to provide you a better banking experience.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close Downtime Warning"
                },
                "centerY": "50%",
                "clipBounds": false,
                "height": "75%",
                "id": "flxCloseDowntimeWarning",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "width": "5%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "sknImgPointer5vs",
                "src": "bbcloseicon.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseDowntimeWarning.add(imgCloseDowntimeWarning);
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, flxCloseDowntimeWarning);
            var flxRenewExpired = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "bottom": "-10dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxRenewExpired",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRenewExpired.setDefaultUnit(kony.flex.DP);
            var imgExpired = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgExpired",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRenewExpired = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblRenewExpired",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl424242SSP15Px",
                "text": "Our online banking application will be unavailable on 13/04/2017 between 12:00 AM to 4:00 AM while we upgrade our system to provide you a better banking experience.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnRenew = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "id": "btnRenew",
                "isVisible": true,
                "left": "1.46%",
                "skin": "btnskn4176a415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountDetails.renewConnection\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRenewExpired.add(imgExpired, lblRenewExpired, btnRenew);
            var flxBackNavigation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxBackNavigation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackNavigation.setDefaultUnit(kony.flex.DP);
            var flxImgBackNavigation = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")"
                },
                "clipBounds": true,
                "focusSkin": "flxHoverSkinPointer",
                "height": "100%",
                "id": "flxImgBackNavigation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "360dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxImgBackNavigation.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "14dp",
                "id": "imgBack",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknImgPointer5vs",
                "src": "arrow_right_blue.png",
                "width": "17dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            var lblBack = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "100%",
                "id": "lblBack",
                "isVisible": true,
                "left": "14dp",
                "skin": "sknSSP4176a415px",
                "text": "Back",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgBackNavigation.add(imgBack, lblBack);
            flxBackNavigation.add(flxImgBackNavigation);
            var flxViewStatements = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxViewStatements",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "minHeight": "240dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewStatements.setDefaultUnit(kony.flex.DP);
            var ViewStatements = new com.InfinityOLB.ArrangementsMA.accountViewStatements({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "ViewStatements",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "accountViewStatements": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "confirmButtons": {
                        "top": "100dp"
                    },
                    "confirmButtons.btnConfirm": {
                        "height": "40dp"
                    },
                    "confirmButtons.btnModify": {
                        "height": "40dp"
                    },
                    "flxAccountSelectedValue": {
                        "isVisible": false
                    },
                    "flxSelectReasonForDispute": {
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            ViewStatements.confirmButtons.btnConfirm.onClick = controller.AS_Button_ff419d5f54fc4dd79ab16a57111df44f;
            ViewStatements.confirmButtons.btnModify.onClick = controller.AS_Button_i62bb1c54183425ea77c496909a49dda;
            var viewStatementsnew = new com.InfinityOLB.ArrangementsMA.viewStatetements({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "viewStatementsnew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "SegmentMonthWiseFiles1": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "btnAdhocStatements": {
                        "height": "40dp",
                        "isVisible": false,
                        "top": "12dp"
                    },
                    "btnCombinedStatements": {
                        "height": "50dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.olb.ViewCombinedStatement\")",
                        "top": "23dp",
                        "width": "300dp"
                    },
                    "btnConfirm": {
                        "bottom": "viz.val_cleared",
                        "height": "50dp",
                        "width": "21.40%"
                    },
                    "btnEStatements": {
                        "height": "50dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.olb.ViewEStatements\")",
                        "isVisible": false,
                        "left": "29dp",
                        "top": "20dp",
                        "width": "300dp"
                    },
                    "flexDataMonth1": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flexDataMonth12": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flexDataMonth2": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flexDataMonth3": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flexDataMonth4": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxAdhocInfoMessage": {
                        "isVisible": true,
                        "width": "100%"
                    },
                    "flxAdhocStatements": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": false,
                        "left": "31dp"
                    },
                    "flxAdhocWarnMsg": {
                        "isVisible": true,
                        "left": "33dp",
                        "top": "20dp",
                        "width": "1160dp"
                    },
                    "flxAdhocWarningMessage": {
                        "height": "481dp",
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxCombinedStatements": {
                        "height": "220dp",
                        "isVisible": false,
                        "left": "31dp",
                        "width": "100%"
                    },
                    "flxDisclaimerInfo": {
                        "centerX": "viz.val_cleared",
                        "height": "65px",
                        "left": "33dp",
                        "right": "viz.val_cleared",
                        "top": "35dp",
                        "width": "100%"
                    },
                    "flxDownload": {
                        "height": "220dp",
                        "left": "9dp",
                        "right": "viz.val_cleared",
                        "top": "7dp",
                        "width": "100%"
                    },
                    "flxFileDownload": {
                        "height": "220dp",
                        "left": "33dp",
                        "top": "35dp",
                        "width": "100%"
                    },
                    "flxFileType": {
                        "height": "220dp",
                        "left": "9dp",
                        "top": "7dp",
                        "width": "100%"
                    },
                    "flxInfoIcon": {
                        "height": "30dp",
                        "left": "9dp",
                        "top": "7dp",
                        "width": "30dp"
                    },
                    "flxInfoImage": {
                        "centerY": "viz.val_cleared",
                        "height": "220dp",
                        "left": "9dp",
                        "top": "7dp",
                        "width": "100%"
                    },
                    "flxInfoImage1": {
                        "left": "9dp"
                    },
                    "flxLine": {
                        "height": "220dp",
                        "left": "0dp",
                        "top": "-1dp",
                        "width": "100%"
                    },
                    "flxLine1": {
                        "height": "220dp",
                        "left": "21dp",
                        "width": "100%"
                    },
                    "flxMain": {
                        "clipBounds": false,
                        "isVisible": false
                    },
                    "flxMainWrapper": {
                        "clipBounds": false,
                        "zIndex": 10
                    },
                    "flxMonthsData": {
                        "clipBounds": false
                    },
                    "flxPaginationContainer": {
                        "left": 70
                    },
                    "flxStatementsTab": {
                        "height": "220dp",
                        "left": "4dp"
                    },
                    "flxWarnInfoImage": {
                        "height": "220dp",
                        "left": "9dp",
                        "top": "7dp",
                        "width": "100%"
                    },
                    "flxWarningMessage": {
                        "height": "220dp",
                        "isVisible": true,
                        "left": "33dp",
                        "top": "35dp",
                        "width": "100%"
                    },
                    "flxlblMonth12Separator": {
                        "height": "1dp",
                        "top": 10
                    },
                    "imgAdhocInfoMessage": {
                        "height": "150dp",
                        "left": "67dp",
                        "src": "info_large.png",
                        "top": "3dp",
                        "width": "150dp"
                    },
                    "imgDownload": {
                        "height": "150dp",
                        "left": "67dp",
                        "right": "viz.val_cleared",
                        "src": "imagedrag.png",
                        "top": "3dp",
                        "width": "150dp"
                    },
                    "imgFileType": {
                        "height": "150dp",
                        "left": "67dp",
                        "src": "imagedrag.png",
                        "top": "3dp",
                        "width": "150dp"
                    },
                    "imgInfoMessage": {
                        "height": "150dp",
                        "left": "67dp",
                        "src": "imagedrag.png",
                        "top": "3dp",
                        "width": "150dp"
                    },
                    "imgSortDate": {
                        "src": "sorting_next_3.png"
                    },
                    "imgWarnInfoMessage": {
                        "height": "150dp",
                        "left": "67dp",
                        "src": "imagedrag.png",
                        "top": "3dp",
                        "width": "150dp"
                    },
                    "infoIcon": {
                        "height": "150dp",
                        "left": "67dp",
                        "src": "info_blue.png",
                        "top": "3dp",
                        "width": "150dp"
                    },
                    "lblAdhocInfoMessage": {
                        "left": "50dp"
                    },
                    "lblDisclaimer": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "left": "85dp",
                        "right": "viz.val_cleared",
                        "text": "Label",
                        "top": "24dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblDisclaimerInfo": {
                        "bottom": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "left": "85dp",
                        "right": "viz.val_cleared",
                        "top": "24dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblDownload": {
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.olb.ViewStatementDownload\")",
                        "left": "1141dp",
                        "right": "viz.val_cleared",
                        "top": "35dp"
                    },
                    "lblGeneratedOnDate": {
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "left": "85dp",
                        "text": "Label",
                        "top": "24dp"
                    },
                    "lblInfoMessage": {
                        "bottom": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "left": "85dp",
                        "right": "viz.val_cleared",
                        "top": "24dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblMonth1": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblViewStatements": {
                        "isVisible": true
                    },
                    "lbnFileName": {
                        "left": "79dp",
                        "text": "Label",
                        "top": "52dp"
                    },
                    "segStatements": {
                        "left": "20dp",
                        "right": "20dp",
                        "width": "97%"
                    },
                    "viewStatetements": {
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxViewStatements.add(ViewStatements, viewStatementsnew);
            var flxTransactions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxTransactions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactions.setDefaultUnit(kony.flex.DP);
            var btnByPass2 = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "50dp",
                "id": "btnByPass2",
                "isVisible": false,
                "left": "0",
                "skin": "btnSkipNavigation",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountDetails.SkiptoPaymentOptions\")",
                "top": "0",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var transactions = new com.InfinityOLB.ArrangementsMA.accountTransactions({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "transactions",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "6%",
                "skin": "CopyslFbox0b1b9a37007eb4bmod",
                "top": "0dp",
                "zIndex": 1,
                "appName": "ArrangementsMA",
                "overrides": {
                    "accountTransactions": {
                        "isVisible": false,
                        "left": "6%",
                        "right": "6%",
                        "top": "0dp",
                        "width": "viz.val_cleared"
                    },
                    "btnAllChecking": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ALL\")"
                    },
                    "btnAllCredit": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ALL\")"
                    },
                    "btnAllDeposit": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ALL\")"
                    },
                    "btnAllLoan": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ALL\")"
                    },
                    "btnCancel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")"
                    },
                    "btnChecksChecking": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.checks\")"
                    },
                    "btnClearSearch": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.CLEARSEARCH\")"
                    },
                    "btnDepositDeposit": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.deposits\")"
                    },
                    "btnDepositsChecking": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.deposits\")"
                    },
                    "btnInterestDeposit": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.INTEREST\")"
                    },
                    "btnModifySearch": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.MODIFYSEARCH\")"
                    },
                    "btnPaymentsCredit": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.PAYMENTS\")"
                    },
                    "btnPurchasesCredit": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.PURCHASES\")"
                    },
                    "btnSearch": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                    },
                    "btnTransfersChecking": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.hamburger.transfers\")"
                    },
                    "btnWithdrawDeposit": {
                        "text": "Withdraw"
                    },
                    "btnWithdrawsChecking": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.withdrawls\")"
                    },
                    "flxAmountRangeTo": {
                        "clipBounds": false
                    },
                    "flxDownload": {
                        "isVisible": true
                    },
                    "flxHeader": {
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "flxNoTransactions": {
                        "clipBounds": false,
                        "isVisible": false
                    },
                    "flxPagination": {
                        "isVisible": true
                    },
                    "flxPaginationWrapper": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "clipBounds": false,
                        "right": "0dp",
                        "width": "25%"
                    },
                    "flxRightSearchWrapper": {
                        "left": "0dp"
                    },
                    "flxSearchContainer": {
                        "clipBounds": false,
                        "isVisible": false,
                        "top": "0dp",
                        "zIndex": 1
                    },
                    "flxSearchResults": {
                        "clipBounds": false,
                        "isVisible": false,
                        "zIndex": 1
                    },
                    "flxSegmentContainer": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": false,
                        "top": "0dp"
                    },
                    "flxSeparator": {
                        "isVisible": false
                    },
                    "flxSort": {
                        "clipBounds": false
                    },
                    "flxSortBalance": {
                        "right": "1.94%"
                    },
                    "flxSortDate": {
                        "left": "6%"
                    },
                    "flxTabsChecking": {
                        "isVisible": true
                    },
                    "flxTabsCredit": {
                        "clipBounds": false
                    },
                    "flxTabsDeposit": {
                        "clipBounds": false,
                        "isVisible": false
                    },
                    "flxTabsLoan": {
                        "clipBounds": false,
                        "isVisible": false
                    },
                    "imgCancel": {
                        "src": "search_close.png"
                    },
                    "imgCancelAmountRange": {
                        "src": "search_close.png"
                    },
                    "imgCancelAmountRangeM": {
                        "src": "search_close.png"
                    },
                    "imgCancelCheckNumber": {
                        "src": "search_close.png"
                    },
                    "imgCancelCheckNumberM": {
                        "src": "search_close.png"
                    },
                    "imgCancelDateRange": {
                        "src": "search_close.png"
                    },
                    "imgCancelDateRangeM": {
                        "src": "search_close.png"
                    },
                    "imgCancelM": {
                        "src": "search_close.png"
                    },
                    "imgCancelType": {
                        "src": "search_close.png"
                    },
                    "imgCancelTypeM": {
                        "src": "search_close.png"
                    },
                    "imgDownload": {
                        "src": "download_blue.png"
                    },
                    "imgInfo": {
                        "src": "info_large.png"
                    },
                    "imgPaginationFirst": {
                        "src": "pagination_inactive.png"
                    },
                    "imgPaginationLast": {
                        "src": "pagination_next_active.png"
                    },
                    "imgPaginationNext": {
                        "src": "pagination_next_active.png"
                    },
                    "imgPaginationPrevious": {
                        "src": "pagination_back_inactive.png"
                    },
                    "imgPrint": {
                        "src": "print_blue.png"
                    },
                    "imgSearch": {
                        "src": "search_blue.png"
                    },
                    "imgSortAmount": {
                        "src": "sorting.png"
                    },
                    "imgSortBalance": {
                        "isVisible": true,
                        "src": "not_applied_sort.png"
                    },
                    "imgSortCategory": {
                        "src": "sorting.png"
                    },
                    "imgSortDate": {
                        "src": "sorting_next.png"
                    },
                    "imgSortDescription": {
                        "src": "not_applied_sort.png"
                    },
                    "imgSortType": {
                        "src": "not_applied_sort.png"
                    },
                    "lblAmountRangeTitle": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.AmountRange\")"
                    },
                    "lblByAmountRange": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ByAmountRange\")"
                    },
                    "lblByCheckNumber": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ByCheckNumber\")",
                        "top": "30dp"
                    },
                    "lblByDate": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ByDate\")"
                    },
                    "lblByKeyword": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ByKeyword\")"
                    },
                    "lblByTimePeriod": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ByTimePeriod\")"
                    },
                    "lblByTransactionType": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ByTransactionType\")"
                    },
                    "lblCheckNumberTitle": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopcheckPayments.CheckNumber\")"
                    },
                    "lblDateRangeTitle": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.DateRange\")"
                    },
                    "lblKeywordTitle": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.keyword\")"
                    },
                    "lblKeywordValue": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.ATT\")"
                    },
                    "lblPagination": {
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.10001000of1000Transactions\")",
                        "left": "4dp",
                        "top": "0",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblSortAmount": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.amountlabel\")"
                    },
                    "lblSortBalance": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Balance\")"
                    },
                    "lblSortDate": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Date\")"
                    },
                    "lblSortDescription": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.pfm.desc\")"
                    },
                    "lblSortType": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.Type\")"
                    },
                    "lblTransactions": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.transactions\")",
                        "left": "0dp"
                    },
                    "lblTypeTitle": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Type\")"
                    },
                    "lblTypeValue": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.allTransactions\")"
                    },
                    "lblYouHaveSearchedFor": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Youhavesearchedfor\")"
                    },
                    "txtCheckNumberFrom": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.ChequeNumber\")"
                    },
                    "txtCheckNumberTo": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.ChequeNumber\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            transactions.btnAllChecking.onClick = controller.AS_Button_i644b6acbbf74d088da18b0d86a938ce;
            transactions.btnAllCredit.onClick = controller.AS_Button_d9436b55edd84749b4a69a0d1cba0173;
            transactions.btnAllDeposit.onClick = controller.AS_Button_f68b4f622da44efb9dc7244f1effaf10;
            transactions.btnAllLoan.onClick = controller.AS_Button_c5a16c9854e442489a5a950f6a1b1a1c;
            transactions.btnChecksChecking.onClick = controller.AS_Button_j374008686304bbe97a227779c029e49;
            transactions.btnDepositDeposit.onClick = controller.AS_Button_f325328e3c614ba49f2d81d43f61989e;
            transactions.btnDepositsChecking.onClick = controller.AS_Button_ha1e0734192245909f32940ab875c29b;
            transactions.btnInterestDeposit.onClick = controller.AS_Button_bfe0fc729d9045a29f6dca8a30ff7572;
            transactions.btnPaymentsCredit.onClick = controller.AS_Button_a2c9e7a7441c43e3bf40d69548b757c1;
            transactions.btnPurchasesCredit.onClick = controller.AS_Button_i5e5f380a10449ec87c9701b1d50556f;
            transactions.btnTransfersChecking.onClick = controller.AS_Button_e292a3acfddc41158ec976692e35175d;
            transactions.btnWithdrawDeposit.onClick = controller.AS_Button_c74de6e605b64d83891d1300e02b5893;
            transactions.btnWithdrawsChecking.onClick = controller.AS_Button_a0123e8f394b40c5a0d68536bad77a07;
            var accountTransactionList = new com.InfinityMB.ArrangementsMA.accountTransactionList({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountTransactionList",
                "isVisible": false,
                "left": "6.40%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "right": "6.40%",
                "skin": "slFbox",
                "top": "0dp",
                "appName": "ArrangementsMA",
                "viewType": "accountTransactionList",
                "overrides": {
                    "accountTransactionList": {
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var accountTransactionList_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmViewStatements"] && appConfig.componentMetadata["ArrangementsMA"]["frmViewStatements"]["accountTransactionList"]) || {};
            accountTransactionList.filterTab1 = accountTransactionList_data.filterTab1 || "{\"Savings\":{\"title\":{\"640\":\"All\",\"default\":\"All\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Checking\":{\"title\":{\"640\":\"All\",\"default\":\"All\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"CreditCard\":{\"title\":{\"640\":\"All\",\"default\":\"Alll\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Loan\":{\"title\":{\"640\":\"All Transactions\",\"default\":\"All Transactions\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Deposit\":{\"title\":{\"640\":\"All\",\"default\":\"All\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Mortgage\":{\"title\":{\"640\":\"All Transactions\",\"default\":\"All Transactions\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"mortgageFacility\":{\"title\":{\"640\":\"All Transactions\",\"default\":\"All Transactions\"},\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}}}";
            accountTransactionList.field1Label = accountTransactionList_data.field1Label || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate}:\",\"default\":\"{i.i18n.transfers.transactionDate}:\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate}:\",\"default\":\"{i.i18n.transfers.transactionDate}:\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate}:\",\"default\":\"{i.i18n.transfers.transactionDate}:\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}},\"CreditCard\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}},\"mortgageFacility\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"},\"ST1\":{\"640\":\"{i.i18n.transfers.transactionDate} :\",\"default\":\"{i.i18n.transfers.transactionDate} :\"}}}}";
            accountTransactionList.TLobjectServiceName = accountTransactionList_data.TLobjectServiceName || "Holdings";
            accountTransactionList.blockTitle = accountTransactionList_data.blockTitle || "Transactions";
            accountTransactionList.sknFilterActiveTab = accountTransactionList_data.sknFilterActiveTab || "sknBtnSSP42424217PxSelectedTab";
            accountTransactionList.sknMBFieldValueBig = accountTransactionList_data.sknMBFieldValueBig || "ICSknSSP42424213Px";
            accountTransactionList.searchLabel1 = accountTransactionList_data.searchLabel1 || "By Keyword:";
            accountTransactionList.iconSearch = accountTransactionList_data.iconSearch || "{\"img\": \"search_blue.png\"}";
            accountTransactionList.amountFormat = accountTransactionList_data.amountFormat || "{ \"locale\":\"\", \"positiveFormat\" : \"{CS}{D}\", \"negativeFormat\" : \"-{CS}{D}\", \"fractionDigits\":\"2\"}";
            accountTransactionList.transactionListArray = accountTransactionList_data.transactionListArray || "{$.S1.Transactions}";
            accountTransactionList.dataGridColumn1 = accountTransactionList_data.dataGridColumn1 || "{\"Savings\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Deposit\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"CreditCard\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"15%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Mortgage\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"mortgageFacility\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"sortBy\":\"transactionDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"}}";
            accountTransactionList.mobileDataGridField1 = accountTransactionList_data.mobileDataGridField1 || "{\"Savings\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Account Number\",\"width\":\"100%\"},\"Checking\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"Deposit\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"CreditCard\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"Loan\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"Mortgage\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"mortgageFacility\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"100%\"}}";
            accountTransactionList.TLaccountId = accountTransactionList_data.TLaccountId || "{$.c.accountID}";
            accountTransactionList.tab6ObjectServiceName = accountTransactionList_data.tab6ObjectServiceName || "Holdings";
            accountTransactionList.checkNumberField = accountTransactionList_data.checkNumberField || "Field 3";
            accountTransactionList.filterValueTab1 = accountTransactionList_data.filterValueTab1 || "{\"Savings\":{\"transactionsTypes\":\"All\"},\"Checking\":{\"transactionsTypes\":\"All\"},\"CreditCard\":{\"transactionsTypes\":\"All\"},\"Loan\":{\"transactionsTypes\":\"All\"},\"Deposit\":{\"transactionsTypes\":\"All\"},\"Mortgage\":{\"transactionsTypes\":\"All\"},\"mortgageFacility\":{\"transactionsTypes\":\"All\"}}";
            accountTransactionList.GAserviceEnable = accountTransactionList_data.GAserviceEnable || true;
            accountTransactionList.isBackendPropEnabled = accountTransactionList_data.isBackendPropEnabled || true;
            accountTransactionList.cacheTotalRecords = accountTransactionList_data.cacheTotalRecords || "{$.c.transactionsCount}";
            accountTransactionList.tab6ObjectName = accountTransactionList_data.tab6ObjectName || "{\"Savings\":{\"objectName\":\"BlockFunds\"},\"Checking\":{\"objectName\":\"BlockFunds\"},\"Loan\":{\"objectName\":\"TransactionsList\"},\"mortgageFacility\":{\"objectName\":\"TransactionsList\"}}";
            accountTransactionList.TLaccountType = accountTransactionList_data.TLaccountType || "{$.c.accountType}";
            accountTransactionList.filterTab2 = accountTransactionList_data.filterTab2 || "{\"Savings\":{\"title\":\"{i.i18n.hamburger.transfers}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Transfers\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Checking\":{\"title\":\"{i.i18n.hamburger.transfers}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Transfers\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"CreditCard\":{\"title\":\"{i.i18n.hamburger.transfers}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Transfers\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Deposit\":{\"title\":\"{i.i18n.hamburger.transfers}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Transfers\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}}}";
            accountTransactionList.field1Value = accountTransactionList_data.field1Value || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}},\"mortgageFacility\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"},\"ST1\":{\"640\":\"{$.L1.postedDate}\",\"default\":\"{$.L1.postedDate}\"}}}}";
            accountTransactionList.TLobjectName = accountTransactionList_data.TLobjectName || "TransactionsList";
            accountTransactionList.transDetailsVisibility = accountTransactionList_data.transDetailsVisibility || true;
            accountTransactionList.sknFilterActiveTabHover = accountTransactionList_data.sknFilterActiveTabHover || "sknBtnSSP42424217PxSelectedTabHover";
            accountTransactionList.sknMBFieldValueSmall = accountTransactionList_data.sknMBFieldValueSmall || "ICSknSSP9b9b9b13Px";
            accountTransactionList.searchLabel2 = accountTransactionList_data.searchLabel2 || "By Transaction Type:";
            accountTransactionList.iconDownload = accountTransactionList_data.iconDownload || "";
            accountTransactionList.dateFormat = accountTransactionList_data.dateFormat || "m/d/Y";
            accountTransactionList.transactionListIdentifier = accountTransactionList_data.transactionListIdentifier || "L1";
            accountTransactionList.dataGridColumn2 = accountTransactionList_data.dataGridColumn2 || "{\"Savings\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Account Number\",\"width\":\"30%\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"Deposit\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"CreditCard\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"Mortgage\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"mortgageFacility\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"description\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"}}";
            accountTransactionList.mobileDataGridField2 = accountTransactionList_data.mobileDataGridField2 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Checking\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Deposit\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"CreditCard\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Loan\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Mortgage\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"mortgageFacility\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"amount\",\"currencyCode\":\"{$.L1.transactionCurrency}\"}}";
            accountTransactionList.swiftTransactionField = accountTransactionList_data.swiftTransactionField || "Field 2";
            accountTransactionList.filterValueTab2 = accountTransactionList_data.filterValueTab2 || "{\"Savings\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"Checking\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"CreditCard\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"Loan\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"Deposit\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"Mortgage\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]},\"mortgageFacility\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Transfers\"]}}";
            accountTransactionList.GAobjectServiceName = accountTransactionList_data.GAobjectServiceName || "DocumentManagement";
            accountTransactionList.filterTab3 = accountTransactionList_data.filterTab3 || "{\"Savings\":{\"title\":\"{i.i18n.accounts.deposits}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Deposits\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Checking\":{\"title\":\"{i.i18n.accounts.deposits}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Deposits\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"CreditCard\":{\"title\":\"{i.i18n.accounts.deposits}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Deposits\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Deposit\":{\"title\":\"{i.i18n.accounts.deposits}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Deposits\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}}}";
            accountTransactionList.field1Type = accountTransactionList_data.field1Type || "{\"Savings\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}},\"Checking\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}},\"Loan\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}},\"Deposit\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}},\"Mortgage\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}},\"mortgageFacility\":{\"ST2\":{\"640\":\"date\",\"default\":\"date\"},\"ST1\":{\"640\":\"date\",\"default\":\"date\"}}}";
            accountTransactionList.TLoperationName = accountTransactionList_data.TLoperationName || "getRecent";
            accountTransactionList.sknFilterInactiveTab = accountTransactionList_data.sknFilterInactiveTab || "sknBtnSSP72727217PxUnSelectedTab";
            accountTransactionList.sknMBTransactionDetailsLabel = accountTransactionList_data.sknMBTransactionDetailsLabel || "ICSknSSP72727213Px";
            accountTransactionList.searchLabel3 = accountTransactionList_data.searchLabel3 || "By Time Period:";
            accountTransactionList.iconPrint = accountTransactionList_data.iconPrint || "{\"img\": \"print_blue.png\"}";
            accountTransactionList.backendDateFormat = accountTransactionList_data.backendDateFormat || "Y-m-d";
            accountTransactionList.dataGridColumn3 = accountTransactionList_data.dataGridColumn3 || "{\"Savings\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"CreditCard\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"Mortgage\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"},\"mortgageFacility\":{\"title\":\"{i.i18n.common.Type}\",\"mapping\":\"transactionType\",\"fieldType\":\"Label\",\"width\":\"15%\",\"alignment\":\"left\"}}";
            accountTransactionList.segregationDecider = accountTransactionList_data.segregationDecider || "statusDescription";
            accountTransactionList.mobileDataGridField3 = accountTransactionList_data.mobileDataGridField3 || "{\"Savings\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"Checking\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"Deposit\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"CreditCard\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"Loan\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"Mortgage\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"},\"mortgageFacility\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.L1.transactionDate}\",\"fieldType\":\"date\",\"width\":\"140dp\",\"sortBy\":\"transactionDate\"}}";
            accountTransactionList.tab6OperationName = accountTransactionList_data.tab6OperationName || "{\"Savings\":{\"operationName\":\"getList\"},\"Checking\":{\"operationName\":\"getList\"},\"Loan\":{\"operationName\":\"getRecent\"},\"mortgageFacility\":{\"operationName\":\"getRecent\"}}";
            accountTransactionList.TLenableForSearch = accountTransactionList_data.TLenableForSearch || true;
            accountTransactionList.sknHyperlink = accountTransactionList_data.sknHyperlink || "ICSknLbl33659113Px";
            accountTransactionList.filterValueTab3 = accountTransactionList_data.filterValueTab3 || "{\"Savings\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]},\"Checking\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]},\"CreditCard\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]},\"Loan\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]},\"Deposit\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]},\"Mortgage\":{\"transactionsTypes\":[\"InternalTransfer\",\"ExternalTransfer\",\"P2P\",\"Deposit\",\"Interest\"]}}";
            accountTransactionList.GAobjectName = accountTransactionList_data.GAobjectName || "CustomerAdvice";
            accountTransactionList.tab6Criteria = accountTransactionList_data.tab6Criteria || "{\"Savings\":{\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":20,\"isScheduled\":\"false\",\"order\":\"desc\"}},\"Checking\":{\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":20,\"isScheduled\":\"false\",\"order\":\"desc\"}},\"Loan\":{\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"LoanSchedule\",\"offset\":0,\"limit\":20,\"isScheduled\":\"false\",\"order\":\"desc\"}},\"mortgageFacility\":{\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"LoanSchedule\",\"offset\":0,\"limit\":20,\"isScheduled\":\"false\",\"order\":\"desc\"}}}";
            accountTransactionList.sknFilterInactiveTabHover = accountTransactionList_data.sknFilterInactiveTabHover || " sknBtnSSP72727217PxUnSelectedTabHover";
            accountTransactionList.filterTab4 = accountTransactionList_data.filterTab4 || "{\"Savings\":{\"title\":\"{i.i18n.accounts.checks}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Checks\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Checking\":{\"title\":\"{i.i18n.accounts.checks}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Checks\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"CreditCard\":{\"title\":\"{i.i18n.accounts.checks}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Checks\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Deposit\":{\"title\":\"{i.i18n.accounts.checks}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Checks\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}}}";
            accountTransactionList.field2Label = accountTransactionList_data.field2Label || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"CreditCard\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}},\"mortgageFacility\":{\"text\":{\"ST2\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"},\"ST1\":{\"640\":\"{i.i18n.konybb.common.ReferenceNumber} :\",\"default\":\"{i.i18n.konybb.common.ReferenceNumber} :\"}}}}";
            accountTransactionList.TLcriteria = accountTransactionList_data.TLcriteria || "{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"All\",\"offset\":0,\"limit\":20,\"isScheduled\":\"false\",\"order\":\"desc\"}";
            accountTransactionList.sknMBTransactionDetailsValue = accountTransactionList_data.sknMBTransactionDetailsValue || "ICSknSSP42424213Px";
            accountTransactionList.searchLabel4 = accountTransactionList_data.searchLabel4 || "By Check Number:";
            accountTransactionList.iconRowExpand = accountTransactionList_data.iconRowExpand || "{\"vizIcon\": \"O\", \"skin\": \"ICSknBtnIconOther\"}";
            accountTransactionList.dataGridColumn4 = accountTransactionList_data.dataGridColumn4 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Checking\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Deposit\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"CreditCard\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Loan\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Mortgage\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"mortgageFacility\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"amount\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"amount\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"}}";
            accountTransactionList.segregationTypes = accountTransactionList_data.segregationTypes || "{\"ST1\":{\"value\":\"Pending\",\"displayText\":\"Pending\"}, \"ST2\":{\"value\":\"Successful\",\"displayText\":\"Posted\"}, \"ST3\":{\"value\":\"due\",\"displayText\":\"Overdue Installments\"}, \"ST4\":{\"value\":\"paid\",\"displayText\":\"Paid Installments\"}}";
            accountTransactionList.filterValueTab4 = accountTransactionList_data.filterValueTab4 || "{\"Savings\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]},\"Checking\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]},\"CreditCard\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]},\"Loan\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]},\"Deposit\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]},\"Mortgage\":{\"transactionsTypes\":[\"CheckWithdrawal\",\"Draft\",\"Cheque\"]}}";
            accountTransactionList.GAoperationName = accountTransactionList_data.GAoperationName || "generate";
            accountTransactionList.sknTableHeader = accountTransactionList_data.sknTableHeader || "sknFlexF9F9F9";
            accountTransactionList.filterTab5 = accountTransactionList_data.filterTab5 || "{\"Savings\":{\"title\":\"{i.i18n.accounts.withdrawls}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Withdrawals\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"Checking\":{\"title\":\"{i.i18n.accounts.withdrawls}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Withdrawals\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true}},\"CreditCard\":{\"title\":\"{i.i18n.accounts.withdrawls}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Withdrawals\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}},\"Deposit\":{\"title\":\"{i.i18n.accounts.withdrawls}\",\"requestPayoad\":{\"accountID\":\"{$.c.accountID}\",\"transactionType\":\"Withdrawals\",\"offset\":0,\"limit\":10,\"isScheduled\":\"false\",\"order\":\"desc\"},\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":false,\"column4\":true,\"column5\":true}}}";
            accountTransactionList.field2Value = accountTransactionList_data.field2Value || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}},\"mortgageFacility\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"},\"ST1\":{\"640\":\"{$.L1.transactionId}\",\"default\":\"{$.L1.transactionId}\"}}}}";
            accountTransactionList.tab6ServiceResponseIdentifier = accountTransactionList_data.tab6ServiceResponseIdentifier || "S2";
            accountTransactionList.searchLabel5 = accountTransactionList_data.searchLabel5 || "By Amount Range:";
            accountTransactionList.iconRowCollapse = accountTransactionList_data.iconRowCollapse || "{\"vizIcon\": \"P\", \"skin\": \"ICSknBtnIconOther\"}";
            accountTransactionList.percentageFormat = accountTransactionList_data.percentageFormat || "";
            accountTransactionList.dataGridColumn5 = accountTransactionList_data.dataGridColumn5 || "{\"Savings\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Checking\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Deposit\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"CreditCard\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Loan\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"Mortgage\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"},\"mortgageFacility\":{\"title\":\"{i.i18n.AccountsDetails.Balance}\",\"mapping\":\"fromAccountBalance\",\"fieldType\":\"amount\",\"width\":\"15%\",\"alignment\":\"right\",\"currencyCode\":\"{$.L1.transactionCurrency}\"}}";
            accountTransactionList.dataAvailability = accountTransactionList_data.dataAvailability || "Service calls by component";
            accountTransactionList.filterValueTab5 = accountTransactionList_data.filterValueTab5 || "{\"Savings\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]},\"Checking\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]},\"CreditCard\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]},\"Loan\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]},\"Deposit\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]},\"Mortgage\":{\"transactionsTypes\":[\"Withdrawal\",\"BillPay\"]}}";
            accountTransactionList.GAcriteria = accountTransactionList_data.GAcriteria || "{\"customerId\":\"{$.c.customerId}\",\"transactionId\":\"{$.c.transactionId}\"}";
            accountTransactionList.sknTableHeaderText = accountTransactionList_data.sknTableHeaderText || "ICSknLblSSP42424215px";
            accountTransactionList.field2Type = accountTransactionList_data.field2Type || "{\"Savings\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Checking\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Loan\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Deposit\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Mortgage\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"mortgageFacility\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}}}";
            accountTransactionList.searchLabel6 = accountTransactionList_data.searchLabel6 || "Date Range:";
            accountTransactionList.currencyCode = accountTransactionList_data.currencyCode || "{$.c.currencyCode}";
            accountTransactionList.dataGridColumn6 = accountTransactionList_data.dataGridColumn6 || "";
            accountTransactionList.tab6Title = accountTransactionList_data.tab6Title || "{\"Savings\":{\"title\":\"{i.i18n.accounts.blockedFunds}\",\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true},\"entitlement_keys\":[]},\"Checking\":{\"title\":\"{i.i18n.accounts.blockedFunds}\",\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true},\"entitlement_keys\":[]},\"Loan\":{\"title\":\"{i.i18n.AccountsDetails.loanSchedule}\",\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true},\"entitlement_keys\":[\"VIEW_LOAN_SCHEDULE\"]},\"mortgageFacility\":{\"title\":\"{i.i18n.AccountsDetails.loanSchedule}\",\"ColumnVisiblity\":{\"column1\":true,\"column2\":true,\"column3\":true,\"column4\":true,\"column5\":true},\"entitlement_keys\":[]}}";
            accountTransactionList.TLserviceResponseIdentifier = accountTransactionList_data.TLserviceResponseIdentifier || "S1";
            accountTransactionList.tab6TransactionListArray = accountTransactionList_data.tab6TransactionListArray || "{$.S2.Transactions}";
            accountTransactionList.sknPendingLabel = accountTransactionList_data.sknPendingLabel || "ICSknLblPendingTransactionsSemiBold";
            accountTransactionList.field3Label = accountTransactionList_data.field3Label || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"CreditCard\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}}}";
            accountTransactionList.val1PlaceHolder = accountTransactionList_data.val1PlaceHolder || "Type Keyword";
            accountTransactionList.tab6DataGridColumn1 = accountTransactionList_data.tab6DataGridColumn1 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.common.ReferenceNumber}\",\"mapping\":\"{$.S2.transactionReference}\",\"fieldType\":\"Label\",\"width\":\"25%\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.i18n.konybb.common.ReferenceNumber}\",\"mapping\":\"{$.S2.transactionReference}\",\"fieldType\":\"Label\",\"width\":\"25%\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.S2.paymentDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"defaultSorting\":true,\"order\":\"desc\",\"sortBy\":\"paymentDate\",\"alignment\":\"left\"},\"mortgageFacility\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"{$.S2.paymentDate}\",\"fieldType\":\"date\",\"width\":\"25%\",\"defaultSorting\":true,\"order\":\"desc\",\"sortBy\":\"paymentDate\",\"alignment\":\"left\"}}";
            accountTransactionList.sknPostedLabel = accountTransactionList_data.sknPostedLabel || "sknLbl04AA1613pxSSPSemiBold";
            accountTransactionList.field3Value = accountTransactionList_data.field3Value || "{\"Savings\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Checking\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"CreditCard\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Deposit\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Loan\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}},\"Mortgage\":{\"text\":{\"ST2\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"},\"ST1\":{\"640\":\"{$.L1.checkNumber}\",\"default\":\"{$.L1.checkNumber}\"}}}}";
            accountTransactionList.val4FromPlaceHolder = accountTransactionList_data.val4FromPlaceHolder || "Check Number";
            accountTransactionList.iconColumnSort = accountTransactionList_data.iconColumnSort || "{\"img\": \"sorting.png\"}";
            accountTransactionList.tab6DataGridColumn2 = accountTransactionList_data.tab6DataGridColumn2 || "{\"Savings\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"{$.S2.lockReason}\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"{$.S2.lockReason}\",\"fieldType\":\"Label\",\"width\":\"30%\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"{$.S2.installmentAmount}\",\"fieldType\":\"amount\",\"width\":\"30%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"mortgageFacility\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"{$.S2.installmentAmount}\",\"fieldType\":\"amount\",\"width\":\"30%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"}}";
            accountTransactionList.sknRowExpanded = accountTransactionList_data.sknRowExpanded || "ICSknFlxfbfbfb";
            accountTransactionList.field3Type = accountTransactionList_data.field3Type || "{\"Savings\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Checking\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"CreditCard\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Deposit\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Loan\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}},\"Mortgage\":{\"ST2\":{\"640\":\"Text\",\"default\":\"Text\"},\"ST1\":{\"640\":\"Text\",\"default\":\"Text\"}}}";
            accountTransactionList.val4ToPlaceHolder = accountTransactionList_data.val4ToPlaceHolder || "Check Number";
            accountTransactionList.iconColumnSortAsc = accountTransactionList_data.iconColumnSortAsc || "{\"img\": \"sorting_previous.png\"}";
            accountTransactionList.tab6DataGridColumn3 = accountTransactionList_data.tab6DataGridColumn3 || "{\"Savings\":{\"title\":\"{i.i18n.accounts.fromDate}\",\"mapping\":\"{$.S2.fromDate}\",\"fieldType\":\"date\",\"width\":\"15%\",\"sortBy\":\"fromDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.i18n.accounts.fromDate}\",\"mapping\":\"{$.S2.fromDate}\",\"fieldType\":\"date\",\"width\":\"15%\",\"sortBy\":\"fromDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.accounts.principal}\",\"mapping\":\"{$.S2.principal}\",\"fieldType\":\"amount\",\"width\":\"20%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"mortgageFacility\":{\"title\":\"{i.i18n.accounts.principal}\",\"mapping\":\"{$.S2.principal}\",\"fieldType\":\"amount\",\"width\":\"20%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"}}";
            accountTransactionList.sknRowHover = accountTransactionList_data.sknRowHover || "ICSknFlxfbfbfb";
            accountTransactionList.field4Label = accountTransactionList_data.field4Label || "";
            accountTransactionList.iconColumnSortDesc = accountTransactionList_data.iconColumnSortDesc || "{\"img\": \"sorting_next.png\"}";
            accountTransactionList.tab6DataGridColumn4 = accountTransactionList_data.tab6DataGridColumn4 || "{\"Savings\":{\"title\":\"{i.i18n.accounts.toDate}\",\"mapping\":\"{$.S2.toDate}\",\"fieldType\":\"date\",\"width\":\"15%\",\"sortBy\":\"toDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Checking\":{\"title\":\"{i.i18n.accounts.toDate}\",\"mapping\":\"{$.S2.toDate}\",\"fieldType\":\"date\",\"width\":\"15%\",\"sortBy\":\"toDate\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"left\"},\"Loan\":{\"title\":\"{i.i18n.Transactions.displayInterest}\",\"mapping\":\"{$.S2.interest}\",\"fieldType\":\"amount\",\"width\":\"20%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"mortgageFacility\":{\"title\":\"{i.i18n.Transactions.displayInterest}\",\"mapping\":\"{$.S2.interest}\",\"fieldType\":\"amount\",\"width\":\"20%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"}}";
            accountTransactionList.sknRowSeperator = accountTransactionList_data.sknRowSeperator || "ICSknLabelBgDBDBDB";
            accountTransactionList.field4Value = accountTransactionList_data.field4Value || "";
            accountTransactionList.tab6DataGridColumn5 = accountTransactionList_data.tab6DataGridColumn5 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"{$.S2.lockedAmount}\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"lockedAmount\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"Checking\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"{$.S2.lockedAmount}\",\"fieldType\":\"amount\",\"width\":\"15%\",\"sortBy\":\"lockedAmount\",\"defaultSorting\":true,\"order\":\"desc\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"Loan\":{\"title\":\"{i.i18n.accounts.outstandingBalance}\",\"mapping\":\"{$.S2.outstandingBalance}\",\"fieldType\":\"amount\",\"width\":\"20%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"mortgageFacility\":{\"title\":\"{i.i18n.accounts.outstandingBalance}\",\"mapping\":\"{$.S2.outstandingBalance}\",\"fieldType\":\"amount\",\"width\":\"20%\",\"alignment\":\"right\",\"currencyCode\":\"{$.S2.transactionCurrency}\"}}";
            accountTransactionList.sknValueField = accountTransactionList_data.sknValueField || "ICSknLblSSP42424215px";
            accountTransactionList.field4Type = accountTransactionList_data.field4Type || "";
            accountTransactionList.tab6DataGridColumn6 = accountTransactionList_data.tab6DataGridColumn6 || "";
            accountTransactionList.sknTransDetailsLabel = accountTransactionList_data.sknTransDetailsLabel || "ICSknSSP72727213Px";
            accountTransactionList.field5Label = accountTransactionList_data.field5Label || "";
            accountTransactionList.tab6MobileDataGridField1 = accountTransactionList_data.tab6MobileDataGridField1 || "{\"Savings\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"lockReason\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"Checking\":{\"title\":\"{i.kony.pfm.desc}\",\"mapping\":\"lockReason\",\"fieldType\":\"Label\",\"width\":\"100%\"},\"Loan\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"paymentDate\",\"fieldType\":\"date\",\"width\":\"100%\"},\"mortgageFacility\":{\"title\":\"{i.i18n.transfers.lblDate}\",\"mapping\":\"paymentDate\",\"fieldType\":\"date\",\"width\":\"100%\"}}";
            accountTransactionList.sknTransDetailsValue = accountTransactionList_data.sknTransDetailsValue || "ICSknSSP42424213Px";
            accountTransactionList.field5Value = accountTransactionList_data.field5Value || "";
            accountTransactionList.tab6MobileDataGridField2 = accountTransactionList_data.tab6MobileDataGridField2 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"lockedAmount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"lockedAmount\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"Checking\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"lockedAmount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"sortBy\":\"lockedAmount\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"Loan\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"installmentAmount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"currencyCode\":\"{$.S2.transactionCurrency}\"},\"mortgageFacility\":{\"title\":\"{i.i18n.konybb.Common.Amount}\",\"mapping\":\"installmentAmount\",\"fieldType\":\"amount\",\"width\":\"130dp\",\"currencyCode\":\"{$.S2.transactionCurrency}\"}}";
            accountTransactionList.sknActionButtons = accountTransactionList_data.sknActionButtons || "flxHoverSkinPointer";
            accountTransactionList.field5Type = accountTransactionList_data.field5Type || "";
            accountTransactionList.tab6MobileDataGridField3 = accountTransactionList_data.tab6MobileDataGridField3 || "{\"Savings\":{\"title\":\"{i.i18n.konybb.common.ReferenceNumber}\",\"mapping\":\"transactionReference\",\"fieldType\":\"Label\",\"width\":\"40%\"},\"Checking\":{\"title\":\"{i.i18n.konybb.common.ReferenceNumber}\",\"mapping\":\"transactionReference\",\"fieldType\":\"Label\",\"width\":\"40%\"}}";
            accountTransactionList.sknSearchLabel = accountTransactionList_data.sknSearchLabel || "ICSknLblSSP72727215px";
            accountTransactionList.field6Label = accountTransactionList_data.field6Label || "";
            accountTransactionList.sknSearchTextbox = accountTransactionList_data.sknSearchTextbox || "skntbxffffffBordere3e3e3SSP15px424242";
            accountTransactionList.field6Value = accountTransactionList_data.field6Value || "";
            accountTransactionList.tab6Field1Label = accountTransactionList_data.tab6Field1Label || "{\"Loan\": {\"text\": {\"ST3\":{\"default\":\"{i.i18n.accounts.charges} :\",\"640\":\"{i.i18n.accounts.principal} :\"} ,\"ST4\":{\"default\":\"{i.i18n.accounts.charges} :\",\"640\":\"{i.i18n.accounts.principal} :\"}}},\"mortgageFacility\": {\"text\": {\"ST3\":{\"default\":\"{i.i18n.accounts.charges} :\",\"640\":\"{i.i18n.accounts.principal} :\"} ,\"ST4\":{\"default\":\"{i.i18n.accounts.charges} :\",\"640\":\"{i.i18n.accounts.principal} :\"}}}}";
            accountTransactionList.sknSearchActiveTextbox = accountTransactionList_data.sknSearchActiveTextbox || "skntbxffffffBordere3e3e3SSP15px424242";
            accountTransactionList.field6Type = accountTransactionList_data.field6Type || "";
            accountTransactionList.tab6Field1Value = accountTransactionList_data.tab6Field1Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.principal}\",\"default\":\"{$.S2.charges}\"},\"ST4\":{\"640\":\"{$.S2.principal}\",\"default\":\"{$.S2.charges}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}},\"mortgageFacility\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.principal}\",\"default\":\"{$.S2.charges}\"},\"ST4\":{\"640\":\"{$.S2.principal}\",\"default\":\"{$.S2.charges}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.sknSearchDropdown = accountTransactionList_data.sknSearchDropdown || "sknlbxaltoffffffB1R2";
            accountTransactionList.field7Label = accountTransactionList_data.field7Label || "";
            accountTransactionList.tab6field1Type = accountTransactionList_data.tab6field1Type || "{\"Loan\":{\"ST3\":{\"default\":\"amount\",\"640\":\"amount\"},\"ST4\":{\"default\":\"amount\",\"640\":\"amount\"}},\"mortgageFacility\":{\"ST3\":{\"default\":\"amount\",\"640\":\"amount\"},\"ST4\":{\"default\":\"amount\",\"640\":\"amount\"}}}";
            accountTransactionList.sknSearchActiveDropdown = accountTransactionList_data.sknSearchActiveDropdown || "sknlbxaltoffffffB1R2";
            accountTransactionList.field7Value = accountTransactionList_data.field7Value || "";
            accountTransactionList.tab6Field2Label = accountTransactionList_data.tab6Field2Label || "{\"Loan\": {\"text\": {\"ST3\":{\"default\":\"{i.i18n.accounts.tax} :\",\"640\":\"{i.i18n.Transactions.displayInterest} :\"} ,\"ST4\":{\"default\":\"{i.i18n.accounts.tax} :\",\"640\":\"{i.i18n.Transactions.displayInterest} :\"}}},\"mortgageFacility\": {\"text\": {\"ST3\":{\"default\":\"{i.i18n.accounts.tax} :\",\"640\":\"{i.i18n.Transactions.displayInterest} :\"} ,\"ST4\":{\"default\":\"{i.i18n.accounts.tax} :\",\"640\":\"{i.i18n.Transactions.displayInterest} :\"}}}}";
            accountTransactionList.sknSearchCalendar = accountTransactionList_data.sknSearchCalendar || "sknCalTransactions";
            accountTransactionList.field7Type = accountTransactionList_data.field7Type || "";
            accountTransactionList.tab6Field2Value = accountTransactionList_data.tab6Field2Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.interest}\",\"default\":\"{$.S2.tax}\"},\"ST4\":{\"640\":\"{$.S2.interest}\",\"default\":\"{$.S2.tax}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}},\"mortgageFacility\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.interest}\",\"default\":\"{$.S2.tax}\"},\"ST4\":{\"640\":\"{$.S2.interest}\",\"default\":\"{$.S2.tax}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.sknSearchActiveCalendar = accountTransactionList_data.sknSearchActiveCalendar || "sknCalTransactions";
            accountTransactionList.field8Label = accountTransactionList_data.field8Label || "";
            accountTransactionList.tab6Field2Type = accountTransactionList_data.tab6Field2Type || "{\"Loan\":{\"ST3\":{\"default\":\"amount\",\"640\":\"amount\"},\"ST4\":{\"default\":\"amount\",\"640\":\"amount\"}},\"mortgageFacility\":{\"ST3\":{\"default\":\"amount\",\"640\":\"amount\"},\"ST4\":{\"default\":\"amount\",\"640\":\"amount\"}}}";
            accountTransactionList.sknSearchButton = accountTransactionList_data.sknSearchButton || "sknBtnBlockedSSPFFFFFF15Px";
            accountTransactionList.field8Value = accountTransactionList_data.field8Value || "";
            accountTransactionList.tab6Field3Label = accountTransactionList_data.tab6Field3Label || "{\"Loan\": {\"text\": {\"ST3\":{\"default\":\"{i.i18n.accounts.insurance} :\",\"640\":\"{i.i18n.accounts.outstandingBalance} :\"} ,\"ST4\":{\"default\":\"{i.i18n.accounts.insurance} :\",\"640\":\"{i.i18n.accounts.outstandingBalance} :\"}}},\"mortgageFacility\": {\"text\": {\"ST3\":{\"default\":\"{i.i18n.accounts.insurance} :\",\"640\":\"{i.i18n.accounts.outstandingBalance} :\"} ,\"ST4\":{\"default\":\"{i.i18n.accounts.insurance} :\",\"640\":\"{i.i18n.accounts.outstandingBalance} :\"}}}}";
            accountTransactionList.sknSearchButtonHover = accountTransactionList_data.sknSearchButtonHover || "sknbtnSSPffffff0278ee15pxbr3px";
            accountTransactionList.field8Type = accountTransactionList_data.field8Type || "";
            accountTransactionList.tab6Field3Value = accountTransactionList_data.tab6Field3Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.outstandingBalance}\",\"default\":\"{$.S2.insurance}\"},\"ST4\":{\"640\":\"{$.S2.outstandingBalance}\",\"default\":\"{$.S2.insurance}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}},\"mortgageFacility\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.outstandingBalance}\",\"default\":\"{$.S2.insurance}\"},\"ST4\":{\"640\":\"{$.S2.outstandingBalance}\",\"default\":\"{$.S2.insurance}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.sknSearchCancelButton = accountTransactionList_data.sknSearchCancelButton || "ICSknBtnffffffBorder0273e31pxRadius2px";
            accountTransactionList.field9Label = accountTransactionList_data.field9Label || "";
            accountTransactionList.tab6Field3Type = accountTransactionList_data.tab6Field3Type || "{\"Loan\": {\"ST3\":{\"default\":\"amount\",\"640\":\"amount\"},\"ST4\":{\"default\":\"amount\",\"640\":\"amount\"}},\"mortgageFacility\": {\"ST3\":{\"default\":\"amount\",\"640\":\"amount\"},\"ST4\":{\"default\":\"amount\",\"640\":\"amount\"}}}";
            accountTransactionList.sknSearchCancelButtonHover = accountTransactionList_data.sknSearchCancelButtonHover || "ICSknBtnffffffBorder0273e31pxRadius2px";
            accountTransactionList.field9Value = accountTransactionList_data.field9Value || "";
            accountTransactionList.tab6Field4Label = accountTransactionList_data.tab6Field4Label || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{i.i18n.accounts.charges} :\"},\"ST4\":{\"640\":\"{i.i18n.accounts.charges} :\"}}},\"mortgageFacility\":{\"text\":{\"ST3\":{\"640\":\"{i.i18n.accounts.charges} :\"},\"ST4\":{\"640\":\"{i.i18n.accounts.charges} :\"}}}}";
            accountTransactionList.sknPositiveAmount = accountTransactionList_data.sknPositiveAmount || "ICSknLblSSP42424215px";
            accountTransactionList.field9Type = accountTransactionList_data.field9Type || "";
            accountTransactionList.tab6Field4Value = accountTransactionList_data.tab6Field4Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.charges}\"},\"ST4\":{\"640\":\"{$.S2.charges}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}},\"mortgageFacility\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.charges}\"},\"ST4\":{\"640\":\"{$.S2.charges}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.sknNegativeAmount = accountTransactionList_data.sknNegativeAmount || "ICSknLblSSP42424215px";
            accountTransactionList.field10Label = accountTransactionList_data.field10Label || "";
            accountTransactionList.tab6Field4Type = accountTransactionList_data.tab6Field4Type || "{\"Loan\":{\"ST3\":{\"640\":\"amount\"},\"ST4\":{\"640\":\"amount\"}},\"mortgageFacility\":{\"ST3\":{\"640\":\"amount\"},\"ST4\":{\"640\":\"amount\"}}}";
            accountTransactionList.sknDate = accountTransactionList_data.sknDate || "ICSknLblSSP42424215px";
            accountTransactionList.field10Value = accountTransactionList_data.field10Value || "";
            accountTransactionList.tab6Field5Label = accountTransactionList_data.tab6Field5Label || "{\"Loan\": {\"text\": {\"ST3\":{\"640\":\"{i.i18n.accounts.tax} :\"} ,\"ST4\":{\"640\":\"{i.i18n.accounts.tax} :\"}}},\"mortgageFacility\": {\"text\": {\"ST3\":{\"640\":\"{i.i18n.accounts.tax} :\"} ,\"ST4\":{\"640\":\"{i.i18n.accounts.tax} :\"}}}}";
            accountTransactionList.sknPercentage = accountTransactionList_data.sknPercentage || "ICSknLblSSP42424215px";
            accountTransactionList.field10Type = accountTransactionList_data.field10Type || "";
            accountTransactionList.tab6Field5Value = accountTransactionList_data.tab6Field5Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.tax}\"},\"ST4\":{\"640\":\"{$.S2.tax}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}},\"mortgageFacility\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.tax}\"},\"ST4\":{\"640\":\"{$.S2.tax}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.btnContextualAction1 = accountTransactionList_data.btnContextualAction1 || "{\"Savings\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}},\"Checking\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}},\"CreditCard\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}},\"Loan\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}},\"Deposit\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}},\"Mortgage\":{\"id\":{\"ST1\":\"Download\",\"ST2\":\"Download\"},\"text\":{\"ST2\":{\"640\":\"Download\",\"default\":\"Download\"},\"ST1\":{\"640\":\"Download\",\"default\":\"Download\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false}}}";
            accountTransactionList.tab6Field5Type = accountTransactionList_data.tab6Field5Type || "{\"Loan\": {\"ST3\":{\"640\":\"amount\"},\"ST4\":{\"640\":\"amount\"}},\"mortgageFacility\": {\"ST3\":{\"640\":\"amount\"},\"ST4\":{\"640\":\"amount\"}}}";
            accountTransactionList.tab6Field6Label = accountTransactionList_data.tab6Field6Label || "{\"Loan\": {\"text\": {\"ST3\":{\"640\":\"{i.i18n.accounts.insurance} :\"} ,\"ST4\":{\"640\":\"{i.i18n.accounts.insurance} :\"}}},\"mortgageFacility\": {\"text\": {\"ST3\":{\"640\":\"{i.i18n.accounts.insurance} :\"} ,\"ST4\":{\"640\":\"{i.i18n.accounts.insurance} :\"}}}}";
            accountTransactionList.btnContextualAction2 = accountTransactionList_data.btnContextualAction2 || "{\"Savings\":{\"id\":{\"ST1\":\"Dispute\",\"ST2\":\"Dispute\"},\"text\":{\"ST2\":{\"640\":\"Dispute\",\"default\":\"Dispute\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Checking\":{\"id\":{\"ST1\":\"Dispute\",\"ST2\":\"Dispute\"},\"text\":{\"ST2\":{\"640\":\"Dispute\",\"default\":\"Dispute\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"CreditCard\":{\"id\":{\"ST1\":\"Dispute\",\"ST2\":\"Dispute\"},\"text\":{\"ST2\":{\"640\":\"Dispute\",\"default\":\"Dispute\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Loan\":{\"id\":{\"ST1\":\"Dispute\",\"ST2\":\"Dispute\"},\"text\":{\"ST2\":{\"640\":\"Dispute\",\"default\":\"Dispute\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Deposit\":{\"id\":{\"ST1\":\"Dispute\",\"ST2\":\"Dispute\"},\"text\":{\"ST2\":{\"640\":\"Dispute\",\"default\":\"Dispute\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}}}";
            accountTransactionList.btnContextualAction3 = accountTransactionList_data.btnContextualAction3 || "{\"Savings\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Checking\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"CreditCard\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Loan\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Deposit\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}},\"Mortgage\":{\"id\":{\"ST1\":\"View Requests\",\"ST2\":\"View Requests\"},\"text\":{\"ST2\":{\"640\":\"View Requests\",\"default\":\"View Requests\"},\"ST1\":{\"640\":\"\",\"default\":\"\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":true}}}";
            accountTransactionList.tab6Field6Value = accountTransactionList_data.tab6Field6Value || "{\"Loan\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.insurance}\"},\"ST4\":{\"640\":\"{$.S2.insurance}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}},\"mortgageFacility\":{\"text\":{\"ST3\":{\"640\":\"{$.S2.insurance}\"},\"ST4\":{\"640\":\"{$.S2.insurance}\"}},\"currencyCode\":{\"ST3\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"},\"ST4\":{\"640\":\"{$.S2.transactionCurrency}\",\"default\":\"{$.S2.transactionCurrency}\"}}}}";
            accountTransactionList.tab6Field6Type = accountTransactionList_data.tab6Field6Type || "{\"Loan\": {\"ST3\":{\"640\":\"amount\"},\"ST4\":{\"640\":\"amount\"}},\"mortgageFacility\": {\"ST3\":{\"640\":\"amount\"},\"ST4\":{\"640\":\"amount\"}}}";
            accountTransactionList.btnContextualAction4 = accountTransactionList_data.btnContextualAction4 || "{\"Savings\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"},\"Checking\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"},\"CreditCard\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"},\"Loan\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"},\"Deposit\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"},\"Mortgage\":{\"id\":{\"ST1\":\"Attachments\",\"ST2\":\"Attachments\"},\"text\":{\"ST2\":{\"640\":\"Attachments\",\"default\":\"Attachments\"},\"ST1\":{\"640\":\"Attachments\",\"default\":\"Attachments\"}},\"width\":{\"ST2\":{\"640\":\"50%\",\"default\":\"50%\"},\"ST1\":{\"640\":\"50%\",\"default\":\"50%\"}},\"skin\":{\"ST2\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"},\"ST1\":{\"640\":\"ICSknBtnSSP0273e315px\",\"default\":\"ICSknBtnSSP0273e315px\"}},\"entitlement_keys\":[],\"entitlement_action\":{\"ST1\":false,\"ST2\":false},\"attachments\":\"{$.L1.fileNames}\"}}";
            accountTransactionList.tab6Field7Label = accountTransactionList_data.tab6Field7Label || "";
            accountTransactionList.tab6Field7Value = accountTransactionList_data.tab6Field7Value || "";
            accountTransactionList.tab6Field7Type = accountTransactionList_data.tab6Field7Type || "";
            accountTransactionList.tab6Field8Label = accountTransactionList_data.tab6Field8Label || "";
            accountTransactionList.tab6Field8Value = accountTransactionList_data.tab6Field8Value || "";
            accountTransactionList.tab6Field8Type = accountTransactionList_data.tab6Field8Type || "";
            accountTransactionList.tab6Field9Label = accountTransactionList_data.tab6Field9Label || "";
            accountTransactionList.tab6Field9Value = accountTransactionList_data.tab6Field9Value || "";
            accountTransactionList.tab6Field9Type = accountTransactionList_data.tab6Field9Type || "";
            accountTransactionList.tab6Field10Label = accountTransactionList_data.tab6Field10Label || "";
            accountTransactionList.tab6Field10Value = accountTransactionList_data.tab6Field10Value || "";
            accountTransactionList.tab6Field10Type = accountTransactionList_data.tab6Field10Type || "";
            accountTransactionList.tab6BtnContextualAction1 = accountTransactionList_data.tab6BtnContextualAction1 || "{\"Loan\":{\"id\":{\"ST3\":\"payOverDue\",\"ST4\":\"\"},\"text\":{\"ST3\":{\"default\":\"Pay Overdue\"},\"ST4\":{\"default\":\"\"}},\"width\":{\"ST3\":{\"default\":\"100%\"},\"ST4\":{\"default\":\"100%\"}},\"skin\":{\"ST3\":{\"default\":\"ICSknBtnSSP0273e315px\"},\"ST4\":{\"default\":\"\"}},\"entitlement_keys\":[\"VIEW_LOAN_SCHEDULE\"],\"entitlement_action\":{\"ST3\":false,\"ST4\":false}}}";
            accountTransactionList.tab6BtnContextualAction2 = accountTransactionList_data.tab6BtnContextualAction2 || "";
            accountTransactionList.tab6BtnContextualAction3 = accountTransactionList_data.tab6BtnContextualAction3 || "";
            accountTransactionList.tab6BtnContextualAction4 = accountTransactionList_data.tab6BtnContextualAction4 || "";
            accountTransactionList.onError = controller.AS_UWI_dcbeb0a30e194382ad9adb9ba8e851b5;
            accountTransactionList.adjustScreen = controller.AS_UWI_i8cdc06c39d24ee9b42fee739e394e58;
            flxTransactions.add(btnByPass2, transactions, accountTransactionList);
            flxMain.add(flxHeading, flxDowntimeWarning, flxRenewExpired, flxBackNavigation, flxViewStatements, flxTransactions);
            flxMainWrapper.add(moreActionsDup, breadcrumb, flxskncontainer, AllForms, moreActions, accountActionsMobile, quicklinksMobile, flxMain);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1100dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "height": "150dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "top": "75dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMainWrapper, flxFooter);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxPopup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopupNew = new com.InfinityOLB.ArrangementsMA.CustomPopupNew({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopupNew",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ArrangementsMA",
                "viewType": "CustomPopupNew",
                "overrides": {
                    "CustomPopupNew": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var CustomPopupNew_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmViewStatements"] && appConfig.componentMetadata["ArrangementsMA"]["frmViewStatements"]["CustomPopupNew"]) || {};
            CustomPopupNew.lblMsg = CustomPopupNew_data.lblMsg || "Account Closure";
            flxPopup.add(CustomPopupNew);
            var flxEditRule = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxEditRule",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditRule.setDefaultUnit(kony.flex.DP);
            var editRule = new com.InfinityOLB.ArrangementsMA.editRule({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "800dp",
                "id": "editRule",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0c69b7ae145714d",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA",
                "overrides": {
                    "CopyLabel0i29828d34ac943": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.SelectedCategory\")"
                    },
                    "CopyLabel0j97febcc29a74d": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Createdon\")"
                    },
                    "Label0a53d93efa98847": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Createdby\")"
                    },
                    "btnCancel": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                        "left": "viz.val_cleared",
                        "right": "199dp",
                        "width": "150dp"
                    },
                    "btnClose": {
                        "right": "20dp"
                    },
                    "btnConfirm": {
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Confirm\")",
                        "right": "30dp",
                        "width": "150dp"
                    },
                    "editRule": {
                        "height": "800dp",
                        "zIndex": 1000
                    },
                    "flxActions": {
                        "height": "80dp"
                    },
                    "flxEditRuleWrapper": {
                        "height": "360dp",
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "width": "795dp"
                    },
                    "lblHeader": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.editRule\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEditRule.add(editRule);
            var flxCheckImage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "200%",
                "id": "flxCheckImage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckImage.setDefaultUnit(kony.flex.DP);
            var CheckImage = new com.InfinityOLB.ArrangementsMA.accDetailsCheckImage({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "700dp",
                "id": "CheckImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexFFFFFFBorderRadius3Pxshadowfcfcfc",
                "top": "100dp",
                "width": "1000dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA",
                "overrides": {
                    "accDetailsCheckImage": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "height": "700dp",
                        "isVisible": true,
                        "left": "0dp",
                        "top": "100dp",
                        "width": "1000dp",
                        "zIndex": 1000
                    },
                    "flxImageCheck": {
                        "width": "90%"
                    },
                    "flxImageContainer": {
                        "isVisible": true
                    },
                    "flxNoimage": {
                        "isVisible": false
                    },
                    "flxZoom": {
                        "isVisible": true
                    },
                    "imgCancel": {
                        "src": "icon_close_grey.png"
                    },
                    "imgCheckImage": {
                        "isVisible": true,
                        "src": "check_img.png"
                    },
                    "imgCheckImageZoom": {
                        "isVisible": false,
                        "src": "check_img.png"
                    },
                    "imgFlipIcon": {
                        "centerY": "52%",
                        "left": "viz.val_cleared",
                        "top": "viz.val_cleared"
                    },
                    "imgInfo": {
                        "src": "info_large.png"
                    },
                    "imgPrintIcon": {
                        "centerY": "52%",
                        "left": "viz.val_cleared",
                        "text": "D",
                        "top": "viz.val_cleared"
                    },
                    "imgZoomIcon": {
                        "centerY": "53%",
                        "left": "viz.val_cleared",
                        "top": "viz.val_cleared"
                    },
                    "lblBillAmount": {
                        "width": "10%"
                    },
                    "lblEbillDetails": {
                        "height": "80dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Ebills.Terms&Conditions\")",
                        "isVisible": false
                    },
                    "lblMemo": {
                        "width": "10%"
                    },
                    "lblMemoValue": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.Max100charcactersallowed\")"
                    },
                    "lblNoCheck": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "lblPostDate": {
                        "left": "0%",
                        "width": "10%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCheckImage.add(CheckImage);
            var flxDownloadTransaction = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "250%",
                "id": "flxDownloadTransaction",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadTransaction.setDefaultUnit(kony.flex.DP);
            var downloadTransction = new com.InfinityOLB.ArrangementsMA.downloadTransction({
                "height": "100%",
                "id": "downloadTransction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0c69b7ae145714d",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "btnCancel": {
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "height": "50dp",
                        "left": "viz.val_cleared",
                        "right": "230dp",
                        "top": "viz.val_cleared",
                        "width": "160dp"
                    },
                    "btnClose": {
                        "centerY": "50%",
                        "height": "15px",
                        "left": "93.50%",
                        "right": 22,
                        "top": "0",
                        "width": "15px"
                    },
                    "btnDownload": {
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "height": "50dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "25dp",
                        "top": "viz.val_cleared",
                        "width": "160dp"
                    },
                    "calFromDate": {
                        "left": "4.34%",
                        "width": "95.60%"
                    },
                    "calToDate": {
                        "left": "4.34%",
                        "right": "viz.val_cleared",
                        "width": "95.60%"
                    },
                    "downloadTransction": {
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "flxButtons": {
                        "bottom": "viz.val_cleared",
                        "height": "60px",
                        "responsiveConfig": {
                            "offset": {
                                "640": 0,
                                "1024": 0,
                                "1366": 0,
                                "1380": 0
                            },
                            "span": {
                                "640": 12,
                                "1024": 12,
                                "1366": 12,
                                "1380": 12
                            }
                        },
                        "top": "0dp"
                    },
                    "flxDisclaimer": {
                        "centerX": "50%",
                        "height": "75%",
                        "left": "viz.val_cleared",
                        "top": "15%",
                        "width": "93%"
                    },
                    "flxDisclaimerInfo": {
                        "height": "112px"
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "responsiveConfig": {
                            "offset": {
                                "640": 0,
                                "1024": 0,
                                "1366": 0,
                                "1380": 0
                            },
                            "span": {
                                "640": 6,
                                "1024": 4,
                                "1366": 12,
                                "1380": 3
                            }
                        }
                    },
                    "flxFromDate": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "isVisible": false,
                        "left": "30.56%",
                        "width": "230dp"
                    },
                    "flxHeader": {
                        "height": "52px",
                        "responsiveConfig": {
                            "offset": {
                                "640": 0,
                                "1024": 0,
                                "1366": 0,
                                "1380": 0
                            },
                            "span": {
                                "640": 12,
                                "1024": 12,
                                "1366": 12,
                                "1380": 12
                            }
                        }
                    },
                    "flxInfoIcon": {
                        "height": "35dp",
                        "left": "5dp",
                        "top": "5dp",
                        "width": "35dp"
                    },
                    "flxMiddle": {
                        "centerX": "viz.val_cleared",
                        "height": "75dp",
                        "isVisible": true,
                        "left": "0dp",
                        "minHeight": "viz.val_cleared",
                        "responsiveConfig": {
                            "offset": {
                                "640": 0,
                                "1024": 0,
                                "1366": 0,
                                "1380": 0
                            },
                            "span": {
                                "640": 12,
                                "1024": 12,
                                "1366": 12,
                                "1380": 12
                            }
                        },
                        "top": "0dp",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxPopup": {
                        "centerX": "47.58%",
                        "height": "310dp",
                        "isModalContainer": true,
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "width": "37%"
                    },
                    "flxSelectFormat": {
                        "isVisible": false,
                        "left": "46.30%",
                        "top": "10dp",
                        "width": "252dp"
                    },
                    "flxSeperator2": {
                        "bottom": "viz.val_cleared",
                        "isVisible": true,
                        "top": "68dp"
                    },
                    "flxToDate": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "isVisible": false,
                        "right": "viz.val_cleared"
                    },
                    "imgArrow": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "height": "15dp",
                        "right": "20dp",
                        "src": "bbcloseicon.png",
                        "width": "15px"
                    },
                    "imgCloseDowntimeWarning": {
                        "src": "icon_close_grey.png"
                    },
                    "imgDowntimeWarning": {
                        "src": "error_yellow.png"
                    },
                    "infoIcon": {
                        "src": "exclaim_info.png"
                    },
                    "lblDisclaimer": {
                        "bottom": "viz.val_cleared",
                        "left": "45dp",
                        "right": "viz.val_cleared",
                        "top": "5dp",
                        "width": "89%"
                    },
                    "lblHeader": {
                        "bottom": "0",
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.downloadTransactions\")",
                        "left": "14%",
                        "top": "viz.val_cleared"
                    },
                    "lblPickDateRange": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.PickDateRange\")",
                        "isVisible": false,
                        "left": "3.77%"
                    },
                    "lblSelectFormat": {
                        "centerY": "viz.val_cleared",
                        "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.achfiledetail.fileType\")",
                        "left": "4.30%",
                        "top": "15dp"
                    },
                    "lblSelectImg": {
                        "isVisible": false,
                        "left": "91%",
                        "top": "17dp"
                    },
                    "lblTo": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "30px",
                        "isVisible": false,
                        "right": "viz.val_cleared"
                    },
                    "lbxSelectFormat": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40dp",
                        "left": "46.30%",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "10dp",
                        "width": "50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {
                    "infoIcon": {
                        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO
                    }
                }
            }, {
                "overrides": {}
            });
            flxDownloadTransaction.add(downloadTransction);
            var flxDownloadLoanSchedule = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150%",
                "id": "flxDownloadLoanSchedule",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadLoanSchedule.setDefaultUnit(kony.flex.DP);
            var downloadLoanSchedule = new com.InfinityOLB.ArrangementsMA.downloadLoanSchedule({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "downloadLoanSchedule",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0c69b7ae145714d",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "btnCancel": {
                        "centerY": "50%",
                        "left": "viz.val_cleared",
                        "right": "190dp",
                        "top": "viz.val_cleared",
                        "width": "150dp"
                    },
                    "btnDownload": {
                        "centerY": "50%",
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "top": "viz.val_cleared",
                        "width": "150dp"
                    },
                    "downloadLoanSchedule": {
                        "isVisible": true
                    },
                    "flxButtons": {
                        "height": "100dp"
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "flxHeader": {
                        "height": "44dp"
                    },
                    "flxMiddle": {
                        "centerX": "viz.val_cleared",
                        "height": "170dp",
                        "isVisible": true,
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%",
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "flxPopup": {
                        "top": "440dp",
                        "width": "38.07%"
                    },
                    "imgClose": {
                        "src": "icon_close_grey.png"
                    },
                    "imgCloseDowntimeWarning": {
                        "right": "0dp",
                        "src": "icon_close_grey_1.png"
                    },
                    "imgDowntimeWarning": {
                        "src": "error_yellow_4.png"
                    },
                    "lblDowntimeWarning": {
                        "left": "20dp",
                        "width": "75%"
                    },
                    "lblHeader": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.Loans.downloadInstallments\")",
                        "left": "20dp"
                    },
                    "lblInstallmentType": {
                        "centerX": "viz.val_cleared",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.Loans.installmentType\")",
                        "left": "20dp",
                        "top": "42dp"
                    },
                    "lblSelectFormat": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.Loans.selectFormat\")",
                        "left": "20dp",
                        "top": "112dp"
                    },
                    "lbxSelectFormat": {
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "top": "100dp",
                        "width": "320dp"
                    },
                    "lbxSelectType": {
                        "centerX": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "top": "30dp",
                        "width": "320dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDownloadLoanSchedule.add(downloadLoanSchedule);
            var flxSearchDownloadTransaction = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearchDownloadTransaction",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchDownloadTransaction.setDefaultUnit(kony.flex.DP);
            var searchDownloadTransction = new com.InfinityOLB.ArrangementsMA.searchDownloadTransction({
                "height": "100%",
                "id": "searchDownloadTransction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0c69b7ae145714d",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "overrides": {
                    "btnClose": {
                        "height": "20dp",
                        "width": "20dp"
                    },
                    "flxPopup": {
                        "width": "500dp"
                    },
                    "lblTypeValue": {
                        "minWidth": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSearchDownloadTransaction.add(searchDownloadTransction);
            var flxSingleTransactionDownload = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxSingleTransactionDownload",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxSingleTransactionDownload.setDefaultUnit(kony.flex.DP);
            var flxSTPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "47.58%",
                "clipBounds": true,
                "id": "flxSTPopup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": true,
                "skin": "Copysknflxffffff",
                "top": "300px",
                "width": "76%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSTPopup.setDefaultUnit(kony.flex.DP);
            var flxSTTransactionHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52px",
                "id": "flxSTTransactionHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSTTransactionHeader.setDefaultUnit(kony.flex.DP);
            var lblSTHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "30px",
                "id": "lblSTHeader",
                "isVisible": true,
                "left": "3.77%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.DOWNLOADTRANSACTIONS\")",
                "top": "11px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSTClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSTClose",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSTClose.setDefaultUnit(kony.flex.DP);
            var imgSTClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSTClose",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "94.71%",
                "right": "2.51%",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "width": "15px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSTClose.add(imgSTClose);
            var btnSTClose = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Close download transaction dialog"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "btnSTClose",
                "isVisible": true,
                "left": "94.70%",
                "right": "2.51%",
                "skin": "btnOLBFontIcon727272",
                "text": "g",
                "width": "20px"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSTTransactionHeader.add(lblSTHeader, flxSTClose, btnSTClose);
            var flxSTSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSTSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSTSeperator.setDefaultUnit(kony.flex.DP);
            flxSTSeperator.add();
            var flxErrorMsg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxErrorMsg",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMsg.setDefaultUnit(kony.flex.DP);
            var imgDTWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDTWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDTWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "status",
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDTWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Error Message",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseDTWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxCloseDTWarning",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseDTWarning.setDefaultUnit(kony.flex.DP);
            var imgCloseDTWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgCloseDTWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCloseDTWarning.add(imgCloseDTWarning);
            flxErrorMsg.add(imgDTWarning, lblDTWarning, flxCloseDTWarning);
            var flxSTDisclaimerInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "70dp",
                "id": "flxSTDisclaimerInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "40dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "90%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSTDisclaimerInfo.setDefaultUnit(kony.flex.DP);
            var flxSTInfoIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxSTInfoIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "9dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSTInfoIcon.setDefaultUnit(kony.flex.DP);
            var infoIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "150dp",
                "id": "infoIcon",
                "isVisible": true,
                "left": "67dp",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "3dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSTInfoIcon.add(infoIcon);
            var lblSTDisclaimer = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "8dp",
                "height": "80%",
                "id": "lblSTDisclaimer",
                "isVisible": true,
                "left": "60dp",
                "right": "50dp",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ViewStatements.DisclaimerInfo\")",
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSTDisclaimerInfo.add(flxSTInfoIcon, lblSTDisclaimer);
            var flxSTButton = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "109px",
                "id": "flxSTButton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSTButton.setDefaultUnit(kony.flex.DP);
            var btnSTDownload = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "50dp",
                "id": "btnSTDownload",
                "isVisible": true,
                "right": "30dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                "width": "257dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnSTCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "50dp",
                "id": "btnSTCancel",
                "isVisible": true,
                "right": "304dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "257dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxSTButton.add(btnSTDownload, btnSTCancel);
            flxSTPopup.add(flxSTTransactionHeader, flxSTSeperator, flxErrorMsg, flxSTDisclaimerInfo, flxSTButton);
            flxSingleTransactionDownload.add(flxSTPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yLabel": "Loading"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxDownloadAttachment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150%",
                "id": "flxDownloadAttachment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadAttachment.setDefaultUnit(kony.flex.DP);
            var flxDownloadItems = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDownloadItems",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "40.50%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "20%",
                "width": "300dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadItems.setDefaultUnit(kony.flex.DP);
            var flxHeader1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "49dp",
                "id": "flxHeader1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader1.setDefaultUnit(kony.flex.DP);
            var lblHeading1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblHeading1",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Download Attachments",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader1.add(lblHeading1);
            var lblSeparator1 = new kony.ui.Label({
                "height": "1dp",
                "id": "lblSeparator1",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segDownloadItems = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgDownloadAttachment": "download_blue.png",
                    "lblDownloadAttachment": "Label",
                    "lblDownloadAttachmentID": "Label",
                    "lblSeparator": ""
                }, {
                    "imgDownloadAttachment": "download_blue.png",
                    "lblDownloadAttachment": "Label",
                    "lblDownloadAttachmentID": "Label",
                    "lblSeparator": ""
                }, {
                    "imgDownloadAttachment": "download_blue.png",
                    "lblDownloadAttachment": "Label",
                    "lblDownloadAttachmentID": "Label",
                    "lblSeparator": ""
                }],
                "groupCells": false,
                "id": "segDownloadItems",
                "isVisible": true,
                "left": 0,
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxDownloadAttachments"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxDownloadAttachment": "flxDownloadAttachment",
                    "flxDownloadAttachments": "flxDownloadAttachments",
                    "imgDownloadAttachment": "imgDownloadAttachment",
                    "lblDownloadAttachment": "lblDownloadAttachment",
                    "lblDownloadAttachmentID": "lblDownloadAttachmentID",
                    "lblSeparator": "lblSeparator"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnDownload = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "bottom": "20dp",
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40dp",
                "id": "btnDownload",
                "isVisible": true,
                "right": "21dp",
                "skin": "sknbtnSSPffffff15px0273e3bg",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.Download\")",
                "width": "120dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px",
                "toolTip": "Continue"
            });
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "centerY": "50.00%",
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.close\")",
                "width": "120dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxButtons.add(btnDownload, btnCancel);
            flxDownloadItems.add(flxHeader1, lblSeparator1, segDownloadItems, flxButtons);
            flxDownloadAttachment.add(flxDownloadItems);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "AllForms": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "moreActions": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "instanceId": "moreActions"
                    },
                    "moreActions.imgToolTip": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "accountActionsMobile": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "accountActionsMobile.imgToolTip": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "quicklinksMobile": {
                        "height": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sbcf3fe0ebf44e11afc761bf08b6ed2b",
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHeading": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "left": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "47%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseDowntimeWarning": {
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxRenewExpired": {
                        "height": {
                            "type": "string",
                            "value": "108dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "flxe3e3e3e30pxradius",
                        "segmentProps": []
                    },
                    "imgExpired": {
                        "centerY": {
                            "type": "string",
                            "value": "25%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "src": "erroricon.png",
                        "segmentProps": []
                    },
                    "lblRenewExpired": {
                        "centerY": {
                            "type": "string",
                            "value": "25%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "btnRenew": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Renew Connection",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigation": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNavigation": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "9px"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "s018b592f2be4ccf98f6e95b092c9c4c",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgBack": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "lblBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxViewStatements": {
                        "minHeight": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.confirmButtons": {
                        "height": {
                            "type": "string",
                            "value": "140px"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.confirmButtons.btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.confirmButtons.btnModify": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.flxSelectReasonForDispute": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "ViewStatements.flxSelectYear": {
                        "left": {
                            "type": "string",
                            "value": "2.10%"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.lblSelectYear": {
                        "left": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.lstSelectAccount": {
                        "left": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.SegmentMonthWiseFiles1": {
                        "height": {
                            "type": "string",
                            "value": "44dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnAdhocStatements": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnCombinedStatements": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnConfirm": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnEStatements": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "i18n_text": "i18n.olb.ViewEStatements",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flexDataMonth1": {
                        "height": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flexDataMonth12": {
                        "height": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flexDataMonth2": {
                        "height": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flexDataMonth3": {
                        "height": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flexDataMonth4": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocInfoMessage": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocStatements": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocWarnMsg": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocWarningMessage": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxCombinedStatements": {
                        "height": {
                            "type": "string",
                            "value": "504dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxDisclaimerInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "95px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknFlxffffffborderradE3E3E3",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxDownload": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "9"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxFileDownload": {
                        "height": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "194dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxFileType": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoImage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoImage1": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxLine": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-2dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxLine1": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxMain": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxMainWrapper": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxPaginationContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxStatementsTab": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxWarnInfoImage": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxWarningMessage": {
                        "height": {
                            "type": "string",
                            "value": "165dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxlblMonth12Separator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgAdhocInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgDownload": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "src": "download_2x.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgFileType": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "pdf_image.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgWarnInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.infoIcon": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDisclaimer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknLblSSP42424213px",
                        "text": "Please bear in mind that your documents may contain personal information, please keep them safe if you chose to open or download any of them.",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDisclaimerInfo": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLblSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDownload": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblGeneratedOnDate": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "text": "26/11/2020, 10 AM",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblInfoMessage": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblMonth1": {
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblViewStatements": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "viewStatementsnew.lbnFileName": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "text": "LInfinity bank -0097 account statement.pdf",
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.segStatements": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew": {
                        "segmentProps": [],
                        "instanceId": "viewStatementsnew"
                    },
                    "flxTransactions": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnByPass2": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "right": {
                            "type": "string",
                            "value": "40%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "transactions": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "instanceId": "transactions"
                    },
                    "transactions.btnAllChecking": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.btnAllCredit": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.btnAllDeposit": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.btnAllLoan": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.btnClearSearch": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0.50%"
                        },
                        "text": "Clear Search",
                        "segmentProps": []
                    },
                    "transactions.btnModifySearch": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0.50%"
                        },
                        "text": "Modify Search",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.btnSearch": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.calDateFrom": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "transactions.calDateTo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxAmountRangeFrom": {
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxAmountRangeTo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxAmountRangeWrapper": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxBlankSpace": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxByAmountRange": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxByCheckNumber": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxByDate": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxCheckNumberWrapper": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxDateRangeWrapper": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxHeader": {
                        "segmentProps": []
                    },
                    "transactions.flxKeywordWrapper": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxLeftSearch": {
                        "height": {
                            "type": "string",
                            "value": "265dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "transactions.flxNoTransactions": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxPagination": {
                        "segmentProps": []
                    },
                    "transactions.flxPaginationPrevious": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxPaginationWrapper": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "290dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxPrint": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "transactions.flxRightSearchWrapper": {
                        "height": {
                            "type": "string",
                            "value": "60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSearchContainer": {
                        "height": {
                            "type": "string",
                            "value": "660dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSearchContainerWrapper": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "transactions.flxSearchItemKeyword": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSearchItemOthers": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "transactions.flxSearchItems": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "right": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSearchItemsMobile": {
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSearchResultActions": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSearchResults": {
                        "height": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSegmentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 4,
                        "segmentProps": []
                    },
                    "transactions.flxSeparatorSearch": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSort": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxTabsChecking": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "transactions.flxTabsCredit": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "transactions.flxTabsDeposit": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "transactions.flxTabsLoan": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "transactions.flxTypeWrapper": {
                        "height": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxWrapper": {
                        "height": {
                            "type": "string",
                            "value": "197dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "transactions.imgCancel": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgCancelAmountRange": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgCancelAmountRangeM": {
                        "centerY": {
                            "type": "string",
                            "value": "45%"
                        },
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgCancelCheckNumber": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgCancelCheckNumberM": {
                        "centerY": {
                            "type": "string",
                            "value": "45%"
                        },
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgCancelDateRange": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgCancelDateRangeM": {
                        "centerY": {
                            "type": "string",
                            "value": "45%"
                        },
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgCancelM": {
                        "centerY": {
                            "type": "string",
                            "value": "45%"
                        },
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgCancelType": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgCancelTypeM": {
                        "centerY": {
                            "type": "string",
                            "value": "45%"
                        },
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblAmountRangeTitle": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblAmountRangeTitleM": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblByAmountRange": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblByCheckNumber": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblByDate": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblByKeyword": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblByTimePeriod": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblByTransactionType": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblCheckNumberTitleM": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblDateRangeTitleM": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblKeywordTitle": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblKeywordTitleM": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblPagination": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblToByAmountRange": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "transactions.lblToByCheckNumber": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "transactions.lblToByDate": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "transactions.lblTransactions": {
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblTypeTitleM": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblYouHaveSearchedFor": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lstbxTimePeriod": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "transactions.lstbxTransactionType": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "transactions.rtxNoPaymentMessage": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.segTransactions": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.txtAmountRangeFrom": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.txtAmountRangeTo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.txtCheckNumberFrom": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "transactions.txtCheckNumberTo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "transactions.txtKeyword": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "accountTransactionList": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupNew": {
                        "segmentProps": []
                    },
                    "flxEditRule": {
                        "segmentProps": []
                    },
                    "editRule.btnCancel": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "editRule.btnConfirm": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "editRule.flxEditRuleWrapper": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCheckImage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CheckImage": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": [],
                        "instanceId": "CheckImage"
                    },
                    "CheckImage.flxImageCheck": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "CheckImage.flxNoimage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CheckImage.imgCheckImage": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CheckImage.imgCheckImageZoom": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CheckImage.lblBillAmount": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "CheckImage.lblMemo": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "CheckImage.lblNoCheck": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CheckImage.lblPostDate": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnClose": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "92%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnDownload": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.calFromDate": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.calToDate": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxButtons": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxDowntimeWarning": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxFromDate": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "115dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "392dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxSelectFormat": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxSeperator2": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxToDate": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.imgClose": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.infoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lblPickDateRange": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lblSelectFormat": {
                        "text": "Select Format",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lblSelectImg": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblTo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10px"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lbxSelectFormat": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "flxDownloadLoanSchedule": {
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6.25%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "37.50%"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.btnDownload": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.25%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "37.50%"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.flxDowntimeWarning": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.flxMiddle": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "174dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.flxPopup": {
                        "top": {
                            "type": "string",
                            "value": "215dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.75%"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.imgCloseDowntimeWarning": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.lblDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.lblInstallmentType": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "top": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.lblSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "top": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.lbxSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.75%"
                        },
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.lbxSelectType": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "3.13%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.75%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchDownloadTransaction": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "searchDownloadTransction.flxPopup": {
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxSTPopup": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "btnSTClose": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "text": "g",
                        "segmentProps": []
                    },
                    "flxCloseDTWarning": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDTWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSTDisclaimerInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknFlxffffffborderradE3E3E3",
                        "segmentProps": []
                    },
                    "flxSTInfoIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "53dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "infoIcon": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSTDisclaimer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxSTButton": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "btnSTDownload": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "btnSTCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxDownloadAttachment": {
                        "segmentProps": []
                    },
                    "flxDownloadItems": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "btnDownload": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "AllForms": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "instanceId": "AllForms"
                    },
                    "moreActions": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "390dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": [],
                        "instanceId": "moreActions"
                    },
                    "moreActions.imgToolTip": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "accountActionsMobile": {
                        "right": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "29.50%"
                        },
                        "segmentProps": []
                    },
                    "accountActionsMobile.imgToolTip": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "quicklinksMobile": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "29.50%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxCloseDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxRenewExpired": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "flxe3e3e3e30pxradius",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgExpired": {
                        "src": "erroricon.png",
                        "segmentProps": []
                    },
                    "lblRenewExpired": {
                        "centerY": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnRenew": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Renew Connection",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigation": {
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNavigation": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxViewStatements": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "instanceId": "ViewStatements"
                    },
                    "ViewStatements.confirmButtons.btnConfirm": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.confirmButtons.btnModify": {
                        "right": {
                            "type": "string",
                            "value": "29.18%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.flxContainerSelectAccounts": {
                        "width": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.flxSelectYear": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.lblSelectYear": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements.lstSelectAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "26.66%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.SegmentMonthWiseFiles1": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnCombinedStatements": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250px"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnEStatements": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "i18n_text": "i18n.olb.ViewEStatements",
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flexDataMonth4": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocInfoMessage": {
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocStatements": {
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocWarnMsg": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocWarningMessage": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxCombinedStatements": {
                        "height": {
                            "type": "string",
                            "value": "587dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.12%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxDisclaimerInfo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxffffffborderradE3E3E3",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxDownload": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "17%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxFileDownload": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxFileType": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoImage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoImage1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxLine": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-4dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxLine1": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxMain": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxMainWrapper": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxPaginationContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxStatementsTab": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxWarnInfoImage": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxWarningMessage": {
                        "height": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgAdhocInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgDownload": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "download_2x.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgFileType": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "pdf_image.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgWarnInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.infoIcon": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblAdhocInfoMessage": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDisclaimer": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "1"
                        },
                        "skin": "sknLblSSP42424213px",
                        "text": "Please bear in mind that your documents may contain personal information, please keep them safe if you chose to open or download any of them.",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDisclaimerInfo": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "right": {
                            "type": "number",
                            "value": "1"
                        },
                        "skin": "sknLblSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDownload": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblGeneratedOnDate": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "text": "26/11/2020, 10A M",
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblInfoMessage": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblMonth1": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblViewStatements": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.lbnFileName": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "text": "LInfinity bank -0097- account statement latest.pdf",
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.segStatements": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxTransactions": {
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "btnByPass2": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "16%"
                        },
                        "right": {
                            "type": "string",
                            "value": "65%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "transactions": {
                        "left": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "segmentProps": [],
                        "instanceId": "transactions"
                    },
                    "transactions.btnClearSearch": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.btnModifySearch": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxDownload": {
                        "segmentProps": []
                    },
                    "transactions.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxPaginationPrevious": {
                        "left": {
                            "type": "string",
                            "value": "128dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxPaginationWrapper": {
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxPrint": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "transactions.flxSearch": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "transactions.flxSearchContainer": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSearchResultActions": {
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSearchResults": {
                        "segmentProps": []
                    },
                    "transactions.flxSortAmount": {
                        "left": {
                            "type": "string",
                            "value": "66.11%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSortBalance": {
                        "width": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSortDate": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSortDescription": {
                        "left": {
                            "type": "string",
                            "value": "14.87%"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSortSixColumn": {
                        "left": {
                            "type": "string",
                            "value": "5.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSortType": {
                        "left": {
                            "type": "string",
                            "value": "55.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgSearchIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgSortAmount": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgSortBalance": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "transactions.lblPagination": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblSortAmount": {
                        "right": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblSortBalance": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblSortDescription": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblSortType": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.rtxNoPaymentMessage": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "accountTransactionList": {
                        "left": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "900dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupNew": {
                        "height": {
                            "type": "string",
                            "value": "300px"
                        },
                        "segmentProps": []
                    },
                    "flxEditRule": {
                        "segmentProps": []
                    },
                    "flxCheckImage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CheckImage": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": [],
                        "instanceId": "CheckImage"
                    },
                    "CheckImage.flxNoimage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CheckImage.imgCancel": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "CheckImage.imgCheckImage": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "CheckImage.lblNoCheck": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnClose": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "93%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnDownload": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.calFromDate": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.calToDate": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction": {
                        "segmentProps": [],
                        "instanceId": "downloadTransction"
                    },
                    "downloadTransction.flxButtons": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxDowntimeWarning": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "downloadTransction.flxFromDate": {
                        "left": {
                            "type": "string",
                            "value": "21.48%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "33.25%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxHeader": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxSeperator2": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "downloadTransction.flxToDate": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "64%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "33.25%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.imgClose": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.infoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lblPickDateRange": {
                        "left": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lblSelectFormat": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lblTo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "58.99%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lbxSelectFormat": {
                        "segmentProps": []
                    },
                    "flxDownloadLoanSchedule": {
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.flxPopup": {
                        "top": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "520dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchDownloadTransaction": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSTPopup": {
                        "height": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseDTWarning": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDTWarning": {
                        "segmentProps": []
                    },
                    "flxSTDisclaimerInfo": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknFlxffffffborderradE3E3E3",
                        "segmentProps": []
                    },
                    "flxSTInfoIcon": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "infoIcon": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSTDisclaimer": {
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxSTButton": {
                        "top": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "segmentProps": []
                    },
                    "btnSTDownload": {
                        "right": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "segmentProps": []
                    },
                    "btnDownload": {
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "moreActions": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "moreActions"
                    },
                    "accountActionsMobile": {
                        "segmentProps": []
                    },
                    "quicklinksMobile": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "290dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.50%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnByPass": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "segmentProps": []
                    },
                    "flxRenewExpired": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "skin": "flxe3e3e3e30pxradius",
                        "width": {
                            "type": "string",
                            "value": "1215dp"
                        },
                        "segmentProps": []
                    },
                    "imgExpired": {
                        "src": "erroricon.png",
                        "segmentProps": []
                    },
                    "lblRenewExpired": {
                        "centerY": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnRenew": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "text": "Renew Connection",
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "flxBackNavigation": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "58%"
                        },
                        "segmentProps": []
                    },
                    "flxImgBackNavigation": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblBack": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxViewStatements": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "ViewStatements": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": [],
                        "instanceId": "ViewStatements"
                    },
                    "ViewStatements.lstSelectAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnAdhocStatements": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnCombinedStatements": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "width": {
                            "type": "string",
                            "value": "250px"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnEStatements": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "i18n_text": "i18n.olb.ViewEStatements",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flexDataMonth4": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocInfoMessage": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocStatements": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocWarnMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocWarningMessage": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxCombinedStatements": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxDisclaimerInfo": {
                        "skin": "sknFlxffffffborderradE3E3E3",
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxDownload": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "131dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxFileDownload": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxFileType": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoImage": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoImage1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxLine": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxLine1": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxMain": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxMainWrapper": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxPaginationContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxStatementsTab": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxWarnInfoImage": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxWarningMessage": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgAdhocInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgDownload": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "download_2x.png",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgFileType": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "pdf_image.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgWarnInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.infoIcon": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDisclaimer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "i18n_text": "i18n.ViewStatements.DisclaimerInfo",
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "text": "Please bear in mind that your documents may contain personal information, please keep them safe if you chose to open or download any of them",
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDisclaimerInfo": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "i18n_text": "i18n.ViewStatements.DisclaimerInfoWithHyphen",
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "text": "-Please bear in mind that your documents may contain personal information, please keep them safe if you chose to open or download any of them",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDownload": {
                        "height": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblGeneratedOnDate": {
                        "height": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "text": "26/11/2020, 10:34 AM",
                        "top": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblMonth1": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.lbnFileName": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "text": "Infinity bank -0097- account statement latest.pdf",
                        "top": {
                            "type": "string",
                            "value": "46dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.segStatements": {
                        "segmentProps": []
                    },
                    "viewStatementsnew": {
                        "left": {
                            "type": "string",
                            "value": "6.40%"
                        },
                        "right": {
                            "type": "string",
                            "value": "6.40%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.20%"
                        },
                        "segmentProps": [],
                        "instanceId": "viewStatementsnew"
                    },
                    "flxTransactions": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnByPass2": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "right": {
                            "type": "string",
                            "value": "60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "transactions": {
                        "left": {
                            "type": "string",
                            "value": "6.40%"
                        },
                        "right": {
                            "type": "string",
                            "value": "6.40%"
                        },
                        "segmentProps": [],
                        "instanceId": "transactions"
                    },
                    "transactions.flxDownload": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "transactions.flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxPaginationPrevious": {
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "4"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxPaginationWrapper": {
                        "width": {
                            "type": "string",
                            "value": "26.50%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxPrint": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSearch": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSortAmount": {
                        "left": {
                            "type": "string",
                            "value": "77.11%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSortBalance": {
                        "segmentProps": []
                    },
                    "transactions.flxSortDate": {
                        "left": {
                            "type": "string",
                            "value": "5.50%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSortDescription": {
                        "left": {
                            "type": "string",
                            "value": "19.50%"
                        },
                        "segmentProps": []
                    },
                    "transactions.flxSortType": {
                        "left": {
                            "type": "string",
                            "value": "62.50%"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgInfo": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgSortAmount": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.imgSortBalance": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "transactions.lblPagination": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblSortAmount": {
                        "right": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblSortBalance": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.lblSortType": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "transactions.rtxNoPaymentMessage": {
                        "left": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "accountTransactionList": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "right": {
                            "type": "string",
                            "value": "4.85%"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooter"
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxEditRule": {
                        "segmentProps": []
                    },
                    "flxCheckImage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CheckImage.imgCancel": {
                        "src": "bbcloseicon.png",
                        "segmentProps": []
                    },
                    "downloadTransction.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnClose": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.btnDownload": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxButtons": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxDisclaimer": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxDowntimeWarning": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "downloadTransction.flxFromDate": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxInfoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxMiddle": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.flxPopup": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxSeperator2": {
                        "segmentProps": []
                    },
                    "downloadTransction.flxToDate": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.imgClose": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.infoIcon": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblDisclaimer": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lblPickDateRange": {
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lblSelectFormat": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblTo": {
                        "left": {
                            "type": "string",
                            "value": "62%"
                        },
                        "top": {
                            "type": "string",
                            "value": "42px"
                        },
                        "segmentProps": []
                    },
                    "downloadTransction.lbxSelectFormat": {
                        "segmentProps": []
                    },
                    "flxDownloadLoanSchedule": {
                        "segmentProps": []
                    },
                    "downloadLoanSchedule.flxPopup": {
                        "width": {
                            "type": "string",
                            "value": "48%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchDownloadTransaction": {
                        "segmentProps": []
                    },
                    "flxSTPopup": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxCloseDTWarning": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxSTDisclaimerInfo": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "skin": "bbSKnFlxf1ab15",
                        "segmentProps": []
                    },
                    "flxSTInfoIcon": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "infoIcon": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSTDisclaimer": {
                        "i18n_text": "i18n.ViewStatements.DisclaimerInfo",
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxSTButton": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "btnSTDownload": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownloadAttachment": {
                        "segmentProps": []
                    },
                    "flxDownloadItems": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnDownload": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxMainWrapper": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "accountActionsMobile": {
                        "segmentProps": []
                    },
                    "flxRenewExpired": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1215dp"
                        },
                        "segmentProps": []
                    },
                    "lblRenewExpired": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnAdhocStatements": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnCombinedStatements": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "width": {
                            "type": "string",
                            "value": "250px"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.btnEStatements": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocInfoMessage": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocStatements": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocWarnMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxAdhocWarningMessage": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxCombinedStatements": {
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxDisclaimerInfo": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxDownload": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "131dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxFileDownload": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxFileType": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoIcon": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoImage": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxInfoImage1": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxLine": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxLine1": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxMain": {
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxPaginationContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxStatementsTab": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxWarnInfoImage": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.flxWarningMessage": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgAdhocInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgDownload": {
                        "height": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "download_2x.png",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgFileType": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "pdf_image.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.imgWarnInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.infoIcon": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDisclaimer": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "text": "Please bear in mind that your documents may contain personal information, please keep them safe if you chose to open or download any of them.",
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDisclaimerInfo": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblDownload": {
                        "height": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblGeneratedOnDate": {
                        "height": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lblInfoMessage": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "viewStatementsnew.lbnFileName": {
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "46dp"
                        },
                        "segmentProps": []
                    },
                    "btnByPass2": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "accountTransactionList": {
                        "right": {
                            "type": "string",
                            "value": "6.40%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEditRule": {
                        "segmentProps": []
                    },
                    "downloadTransction.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchDownloadTransaction": {
                        "segmentProps": []
                    },
                    "flxSTPopup": {
                        "height": {
                            "type": "string",
                            "value": "26%"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "btnSTClose": {
                        "left": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxSTDisclaimerInfo": {
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxSTInfoIcon": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "infoIcon": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "info_blue.png",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSTDisclaimer": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxSTButton": {
                        "top": {
                            "type": "string",
                            "value": "17%"
                        },
                        "segmentProps": []
                    },
                    "btnSTDownload": {
                        "right": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "btnSTCancel": {
                        "right": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "moreActionsDup": {
                    "left": "65%",
                    "top": "350dp",
                    "width": "28.48%",
                    "zIndex": 10
                },
                "moreActionsDup.imgToolTip": {
                    "left": "86.50%",
                    "src": "tool_tip.png"
                },
                "moreActionsDup.segAccountTypes": {
                    "data": [{
                        "lblSeparator": "Separator",
                        "lblUsers": "Pay a Person from"
                    }, {
                        "lblSeparator": "Separator",
                        "lblUsers": "Order Check"
                    }, {
                        "lblSeparator": "Separator",
                        "lblUsers": "Edit Account"
                    }, {
                        "lblSeparator": "Separator",
                        "lblUsers": "Download Statement"
                    }, {
                        "lblSeparator": "Separator",
                        "lblUsers": "Settings & Alerts"
                    }],
                    "maxHeight": "",
                    "width": "100%"
                },
                "breadcrumb": {
                    "height": "53dp",
                    "top": "0dp"
                },
                "breadcrumb.flxBottomBorder": {
                    "bottom": "0dp"
                },
                "breadcrumb.flxBreadcrumbcontainer": {
                    "centerX": "50%",
                    "height": "50dp",
                    "top": "1dp",
                    "width": "1366dp"
                },
                "breadcrumb.flxTopBorder": {
                    "top": "0dp"
                },
                "breadcrumb.imgBreadcrumb": {
                    "src": "breadcrumb_icon.png"
                },
                "breadcrumb.imgBreadcrumb2": {
                    "src": "breadcrumb_icon.png"
                },
                "AllForms": {
                    "left": "51.60%",
                    "top": "290dp",
                    "width": "270dp",
                    "zIndex": 10
                },
                "AllForms.flxAccountType": {
                    "top": "-2dp"
                },
                "AllForms.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "AllForms.imgToolTip": {
                    "left": "125px",
                    "src": "tool_tip.png"
                },
                "moreActions": {
                    "left": "",
                    "right": "6%",
                    "top": "290dp",
                    "width": "28.50%",
                    "zIndex": 10
                },
                "moreActions.imgToolTip": {
                    "left": "",
                    "right": "22dp",
                    "src": "tool_tip.png"
                },
                "accountActionsMobile": {
                    "left": "",
                    "right": "6%",
                    "top": "290dp",
                    "width": "28.50%",
                    "zIndex": 200
                },
                "accountActionsMobile.imgToolTip": {
                    "left": "",
                    "right": "22dp",
                    "src": "tool_tip.png"
                },
                "quicklinksMobile": {
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "ViewStatements": {
                    "width": "100%"
                },
                "ViewStatements.confirmButtons": {
                    "top": "100dp"
                },
                "ViewStatements.confirmButtons.btnConfirm": {
                    "height": "40dp"
                },
                "ViewStatements.confirmButtons.btnModify": {
                    "height": "40dp"
                },
                "ViewStatements.flxSelectReasonForDispute": {
                    "width": "100%"
                },
                "viewStatementsnew.btnAdhocStatements": {
                    "height": "40dp",
                    "top": "12dp"
                },
                "viewStatementsnew.btnCombinedStatements": {
                    "height": "50dp",
                    "top": "23dp",
                    "width": "300dp"
                },
                "viewStatementsnew.btnConfirm": {
                    "bottom": "",
                    "height": "50dp",
                    "width": "21.40%"
                },
                "viewStatementsnew.btnEStatements": {
                    "height": "50dp",
                    "left": "29dp",
                    "top": "20dp",
                    "width": "300dp"
                },
                "viewStatementsnew.flxAdhocInfoMessage": {
                    "width": "100%"
                },
                "viewStatementsnew.flxAdhocStatements": {
                    "left": "31dp"
                },
                "viewStatementsnew.flxAdhocWarnMsg": {
                    "left": "33dp",
                    "top": "20dp",
                    "width": "1160dp"
                },
                "viewStatementsnew.flxAdhocWarningMessage": {
                    "height": "481dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxCombinedStatements": {
                    "height": "220dp",
                    "left": "31dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxDisclaimerInfo": {
                    "centerX": "",
                    "height": "65px",
                    "left": "33dp",
                    "right": "",
                    "top": "35dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxDownload": {
                    "height": "220dp",
                    "left": "9dp",
                    "right": "",
                    "top": "7dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxFileDownload": {
                    "height": "220dp",
                    "left": "33dp",
                    "top": "35dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxFileType": {
                    "height": "220dp",
                    "left": "9dp",
                    "top": "7dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxInfoIcon": {
                    "height": "30dp",
                    "left": "9dp",
                    "top": "7dp",
                    "width": "30dp"
                },
                "viewStatementsnew.flxInfoImage": {
                    "centerY": "",
                    "height": "220dp",
                    "left": "9dp",
                    "top": "7dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxInfoImage1": {
                    "left": "9dp"
                },
                "viewStatementsnew.flxLine": {
                    "height": "220dp",
                    "left": "0dp",
                    "top": "-1dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxLine1": {
                    "height": "220dp",
                    "left": "21dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxMainWrapper": {
                    "zIndex": 10
                },
                "viewStatementsnew.flxPaginationContainer": {
                    "left": 70
                },
                "viewStatementsnew.flxStatementsTab": {
                    "height": "220dp",
                    "left": "4dp"
                },
                "viewStatementsnew.flxWarnInfoImage": {
                    "height": "220dp",
                    "left": "9dp",
                    "top": "7dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxWarningMessage": {
                    "height": "220dp",
                    "left": "33dp",
                    "top": "35dp",
                    "width": "100%"
                },
                "viewStatementsnew.flxlblMonth12Separator": {
                    "height": "1dp",
                    "top": 10
                },
                "viewStatementsnew.imgAdhocInfoMessage": {
                    "height": "150dp",
                    "left": "67dp",
                    "src": "info_large.png",
                    "top": "3dp",
                    "width": "150dp"
                },
                "viewStatementsnew.imgDownload": {
                    "height": "150dp",
                    "left": "67dp",
                    "right": "",
                    "src": "imagedrag.png",
                    "top": "3dp",
                    "width": "150dp"
                },
                "viewStatementsnew.imgFileType": {
                    "height": "150dp",
                    "left": "67dp",
                    "src": "imagedrag.png",
                    "top": "3dp",
                    "width": "150dp"
                },
                "viewStatementsnew.imgInfoMessage": {
                    "height": "150dp",
                    "left": "67dp",
                    "src": "imagedrag.png",
                    "top": "3dp",
                    "width": "150dp"
                },
                "viewStatementsnew.imgSortDate": {
                    "src": "sorting_next_3.png"
                },
                "viewStatementsnew.imgWarnInfoMessage": {
                    "height": "150dp",
                    "left": "67dp",
                    "src": "imagedrag.png",
                    "top": "3dp",
                    "width": "150dp"
                },
                "viewStatementsnew.infoIcon": {
                    "height": "150dp",
                    "left": "67dp",
                    "src": "info_blue.png",
                    "top": "3dp",
                    "width": "150dp"
                },
                "viewStatementsnew.lblAdhocInfoMessage": {
                    "left": "50dp"
                },
                "viewStatementsnew.lblDisclaimer": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "85dp",
                    "right": "",
                    "text": "Label",
                    "top": "24dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "viewStatementsnew.lblDisclaimerInfo": {
                    "bottom": "",
                    "centerY": "",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "85dp",
                    "right": "",
                    "top": "24dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "viewStatementsnew.lblDownload": {
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "1141dp",
                    "right": "",
                    "top": "35dp"
                },
                "viewStatementsnew.lblGeneratedOnDate": {
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "85dp",
                    "text": "Label",
                    "top": "24dp"
                },
                "viewStatementsnew.lblInfoMessage": {
                    "bottom": "",
                    "centerY": "",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "85dp",
                    "right": "",
                    "top": "24dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "viewStatementsnew.lblMonth1": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "viewStatementsnew.lbnFileName": {
                    "left": "79dp",
                    "text": "Label",
                    "top": "52dp"
                },
                "viewStatementsnew.segStatements": {
                    "left": "20dp",
                    "right": "20dp",
                    "width": "97%"
                },
                "viewStatementsnew": {
                    "left": "0dp",
                    "right": "",
                    "width": "100%"
                },
                "transactions": {
                    "left": "6%",
                    "right": "6%",
                    "top": "0dp",
                    "width": ""
                },
                "transactions.btnWithdrawDeposit": {
                    "text": "Withdraw"
                },
                "transactions.flxHeader": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "transactions.flxPaginationWrapper": {
                    "centerX": "",
                    "centerY": "",
                    "right": "0dp",
                    "width": "25%"
                },
                "transactions.flxRightSearchWrapper": {
                    "left": "0dp"
                },
                "transactions.flxSearchContainer": {
                    "top": "0dp",
                    "zIndex": 1
                },
                "transactions.flxSearchResults": {
                    "zIndex": 1
                },
                "transactions.flxSegmentContainer": {
                    "top": "0dp"
                },
                "transactions.flxSortBalance": {
                    "right": "1.94%"
                },
                "transactions.flxSortDate": {
                    "left": "6%"
                },
                "transactions.imgCancel": {
                    "src": "search_close.png"
                },
                "transactions.imgCancelAmountRange": {
                    "src": "search_close.png"
                },
                "transactions.imgCancelAmountRangeM": {
                    "src": "search_close.png"
                },
                "transactions.imgCancelCheckNumber": {
                    "src": "search_close.png"
                },
                "transactions.imgCancelCheckNumberM": {
                    "src": "search_close.png"
                },
                "transactions.imgCancelDateRange": {
                    "src": "search_close.png"
                },
                "transactions.imgCancelDateRangeM": {
                    "src": "search_close.png"
                },
                "transactions.imgCancelM": {
                    "src": "search_close.png"
                },
                "transactions.imgCancelType": {
                    "src": "search_close.png"
                },
                "transactions.imgCancelTypeM": {
                    "src": "search_close.png"
                },
                "transactions.imgDownload": {
                    "src": "download_blue.png"
                },
                "transactions.imgInfo": {
                    "src": "info_large.png"
                },
                "transactions.imgPaginationFirst": {
                    "src": "pagination_inactive.png"
                },
                "transactions.imgPaginationLast": {
                    "src": "pagination_next_active.png"
                },
                "transactions.imgPaginationNext": {
                    "src": "pagination_next_active.png"
                },
                "transactions.imgPaginationPrevious": {
                    "src": "pagination_back_inactive.png"
                },
                "transactions.imgPrint": {
                    "src": "print_blue.png"
                },
                "transactions.imgSearch": {
                    "src": "search_blue.png"
                },
                "transactions.imgSortAmount": {
                    "src": "sorting.png"
                },
                "transactions.imgSortBalance": {
                    "src": "not_applied_sort.png"
                },
                "transactions.imgSortCategory": {
                    "src": "sorting.png"
                },
                "transactions.imgSortDate": {
                    "src": "sorting_next.png"
                },
                "transactions.imgSortDescription": {
                    "src": "not_applied_sort.png"
                },
                "transactions.imgSortType": {
                    "src": "not_applied_sort.png"
                },
                "transactions.lblByCheckNumber": {
                    "top": "30dp"
                },
                "transactions.lblPagination": {
                    "centerY": "50%",
                    "left": "4dp",
                    "top": "0",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "transactions.lblTransactions": {
                    "left": "0dp"
                },
                "accountTransactionList": {
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "150dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "top": "75dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopupNew": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": ""
                },
                "editRule.btnCancel": {
                    "height": "40dp",
                    "left": "",
                    "right": "199dp",
                    "width": "150dp"
                },
                "editRule.btnClose": {
                    "right": "20dp"
                },
                "editRule.btnConfirm": {
                    "height": "40dp",
                    "right": "30dp",
                    "width": "150dp"
                },
                "editRule": {
                    "height": "800dp",
                    "zIndex": 1000
                },
                "editRule.flxActions": {
                    "height": "80dp"
                },
                "editRule.flxEditRuleWrapper": {
                    "height": "360dp",
                    "left": "",
                    "right": "",
                    "width": "795dp"
                },
                "CheckImage": {
                    "centerX": "50%",
                    "centerY": "",
                    "height": "700dp",
                    "left": "0dp",
                    "top": "100dp",
                    "width": "1000dp",
                    "zIndex": 1000
                },
                "CheckImage.flxImageCheck": {
                    "width": "90%"
                },
                "CheckImage.imgCancel": {
                    "src": "icon_close_grey.png"
                },
                "CheckImage.imgCheckImage": {
                    "src": "check_img.png"
                },
                "CheckImage.imgCheckImageZoom": {
                    "src": "check_img.png"
                },
                "CheckImage.imgFlipIcon": {
                    "centerY": "52%",
                    "left": "",
                    "top": ""
                },
                "CheckImage.imgInfo": {
                    "src": "info_large.png"
                },
                "CheckImage.imgPrintIcon": {
                    "centerY": "52%",
                    "left": "",
                    "text": "D",
                    "top": ""
                },
                "CheckImage.imgZoomIcon": {
                    "centerY": "53%",
                    "left": "",
                    "top": ""
                },
                "CheckImage.lblBillAmount": {
                    "width": "10%"
                },
                "CheckImage.lblEbillDetails": {
                    "height": "80dp"
                },
                "CheckImage.lblMemo": {
                    "width": "10%"
                },
                "CheckImage.lblNoCheck": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CheckImage.lblPostDate": {
                    "left": "0%",
                    "width": "10%"
                },
                "downloadTransction.btnCancel": {
                    "centerX": "",
                    "centerY": "50%",
                    "height": "50dp",
                    "left": "",
                    "right": "230dp",
                    "top": "",
                    "width": "160dp"
                },
                "downloadTransction.btnClose": {
                    "centerY": "50%",
                    "height": "15px",
                    "left": "93.50%",
                    "right": 22,
                    "top": "0",
                    "width": "15px"
                },
                "downloadTransction.btnDownload": {
                    "centerX": "",
                    "centerY": "50%",
                    "height": "50dp",
                    "left": "",
                    "right": "25dp",
                    "top": "",
                    "width": "160dp"
                },
                "downloadTransction.calFromDate": {
                    "left": "4.34%",
                    "width": "95.60%"
                },
                "downloadTransction.calToDate": {
                    "left": "4.34%",
                    "right": "",
                    "width": "95.60%"
                },
                "downloadTransction": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "downloadTransction.flxButtons": {
                    "bottom": "",
                    "height": "60px",
                    "top": "0dp"
                },
                "downloadTransction.flxDisclaimer": {
                    "centerX": "50%",
                    "height": "75%",
                    "left": "",
                    "top": "15%",
                    "width": "93%"
                },
                "downloadTransction.flxDisclaimerInfo": {
                    "height": "112px"
                },
                "downloadTransction.flxFromDate": {
                    "centerX": "",
                    "centerY": "",
                    "left": "30.56%",
                    "width": "230dp"
                },
                "downloadTransction.flxHeader": {
                    "height": "52px"
                },
                "downloadTransction.flxInfoIcon": {
                    "height": "35dp",
                    "left": "5dp",
                    "top": "5dp",
                    "width": "35dp"
                },
                "downloadTransction.flxMiddle": {
                    "centerX": "",
                    "height": "75dp",
                    "left": "0dp",
                    "minHeight": "",
                    "top": "0dp",
                    "layoutType": kony.flex.FREE_FORM
                },
                "downloadTransction.flxPopup": {
                    "centerX": "47.58%",
                    "height": "310dp",
                    "left": "",
                    "right": "",
                    "width": "37%"
                },
                "downloadTransction.flxSelectFormat": {
                    "left": "46.30%",
                    "top": "10dp",
                    "width": "252dp"
                },
                "downloadTransction.flxSeperator2": {
                    "bottom": "",
                    "top": "68dp"
                },
                "downloadTransction.flxToDate": {
                    "centerX": "",
                    "centerY": "",
                    "right": ""
                },
                "downloadTransction.imgClose": {
                    "height": "15dp",
                    "right": "20dp",
                    "src": "bbcloseicon.png",
                    "width": "15px"
                },
                "downloadTransction.imgCloseDowntimeWarning": {
                    "src": "icon_close_grey.png"
                },
                "downloadTransction.imgDowntimeWarning": {
                    "src": "error_yellow.png"
                },
                "downloadTransction.infoIcon": {
                    "src": "exclaim_info.png"
                },
                "downloadTransction.lblDisclaimer": {
                    "bottom": "",
                    "left": "45dp",
                    "right": "",
                    "top": "5dp",
                    "width": "89%"
                },
                "downloadTransction.lblHeader": {
                    "bottom": "0",
                    "centerY": "50%",
                    "left": "14%",
                    "top": ""
                },
                "downloadTransction.lblPickDateRange": {
                    "centerX": "",
                    "centerY": "",
                    "left": "3.77%"
                },
                "downloadTransction.lblSelectFormat": {
                    "centerY": "",
                    "left": "4.30%",
                    "top": "15dp"
                },
                "downloadTransction.lblSelectImg": {
                    "left": "91%",
                    "top": "17dp"
                },
                "downloadTransction.lblTo": {
                    "centerX": "",
                    "centerY": "",
                    "height": "30px",
                    "right": ""
                },
                "downloadTransction.lbxSelectFormat": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "",
                    "height": "40dp",
                    "left": "46.30%",
                    "minWidth": "",
                    "right": "",
                    "top": "10dp",
                    "width": "50%"
                },
                "downloadLoanSchedule.btnCancel": {
                    "centerY": "50%",
                    "left": "",
                    "right": "190dp",
                    "top": "",
                    "width": "150dp"
                },
                "downloadLoanSchedule.btnDownload": {
                    "centerY": "50%",
                    "left": "",
                    "right": "20dp",
                    "top": "",
                    "width": "150dp"
                },
                "downloadLoanSchedule.flxButtons": {
                    "height": "100dp"
                },
                "downloadLoanSchedule.flxDowntimeWarning": {
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "downloadLoanSchedule.flxHeader": {
                    "height": "44dp"
                },
                "downloadLoanSchedule.flxMiddle": {
                    "centerX": "",
                    "height": "170dp",
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%",
                    "layoutType": kony.flex.FREE_FORM
                },
                "downloadLoanSchedule.flxPopup": {
                    "top": "440dp",
                    "width": "38.07%"
                },
                "downloadLoanSchedule.imgClose": {
                    "src": "icon_close_grey.png"
                },
                "downloadLoanSchedule.imgCloseDowntimeWarning": {
                    "right": "0dp",
                    "src": "icon_close_grey_1.png"
                },
                "downloadLoanSchedule.imgDowntimeWarning": {
                    "src": "error_yellow_4.png"
                },
                "downloadLoanSchedule.lblDowntimeWarning": {
                    "left": "20dp",
                    "width": "75%"
                },
                "downloadLoanSchedule.lblHeader": {
                    "left": "20dp"
                },
                "downloadLoanSchedule.lblInstallmentType": {
                    "centerX": "",
                    "left": "20dp",
                    "top": "42dp"
                },
                "downloadLoanSchedule.lblSelectFormat": {
                    "left": "20dp",
                    "top": "112dp"
                },
                "downloadLoanSchedule.lbxSelectFormat": {
                    "left": "",
                    "right": "20dp",
                    "top": "100dp",
                    "width": "320dp"
                },
                "downloadLoanSchedule.lbxSelectType": {
                    "centerX": "",
                    "left": "",
                    "right": "20dp",
                    "top": "30dp",
                    "width": "320dp"
                },
                "searchDownloadTransction.btnClose": {
                    "height": "20dp",
                    "width": "20dp"
                },
                "searchDownloadTransction.flxPopup": {
                    "width": "500dp"
                },
                "searchDownloadTransction.lblTypeValue": {
                    "minWidth": ""
                }
            }
            this.add(flxHeader, flxFormContent, flxLogout, flxPopup, flxEditRule, flxCheckImage, flxDownloadTransaction, flxDownloadLoanSchedule, flxSearchDownloadTransaction, flxSingleTransactionDownload, flxLoading, flxDownloadAttachment);
        };
        return [{
            "addWidgets": addWidgetsfrmViewStatements,
            "enabledForIdleTimeout": true,
            "id": "frmViewStatements",
            "init": controller.AS_Form_dd401fa4e6c84690bb190bdadd036569,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_a556ff33d54a4d87b90c7e122318a300,
            "postShow": controller.AS_Form_aae97ff7c78e4c6d97d9e58ac69b6bd0,
            "preShow": function(eventobject) {
                controller.AS_Form_ccb2f9b5921a452d80df9237ee3af1d0(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Account Statements",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "onBreakpointChange": controller.AS_Form_j18e2b65860a41a2b0aab4c8d91fcfd3,
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_jf394542d18e43f3aea460e011e693b9,
            "retainScrollPosition": true
        }]
    }
});