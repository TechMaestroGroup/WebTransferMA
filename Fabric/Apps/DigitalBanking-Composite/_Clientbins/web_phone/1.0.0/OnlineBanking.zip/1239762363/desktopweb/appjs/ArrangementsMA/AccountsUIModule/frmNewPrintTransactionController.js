define("ArrangementsMA/AccountsUIModule/userfrmNewPrintTransactionController", ['CommonUtilities', 'OLBConstants'], function(CommonUtilities, OLBConstants) {
    var orientationHandler = new OrientationHandler();
    return {
        showInfo: {},
        preShow: function() {
            var navMan = applicationManager.getNavigationManager();
            var scopeObj = this;
            this.showInfo = navMan.getCustomInfo("frmNewPrintTransaction");
            this.setUpFormData();
        },
        setUpFormData: function() {
            this.view.lblKonyBank.text = this.showInfo.accountName;
            this.view.lblMyCheckingAccount.text = this.showInfo.accountName;
            this.view.keyValueAccHolderName.lblValue.text = this.showInfo.AccountName;
            this.view.keyValueAccNumber.lblValue.text = this.showInfo.AccountNumber;
            this.view.keyValueAvailableBalance.lblValue.text = this.showInfo.principalBalance;
            this.view.keyValueCurrentBalance.lblValue.text = this.showInfo.currentBalance;
            this.view.keyValuePendingDeposits.lblValue.text = this.showInfo.pendingDeposits;
            this.view.keyValuePendingWithdrawal.lblValue.text = this.showInfo.pendingWithdrawals;
            this.view.lblPendingTransactions.text = this.showInfo.selectedTab + " " + "Transactions";
            if (this.showInfo.selectedTab === "Blocked") {
                this.view.lblDate.text = kony.i18n.getLocalizedString("i18n.transfers.RefrenceNumber");
                this.view.lblType.text = kony.i18n.getLocalizedString("i18n.accounts.toDate");
                this.view.lblAmount.text = kony.i18n.getLocalizedString("i18n.transfers.amountlabel");
                this.view.lblBalance.text = kony.i18n.getLocalizedString("i18n.accounts.fromDate");
                this.view.lblDescription.left = "18%";
            } else {
                this.view.lblDate.text = kony.i18n.getLocalizedString("i18n.transfers.lblDate");
                this.view.lblType.text = kony.i18n.getLocalizedString("i18n.common.Type");
                this.view.lblAmount.text = kony.i18n.getLocalizedString("i18n.transfers.amountlabel");
                this.view.lblBalance.text = kony.i18n.getLocalizedString("i18n.AccountsDetails.Balance");
                this.view.lblDescription.left = "14%";
            }
        },
        postShow: function() {
            scope = this;
            applicationManager.getNavigationManager().applyUpdates(this);
            var navMan = applicationManager.getNavigationManager();
            var transactions = navMan.getCustomInfo("frmNewPrintTransactionData");
            this.showInfo.transactions = transactions;
            //  var segData = [];
            if (kony.application.getCurrentBreakpoint() === 640 || orientationHandler.isMobile) {
                var segData = [];
                transactions.forEach(function(transaction) {
                    segData.push({
                        "lblAmount": transaction.lbl2.text,
                        "lblDate": transaction.lbl1.text,
                        "lblSeparator": "",
                        "lblDescription": "",
                        "lblBalance": "",
                        "lblType": ""
                    })
                })
                this.view.segPendingTransaction.isVisible = true;
                this.view.segPendingTransaction.setData(segData);
            } else if (kony.application.getCurrentBreakpoint() === 1024 || orientationHandler.isTablet) {
                var segData = [];
                transactions.forEach(function(transaction) {
                    segData.push({
                        "lblAmount": transaction.lbl3.text,
                        "lblBalance": transaction.lbl2.text,
                        "lblDate": transaction.lbl1.text,
                        "lblDescription": "",
                        "lblSeparator": "",
                        "lblType": transaction.lbl4.text
                    })
                })
                this.view.segPendingTransaction.isVisible = true;
                this.view.segPendingTransaction.setData(segData);
            } else {
                var segData = [];
                if (this.showInfo.selectedTab === "Blocked") {
                    transactions.forEach(function(transaction) {
                        segData.push({
                            "lblAmount": transaction.lbl2.text,
                            "lblBalance": transaction.lbl3.text,
                            "lblDate": transaction.lbl1.text,
                            "lblDescription": {
                                "text": transaction.lbl5.text !== undefined ? transaction.lbl5.text : "",
                                "left": "18%"
                            },
                            "lblSeparator": "",
                            "lblType": transaction.lbl4.text
                        })
                    })
                } else {
                    transactions.forEach(function(transaction) {
                        segData.push({
                            "lblAmount": transaction.lbl2.text,
                            "lblBalance": transaction.lbl3.text,
                            "lblDate": transaction.lbl1.text,
                            "lblDescription": transaction.lbl5.text !== undefined ? transaction.lbl5.text : "",
                            "lblSeparator": "",
                            "lblType": transaction.lbl4.text
                        })
                    })
                }
                this.view.segPendingTransaction.isVisible = true;
                this.view.segPendingTransaction.setData(segData);
            }
            if (segData.length == 0) {
                this.view.segPendingTransaction.isVisible = false;
            }
            setTimeout(function() {
                scope.printCall();
            }, "17ms");
            applicationManager.getNavigationManager().applyUpdates(this);
        },
        printCall: function() {
            var scope = this;
            kony.os.print();
            setTimeout(function() {
                scope.loadAccountsDetails();
            }, "17ms");
        },
        loadAccountsDetails: function() {
            var navMan = applicationManager.getNavigationManager();
            kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("AccountsUIModule").presentationController.presentAccountDetails();
            kony.application.dismissLoadingScreen();
        }
    }
});
define("ArrangementsMA/AccountsUIModule/frmNewPrintTransactionControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for frmNewPrintTransaction **/
    AS_Form_b269b4f03231402a91128bdecb4d6cbc: function AS_Form_b269b4f03231402a91128bdecb4d6cbc(eventobject) {
        var self = this;
        this.preShow();
    },
    /** postShow defined for frmNewPrintTransaction **/
    AS_Form_gba543ca9f94493ea7454a568dc7ea2f: function AS_Form_gba543ca9f94493ea7454a568dc7ea2f(eventobject) {
        var self = this;
        this.postShow();
    }
});
define("ArrangementsMA/AccountsUIModule/frmNewPrintTransactionController", ["ArrangementsMA/AccountsUIModule/userfrmNewPrintTransactionController", "ArrangementsMA/AccountsUIModule/frmNewPrintTransactionControllerActions"], function() {
    var controller = require("ArrangementsMA/AccountsUIModule/userfrmNewPrintTransactionController");
    var controllerActions = ["ArrangementsMA/AccountsUIModule/frmNewPrintTransactionControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
