define("ForeignExchangeMA/ForeignExchangeUIModule/userfrmForexDashboardController", ["FormControllerUtility"], function(FormControllerUtility) {
    return {
        init: function() {
            this.view.onBreakpointChange = this.onBreakpointChange;
            this.presenter = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("ForeignExchangeUIModule").presentationController;
        },
        updateFormUI: function(viewModel) {
            if (viewModel.isLoading === true) {
                FormControllerUtility.showProgressBar(this.view);
            } else if (viewModel.isLoading === false) {
                FormControllerUtility.hideProgressBar(this.view);
            }
        },
        preShow: function() {
            var scopeObj = this;
            this.view.customheadernew.activateMenu(kony.i18n.getLocalizedString("i18n.kony.exchangeRates.ExchangeRatesHeader"), "");
            this.setCountryCodeForExchange();
            this.setFeatures();
            this.setMobileHeader();
            this.fetchExchangeRates();
            FormControllerUtility.updateWidgetsHeightInInfo(this, ["flxHeader", "flxFooter", "flxMain", "flxFormContent", ]);
            scopeObj.view.customheadernew.activateMenu("Exchange Rates", " ");
        },
        postShow: function() {
            // this.view.flxMain.minHeight = kony.os.deviceInfo().screenHeight - this.view.flxHeader.info.frame.height - this.view.flxFooter.info.frame.height + "dp";
        },
        onBreakpointChange: function(form, width) {
            FormControllerUtility.setupFormOnTouchEnd(width);
            this.view.customheadernew.onBreakpointChangeComponent(width);
            this.view.customfooternew.onBreakpointChangeComponent(width);
            this.setMobileHeader();
        },
        setFeatures: function() {
            this.view.foreignExchange.setFeaturesAndPermissions(applicationManager.getConfigurationManager().getUserFeatures(), applicationManager.getConfigurationManager().getUserPermissions());
        },
        setCountryCodeForExchange: function() {
            var countryCode = "";
            var userAddresses = applicationManager.getUserPreferencesManager().getUserObj().Addresses;
            if (Array.isArray(userAddresses) && userAddresses.length > 0) {
                userAddresses.forEach(function(address) {
                    if (address.isPrimary === "true") {
                        countryCode = address.CountryCode;
                    }
                });
            }
            this.view.foreignExchange.setCountryCode(countryCode);
        },
        setMobileHeader: function() {
            var orientationHandler = new OrientationHandler();
            var isMobile = orientationHandler.isMobile || kony.application.getCurrentBreakpoint() === 640;
            if (isMobile) {
                this.view.flxForexHeader.setVisibility(false);
                this.view.lblForexHeader.text = "";
                this.view.flxFormContent.top = "70dp";
                this.view.customheadernew.lblHeaderMobile.text = kony.i18n.getLocalizedString("kony.mb.Europe.ExchangeRate");
            } else {
                this.view.flxForexHeader.setVisibility(true);
                this.view.customheadernew.lblHeaderMobile.text = "";
                this.view.lblForexHeader.text = kony.i18n.getLocalizedString("kony.mb.Europe.ExchangeRate");
            }
        },
        fetchExchangeRates: function() {
            var self = this;
            var exchangeRateMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("ForeignExchangeUIModule");
            var errorCallback = function(error) {
                alert("Error fetching rates: " + JSON.stringify(error));
            };
            exchangeRateMod.presentationController.getExchangeRates(function(response) {
                applicationManager.getPresentationUtility().dismissLoadingScreen();
                self.view.segRatesDetails.widgetDataMap = {
                    lblCurrCode: "lblCurrCode",
                    lblBuyRate: "lblBuyRate",
                    lblSellRate: "lblSellRate",
                    imgCurrency: "imgCurrency",
                };
                var images = ["aed.png", "ats.png", "aud.png", "bef.png", "cad.png", "chf.png", "dem.png", "djf.png", "dkk.png", "etb.png", "eur.png", "frf.png", "gbp.png", "inr.png", "itl.png", "jpy.png", "kes.png", "nlg.png", "nok.png", "sar.png", "sek.png", "usd.png", "xaf.png", "zar.png", ];
                if (!Array.isArray(response.body)) {
                    alert("Unexpected response format");
                    return;
                }
                // alert(response.body);
                var mappedCurrencyData = response.body.map(function(currency) {
                    var matchingImage = images.find((image) => image.startsWith((currency.currencyCode || "").toLowerCase()));
                    return {
                        lblCurrCode: currency.currencyCode,
                        lblBuyRate: currency.buyRate.toFixed(4),
                        lblSellRate: currency.sellRate.toFixed(4),
                        imgCurrency: matchingImage || "defaultflag.png",
                    };
                });
                if (self.view.segRatesDetails) {
                    self.view.segRatesDetails.setData(mappedCurrencyData);
                }
            }, errorCallback); // make sure this is supported
        },
    };
});
define("ForeignExchangeMA/ForeignExchangeUIModule/frmForexDashboardControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for frmForexDashboard **/
    AS_Form_a09971ae49914bceb7ad9545cec39442: function AS_Form_a09971ae49914bceb7ad9545cec39442(eventobject) {
        var self = this;
        self.init();
    },
    /** postShow defined for frmForexDashboard **/
    AS_Form_a6abd548364e49a19ba1cfaf299b7f60: function AS_Form_a6abd548364e49a19ba1cfaf299b7f60(eventobject) {
        var self = this;
        return self.postShow.call(this);
    },
    /** preShow defined for frmForexDashboard **/
    AS_Form_da81c7208cbb471bbd8f7eefe0a1d2df: function AS_Form_da81c7208cbb471bbd8f7eefe0a1d2df(eventobject) {
        var self = this;
        return self.preShow.call(this);
    }
});
define("ForeignExchangeMA/ForeignExchangeUIModule/frmForexDashboardController", ["ForeignExchangeMA/ForeignExchangeUIModule/userfrmForexDashboardController", "ForeignExchangeMA/ForeignExchangeUIModule/frmForexDashboardControllerActions"], function() {
    var controller = require("ForeignExchangeMA/ForeignExchangeUIModule/userfrmForexDashboardController");
    var controllerActions = ["ForeignExchangeMA/ForeignExchangeUIModule/frmForexDashboardControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
