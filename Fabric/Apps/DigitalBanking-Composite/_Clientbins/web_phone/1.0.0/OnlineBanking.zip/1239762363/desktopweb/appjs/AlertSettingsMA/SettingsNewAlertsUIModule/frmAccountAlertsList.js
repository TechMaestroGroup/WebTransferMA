define("AlertSettingsMA/SettingsNewAlertsUIModule/frmAccountAlertsList", function() {
    return function(controller) {
        function addWidgetsfrmAccountAlertsList() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblHeading",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknSupportedFileTypes",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Settingscapson\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxProfileError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxProfileError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileError.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgError",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxError = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "rtxError",
                "isVisible": true,
                "left": "76dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.WecouldntfindanexactmatchPleaseenteryourpayeeinformationasitappearsonyourbill\")",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileError.add(imgError, rtxError);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "27dp",
                "width": "87.80%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "sknLblSSP42424215px",
                "text": "ACCOUNT SETTINGS",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "lblAccountSettingsMobile",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "262dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxProfileMenu": {
                        "isVisible": true
                    },
                    "profileMenu": {
                        "centerX": "viz.val_cleared",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxAccountAlertsWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountAlertsWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountAlertsWrapper.setDefaultUnit(kony.flex.DP);
            var accountAlerts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "accountAlerts",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            accountAlerts.setDefaultUnit(kony.flex.DP);
            var flxAlertsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxAlertsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFFFFFFnoBor",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsHeader.setDefaultUnit(kony.flex.DP);
            var flxAlertsSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAlertsSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxd3d3d3op60",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsSeperator.setDefaultUnit(kony.flex.DP);
            flxAlertsSeperator.add();
            var lblAlertsHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblAlertsHeading",
                "isVisible": true,
                "left": "0px",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PersonalDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnModifyAlerts = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "id": "btnModifyAlerts",
                "isVisible": false,
                "right": "0px",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Modify\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Modify"
            });
            flxAlertsHeader.add(flxAlertsSeperator, lblAlertsHeading, btnModifyAlerts);
            var flxAlertsWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAlertsWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsWarning.setDefaultUnit(kony.flex.DP);
            var flxAlertsWarningWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxAlertsWarningWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0px",
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "20dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsWarningWrapper.setDefaultUnit(kony.flex.DP);
            var imgAlertsWarningImage = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgAlertsWarningImage",
                "isVisible": true,
                "left": "12dp",
                "skin": "slImage",
                "src": "info_icon_blue.png",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAlertsWarningImage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "lblAlertsWarningImage",
                "isVisible": false,
                "left": "15dp",
                "skin": "sknlbl4a90e230OLBFontIconsPx",
                "text": "K",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAlertsWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAlertsWarning",
                "isVisible": true,
                "left": "60dp",
                "skin": "sknLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Profilemanagement.lblAlertsWarningNew\")",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertsWarningWrapper.add(imgAlertsWarningImage, lblAlertsWarningImage, lblAlertsWarning);
            flxAlertsWarning.add(flxAlertsWarningWrapper);
            var flxFilterAndSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxFilterAndSearch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "99%",
                "zIndex": 2,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterAndSearch.setDefaultUnit(kony.flex.DP);
            var flxFilterContainer = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxFilterContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterContainer.setDefaultUnit(kony.flex.DP);
            var flxFilter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "40px",
                "id": "flxFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "0dp",
                "width": "36%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilter.setDefaultUnit(kony.flex.DP);
            var flxFilterAccountTypeContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxFilterAccountTypeContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterAccountTypeContainer.setDefaultUnit(kony.flex.DP);
            var lblAccountType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblAccountType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountType\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountTypeValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "45%",
                "id": "lblAccountTypeValue",
                "isVisible": true,
                "left": "5dp",
                "right": "13%",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "All Accounts",
                "top": "11dp",
                "width": "138dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFilterAccountTypeContainer.add(lblAccountType, lblAccountTypeValue);
            var flxDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "22px",
                "id": "flxDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.30%",
                "skin": "slFbox",
                "top": "10dp",
                "width": "22dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var lblDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblDropdown",
                "isVisible": true,
                "left": "0dp",
                "right": "13%",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropdown.add(lblDropdown);
            flxFilter.add(flxFilterAccountTypeContainer, flxDropdown);
            var flxSegFilterDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSegFilterDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBorderOpace3e3e31pxRadius3pxShadowBottom",
                "top": "0dp",
                "width": "45%",
                "zIndex": 12,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegFilterDropdown.setDefaultUnit(kony.flex.DP);
            var segFilterDropdown = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }],
                "groupCells": false,
                "id": "segFilterDropdown",
                "isVisible": true,
                "left": "20dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal2",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AboutUsMA",
                    "friendlyName": "flxTimePeriodMain"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFeatureRow": "flxFeatureRow",
                    "flxTimePeriodMain": "flxTimePeriodMain",
                    "lblCheckFeature": "lblCheckFeature",
                    "lblFeatureName": "lblFeatureName"
                },
                "width": "90%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegFilterDropdown.add(segFilterDropdown);
            flxFilterContainer.add(flxFilter, flxSegFilterDropdown);
            var flxSearch = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "40px",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknBorderE3E3E3",
                "top": "0dp",
                "width": "40%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var flxSearchIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "22px",
                "id": "flxSearchIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "22dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchIcon.setDefaultUnit(kony.flex.DP);
            var lblSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblSearch",
                "isVisible": true,
                "left": "0dp",
                "right": "13%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchIcon.add(lblSearch);
            var tbxSearch = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "15dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.AlertSettings.Accounts.Search\")",
                "secureTextEntry": false,
                "skin": "tbxPlaceholderskna0a0a015px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxClear = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "22px",
                "id": "flxClear",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "8dp",
                "skin": "slFbox",
                "top": "8dp",
                "width": "22dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClear.setDefaultUnit(kony.flex.DP);
            var lblClear = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblClear",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClear.add(lblClear);
            flxSearch.add(flxSearchIcon, tbxSearch, flxClear);
            var flxNoAccountsFound = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxNoAccountsFound",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0px",
                "top": "40dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAccountsFound.setDefaultUnit(kony.flex.DP);
            var imgNoAccountsFound = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgNoAccountsFound",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_icon_blue.png",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoAccountsFound = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblNoAccountsFound",
                "isVisible": true,
                "left": "38dp",
                "skin": "sknLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.manageUser.noAccountAccess\")",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoAccountsFound.add(imgNoAccountsFound, lblNoAccountsFound);
            flxFilterAndSearch.add(flxFilterContainer, flxSearch, flxNoAccountsFound);
            var flxMultiCustomerFilter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flxMultiCustomerFilter",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "99%",
                "zIndex": 2,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMultiCustomerFilter.setDefaultUnit(kony.flex.DP);
            var flxCusOrAccFilterContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxCusOrAccFilterContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "20%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCusOrAccFilterContainer.setDefaultUnit(kony.flex.DP);
            var flxCusOrAccFilter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "40px",
                "id": "flxCusOrAccFilter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "0dp",
                "width": "36%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCusOrAccFilter.setDefaultUnit(kony.flex.DP);
            var flxCusOrAccLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxCusOrAccLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCusOrAccLeft.setDefaultUnit(kony.flex.DP);
            var lblCusOrAcc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblCusOrAcc",
                "isVisible": true,
                "left": "7dp",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AlertSettings.Accounts.ViewBy\")",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCusOrAccValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "id": "lblCusOrAccValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Customer",
                "top": "11dp",
                "width": "61dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCusOrAccLeft.add(lblCusOrAcc, lblCusOrAccValue);
            var flxCusOrAccDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "22px",
                "id": "flxCusOrAccDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "22dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCusOrAccDropdown.setDefaultUnit(kony.flex.DP);
            var lblCusOrAccDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblCusOrAccDropdown",
                "isVisible": true,
                "left": "0dp",
                "right": "13%",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCusOrAccDropdown.add(lblCusOrAccDropdown);
            flxCusOrAccFilter.add(flxCusOrAccLeft, flxCusOrAccDropdown);
            var flxCusOrAccSeg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCusOrAccSeg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBorderOpace3e3e31pxRadius3pxShadowBottom",
                "top": "0dp",
                "width": "45%",
                "zIndex": 12,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCusOrAccSeg.setDefaultUnit(kony.flex.DP);
            var segCusOrAcc = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }],
                "groupCells": false,
                "id": "segCusOrAcc",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal2",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AlertSettingsMA",
                    "friendlyName": "flxAccountTypes"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountTypes": "flxAccountTypes",
                    "lblSeparator": "lblSeparator",
                    "lblUsers": "lblUsers"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCusOrAccSeg.add(segCusOrAcc);
            flxCusOrAccFilterContainer.add(flxCusOrAccFilter, flxCusOrAccSeg);
            var flxCustomerFilterConatiner = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxCustomerFilterConatiner",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "15dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "32%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerFilterConatiner.setDefaultUnit(kony.flex.DP);
            var flxCustomerFilter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "clipBounds": false,
                "height": "40px",
                "id": "flxCustomerFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "0dp",
                "width": "36%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerFilter.setDefaultUnit(kony.flex.DP);
            var lblCustomerValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblCustomerValue",
                "isVisible": true,
                "left": "3%",
                "right": "13%",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "All Accounts",
                "width": "65%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCustomerDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "22px",
                "id": "flxCustomerDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.30%",
                "skin": "slFbox",
                "top": "10dp",
                "width": "22dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerDropdown.setDefaultUnit(kony.flex.DP);
            var lblCustomerDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblCustomerDropdown",
                "isVisible": true,
                "left": "0dp",
                "right": "13%",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerDropdown.add(lblCustomerDropdown);
            var tbxCustomerSearch = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "autocomplete": "off",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxCustomerSearch",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "15dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.AlertSettings.Accounts.SelectCustomer\")",
                "secureTextEntry": false,
                "skin": "tbxPlaceholderskna0a0a015px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxCustomerClear = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Clear Text"
                },
                "clipBounds": true,
                "height": "22px",
                "id": "flxCustomerClear",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "8dp",
                "skin": "slFbox",
                "top": "8dp",
                "width": "22dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerClear.setDefaultUnit(kony.flex.DP);
            var lblCustomerClear = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblCustomerClear",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerClear.add(lblCustomerClear);
            flxCustomerFilter.add(lblCustomerValue, flxCustomerDropdown, tbxCustomerSearch, flxCustomerClear);
            var flxCustomerSeg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCustomerSeg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBorderOpace3e3e31pxRadius3pxShadowBottom",
                "top": "0dp",
                "width": "45%",
                "zIndex": 12,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerSeg.setDefaultUnit(kony.flex.DP);
            var segCustomer = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }, {
                    "lblSeparator": "-",
                    "lblUsers": "Label"
                }],
                "groupCells": false,
                "id": "segCustomer",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal2",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AlertSettingsMA",
                    "friendlyName": "flxAccountTypes"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountTypes": "flxAccountTypes",
                    "lblSeparator": "lblSeparator",
                    "lblUsers": "lblUsers"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoSearchCustomerResults = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.Alerts.NoSearchResults\")"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50px",
                "id": "flxNoSearchCustomerResults",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoSearchCustomerResults.setDefaultUnit(kony.flex.DP);
            var lblNoSearchCustomerResults = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "80%",
                "id": "lblNoSearchCustomerResults",
                "isVisible": true,
                "left": "10dp",
                "right": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Alerts.NoSearchResults\")",
                "top": "7px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoSearchCustomerResults.add(lblNoSearchCustomerResults);
            flxCustomerSeg.add(segCustomer, flxNoSearchCustomerResults);
            flxCustomerFilterConatiner.add(flxCustomerFilter, flxCustomerSeg);
            var flxAccountTypeContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxAccountTypeContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "13%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "30%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountTypeContainer.setDefaultUnit(kony.flex.DP);
            var flxAccountType = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "40px",
                "id": "flxAccountType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "0dp",
                "width": "36%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountType.setDefaultUnit(kony.flex.DP);
            var flxAccountTypeLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxAccountTypeLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountTypeLeft.setDefaultUnit(kony.flex.DP);
            var lblAccType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblAccType",
                "isVisible": true,
                "left": "7dp",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountType\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccTypeValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblAccTypeValue",
                "isVisible": true,
                "left": "5dp",
                "right": "10%",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "All",
                "top": "12dp",
                "width": "53%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountTypeLeft.add(lblAccType, lblAccTypeValue);
            var flxAccountTypeDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "22px",
                "id": "flxAccountTypeDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "4.30%",
                "skin": "slFbox",
                "top": "10dp",
                "width": "22dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountTypeDropdown.setDefaultUnit(kony.flex.DP);
            var lblAccountTypeDropdown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblAccountTypeDropdown",
                "isVisible": true,
                "left": "0dp",
                "right": "13%",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountTypeDropdown.add(lblAccountTypeDropdown);
            flxAccountType.add(flxAccountTypeLeft, flxAccountTypeDropdown);
            var flxAccountTypeSeg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccountTypeSeg",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBorderOpace3e3e31pxRadius3pxShadowBottom",
                "top": "0dp",
                "width": "45%",
                "zIndex": 12,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountTypeSeg.setDefaultUnit(kony.flex.DP);
            var segAccountType = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }],
                "groupCells": false,
                "id": "segAccountType",
                "isVisible": true,
                "left": "20dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal2",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AboutUsMA",
                    "friendlyName": "flxTimePeriodMain"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFeatureRow": "flxFeatureRow",
                    "flxTimePeriodMain": "flxTimePeriodMain",
                    "lblCheckFeature": "lblCheckFeature",
                    "lblFeatureName": "lblFeatureName"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountTypeSeg.add(segAccountType);
            flxAccountTypeContainer.add(flxAccountType, flxAccountTypeSeg);
            var flxAccountFilterContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxAccountFilterContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountFilterContainer.setDefaultUnit(kony.flex.DP);
            var flxSearchOrSelectAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSearchOrSelectAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchOrSelectAccount.setDefaultUnit(kony.flex.DP);
            var lblSelectAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblSelectAccount",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtSearchAccount = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "autocomplete": "off",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtSearchAccount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Alerts.SearchOrSelectAccount\")",
                "secureTextEntry": false,
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxClearSearchAccountText = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Clear Text"
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxClearSearchAccountText",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClearSearchAccountText.setDefaultUnit(kony.flex.DP);
            var lblClearSearchAccountText = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "lblClearSearchAccountText",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClearSearchAccountText.add(lblClearSearchAccountText);
            var flxSearchAccountDropdownIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSearchAccountDropdownIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchAccountDropdownIcon.setDefaultUnit(kony.flex.DP);
            var lblSearchAccountDropdownIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "lblSearchAccountDropdownIcon",
                "isVisible": true,
                "left": "0",
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchAccountDropdownIcon.add(lblSearchAccountDropdownIcon);
            flxSearchOrSelectAccount.add(lblSelectAccount, txtSearchAccount, flxClearSearchAccountText, flxSearchAccountDropdownIcon);
            var flxSearchAccountsSegmentContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxSearchAccountsSegmentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBorderOpace3e3e31pxRadius3pxShadowBottom",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchAccountsSegmentContainer.setDefaultUnit(kony.flex.DP);
            var segSelectAccounts = new kony.ui.SegmentedUI2({
                "groupCells": false,
                "height": "240dp",
                "id": "segSelectAccounts",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoSearchAccountsResults = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.Alerts.NoSearchResults\")"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNoSearchAccountsResults",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoSearchAccountsResults.setDefaultUnit(kony.flex.DP);
            var lblNoSearchAccountsResults = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblNoSearchAccountsResults",
                "isVisible": true,
                "left": "0",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Alerts.NoSearchResults\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoSearchAccountsResults.add(lblNoSearchAccountsResults);
            flxSearchAccountsSegmentContainer.add(segSelectAccounts, flxNoSearchAccountsResults);
            flxAccountFilterContainer.add(flxSearchOrSelectAccount, flxSearchAccountsSegmentContainer);
            flxMultiCustomerFilter.add(flxCusOrAccFilterContainer, flxCustomerFilterConatiner, flxAccountTypeContainer, flxAccountFilterContainer);
            var flxScrollAlertsBody = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "590dp",
                "horizontalScrollIndicator": true,
                "id": "flxScrollAlertsBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxScrollAlertsBody.setDefaultUnit(kony.flex.DP);
            var flxNoAlertsFound = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNoAlertsFound",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAlertsFound.setDefaultUnit(kony.flex.DP);
            var flxMessage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70px",
                "id": "flxMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.77%",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3border",
                "top": "30px",
                "width": "92.44%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessage.setDefaultUnit(kony.flex.DP);
            var CopyimgError0afb44e1d41c948 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40px",
                "id": "CopyimgError0afb44e1d41c948",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "2.18%",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "22dp",
                "width": "40px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoAlertsWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblNoAlertsWarning",
                "isVisible": true,
                "left": "3.77%",
                "skin": "skntxtSSPff000015pxlbl",
                "text": "No alerts to display",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMessage.add(CopyimgError0afb44e1d41c948, lblNoAlertsWarning);
            flxNoAlertsFound.add(flxMessage);
            var flxMultiCustomerSearchAccountsInfo = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxMultiCustomerSearchAccountsInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMultiCustomerSearchAccountsInfo.setDefaultUnit(kony.flex.DP);
            var imgInfoMultiCustomerAccountsSearch = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgInfoMultiCustomerAccountsSearch",
                "isVisible": true,
                "left": "12dp",
                "skin": "slImage",
                "src": "info_icon_blue.png",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfoMultiCustomerAccountsSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblInfoMultiCustomerAccountsSearch",
                "isVisible": true,
                "left": "60dp",
                "skin": "sknLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Alerts.SearchOrSelectAccountInfo\")",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMultiCustomerSearchAccountsInfo.add(imgInfoMultiCustomerAccountsSearch, lblInfoMultiCustomerAccountsSearch);
            var flxAlertsSegment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAlertsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsSegment.setDefaultUnit(kony.flex.DP);
            var flxAlertsSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxAlertsSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxe3e3e3bg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsSeperator2.setDefaultUnit(kony.flex.DP);
            flxAlertsSeperator2.add();
            var segAlerts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segAlerts",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal2",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AuthenticationMA",
                    "friendlyName": "flxAccountTypeAlerts"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "64646400",
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnModifyAlerts": "btnModifyAlerts",
                    "flxAccountTypeAlerts": "flxAccountTypeAlerts",
                    "flxAlertsRow1": "flxAlertsRow1",
                    "flxAlertsStatusCheckbox": "flxAlertsStatusCheckbox",
                    "flxRow2": "flxRow2",
                    "flxSeperator": "flxSeperator",
                    "lblAccountType": "lblAccountType",
                    "lblAlertStatusIndicator": "lblAlertStatusIndicator",
                    "lblAlertsStatus": "lblAlertsStatus",
                    "lblSeperator": "lblSeperator"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertsSegment.add(flxAlertsSeperator2, segAlerts);
            var flxClickBlocker = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "id": "flxClickBlocker",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "50dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClickBlocker.setDefaultUnit(kony.flex.DP);
            flxClickBlocker.add();
            flxScrollAlertsBody.add(flxNoAlertsFound, flxMultiCustomerSearchAccountsInfo, flxAlertsSegment, flxClickBlocker);
            var flxPagination = new kony.ui.FlexContainer({
                "bottom": "0",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPagination",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "440dp",
                "isModalContainer": false,
                "top": "7dp",
                "width": "50%",
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPagination.setDefaultUnit(kony.flex.DP);
            var pagination = new com.InfinityOLB.Resources.pagination({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "pagination",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ResourcesMA",
                "viewType": "pagination",
                "overrides": {
                    "pagination": {
                        "right": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var pagination_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmAccountAlertsList"] && appConfig.componentMetadata["ResourcesMA"]["frmAccountAlertsList"]["pagination"]) || {};
            pagination.iconPaginationPreviousEnabled = pagination_data.iconPaginationPreviousEnabled || "{\"img\": \"paginationleftenable.png\"}";
            pagination.sknPaginationText = pagination_data.sknPaginationText || "{\"$.BREAKPTS.BP1\":\"ICSknLblSSP42424214px\",\"default\":\"ICSknLblSSP42424215px\"}";
            pagination.componentVisibility = pagination_data.componentVisibility || "Hide dropdown";
            pagination.iconPaginationNextEnabled = pagination_data.iconPaginationNextEnabled || "{\"img\": \"paginationrightenable.png\"}";
            pagination.sknRecordsPerPageLabel = pagination_data.sknRecordsPerPageLabel || "bbSknLbl424242SSP15Px";
            pagination.BREAKPTS = pagination_data.BREAKPTS || "{\"BP1\":\"640\",\"BP2\":\"1024\",\"BP3\":\"1366\"}";
            pagination.recordsPerPage = pagination_data.recordsPerPage || "10";
            pagination.iconPaginationLastEnabled = pagination_data.iconPaginationLastEnabled || "{\"img\": \"paginationrightendenable.png\"}";
            pagination.sknRecordsPerPageListItems = pagination_data.sknRecordsPerPageListItems || "{\"$.BREAKPTS.BP1\":\"ICSknBtnSSP72727213px\",\"default\":\"ICSknBtnSSP72727215px\"}";
            pagination.iconPaginationFirstEnabled = pagination_data.iconPaginationFirstEnabled || "{\"img\":\"paginationleftendenable.png\"}";
            pagination.defaultPageNumber = pagination_data.defaultPageNumber || "1";
            pagination.sknRecordsPerPageSelected = pagination_data.sknRecordsPerPageSelected || "{\"$.BREAKPTS.BP1\":\"ICSknLblSSP42424213px\",\"default\":\"ICSknLblSSP42424215px\"}";
            pagination.paginationText = pagination_data.paginationText || "{ \"default\": \"{$.t.currentPage} of {$.t.totalPages} Pages\", \"$.BREAKPTS.BP1\": \"{$.t.currentPage} of {$.t.totalPages} Pages\"}";
            pagination.dropdownExpandIcon = pagination_data.dropdownExpandIcon || "{\"img\": \"chevrondown32px1x.png\"}";
            pagination.recordsPerPageLabel = pagination_data.recordsPerPageLabel || "{\"default\": \"View:\"} ";
            pagination.iconPaginationPreviousDisabled = pagination_data.iconPaginationPreviousDisabled || "{\"img\": \"paginationleftdisable.png\"}";
            pagination.recordsPerPageList = pagination_data.recordsPerPageList || "[{\"10\":\"10 Per Page\"},{\"20\":\"20 Per Page\"}]";
            pagination.iconPaginationNextDisabled = pagination_data.iconPaginationNextDisabled || "{\"img\": \"paginationrightdisable.png\"}";
            pagination.iconPaginationLastDisabled = pagination_data.iconPaginationLastDisabled || "{\"img\":\"paginationrightenddisable.png\"}";
            pagination.iconPaginationFirstDisabled = pagination_data.iconPaginationFirstDisabled || "{\"img\": \"paginationleftenddisable.png\"}";
            pagination.dropdownCollapseIcon = pagination_data.dropdownCollapseIcon || "{\"img\": \"chevronup32px.png\"}";
            flxPagination.add(pagination);
            accountAlerts.add(flxAlertsHeader, flxAlertsWarning, flxFilterAndSearch, flxMultiCustomerFilter, flxScrollAlertsBody, flxPagination);
            flxAccountAlertsWrapper.add(accountAlerts);
            flxRight.add(flxAccountAlertsWrapper);
            flxContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxMainContainer.add(flxContainer);
            flxMain.add(lblHeading, flxProfileError, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "height": "100dp"
                    },
                    "flxFooterMenu": {
                        "top": "26.60%"
                    },
                    "lblCopyright": {
                        "top": "75dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": true,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10000,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxProfileDeletePopUp = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "102%",
                "id": "flxProfileDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxProfileDelete = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "268dp",
                "id": "flxProfileDelete",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDelete.setDefaultUnit(kony.flex.DP);
            var flxprofileDeleteHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxprofileDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofileDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblProfileDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknLblSSP42424215px",
                "text": "Delete Picture",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxprofiledeleteClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxprofiledeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "CopyslFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.setDefaultUnit(kony.flex.DP);
            var imgProfileDeleteClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgProfileDeleteClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.add(imgProfileDeleteClose);
            flxprofileDeleteHeader.add(lblProfileDeleteHeader, flxprofiledeleteClose);
            var flxProfileDeleteSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxProfileDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxProfileDeleteSeperator.add();
            var flxProfileDeleteContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "65dp",
                "id": "flxProfileDeleteContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteContent = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblProfileDeleteContent",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknSupportedFileTypes",
                "text": "Are you sure you want to remove your profile picture?",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.add(lblProfileDeleteContent);
            var flxWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "0%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var flxDisablWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxDisablWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20px",
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "20dp",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisablWarning.setDefaultUnit(kony.flex.DP);
            flxDisablWarning.add();
            flxWarning.add(flxDisablWarning);
            var flxProfileDeleteButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": 0,
                "clipBounds": true,
                "height": "109px",
                "id": "flxProfileDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AlertSettingsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnDeletePopupYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupYes",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "28.44%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnDeletePopupNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupNo",
                "isVisible": true,
                "left": "35.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "28.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxProfileDeleteButtons.add(btnDeletePopupYes, btnDeletePopupNo);
            flxProfileDelete.add(flxprofileDeleteHeader, flxProfileDeleteSeperator, flxProfileDeleteContent, flxWarning, flxProfileDeleteButtons);
            flxProfileDeletePopUp.add(flxProfileDelete);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxProfileDeletePopUp, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmAccountAlertsList": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Alerts Settings",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknFlxf8f7f8",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "rtxError": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "text": "We couldn't find an exact match.Please enter your payee information as it appears on your bill.",
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "text": "Account Alerts",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "profileMenu.flxProfileMenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": "525dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "640dp"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxRight": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "620dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxAccountAlertsWrapper": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "skin": "CopysknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91.20%"
                        },
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAlertsWarningWrapper": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "flxFilterAndSearch": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxFilter": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountType": {
                        "segmentProps": []
                    },
                    "lblAccountTypeValue": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSegFilterDropdown": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segFilterDropdown": {
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "22px"
                        },
                        "left": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "lblSearch": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxSearch": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [30, 3, 1, 3],
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxClear": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoAccountsFound": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "lblNoAccountsFound": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "flxMultiCustomerFilter": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccFilterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "zIndex": 4,
                        "segmentProps": []
                    },
                    "flxCusOrAccFilter": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccLeft": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblCusOrAcc": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCusOrAccValue": {
                        "segmentProps": []
                    },
                    "flxCusOrAccDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "4.30%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccSeg": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 14,
                        "segmentProps": []
                    },
                    "segCusOrAcc": {
                        "segmentProps": []
                    },
                    "flxCustomerFilterConatiner": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxCustomerFilter": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerValue": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "tbxCustomerSearch": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "flxCustomerClear": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerSeg": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 13,
                        "segmentProps": []
                    },
                    "segCustomer": {
                        "segmentProps": []
                    },
                    "lblNoSearchCustomerResults": {
                        "segmentProps": []
                    },
                    "flxAccountTypeContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypeLeft": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblAccType": {
                        "segmentProps": []
                    },
                    "lblAccTypeValue": {
                        "right": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypeDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "4.30%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypeSeg": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segAccountType": {
                        "segmentProps": []
                    },
                    "flxAccountFilterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchOrSelectAccount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "sknBorderE3E3E3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "text": "Savings Account - 12345",
                        "segmentProps": []
                    },
                    "txtSearchAccount": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "placeholder": "Search or select account",
                        "skin": "tbxPlaceholderskna0a0a015pxNoborder",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "flxClearSearchAccountText": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "lblClearSearchAccountText": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknOLBFonts003e7512px",
                        "text": "g",
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchAccountDropdownIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "lblSearchAccountDropdownIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchAccountsSegmentContainer": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "segSelectAccounts": {
                        "data": [
                            [{
                                    "imgDropDown": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "P"
                                    },
                                    "lblAccountsSearchHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblTopSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ],
                            [{
                                    "imgDropDown": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "P"
                                    },
                                    "lblAccountsSearchHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblTopSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAlertsAccountsSearchList"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAlertsAccountsSearchHeader"
                        }),
                        "widgetDataMap": {
                            "flxAccountTypeContainer": "flxAccountTypeContainer",
                            "flxAlertsAccountsSearchHeader": "flxAlertsAccountsSearchHeader",
                            "flxAlertsAccountsSearchList": "flxAlertsAccountsSearchList",
                            "flxAlertsSearchAccountListItem": "flxAlertsSearchAccountListItem",
                            "flxDropDown": "flxDropDown",
                            "imgDropDown": "imgDropDown",
                            "lblAccType": "lblAccType",
                            "lblAccountCustomer": "lblAccountCustomer",
                            "lblAccountName": "lblAccountName",
                            "lblAccountNameDummy": "lblAccountNameDummy",
                            "lblAccountsSearchHeader": "lblAccountsSearchHeader",
                            "lblSeparator": "lblSeparator",
                            "lblTopSeparator": "lblTopSeparator"
                        },
                        "zIndex": 5,
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "lblNoSearchAccountsResults": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxScrollAlertsBody": {
                        "segmentProps": []
                    },
                    "flxMultiCustomerSearchAccountsInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "imgInfoMultiCustomerAccountsSearch": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblInfoMultiCustomerAccountsSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "skin": "sknLabelSSP42424215px",
                        "text": "Search or select an account to view or update its settings",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "segAlerts": {
                        "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                        "isVisible": false,
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountIdAlerts"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountTypes"
                        }),
                        "widgetDataMap": {
                            "btnModifyAlerts": "btnModifyAlerts",
                            "flxAccountTypeAlerts": "flxAccountTypeAlerts",
                            "flxAlertsRow1": "flxAlertsRow1",
                            "flxAlertsStatusCheckbox": "flxAlertsStatusCheckbox",
                            "flxRow2": "flxRow2",
                            "flxSeperator": "flxSeperator",
                            "lblAccountType": "lblAccountType",
                            "lblAlertStatusIndicator": "lblAlertStatusIndicator",
                            "lblAlertsStatus": "lblAlertsStatus",
                            "lblSeperator": "lblSeperator"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "flxPagination": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "pagination": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "59dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "instanceId": "customfooternew"
                    },
                    "customfooternew.flxFooterMenu": {
                        "top": {
                            "type": "string",
                            "value": "20.60%"
                        },
                        "segmentProps": []
                    },
                    "customfooternew.lblCopyright": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountAlertsWrapper": {
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsHeader": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarningWrapper": {
                        "width": {
                            "type": "string",
                            "value": "95.80%"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterAndSearch": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterContainer": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxFilter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountType": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountTypeValue": {
                        "right": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxSegFilterDropdown": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segFilterDropdown": {
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [30, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxClear": {
                        "segmentProps": []
                    },
                    "flxNoAccountsFound": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.80%"
                        },
                        "segmentProps": []
                    },
                    "lblNoAccountsFound": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxMultiCustomerFilter": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccFilterContainer": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 4,
                        "segmentProps": []
                    },
                    "flxCusOrAccFilter": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccLeft": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblCusOrAcc": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCusOrAccValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "4.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblCusOrAccDropdown": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccSeg": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 14,
                        "segmentProps": []
                    },
                    "segCusOrAcc": {
                        "segmentProps": []
                    },
                    "flxCustomerFilterConatiner": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "flxCustomerFilter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerValue": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "tbxCustomerSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerClear": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCustomerSeg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 13,
                        "segmentProps": []
                    },
                    "segCustomer": {
                        "segmentProps": []
                    },
                    "lblNoSearchCustomerResults": {
                        "segmentProps": []
                    },
                    "flxAccountTypeContainer": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypeLeft": {
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "lblAccType": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblAccTypeValue": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypeDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "4.30%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypeSeg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segAccountType": {
                        "segmentProps": []
                    },
                    "flxAccountFilterContainer": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchOrSelectAccount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "sknBorderE3E3E3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "text": "Savings Account - 12345",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "txtSearchAccount": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "i18n_placeholder": "i18n.Alerts.SearchOrSelectAccount",
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "placeholder": "Search or select account",
                        "placeholderSkin": "tbxPlaceholderskna0a0a015pxNoborder",
                        "skin": "tbxPlaceholderskna0a0a015pxNoborder",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "flxClearSearchAccountText": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "lblClearSearchAccountText": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknOLBFonts003e7512px",
                        "text": "g",
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchAccountDropdownIcon": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "lblSearchAccountDropdownIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchAccountsSegmentContainer": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "segSelectAccounts": {
                        "data": [
                            [{
                                    "imgDropDown": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "P"
                                    },
                                    "lblAccountsSearchHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblTopSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ],
                            [{
                                    "imgDropDown": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "P"
                                    },
                                    "lblAccountsSearchHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblTopSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAlertsAccountsSearchList"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAlertsAccountsSearchHeader"
                        }),
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "widgetDataMap": {
                            "flxAccountTypeContainer": "flxAccountTypeContainer",
                            "flxAlertsAccountsSearchHeader": "flxAlertsAccountsSearchHeader",
                            "flxAlertsAccountsSearchList": "flxAlertsAccountsSearchList",
                            "flxAlertsSearchAccountListItem": "flxAlertsSearchAccountListItem",
                            "flxDropDown": "flxDropDown",
                            "imgDropDown": "imgDropDown",
                            "lblAccType": "lblAccType",
                            "lblAccountCustomer": "lblAccountCustomer",
                            "lblAccountName": "lblAccountName",
                            "lblAccountNameDummy": "lblAccountNameDummy",
                            "lblAccountsSearchHeader": "lblAccountsSearchHeader",
                            "lblSeparator": "lblSeparator",
                            "lblTopSeparator": "lblTopSeparator"
                        },
                        "zIndex": 5,
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "lblNoSearchAccountsResults": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.Alerts.NoSearchResults",
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxScrollAlertsBody": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxMultiCustomerSearchAccountsInfo": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgInfoMultiCustomerAccountsSearch": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblInfoMultiCustomerAccountsSearch": {
                        "left": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "text": "Search or select an account to view or update its settings",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "segAlerts": {
                        "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                        "isVisible": false,
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountIdAlerts"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountTypes"
                        }),
                        "widgetDataMap": {
                            "btnModifyAlerts": "btnModifyAlerts",
                            "flxAccountTypeAlerts": "flxAccountTypeAlerts",
                            "flxAlertsRow1": "flxAlertsRow1",
                            "flxAlertsStatusCheckbox": "flxAlertsStatusCheckbox",
                            "flxRow2": "flxRow2",
                            "flxSeperator": "flxSeperator",
                            "lblAccountType": "lblAccountType",
                            "lblAlertStatusIndicator": "lblAlertStatusIndicator",
                            "lblAlertsStatus": "lblAlertsStatus",
                            "lblSeperator": "lblSeperator"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "flxPagination": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "pagination": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteContent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Are you sure you want to remove your profile picture?",
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "skin": "sknSupportedFileTypes",
                        "text": "Settings",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "number",
                            "value": "10"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.84%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "skin": "bbSKnFlxf1ab15",
                        "segmentProps": []
                    },
                    "profileMenu": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "skin": "bbSKnFlxf1ab15",
                        "segmentProps": []
                    },
                    "flxAccountAlertsWrapper": {
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsHeader": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarningWrapper": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterAndSearch": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterContainer": {
                        "width": {
                            "type": "string",
                            "value": "36%"
                        },
                        "segmentProps": []
                    },
                    "flxFilter": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblAccountType": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblAccountTypeValue": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSegFilterDropdown": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segFilterDropdown": {
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "57%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxSearchIcon": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "22px"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblSearch": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "focusSkin": "sff65e7c09cf4045a3ea2d9e236589a7",
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [30, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxClear": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblClear": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxNoAccountsFound": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblNoAccountsFound": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxMultiCustomerFilter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccFilterContainer": {
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccFilter": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCusOrAcc": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCusOrAccValue": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxCusOrAccDropdown": {
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCusOrAccDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "13%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccSeg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segCusOrAcc": {
                        "segmentProps": []
                    },
                    "flxCustomerFilterConatiner": {
                        "segmentProps": []
                    },
                    "flxCustomerFilter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCustomerValue": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxCustomerDropdown": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCustomerDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxCustomerSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "focusSkin": "sff65e7c09cf4045a3ea2d9e236589a7",
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerClear": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblCustomerClear": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCustomerSeg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segCustomer": {
                        "segmentProps": []
                    },
                    "lblNoSearchCustomerResults": {
                        "i18n_text": "i18n.Alerts.NoSearchResults",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxAccountTypeContainer": {
                        "left": {
                            "type": "string",
                            "value": "9.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxAccountTypeLeft": {
                        "width": {
                            "type": "string",
                            "value": "89%"
                        },
                        "segmentProps": []
                    },
                    "lblAccType": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblAccTypeValue": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "54%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxAccountTypeDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "4.30%"
                        },
                        "skin": "slFbox",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "lblAccountTypeDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "right": {
                            "type": "string",
                            "value": "13%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypeSeg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segAccountType": {
                        "segmentProps": []
                    },
                    "flxAccountFilterContainer": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchOrSelectAccount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknBorderE3E3E3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "text": "Savings Account - 12345",
                        "segmentProps": []
                    },
                    "txtSearchAccount": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "i18n_placeholder": "i18n.Alerts.SearchOrSelectAccount",
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "padding": [2, 0, 0, 0],
                        "placeholder": "Search or select account",
                        "placeholderSkin": "",
                        "skin": "tbxPlaceholderskna0a0a015pxNoborder",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "flxClearSearchAccountText": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "lblClearSearchAccountText": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknOLBFonts003e7512px",
                        "text": "g",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchAccountDropdownIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "lblSearchAccountDropdownIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchAccountsSegmentContainer": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "segSelectAccounts": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "data": [
                            [{
                                    "imgDropDown": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "P"
                                    },
                                    "lblAccountsSearchHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblTopSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ],
                            [{
                                    "imgDropDown": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "P"
                                    },
                                    "lblAccountsSearchHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblTopSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAlertsAccountsSearchList"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAlertsAccountsSearchHeader"
                        }),
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "widgetDataMap": {
                            "flxAccountTypeContainer": "flxAccountTypeContainer",
                            "flxAlertsAccountsSearchHeader": "flxAlertsAccountsSearchHeader",
                            "flxAlertsAccountsSearchList": "flxAlertsAccountsSearchList",
                            "flxAlertsSearchAccountListItem": "flxAlertsSearchAccountListItem",
                            "flxDropDown": "flxDropDown",
                            "imgDropDown": "imgDropDown",
                            "lblAccType": "lblAccType",
                            "lblAccountCustomer": "lblAccountCustomer",
                            "lblAccountName": "lblAccountName",
                            "lblAccountNameDummy": "lblAccountNameDummy",
                            "lblAccountsSearchHeader": "lblAccountsSearchHeader",
                            "lblSeparator": "lblSeparator",
                            "lblTopSeparator": "lblTopSeparator"
                        },
                        "zIndex": 5,
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "lblNoSearchAccountsResults": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "i18n_text": "i18n.Alerts.NoSearchResults",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxScrollAlertsBody": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxMultiCustomerSearchAccountsInfo": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblInfoMultiCustomerAccountsSearch": {
                        "i18n_text": "i18n.Alerts.SearchOrSelectAccountInfo",
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "text": "Search or select an account to view or update its settings",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "segAlerts": {
                        "data": [
                            [{
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblUsers": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                },
                                [{
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ],
                            [{
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "-"
                                    },
                                    "lblUsers": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    }
                                },
                                [{
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "isVisible": false,
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountIdAlerts"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountTypes"
                        }),
                        "widgetDataMap": {
                            "btnModifyAlerts": "btnModifyAlerts",
                            "flxAccountTypeAlerts": "flxAccountTypeAlerts",
                            "flxAccountTypes": "flxAccountTypes",
                            "flxAlertsRow1": "flxAlertsRow1",
                            "flxAlertsStatusCheckbox": "flxAlertsStatusCheckbox",
                            "flxRow2": "flxRow2",
                            "flxSeperator": "flxSeperator",
                            "lblAccountType": "lblAccountType",
                            "lblAlertStatusIndicator": "lblAlertStatusIndicator",
                            "lblAlertsStatus": "lblAlertsStatus",
                            "lblSeparator": "lblSeparator",
                            "lblSeperator": "lblSeperator",
                            "lblUsers": "lblUsers"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "pagination": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmAccountAlertsList": {
                        "segmentProps": []
                    },
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileError": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAccountAlertsWrapper": {
                        "minHeight": {
                            "type": "string",
                            "value": "450dp"
                        },
                        "segmentProps": []
                    },
                    "accountAlerts": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsHeader": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAlertsWarningWrapper": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterAndSearch": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterContainer": {
                        "width": {
                            "type": "string",
                            "value": "36%"
                        },
                        "segmentProps": []
                    },
                    "flxFilter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountType": {
                        "segmentProps": []
                    },
                    "lblAccountTypeValue": {
                        "segmentProps": []
                    },
                    "flxSegFilterDropdown": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segFilterDropdown": {
                        "segmentProps": []
                    },
                    "flxSearch": {
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "width": {
                            "type": "string",
                            "value": "57%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchIcon": {
                        "top": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "segmentProps": []
                    },
                    "tbxSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [30, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxNoAccountsFound": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblNoAccountsFound": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxMultiCustomerFilter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccFilterContainer": {
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccFilter": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCusOrAcc": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCusOrAccValue": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "flxCusOrAccSeg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segCusOrAcc": {
                        "segmentProps": []
                    },
                    "flxCustomerFilterConatiner": {
                        "segmentProps": []
                    },
                    "flxCustomerFilter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerValue": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "tbxCustomerSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerSeg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segCustomer": {
                        "segmentProps": []
                    },
                    "lblNoSearchCustomerResults": {
                        "segmentProps": []
                    },
                    "flxAccountTypeContainer": {
                        "left": {
                            "type": "string",
                            "value": "9.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypeLeft": {
                        "width": {
                            "type": "string",
                            "value": "89%"
                        },
                        "segmentProps": []
                    },
                    "lblAccType": {
                        "segmentProps": []
                    },
                    "lblAccTypeValue": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "58%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypeDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "4.30%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountTypeDropdown": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "segmentProps": []
                    },
                    "flxAccountTypeSeg": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segAccountType": {
                        "segmentProps": []
                    },
                    "flxAccountFilterContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchOrSelectAccount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "skin": "sknBorderE3E3E3",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "text": "Savings Account - 12345",
                        "segmentProps": []
                    },
                    "txtSearchAccount": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "padding": [2, 0, 0, 0],
                        "placeholderSkin": "s5b39e4a75ca4e1f8749d796150d7ab9",
                        "skin": "tbxPlaceholderskna0a0a015pxNoborder",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "flxClearSearchAccountText": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "lblClearSearchAccountText": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknOLBFonts003e7512px",
                        "text": "g",
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchAccountDropdownIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "lblSearchAccountDropdownIcon": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxSearchAccountsSegmentContainer": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "segSelectAccounts": {
                        "data": [
                            [{
                                    "imgDropDown": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "P"
                                    },
                                    "lblAccountsSearchHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblTopSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ],
                            [{
                                    "imgDropDown": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "P"
                                    },
                                    "lblAccountsSearchHeader": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblTopSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }, {
                                    "lblAccType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Checking"
                                    },
                                    "lblAccountCustomer": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Airbnb - 1212"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblAccountNameDummy": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "My Account 1234"
                                    },
                                    "lblSeparator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAlertsAccountsSearchList"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAlertsAccountsSearchHeader"
                        }),
                        "widgetDataMap": {
                            "flxAccountTypeContainer": "flxAccountTypeContainer",
                            "flxAlertsAccountsSearchHeader": "flxAlertsAccountsSearchHeader",
                            "flxAlertsAccountsSearchList": "flxAlertsAccountsSearchList",
                            "flxAlertsSearchAccountListItem": "flxAlertsSearchAccountListItem",
                            "flxDropDown": "flxDropDown",
                            "imgDropDown": "imgDropDown",
                            "lblAccType": "lblAccType",
                            "lblAccountCustomer": "lblAccountCustomer",
                            "lblAccountName": "lblAccountName",
                            "lblAccountNameDummy": "lblAccountNameDummy",
                            "lblAccountsSearchHeader": "lblAccountsSearchHeader",
                            "lblSeparator": "lblSeparator",
                            "lblTopSeparator": "lblTopSeparator"
                        },
                        "zIndex": 5,
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "lblNoSearchAccountsResults": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "i18n_text": "i18n.Alerts.NoSearchResults",
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "flxScrollAlertsBody": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxMultiCustomerSearchAccountsInfo": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblInfoMultiCustomerAccountsSearch": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "text": "Search or select an account to view or update its settings",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "segAlerts": {
                        "data": [
                            [{
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                },
                                [{
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }]
                            ],
                            [{
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                },
                                [{
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }, {
                                    "btnModifyAlerts": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.transfers.Modify",
                                        "text": "View/Modify "
                                    },
                                    "lblAccountIcon": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAccountName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Savings Accounts"
                                    },
                                    "lblAccountNumber": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Account Number xxxxxxxxx88752"
                                    },
                                    "lblAccountType": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblAlertStatusIndicator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Active/Suspended"
                                    },
                                    "lblAlertsStatus": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.Alerts.Enabled",
                                        "text": "Alerts Enabled"
                                    },
                                    "lblSeperator": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "'"
                                    }
                                }]
                            ]
                        ],
                        "isVisible": false,
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountIdAlerts"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "AlertSettingsMA",
                            "friendlyName": "flxAccountTypes"
                        }),
                        "widgetDataMap": {
                            "btnModifyAlerts": "btnModifyAlerts",
                            "flxAccountDetails": "flxAccountDetails",
                            "flxAccountIdAlerts": "flxAccountIdAlerts",
                            "flxAccountTypes": "flxAccountTypes",
                            "flxAlertsRow1": "flxAlertsRow1",
                            "flxAlertsStatusCheckbox": "flxAlertsStatusCheckbox",
                            "flxRow2": "flxRow2",
                            "flxSeperator": "flxSeperator",
                            "lblAccountIcon": "lblAccountIcon",
                            "lblAccountName": "lblAccountName",
                            "lblAccountNumber": "lblAccountNumber",
                            "lblAccountType": "lblAccountType",
                            "lblAlertStatusIndicator": "lblAlertStatusIndicator",
                            "lblAlertsStatus": "lblAlertsStatus",
                            "lblSeparator": "lblSeparator",
                            "lblSeperator": "lblSeperator",
                            "lblUsers": "lblUsers"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "AlertSettingsMA"
                    },
                    "pagination": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxprofileDeleteHeader": {
                        "skin": "CopyslFbox",
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "profileMenu": {
                    "centerX": "",
                    "width": "100%"
                },
                "pagination": {
                    "right": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "customfooternew": {
                    "height": "100dp"
                },
                "customfooternew.flxFooterMenu": {
                    "top": "26.60%"
                },
                "customfooternew.lblCopyright": {
                    "top": "75dp"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmAccountAlertsList,
            "enabledForIdleTimeout": true,
            "id": "frmAccountAlertsList",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_b9331c44b3014563bf4a6cbcdf6038f1(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Account Alerts List",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AlertSettingsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});