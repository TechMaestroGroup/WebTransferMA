define(function() {
    return function(controller) {
        var chooseStrategy = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "isMaster": true,
            "height": "100%",
            "id": "chooseStrategy",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "bbSKnFlxf1ab15",
            "top": "0dp",
            "width": "100%",
            "zIndex": 2,
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "PortfolioManagementMA"
        }, controller.args[0], "chooseStrategy"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "chooseStrategy"), extendConfig({}, controller.args[2], "chooseStrategy"));
        chooseStrategy.setDefaultUnit(kony.flex.DP);
        var flxLeft = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "flxLeft",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "bbSKnFlxf1ab15",
            "top": "28dp",
            "width": "24dp",
            "zIndex": 100,
            "appName": "PortfolioManagementMA"
        }, controller.args[0], "flxLeft"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxLeft"), extendConfig({}, controller.args[2], "flxLeft"));
        flxLeft.setDefaultUnit(kony.flex.DP);
        var imgLeft = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgLeft",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknBBffffff",
            "src": "arrow_left.png",
            "top": "28dp",
            "width": "24dp",
            "zIndex": 100
        }, controller.args[0], "imgLeft"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgLeft"), extendConfig({}, controller.args[2], "imgLeft"));
        flxLeft.add(imgLeft);
        var flxMain = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": false,
            "id": "flxMain",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "reverseLayoutDirection": false,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "slFbox",
            "top": "0dp",
            "width": "96%",
            "zIndex": 1,
            "appName": "PortfolioManagementMA"
        }, controller.args[0], "flxMain"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxMain"), extendConfig({}, controller.args[2], "flxMain"));
        flxMain.setDefaultUnit(kony.flex.DP);
        var flxCard1 = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
            "clipBounds": false,
            "id": "flxCard1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "top": "0dp",
            "width": "100%",
            "zIndex": 2,
            "appName": "PortfolioManagementMA"
        }, controller.args[0], "flxCard1"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxCard1"), extendConfig({}, controller.args[2], "flxCard1"));
        flxCard1.setDefaultUnit(kony.flex.DP);
        flxCard1.add();
        flxMain.add(flxCard1);
        var flxRight = new kony.ui.FlexContainer(extendConfig({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": false,
            "height": "100%",
            "id": "flxRight",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "bbSKnFlxf1ab15",
            "top": "28dp",
            "width": "24dp",
            "zIndex": 100,
            "appName": "PortfolioManagementMA"
        }, controller.args[0], "flxRight"), extendConfig({
            "paddingInPixel": false
        }, controller.args[1], "flxRight"), extendConfig({}, controller.args[2], "flxRight"));
        flxRight.setDefaultUnit(kony.flex.DP);
        var imgRight = new kony.ui.Image2(extendConfig({
            "height": "100%",
            "id": "imgRight",
            "isVisible": true,
            "left": "0dp",
            "skin": "sknBBffffff",
            "src": "arrow_right.png",
            "top": "28dp",
            "width": "24dp",
            "zIndex": 100
        }, controller.args[0], "imgRight"), extendConfig({
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, controller.args[1], "imgRight"), extendConfig({}, controller.args[2], "imgRight"));
        flxRight.add(imgRight);
        chooseStrategy.add(flxLeft, flxMain, flxRight);
        chooseStrategy.breakpointResetData = {};
        chooseStrategy.breakpointData = {
            maxBreakpointWidth: 1380,
            "1024": {
                "flxLeft": {
                    "segmentProps": []
                },
                "imgLeft": {
                    "centerX": {
                        "type": "string",
                        "value": ""
                    },
                    "centerY": {
                        "type": "string",
                        "value": "50%"
                    },
                    "height": {
                        "type": "string",
                        "value": "10%"
                    },
                    "left": {
                        "type": "string",
                        "value": ""
                    },
                    "right": {
                        "type": "string",
                        "value": "0dp"
                    },
                    "width": {
                        "type": "string",
                        "value": "14dp"
                    },
                    "segmentProps": []
                },
                "flxRight": {
                    "width": {
                        "type": "string",
                        "value": "24dp"
                    },
                    "zIndex": 100,
                    "segmentProps": []
                },
                "imgRight": {
                    "centerX": {
                        "type": "string",
                        "value": ""
                    },
                    "centerY": {
                        "type": "string",
                        "value": "50%"
                    },
                    "height": {
                        "type": "string",
                        "value": "10%"
                    },
                    "left": {
                        "type": "string",
                        "value": ""
                    },
                    "right": {
                        "type": "string",
                        "value": "0dp"
                    },
                    "width": {
                        "type": "string",
                        "value": "14dp"
                    },
                    "segmentProps": []
                }
            },
            "1366": {
                "flxLeft": {
                    "segmentProps": []
                },
                "imgLeft": {
                    "centerY": {
                        "type": "string",
                        "value": "50%"
                    },
                    "height": {
                        "type": "string",
                        "value": "10%"
                    },
                    "top": {
                        "type": "string",
                        "value": "28dp"
                    },
                    "segmentProps": []
                },
                "flxRight": {
                    "segmentProps": []
                },
                "imgRight": {
                    "centerY": {
                        "type": "string",
                        "value": "50%"
                    },
                    "height": {
                        "type": "string",
                        "value": "10%"
                    },
                    "segmentProps": []
                }
            }
        }
        chooseStrategy.compInstData = {}
        return chooseStrategy;
    }
})