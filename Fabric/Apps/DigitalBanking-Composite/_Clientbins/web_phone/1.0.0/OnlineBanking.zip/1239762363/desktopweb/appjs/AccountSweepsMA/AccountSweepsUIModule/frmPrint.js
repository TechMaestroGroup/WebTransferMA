define("AccountSweepsMA/AccountSweepsUIModule/frmPrint", function() {
    return function(controller) {
        function addWidgetsfrmPrint() {
            this.setDefaultUnit(kony.flex.DP);
            var flxPrintReceivedClaims = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPrintReceivedClaims",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "40dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1000dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrintReceivedClaims.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "40dp",
                "skin": "slFbox",
                "top": "40dp",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var imgHeader = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgHeader",
                "isVisible": true,
                "left": "0dp",
                "src": "digital_banking.png",
                "top": "0dp",
                "width": "68dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(imgHeader);
            var lblHeader = new kony.ui.Label({
                "id": "lblHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLabelSSPBold42424215px",
                "text": "Sweep Details",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUserDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUserDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxE3E3E3Bdr1PX",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserDetails.setDefaultUnit(kony.flex.DP);
            var flxMainContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxConfirmDetail1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail1.setDefaultUnit(kony.flex.DP);
            var flxKey1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "22%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey1.setDefaultUnit(kony.flex.DP);
            var lblKey1 = new kony.ui.Label({
                "id": "lblKey1",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.primaryAccountWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey1.add(lblKey1);
            var flxValue1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "24.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue1.setDefaultUnit(kony.flex.DP);
            var lblPrimaryAccountValue = new kony.ui.Label({
                "id": "lblPrimaryAccountValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue1.add(lblPrimaryAccountValue);
            flxConfirmDetail1.add(flxKey1, flxValue1);
            var flxConfirmDetail2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail2.setDefaultUnit(kony.flex.DP);
            var flxKey2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey2.setDefaultUnit(kony.flex.DP);
            var lblKey2 = new kony.ui.Label({
                "id": "lblKey2",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.secondaryAccountWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey2.add(lblKey2);
            var flxValue2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue2.setDefaultUnit(kony.flex.DP);
            var lblSecondaryAccountValue = new kony.ui.Label({
                "id": "lblSecondaryAccountValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue2.add(lblSecondaryAccountValue);
            flxConfirmDetail2.add(flxKey2, flxValue2);
            var flxConfirmDetail3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail3.setDefaultUnit(kony.flex.DP);
            var flxKey3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey3.setDefaultUnit(kony.flex.DP);
            var lblKey3 = new kony.ui.Label({
                "id": "lblKey3",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.sweepConditionWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey3.add(lblKey3);
            var flxValue3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue3.setDefaultUnit(kony.flex.DP);
            var lblSweepConditionValue = new kony.ui.Label({
                "id": "lblSweepConditionValue",
                "isVisible": true,
                "left": "0",
                "skin": "bblblskn424242Bold",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxCondition = new kony.ui.RichText({
                "id": "rtxCondition",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknRtx424242SSP15px",
                "top": 10,
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBoth = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBoth",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoth.setDefaultUnit(kony.flex.DP);
            var flxConditionBelow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionBelow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionBelow.setDefaultUnit(kony.flex.DP);
            var flxPoint = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8dp",
                "id": "flxPoint",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxRoundedCorner727272Radius8px",
                "top": "7dp",
                "width": "8dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPoint.setDefaultUnit(kony.flex.DP);
            flxPoint.add();
            var rtxSweepCond = new kony.ui.RichText({
                "id": "rtxSweepCond",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknRtx424242SSP15px",
                "top": "0dp",
                "width": "96%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConditionBelow.add(flxPoint, rtxSweepCond);
            var flxConditionAbove = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConditionAbove",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConditionAbove.setDefaultUnit(kony.flex.DP);
            var flxPointAbove = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8dp",
                "id": "flxPointAbove",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxRoundedCorner727272Radius8px",
                "top": "7dp",
                "width": "8dp",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPointAbove.setDefaultUnit(kony.flex.DP);
            flxPointAbove.add();
            var rtxSweepCondAbove = new kony.ui.RichText({
                "id": "rtxSweepCondAbove",
                "isVisible": true,
                "left": "15dp",
                "skin": "bbSknRtx424242SSP15px",
                "top": "0dp",
                "width": "96%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConditionAbove.add(flxPointAbove, rtxSweepCondAbove);
            flxBoth.add(flxConditionBelow, flxConditionAbove);
            flxValue3.add(lblSweepConditionValue, rtxCondition, flxBoth);
            flxConfirmDetail3.add(flxKey3, flxValue3);
            var flxConfirmDetail4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail4.setDefaultUnit(kony.flex.DP);
            var flxKey4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey4.setDefaultUnit(kony.flex.DP);
            var lblKey4 = new kony.ui.Label({
                "id": "lblKey4",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.frequency\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey4.add(lblKey4);
            var flxValue4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue4.setDefaultUnit(kony.flex.DP);
            var lblFrequencyValue = new kony.ui.Label({
                "id": "lblFrequencyValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue4.add(lblFrequencyValue);
            flxConfirmDetail4.add(flxKey4, flxValue4);
            var flxConfirmDetail5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail5.setDefaultUnit(kony.flex.DP);
            var flxKey5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey5.setDefaultUnit(kony.flex.DP);
            var lblKey5 = new kony.ui.Label({
                "id": "lblKey5",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.startingFromWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey5.add(lblKey5);
            var flxValue5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue5.setDefaultUnit(kony.flex.DP);
            var lblStartDateValue = new kony.ui.Label({
                "id": "lblStartDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue5.add(lblStartDateValue);
            flxConfirmDetail5.add(flxKey5, flxValue5);
            var flxConfirmDetail6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail6.setDefaultUnit(kony.flex.DP);
            var flxKey6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey6.setDefaultUnit(kony.flex.DP);
            var lblKey6 = new kony.ui.Label({
                "id": "lblKey6",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accountsweeps.endDateWithColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey6.add(lblKey6);
            var flxValue6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue6.setDefaultUnit(kony.flex.DP);
            var lblEndDateValue = new kony.ui.Label({
                "id": "lblEndDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue6.add(lblEndDateValue);
            flxConfirmDetail6.add(flxKey6, flxValue6);
            var flxConfirmDetail7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmDetail7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "23dp",
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmDetail7.setDefaultUnit(kony.flex.DP);
            var flxKey7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxKey7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.20%",
                "isModalContainer": false,
                "top": "0",
                "width": "25%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxKey7.setDefaultUnit(kony.flex.DP);
            var lblKey7 = new kony.ui.Label({
                "id": "lblKey7",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.refNumberColon\")",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxKey7.add(lblKey7);
            var flxValue7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxValue7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "27.30%",
                "isModalContainer": false,
                "top": "0",
                "width": "72%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValue7.setDefaultUnit(kony.flex.DP);
            var lblReferenceNumberValue = new kony.ui.Label({
                "id": "lblReferenceNumberValue",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValue7.add(lblReferenceNumberValue);
            flxConfirmDetail7.add(flxKey7, flxValue7);
            var flxGap = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxGap",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": 0,
                "width": "100%",
                "appName": "AccountSweepsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGap.setDefaultUnit(kony.flex.DP);
            flxGap.add();
            flxMainContent.add(flxConfirmDetail1, flxConfirmDetail2, flxConfirmDetail3, flxConfirmDetail4, flxConfirmDetail5, flxConfirmDetail6, flxConfirmDetail7, flxGap);
            flxUserDetails.add(flxMainContent);
            flxPrintReceivedClaims.add(flxHeader, lblHeader, flxUserDetails);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxConfirmDetail1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxKey1": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxValue1": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmDetail2": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "flxKey2": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmDetail3": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "flxKey3": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "rtxSweepCond": {
                        "segmentProps": []
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": []
                    },
                    "flxConfirmDetail4": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "flxKey4": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmDetail5": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "flxKey5": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmDetail6": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "flxKey6": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmDetail7": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "flxKey7": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxValue7": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "lblKey1": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxKey2": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey2": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey3": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey3": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "rtxSweepCond": {
                        "segmentProps": []
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": []
                    },
                    "flxKey4": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey4": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey5": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey5": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey6": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey6": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey7": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey7": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue7": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxKey1": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey1": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue1": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey2": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey2": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey3": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey3": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "rtxSweepCond": {
                        "segmentProps": []
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": []
                    },
                    "flxKey4": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey4": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey5": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey5": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey6": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey6": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "72%"
                        },
                        "segmentProps": []
                    },
                    "flxKey7": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey7": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue7": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "72%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxKey1": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey1": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue1": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey2": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey2": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue2": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey3": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey3": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue3": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "rtxSweepCond": {
                        "segmentProps": []
                    },
                    "rtxSweepCondAbove": {
                        "segmentProps": []
                    },
                    "flxKey4": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey4": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue4": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey5": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey5": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue5": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey6": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey6": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue6": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    },
                    "flxKey7": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblKey7": {
                        "padding": [0, 0, 2, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxValue7": {
                        "left": {
                            "type": "string",
                            "value": "24.30%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {}
            this.add(flxPrintReceivedClaims);
        };
        return [{
            "addWidgets": addWidgetsfrmPrint,
            "enabledForIdleTimeout": true,
            "id": "frmPrint",
            "init": controller.AS_Form_h7a2e8590a184bc8972f8a123b5d8f56,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "AccountSweepsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});