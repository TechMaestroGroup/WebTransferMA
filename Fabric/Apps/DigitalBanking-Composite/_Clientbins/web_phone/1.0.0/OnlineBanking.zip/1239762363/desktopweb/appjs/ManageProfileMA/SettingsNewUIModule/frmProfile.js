define("ManageProfileMA/SettingsNewUIModule/frmProfile", function() {
    return function(controller) {
        function addWidgetsfrmProfile() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxHamburger": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "menu_close_white.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgKonyHamburger": {
                        "src": "kony_logo_white.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.profilesettings\")"
                    },
                    "lblMyBills": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-live": "off",
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblHeading",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Settingscapson\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "27dp",
                "width": "87.80%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.updateSettingAndPreferences\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Settings"
            });
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Dropdown",
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "262dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxProfile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxProfile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "550dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfile.setDefaultUnit(kony.flex.DP);
            var flxProfileWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": 0,
                "clipBounds": true,
                "height": "360dp",
                "id": "flxProfileWrapper",
                "isVisible": false,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "7dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileWrapper.setDefaultUnit(kony.flex.DP);
            var flxPersonalDetailsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "78px",
                "id": "flxPersonalDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalDetailsHeader.setDefaultUnit(kony.flex.DP);
            var flxPersonalDetailsSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "29dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPersonalDetailsSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPersonalDetailsSeperator.setDefaultUnit(kony.flex.DP);
            flxPersonalDetailsSeperator.add();
            var lblPersonalDetailsHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "30%",
                "id": "lblPersonalDetailsHeading",
                "isVisible": true,
                "left": 0,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PersonalDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPersonalDetailsHeader.add(flxPersonalDetailsSeperator, lblPersonalDetailsHeading);
            var flxImageError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "52dp",
                "id": "flxImageError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknrounded",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageError.setDefaultUnit(kony.flex.DP);
            var flxErrorContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxErrorContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorContainer.setDefaultUnit(kony.flex.DP);
            var lblImageError = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Pageleveltransaction\")",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblImageError",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknlblff000015px",
                "text": "We couldn't upload your profile picture, as your file does not match with image uplaod criteria, please check again and upload.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgErr = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "imgErr",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorContainer.add(lblImageError, imgErr);
            flxImageError.add(flxErrorContainer);
            var flxPersonalDetailsBody = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPersonalDetailsBody",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxe3e3e3e30pxradius",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPersonalDetailsBody.setDefaultUnit(kony.flex.DP);
            var flxProfileImageWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxProfileImageWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "21.90%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileImageWrapper.setDefaultUnit(kony.flex.DP);
            var flxProfileImage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": false,
                "height": "151dp",
                "id": "flxProfileImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFboxRound",
                "top": "20dp",
                "width": "151dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileImage.setDefaultUnit(kony.flex.DP);
            var imgProfile = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Profile Image"
                },
                "height": "100%",
                "id": "imgProfile",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "img_frame.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileImage.add(imgProfile);
            var flxAddPhoto = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100%",
                "id": "flxAddPhoto",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPhoto.setDefaultUnit(kony.flex.DP);
            var btnAddPhoto = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.ADDPHOTO\")"
                },
                "centerX": "50%",
                "id": "btnAddPhoto",
                "isVisible": true,
                "left": "42dp",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.ADDPHOTO\")",
                "top": "185dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP3343A813PxBg0hover"
            });
            var flxWhatIsSSN = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-haspopup": "dialog",
                        "aria-label": "Info",
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.NAO.Info\")"
                },
                "clipBounds": true,
                "height": "18dp",
                "id": "flxWhatIsSSN",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "185dp",
                "width": "18dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxWhatIsSSN.setDefaultUnit(kony.flex.DP);
            var imgWhatIsSSN = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.NAO.Info\")"
                },
                "height": "15dp",
                "id": "imgWhatIsSSN",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "3.03%",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": 2,
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWhatIsSSN.add(imgWhatIsSSN);
            flxAddPhoto.add(btnAddPhoto, flxWhatIsSSN);
            var btnEditPhoto = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Edit Profile Photo"
                },
                "id": "btnEditPhoto",
                "isVisible": false,
                "left": "50dp",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": "185dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP3343A813PxBg0hover"
            });
            var btnDeletephoto = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Delete Profile Photo"
                },
                "id": "btnDeletephoto",
                "isVisible": false,
                "right": "40dp",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                "top": "185dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnSSP3343A813PxBg0hover"
            });
            var flxSeperator4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxSeperator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "1px",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator4.setDefaultUnit(kony.flex.DP);
            flxSeperator4.add();
            flxProfileImageWrapper.add(flxProfileImage, flxAddPhoto, btnEditPhoto, btnDeletephoto, flxSeperator4);
            var flxProfileDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "220dp",
                "id": "flxProfileDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": 0,
                "skin": "slFbox",
                "top": "0dp",
                "width": "78.09%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9,
                        "1380": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDetails.setDefaultUnit(kony.flex.DP);
            var flxName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxName",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxName.setDefaultUnit(kony.flex.DP);
            var flxNameKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNameKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.79%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 5,
                        "1366": 4,
                        "1380": 4
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameKey.setDefaultUnit(kony.flex.DP);
            var lblNameKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNameKey",
                "isVisible": true,
                "left": "8%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Name\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxNameKey.add(lblNameKey);
            var flxNameValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNameValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "28.97%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "60%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 7,
                        "1366": 8,
                        "1380": 8
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameValue.setDefaultUnit(kony.flex.DP);
            var lblNameValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNameValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Mr. John Smith III",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxNameValue.add(lblNameValue);
            flxName.add(flxNameKey, flxNameValue);
            var flxDOB = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDOB",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDOB.setDefaultUnit(kony.flex.DP);
            var flxDOBKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDOBKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.79%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 5,
                        "1366": 4,
                        "1380": 4
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDOBKey.setDefaultUnit(kony.flex.DP);
            var lblDOBKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblDOBKey",
                "isVisible": true,
                "left": "8%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.DOB\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxDOBKey.add(lblDOBKey);
            var flxDOBValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDOBValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "28.97%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "60%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 7,
                        "1366": 8,
                        "1380": 8
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDOBValue.setDefaultUnit(kony.flex.DP);
            var lblDOBValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblDOBValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "01/12/1980",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxDOBValue.add(lblDOBValue);
            flxDOB.add(flxDOBKey, flxDOBValue);
            var flxSSN = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "12dp",
                "clipBounds": true,
                "id": "flxSSN",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSSN.setDefaultUnit(kony.flex.DP);
            var flxSocialSecurityKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSocialSecurityKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.79%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 5,
                        "1366": 4,
                        "1380": 4
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSocialSecurityKey.setDefaultUnit(kony.flex.DP);
            var lblSocialSecurityKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSocialSecurityKey",
                "isVisible": true,
                "left": "8%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.SocialSecurity\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxSocialSecurityKey.add(lblSocialSecurityKey);
            var flxSocialSecurityValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSocialSecurityValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "28.97%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "60%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 7,
                        "1366": 8,
                        "1380": 8
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSocialSecurityValue.setDefaultUnit(kony.flex.DP);
            var lblSocialSecurityValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblSocialSecurityValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "***-**-1234",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblAltSocialSecurityValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblAltSocialSecurityValue",
                "isVisible": true,
                "left": "0",
                "top": "0",
                "width": "1dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSocialSecurityValue.add(lblSocialSecurityValue, lblAltSocialSecurityValue);
            flxSSN.add(flxSocialSecurityKey, flxSocialSecurityValue);
            var flxMobileNumber = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMobileNumber",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMobileNumber.setDefaultUnit(kony.flex.DP);
            var flxMobileKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMobileKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.79%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 5,
                        "1366": 4,
                        "1380": 4
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMobileKey.setDefaultUnit(kony.flex.DP);
            var lblMobileKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMobileKey",
                "isVisible": true,
                "left": "3%",
                "skin": "sknlbla0a0a013px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PhoneNumbers\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxMobileKey.add(lblMobileKey);
            var flxMobileValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMobileValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "28.97%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "60%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 7,
                        "1366": 8,
                        "1380": 8
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMobileValue.setDefaultUnit(kony.flex.DP);
            var lblMobileValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMobileValue",
                "isVisible": true,
                "left": "3%",
                "skin": "sknLblSSP42424213px",
                "text": "992929292",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxMobileValue.add(lblMobileValue);
            flxMobileNumber.add(flxMobileKey, flxMobileValue);
            var flxEmailId = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "12dp",
                "clipBounds": true,
                "id": "flxEmailId",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "12dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEmailId.setDefaultUnit(kony.flex.DP);
            var flxEmailIdKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEmailIdKey",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.79%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 5,
                        "1366": 4,
                        "1380": 4
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailIdKey.setDefaultUnit(kony.flex.DP);
            var lblEmailId = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEmailId",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.EmailID\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxEmailIdKey.add(lblEmailId);
            var flxEmailIdValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEmailIdValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "28.97%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "60%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 7,
                        "1366": 4,
                        "1380": 4
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmailIdValue.setDefaultUnit(kony.flex.DP);
            var lblEmailIdValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEmailIdValue",
                "isVisible": true,
                "left": "3%",
                "skin": "sknLblSSP42424213px",
                "text": "Sample@sample.com",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxEmailIdValue.add(lblEmailIdValue);
            flxEmailId.add(flxEmailIdKey, flxEmailIdValue);
            flxProfileDetails.add(flxName, flxDOB, flxSSN, flxMobileNumber, flxEmailId);
            flxPersonalDetailsBody.add(flxProfileImageWrapper, flxProfileDetails);
            flxProfileWrapper.add(flxPersonalDetailsHeader, flxImageError, flxPersonalDetailsBody);
            var ProfileInfo = new com.InfinityOLB.PortfolioManagementMA.AllForms({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "ProfileInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": true,
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "RichTextInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.profileManagement.profileImageInfo\")",
                        "isVisible": true
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip.png"
                    },
                    "lblInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.WireTransfers.Information\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxProfile.add(flxProfileWrapper, ProfileInfo);
            flxRight.add(flxProfile);
            flxContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxMainContainer.add(flxContainer);
            flxMain.add(lblHeading, flxMainContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxProfileDeletePopUp = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog"
                    }
                },
                "clipBounds": true,
                "height": "102%",
                "id": "flxProfileDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxProfileDelete = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "268dp",
                "id": "flxProfileDelete",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDelete.setDefaultUnit(kony.flex.DP);
            var flxprofileDeleteHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "50dp",
                "id": "flxprofileDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofileDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblProfileDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Profile.DeleteProfilePicture\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxprofiledeleteClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.settings.closeDeletePopup\")"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxprofiledeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.setDefaultUnit(kony.flex.DP);
            var imgProfileDeleteClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgProfileDeleteClose",
                "isVisible": false,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcross = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblcross",
                "isVisible": true,
                "skin": "sknOlbFonts0273e317px",
                "text": "g",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.add(imgProfileDeleteClose, lblcross);
            flxprofileDeleteHeader.add(lblProfileDeleteHeader, flxprofiledeleteClose);
            var flxProfileDeleteSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxProfileDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxProfileDeleteSeperator.add();
            var flxProfileDeleteContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "65dp",
                "id": "flxProfileDeleteContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteContent = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblProfileDeleteContent",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Profile.DeleteProfilePictureWarning\")",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.add(lblProfileDeleteContent);
            var flxWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "0%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var flxDisablWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxDisablWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20px",
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "20dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisablWarning.setDefaultUnit(kony.flex.DP);
            flxDisablWarning.add();
            flxWarning.add(flxDisablWarning);
            var flxProfileDeleteButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": 0,
                "clipBounds": true,
                "height": "109px",
                "id": "flxProfileDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteButtons.setDefaultUnit(kony.flex.DP);
            var flxDeleteSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxDeleteSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeleteSeperator2.setDefaultUnit(kony.flex.DP);
            flxDeleteSeperator2.add();
            var btnDeletePopupYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Yes, remove the profile picture"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupYes",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "28.44%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            var btnDeletePopupNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "No, don't remove the profile picture"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupNo",
                "isVisible": true,
                "left": "35.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "28.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxProfileDeleteButtons.add(flxDeleteSeperator2, btnDeletePopupYes, btnDeletePopupNo);
            flxProfileDelete.add(flxprofileDeleteHeader, flxProfileDeleteSeperator, flxProfileDeleteContent, flxWarning, flxProfileDeleteButtons);
            flxProfileDeletePopUp.add(flxProfileDelete);
            var flxLogout = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxProfileDeletePopUp, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "frmProfile": {
                        "skin": "sknFrmf8f7f8",
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheadernew.flxShadowContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "text": "Profile Settings",
                        "segmentProps": []
                    },
                    "customheadernew.lblMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "isVisible": true,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "minHeight": {
                            "type": "string",
                            "value": "540dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "590px"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "580px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "478px"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc3",
                        "top": {
                            "type": "string",
                            "value": "5px"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPersonalDetailsHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxPersonalDetailsSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknflxe9ebee",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblPersonalDetailsHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxImageError": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "isVisible": true,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "lblImageError": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "skin": "sknlblff000011px",
                        "text": "We couldn't upload your profile picture, as your file does not match with image upload criteria, please check again and upload.",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "imgErr": {
                        "left": {
                            "type": "string",
                            "value": "5px"
                        },
                        "segmentProps": []
                    },
                    "flxPersonalDetailsBody": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxProfileImageWrapper": {
                        "height": {
                            "type": "string",
                            "value": "235dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileImage": {
                        "height": {
                            "type": "string",
                            "value": "151dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "151dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddPhoto": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddPhoto": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxWhatIsSSN": {
                        "height": {
                            "type": "string",
                            "value": "18px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "35%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "btnEditPhoto": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "btnDeletephoto": {
                        "left": {
                            "type": "string",
                            "value": "57%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSeperator4": {
                        "bottom": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "2px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxName": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblNameKey": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknlbla0a0a013px",
                        "segmentProps": []
                    },
                    "lblNameValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxDOB": {
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "lblDOBKey": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknlbla0a0a013px",
                        "segmentProps": []
                    },
                    "lblDOBValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxSSN": {
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "segmentProps": []
                    },
                    "lblSocialSecurityKey": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknlbla0a0a013px",
                        "segmentProps": []
                    },
                    "lblSocialSecurityValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknLblSSP42424213px",
                        "segmentProps": []
                    },
                    "flxMobileNumber": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxEmailId": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblEmailId": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknlbla0a0a013px",
                        "segmentProps": []
                    },
                    "ProfileInfo": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": [],
                        "instanceId": "ProfileInfo"
                    },
                    "ProfileInfo.RichTextInfo": {
                        "isVisible": true,
                        "text": "Add supported image formats like JPEG and PNG.",
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxprofileDeleteHeader": {
                        "height": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteHeader": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteContent": {
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "30"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "340dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxRight": {
                        "minHeight": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxPersonalDetailsHeader": {
                        "height": {
                            "type": "string",
                            "value": "70px"
                        },
                        "segmentProps": []
                    },
                    "flxPersonalDetailsSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "lblPersonalDetailsHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxImageError": {
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "isVisible": false,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknrounded",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "lblImageError": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "We couldn't upload your profile picture, as your file does not match with image upload criteria, please check again and upload.",
                        "segmentProps": []
                    },
                    "flxProfileImage": {
                        "height": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "imgProfile": {
                        "segmentProps": []
                    },
                    "flxAddPhoto": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddPhoto": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "34%"
                        },
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxWhatIsSSN": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnEditPhoto": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "btnDeletephoto": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "flxSeperator4": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblNameValue": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "lblDOBValue": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxSSN": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblSocialSecurityValue": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxMobileNumber": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblMobileKey": {
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "skin": "sknlbla0a0a015px",
                        "segmentProps": []
                    },
                    "lblMobileValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailId": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblEmailId": {
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "skin": "sknlbla0a0a015px",
                        "segmentProps": []
                    },
                    "lblEmailIdValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "ProfileInfo": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": [],
                        "instanceId": "ProfileInfo"
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "height": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteContent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Are you sure you want to remove your profile picture?",
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "left": {
                            "type": "string",
                            "value": "-100%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "skin": "sknlblUserName",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "skin": "slFboxffffff",
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "left": {
                            "type": "string",
                            "value": "2.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.60%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPersonalDetailsHeader": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxPersonalDetailsSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "lblPersonalDetailsHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxImageError": {
                        "height": {
                            "type": "string",
                            "value": "72dp"
                        },
                        "isVisible": false,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "skin": "sknrounded",
                        "segmentProps": []
                    },
                    "lblImageError": {
                        "text": "We couldn't upload your profile picture, as your file does not match with image upload criteria, please check again and upload.",
                        "segmentProps": []
                    },
                    "flxPersonalDetailsBody": {
                        "skin": "sknflxBordere3e3e3",
                        "segmentProps": []
                    },
                    "flxAddPhoto": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnAddPhoto": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxWhatIsSSN": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnEditPhoto": {
                        "isVisible": true,
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "btnDeletephoto": {
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "flxNameKey": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblNameKey": {
                        "segmentProps": []
                    },
                    "lblNameValue": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxDOBKey": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblDOBKey": {
                        "left": {
                            "type": "string",
                            "value": "8.00%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblDOBValue": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxSSN": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSocialSecurityKey": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblSocialSecurityKey": {
                        "segmentProps": []
                    },
                    "lblSocialSecurityValue": {
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxMobileNumber": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblMobileKey": {
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "skin": "sknlbla0a0a015px",
                        "segmentProps": []
                    },
                    "lblMobileValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "flxEmailId": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblEmailId": {
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "segmentProps": []
                    },
                    "lblEmailIdValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "width": {
                            "type": "string",
                            "value": "99%"
                        },
                        "segmentProps": []
                    },
                    "ProfileInfo": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ProfileInfo"
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblProfileDeleteHeader": {
                        "segmentProps": []
                    },
                    "lblcross": {
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "height": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "lblProfileDeleteContent": {
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "frmProfile": {
                        "segmentProps": []
                    },
                    "customheadernew.flxHamburger": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1202dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxProfile": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "860dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileWrapper": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPersonalDetailsHeader": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "flxPersonalDetailsSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "lblPersonalDetailsHeading": {
                        "centerY": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxImageError": {
                        "height": {
                            "type": "string",
                            "value": "72dp"
                        },
                        "isVisible": false,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxErrorContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "52dp"
                        },
                        "skin": "sknrounded",
                        "segmentProps": []
                    },
                    "flxAddPhoto": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": []
                    },
                    "btnAddPhoto": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxWhatIsSSN": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "btnEditPhoto": {
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "btnDeletephoto": {
                        "skin": "sknBtnSSP0dabb3e467ecc44",
                        "segmentProps": []
                    },
                    "flxSSN": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxMobileNumber": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblMobileKey": {
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "skin": "sknlbla0a0a015px",
                        "text": "Phone Number ",
                        "segmentProps": []
                    },
                    "lblMobileValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxEmailId": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblEmailId": {
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "segmentProps": []
                    },
                    "lblEmailIdValue": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "ProfileInfo": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ProfileInfo"
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxprofileDeleteHeader": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxProfileDeleteContent": {
                        "height": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDeleteSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgClose": {
                    "src": "menu_close_white.png"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgKonyHamburger": {
                    "src": "kony_logo_white.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "ProfileInfo": {
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%"
                },
                "ProfileInfo.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "ProfileInfo.imgToolTip": {
                    "src": "tool_tip.png"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmProfile,
            "enabledForIdleTimeout": true,
            "id": "frmProfile",
            "init": controller.AS_Form_b1266ecdb59042b9aa40b308e9f0afdb,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.profileview\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ManageProfileMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});