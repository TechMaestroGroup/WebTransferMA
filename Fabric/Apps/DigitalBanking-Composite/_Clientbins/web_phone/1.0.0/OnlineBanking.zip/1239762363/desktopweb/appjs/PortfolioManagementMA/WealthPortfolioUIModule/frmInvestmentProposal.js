define("PortfolioManagementMA/WealthPortfolioUIModule/frmInvestmentProposal", function() {
    return function(controller) {
        function addWidgetsfrmInvestmentProposal() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.hamburger.myaccounts\")",
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "10dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var lblProposalHeader = new kony.ui.Label({
                "id": "lblProposalHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.confirmInvestmentProposal\")",
                "top": "26dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxBack",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "200dp",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBack.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgBack",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "back_icon_blue.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtn0273e3SSP15px",
                "id": "btnBack",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknBtn0273e3SSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.back\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack.add(imgBack, btnBack);
            var flxContents = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContents.setDefaultUnit(kony.flex.DP);
            var flxProposalList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxProposalList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProposalList.setDefaultUnit(kony.flex.DP);
            var proposalList = new com.InfinityOLB.PortfolioManagementMA.proposalList({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "proposalList",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "viewType": "proposalList",
                "overrides": {
                    "proposalList": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var proposalList_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmInvestmentProposal"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmInvestmentProposal"]["proposalList"]) || {};
            proposalList.objSerivce = proposalList_data.objSerivce || "PortfolioServicing";
            proposalList.objName = proposalList_data.objName || "InvestmentProposals";
            proposalList.operation = proposalList_data.operation || "getInvestmentProposal";
            proposalList.criteria = proposalList_data.criteria || "{\"pageSize\": \"10\", \"pageOffset\": \"0\"}";
            proposalList.serviceResponseKey = proposalList_data.serviceResponseKey || "investmentProposals";
            flxProposalList.add(proposalList);
            var flxAssetAllocationcheck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": false,
                "id": "flxAssetAllocationcheck",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssetAllocationcheck.setDefaultUnit(kony.flex.DP);
            var AllocationCheck = new com.InfinityOLB.PortfolioManagementMA.AllocationCheck({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 15,
                "centerX": "50%",
                "id": "AllocationCheck",
                "isVisible": true,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "viewType": "AllocationCheck",
                "overrides": {
                    "AllocationCheck": {
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var AllocationCheck_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmInvestmentProposal"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmInvestmentProposal"]["AllocationCheck"]) || {};
            AllocationCheck.serviceParam = AllocationCheck_data.serviceParam || {
                "ObjectName": "InvestmentProposal",
                "ServiceName": "PortfolioServicing",
                "OperationName": "getOrderProposal"
            };
            flxAssetAllocationcheck.add(AllocationCheck);
            var flxRisk = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRisk",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRisk.setDefaultUnit(kony.flex.DP);
            var RiskAnalysisGraph = new com.InfinityOLB.PortfolioManagementMA.RiskAnalysisGraph({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.accounts.viewAccountInfo\")"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "RiskAnalysisGraph",
                "isVisible": true,
                "left": "30dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "viewType": "RiskAnalysisGraph",
                "overrides": {
                    "RiskAnalysisGraph": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var RiskAnalysisGraph_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmInvestmentProposal"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmInvestmentProposal"]["RiskAnalysisGraph"]) || {};
            RiskAnalysisGraph.serviceParam = RiskAnalysisGraph_data.serviceParam || {
                "ObjectName": "InvestmentProposal",
                "ServiceName": "PortfolioServicing",
                "OperationName": "getRiskAnalysisIP"
            };
            flxRisk.add(RiskAnalysisGraph);
            var flxInvestment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxInvestment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "20px",
                "width": "96%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInvestment.setDefaultUnit(kony.flex.DP);
            var flxConstraintsSeg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConstraintsSeg",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknFlxe2e2e2Border",
                "width": "49%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConstraintsSeg.setDefaultUnit(kony.flex.DP);
            var flxConstraints = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConstraints",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5px",
                "isModalContainer": false,
                "top": "0dp",
                "width": "98%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConstraints.setDefaultUnit(kony.flex.DP);
            var investmentConstraints = new com.InfinityOLB.PortfolioManagementMA.investmentConstraints({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "investmentConstraints",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "viewType": "investmentConstraints",
                "overrides": {
                    "investmentConstraints": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var investmentConstraints_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmInvestmentProposal"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmInvestmentProposal"]["investmentConstraints"]) || {};
            flxConstraints.add(investmentConstraints);
            flxConstraintsSeg.add(flxConstraints);
            var flxRecommendationSeg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "height": "101px",
                "id": "flxRecommendationSeg",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "right": 0,
                "skin": "sknFlxe2e2e2Border",
                "top": "0dp",
                "width": "49%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecommendationSeg.setDefaultUnit(kony.flex.DP);
            var flxRecommendation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRecommendation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": 5,
                "isModalContainer": false,
                "top": "0dp",
                "width": "98%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecommendation.setDefaultUnit(kony.flex.DP);
            var recommendedInstruments = new com.InfinityOLB.PortfolioManagementMA.recommendedInstruments({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "recommendedInstruments",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "viewType": "recommendedInstruments",
                "overrides": {
                    "recommendedInstruments": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var recommendedInstruments_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmInvestmentProposal"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmInvestmentProposal"]["recommendedInstruments"]) || {};
            flxRecommendation.add(recommendedInstruments);
            flxRecommendationSeg.add(flxRecommendation);
            flxInvestment.add(flxConstraintsSeg, flxRecommendationSeg);
            var flxConfirmation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxConfirmation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "96%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmation.setDefaultUnit(kony.flex.DP);
            var imgConfirmation = new kony.ui.Image2({
                "height": "20px",
                "id": "imgConfirmation",
                "isVisible": true,
                "left": "0dp",
                "src": "inactivecheckbox_2.png",
                "top": "35px",
                "width": "1.50%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblConfirmation = new kony.ui.Label({
                "id": "lblConfirmation",
                "isVisible": true,
                "left": "1.50%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.confirmClick\")",
                "top": "35px",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConfirmation.add(imgConfirmation, lblConfirmation);
            var flxBtns = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBtns",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBtns.setDefaultUnit(kony.flex.DP);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "CopyslFbox0h5130b256c044e",
                "top": "30dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "top": "20dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnConfirm = new kony.ui.Button({
                "height": "40dp",
                "id": "btnConfirm",
                "isVisible": true,
                "right": "21dp",
                "skin": "sknBtnBlockedSSP00000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.accept\")",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnReject = new kony.ui.Button({
                "height": "40dp",
                "id": "btnReject",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.reject\")",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnContactAdvisor = new kony.ui.Button({
                "height": "40dp",
                "id": "btnContactAdvisor",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.contactAdvisor\")",
                "top": "0",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(btnConfirm, btnReject, btnContactAdvisor);
            flxBtns.add(flxSeparator, flxButtons);
            flxContents.add(flxProposalList, flxAssetAllocationcheck, flxRisk, flxInvestment, flxConfirmation, flxBtns);
            flxMainContainer.add(lblProposalHeader, flxBack, flxContents);
            var flxAcknowledgement = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcknowledgement",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.70%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "88%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgement.setDefaultUnit(kony.flex.DP);
            var lblAckHeader = new kony.ui.Label({
                "id": "lblAckHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.verifyAccountAck\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "16dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAck.setDefaultUnit(kony.flex.DP);
            var acknowledgmentModify = new com.InfinityOLB.PortfolioManagementMA.acknowledgmentModify({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "410dp",
                "id": "acknowledgmentModify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9noshadow",
                "width": "100%",
                "appName": "PortfolioManagementMA",
                "overrides": {
                    "ImgAcknowledged": {
                        "height": "80dp",
                        "src": "success_icon.png",
                        "top": "140dp",
                        "width": "80dp"
                    },
                    "btnModifyTransfer": {
                        "isVisible": false
                    },
                    "confirmHeaders.lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.acknowledgement\")"
                    },
                    "flxBalance": {
                        "isVisible": false
                    },
                    "lblRefrenceNumber": {
                        "isVisible": false
                    },
                    "lblRefrenceNumberValue": {
                        "isVisible": false
                    },
                    "lblTransactionDate": {
                        "isVisible": false
                    },
                    "lblTransactionMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.thankYouAck\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAck.add(acknowledgmentModify);
            var flxButton = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxButton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButton.setDefaultUnit(kony.flex.DP);
            var btnBackToAccountDet = new kony.ui.Button({
                "height": "50dp",
                "id": "btnBackToAccountDet",
                "isVisible": true,
                "right": "0",
                "skin": "sknBtnSSPBg0273e3Border0273e3",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.backToAccDetails\")",
                "top": "30dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButton.add(btnBackToAccountDet);
            flxAcknowledgement.add(lblAckHeader, flxAck, flxButton);
            flxMain.add(flxMainContainer, flxAcknowledgement);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "130dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnFaqs": {
                        "isVisible": true
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    },
                    "btnPrivacy": {
                        "isVisible": true
                    },
                    "btnTermsAndConditions": {
                        "isVisible": true
                    },
                    "customfooter": {
                        "centerX": "50%",
                        "height": "130dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "flxVBar2": {
                        "isVisible": true
                    },
                    "flxVBar3": {
                        "isVisible": true
                    },
                    "flxVBar4": {
                        "isVisible": true
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew, customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            var flxRejectProposalPopup = new kony.ui.FlexContainer({
                "bottom": 0,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxRejectProposalPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": 0,
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectProposalPopup.setDefaultUnit(kony.flex.DP);
            var rejectProposalPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "rejectProposalPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnNo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")"
                    },
                    "btnYes": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")"
                    },
                    "lblHeading": {
                        "isVisible": true
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.rejectPopupheading\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRejectProposalPopup.add(rejectProposalPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "Accounts",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxBack": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "rejectProposalPopup.btnNo": {
                        "segmentProps": []
                    },
                    "rejectProposalPopup.btnYes": {
                        "segmentProps": []
                    },
                    "rejectProposalPopup.lblHeading": {
                        "segmentProps": []
                    },
                    "rejectProposalPopup.lblPopupMessage": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxFormContent": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBack": {
                        "segmentProps": []
                    },
                    "flxAssetAllocationcheck": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "AllocationCheck": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxRisk": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "RiskAnalysisGraph": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxInvestment": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxConstraintsSeg": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxConstraints": {
                        "segmentProps": []
                    },
                    "flxRecommendationSeg": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRecommendation": {
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnReject": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactAdvisor": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxRejectProposalPopup": {
                        "skin": "sknBackground000000Op35",
                        "segmentProps": []
                    },
                    "rejectProposalPopup.btnNo": {
                        "segmentProps": []
                    },
                    "rejectProposalPopup.btnYes": {
                        "segmentProps": []
                    },
                    "rejectProposalPopup.lblHeading": {
                        "segmentProps": []
                    },
                    "rejectProposalPopup.lblPopupMessage": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxFormContent": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxBack": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAssetAllocationcheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "AllocationCheck": {
                        "segmentProps": []
                    },
                    "flxRisk": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "RiskAnalysisGraph": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxInvestment": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxConstraintsSeg": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxConstraints": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "investmentConstraints": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxRecommendationSeg": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxRecommendation": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "recommendedInstruments": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxConfirmation": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBtns": {
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnConfirm": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "btnReject": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactAdvisor": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxRejectProposalPopup": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBackground000000Op35",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "rejectProposalPopup.btnNo": {
                        "segmentProps": []
                    },
                    "rejectProposalPopup.btnYes": {
                        "segmentProps": []
                    },
                    "rejectProposalPopup.lblHeading": {
                        "segmentProps": []
                    },
                    "rejectProposalPopup.lblPopupMessage": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxAssetAllocationcheck": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "rejectProposalPopup.btnNo": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "proposalList": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "AllocationCheck": {
                    "right": "",
                    "top": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                },
                "RiskAnalysisGraph": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "investmentConstraints": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "recommendedInstruments": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "acknowledgmentModify.ImgAcknowledged": {
                    "height": "80dp",
                    "src": "success_icon.png",
                    "top": "140dp",
                    "width": "80dp"
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "130dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs, flxRejectProposalPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmInvestmentProposal,
            "enabledForIdleTimeout": true,
            "id": "frmInvestmentProposal",
            "init": controller.AS_Form_g89b8aa797e34c048d5dad5fe431617e,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_a80e891fe26447a99147aafe50f18ca6,
            "preShow": function(eventobject) {
                controller.AS_Form_f84d185360fe476d8d5f8ca913de89ff(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "PortfolioManagementMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});