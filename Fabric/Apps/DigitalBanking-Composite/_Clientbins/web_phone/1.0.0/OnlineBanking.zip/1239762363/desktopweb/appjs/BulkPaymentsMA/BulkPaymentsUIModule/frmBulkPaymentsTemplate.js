define("BulkPaymentsMA/BulkPaymentsUIModule/frmBulkPaymentsTemplate", function() {
    return function(controller) {
        function addWidgetsfrmBulkPaymentsTemplate() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderMain.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxSeperatorHor2": {
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.lblFeedback": {
                        "text": "Feedback"
                    },
                    "topmenu.lblHelp": {
                        "text": "Help"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderMain.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow_1.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            var flxOverdraftWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxOverdraftWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverdraftWarning.setDefaultUnit(kony.flex.DP);
            var imgOverDraft = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgOverDraft",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverdraftWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOverdraftWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.OverDraftWarning\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOverdraftWarning.add(imgOverDraft, lblOverdraftWarning, imgCloseWarning);
            var flxOutageWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxOutageWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOutageWarning.setDefaultUnit(kony.flex.DP);
            var imgInfoIconWarning = new kony.ui.Image2({
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgInfoIconWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutageWarning = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblOutageWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "13dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseOutageWarning = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgCloseOutageWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOutageWarning.add(imgInfoIconWarning, lblOutageWarning, imgCloseOutageWarning);
            flxMainWrapper.add(flxDowntimeWarning, flxOverdraftWarning, flxOutageWarning);
            var flxskncontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "width": "50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            var flxContentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxContentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainer.setDefaultUnit(kony.flex.DP);
            var flxContentHeader = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "2dp",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.createTemplate\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgDownloadAch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImgDownloadAch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "2%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgDownloadAch.setDefaultUnit(kony.flex.DP);
            var imgDownloadAchTransaction = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgDownloadAchTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbdownloadicon.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgDownloadAch.add(imgDownloadAchTransaction);
            var flxImgPrintAch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImgPrintAch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "93.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "3%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgPrintAch.setDefaultUnit(kony.flex.DP);
            var imgPrintAchTransaction = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgPrintAchTransaction",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "bbprint.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgPrintAch.add(imgPrintAchTransaction);
            flxContentHeader.add(lblContentHeader, flxImgDownloadAch, flxImgPrintAch);
            var flxTemplateDetails = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxTemplateDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "1200dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateDetails.setDefaultUnit(kony.flex.DP);
            var lblTemplateNameTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.transactionDate\")"
                },
                "centerX": "5.50%",
                "centerY": "52%",
                "id": "lblTemplateNameTitle",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkWire.templateName\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "File Name"
            });
            var lblTemplateName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.transactionDate\")"
                },
                "centerY": "52%",
                "id": "lblTemplateName",
                "isVisible": true,
                "left": "4dp",
                "skin": "sknLblSSP42424215pxBold",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalBeneficiariesTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.transactionDate\")"
                },
                "centerY": "52%",
                "id": "lblTotalBeneficiariesTitle",
                "isVisible": true,
                "left": "273dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.totalBeneficiariesWithColon\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalBeneficiaries = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.transactionDate\")"
                },
                "centerY": "52%",
                "id": "lblTotalBeneficiaries",
                "isVisible": true,
                "left": "3dp",
                "skin": "sknLblSSP42424215pxBold",
                "width": "80dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDomesticTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.transactionDate\")"
                },
                "centerY": "52%",
                "id": "lblDomesticTitle",
                "isVisible": true,
                "left": "104dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.domesticWithColon\")",
                "width": "166dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Domestic Recipients"
            });
            var lblDomestic = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.transactionDate\")"
                },
                "centerY": "52%",
                "id": "lblDomestic",
                "isVisible": true,
                "left": "3dp",
                "skin": "sknLblSSP42424215pxBold",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInternationalTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.transactionDate\")"
                },
                "centerY": "52%",
                "id": "lblInternationalTitle",
                "isVisible": true,
                "left": "104dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.internationalWithColon\")",
                "width": "166dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInternational = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.transactionDate\")"
                },
                "centerY": "52%",
                "id": "lblInternational",
                "isVisible": true,
                "left": "3dp",
                "skin": "sknLblSSP42424215pxBold",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInternalTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.transactionDate\")"
                },
                "centerY": "52%",
                "id": "lblInternalTitle",
                "isVisible": true,
                "left": "104dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.sameBankWithColon\")",
                "width": "166dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInternal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.transactionDate\")"
                },
                "centerY": "52%",
                "id": "lblInternal",
                "isVisible": true,
                "left": "3dp",
                "skin": "sknLblSSP42424215pxBold",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTemplateDetails.add(lblTemplateNameTitle, lblTemplateName, lblTotalBeneficiariesTitle, lblTotalBeneficiaries, lblDomesticTitle, lblDomestic, lblInternationalTitle, lblInternational, lblInternalTitle, lblInternal);
            var flxDisplayErrorMessage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "66dp",
                "id": "flxDisplayErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgDisplayError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgDisplayError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDisplayError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblDisplayError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblee0005SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.add(imgDisplayError, lblDisplayError);
            var flxAckMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "18dp",
                "clipBounds": false,
                "height": "90dp",
                "id": "flxAckMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckMessage.setDefaultUnit(kony.flex.DP);
            var flxImgContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxImgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "10%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgContainer.setDefaultUnit(kony.flex.DP);
            var imgCheck = new kony.ui.Image2({
                "height": "60dp",
                "id": "imgCheck",
                "isVisible": true,
                "left": "2%",
                "skin": "slImage",
                "src": "success_green_2.png",
                "top": 0,
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgContainer.add(imgCheck);
            var lblSuccessMessage = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblSuccessMessage",
                "isVisible": true,
                "left": "0%",
                "skin": "bbSknLbl424242SSP20Px",
                "text": "Your application for business enrollement is submitted successfully & we will notify you with further process after verification",
                "top": 0,
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRightContainerInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRightContainerInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainerInfo.setDefaultUnit(kony.flex.DP);
            var lblReferenceHeader = new kony.ui.Label({
                "centerY": "35%",
                "id": "lblReferenceHeader",
                "isVisible": true,
                "left": "332dp",
                "right": "10%",
                "skin": "sknLabelSSP42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.ReferenceNumber\")",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumber = new kony.ui.Label({
                "centerY": "65%",
                "id": "lblReferenceNumber",
                "isVisible": true,
                "left": "480dp",
                "right": "10%",
                "skin": "bbSknLbl424242SSP20Px",
                "text": "Label",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightContainerInfo.add(lblReferenceHeader, lblReferenceNumber);
            flxAckMessage.add(flxImgContainer, lblSuccessMessage, flxRightContainerInfo);
            var flxContentDashBoard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContentDashBoard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentDashBoard.setDefaultUnit(kony.flex.DP);
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "4dp",
                "width": "90%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var flxTabPaneContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTabPaneContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabPaneContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgementContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "19dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "90dp",
                "id": "flxAcknowledgementContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgement = new com.InfinityOLB.Resources.flxAcknowledgement({
                "centerY": "50%",
                "height": "100%",
                "id": "flxAcknowledgement",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ResourcesMA",
                "viewType": "flxAcknowledgement",
                "overrides": {
                    "flxTickImage": {
                        "width": "4.44%"
                    },
                    "rTextSuccess": {
                        "text": "Your transaction has been successfully submitted\nReference Number 45423792753"
                    },
                    "flxAcknowledgement": {
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAcknowledgement_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmBulkPaymentsTemplate"] && appConfig.componentMetadata["ResourcesMA"]["frmBulkPaymentsTemplate"]["flxAcknowledgement"]) || {};
            var flxAcknowledgementNew = new com.InfinityOLB.Resources.flxAcknowledgementNew({
                "height": "100%",
                "id": "flxAcknowledgementNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxAckContainer": {
                        "height": "85dp"
                    },
                    "flxAcknowledgementNew": {
                        "isVisible": true,
                        "left": "0dp",
                        "width": "100%"
                    },
                    "flxImgPrint": {
                        "isVisible": false
                    },
                    "flxImgdownload": {
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "height": "22dp",
                        "isVisible": true,
                        "left": "95%",
                        "width": "22dp"
                    },
                    "imgDownload": {
                        "height": "100%",
                        "imageWhenFailed": "bbcloseicon_1.png",
                        "imageWhileDownloading": "bbcloseicon_1.png",
                        "src": "bbcloseicon_1.png",
                        "width": "100%"
                    },
                    "imgPrint": {
                        "src": "bbprint.png"
                    },
                    "imgTick": {
                        "src": "bulk_billpay_success.png"
                    },
                    "rTextSuccess": {
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "left": "8.80%",
                        "text": "User has been Successfully Added ."
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAcknowledgementContainer.add(flxAcknowledgement, flxAcknowledgementNew);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "blur": {
                    "enabled": false,
                    "value": 0
                },
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "focusSkin": "sknFlxffffffShadowdddcdc",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblee0005SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(imgError, lblError);
            var flxTemplate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTemplate",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplate.setDefaultUnit(kony.flex.DP);
            var flxCreateUI = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxCreateUI",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateUI.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var lblTitle = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "lblTitle",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wireTemplate.providePrimaryDetails\")",
                "width": "153dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(lblTitle);
            var flxTopSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "7dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeparator.setDefaultUnit(kony.flex.DP);
            flxTopSeparator.add();
            var lblInvalidDescription = new kony.ui.Label({
                "height": "17dp",
                "id": "lblInvalidDescription",
                "isVisible": false,
                "left": "2.52%",
                "skin": "ICSknLblErrorNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.bulkPayments.invalidDescription\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCreateDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "165dp",
                "id": "flxCreateDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateDetails.setDefaultUnit(kony.flex.DP);
            var flxNameDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNameDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNameDetails.setDefaultUnit(kony.flex.DP);
            var lblName = new kony.ui.Label({
                "height": "17dp",
                "id": "lblName",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.TemplateName\")",
                "top": "18dp",
                "width": "101dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTemplateName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxTemplateName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "8dp",
                "width": "55.57%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateName.setDefaultUnit(kony.flex.DP);
            var tbxTemplateName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "tbxTemplateName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "20dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"kony.mb.achtransationdetail.TemplateName\")",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBorder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015pxNoborder"
            });
            flxTemplateName.add(tbxTemplateName);
            flxNameDetails.add(lblName, flxTemplateName);
            var lblFromAccount = new kony.ui.Label({
                "height": "17dp",
                "id": "lblFromAccount",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.Bulkpayments.selectFromAccount\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFromAccount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "19%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxFromAccount",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "8dp",
                "width": "33.30%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromAccount.setDefaultUnit(kony.flex.DP);
            var lstbFromAccount = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox455574SSP15Px",
                "height": "100%",
                "id": "lstbFromAccount",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknListBox455574SSP15Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFromAccount.add(lstbFromAccount);
            var flxFromWrap = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFromWrap",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.52%",
                "isModalContainer": false,
                "top": "8dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromWrap.setDefaultUnit(kony.flex.DP);
            var flxFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "width": "55.81%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrom.setDefaultUnit(kony.flex.DP);
            var lblFromAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.TransferFrom\")"
                },
                "centerY": "50%",
                "id": "lblFromAmount",
                "isVisible": false,
                "right": "59dp",
                "skin": "sknSSP42424215Px",
                "text": "Transfer From",
                "width": "100dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtTransferFrom = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.SearchByAccountNameOrNumber\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "100%",
                "id": "txtTransferFrom",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBorder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015pxNoborder"
            });
            var flxFilterDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxFilterDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxFilterDropdown.setDefaultUnit(kony.flex.DP);
            var imgDropDown = new kony.ui.Label({
                "height": "12dp",
                "id": "imgDropDown",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLblFontTypeIcon1a98ff12pxOther",
                "text": "O",
                "top": "7dp",
                "width": "12dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFilterDropdown.add(imgDropDown);
            var flxCancelIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxCancelIcon",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxCancelIcon.setDefaultUnit(kony.flex.DP);
            var imgCancelFilterFrom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCancelFilterFrom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "search_close.png",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            flxCancelIcon.add(imgCancelFilterFrom);
            var flxLoadingContainerFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoadingContainerFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 10,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingContainerFrom.setDefaultUnit(kony.flex.DP);
            var flxLoadingIndicatorFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxLoadingIndicatorFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1%",
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxLoadingIndicatorFrom.setDefaultUnit(kony.flex.DP);
            var imgLoadingIndicatorFrom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.payAPersonDeregister\")"
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgLoadingIndicatorFrom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "rb_4_0_ad_loading_indicator.gif",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Remove"
            });
            flxLoadingIndicatorFrom.add(imgLoadingIndicatorFrom);
            flxLoadingContainerFrom.add(flxLoadingIndicatorFrom);
            var flxFromValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxFromValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromValue.setDefaultUnit(kony.flex.DP);
            var flxTypeIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTypeIcon",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "20dp",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTypeIcon.setDefaultUnit(kony.flex.DP);
            var lblTypeIcon = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblTypeIcon",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblOLBFontIcons003E7512pxbordere3e3e3",
                "text": "g",
                "top": "0",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTypeIcon.add(lblTypeIcon);
            var lblSelectAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.TransferFrom\")"
                },
                "centerY": "50%",
                "id": "lblSelectAccount",
                "isVisible": false,
                "left": "10dp",
                "skin": "sknSSP42424215Px",
                "text": "Pay From",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromValue.add(flxTypeIcon, lblSelectAccount);
            flxFrom.add(lblFromAmount, txtTransferFrom, flxFilterDropdown, flxCancelIcon, flxLoadingContainerFrom, flxFromValue);
            var flxAvailableBalance = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAvailableBalance",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "width": "35%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAvailableBalance.setDefaultUnit(kony.flex.DP);
            var lblAvailableBalanceKey = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAvailableBalanceKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.availableBalancewithColon\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAvailableBalanceValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAvailableBalanceValue",
                "isVisible": true,
                "left": "4dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "$2,324",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAvailableBalance.add(lblAvailableBalanceKey, lblAvailableBalanceValue);
            flxFromWrap.add(flxFrom, flxAvailableBalance);
            var flxFromSegment = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "2dp",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "270dp",
                "horizontalScrollIndicator": true,
                "id": "flxFromSegment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "CopysknFlxscrollffffffShadowdddcdc0c89e2b18399448",
                "verticalScrollIndicator": true,
                "width": "55.80%",
                "zIndex": 10
            }, {
                "paddingInPixel": false
            }, {});
            flxFromSegment.setDefaultUnit(kony.flex.DP);
            var lblSelectFromAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoAccountsToTransferFrom\")"
                },
                "height": "40dp",
                "id": "lblSelectFromAccount",
                "isVisible": true,
                "left": "22dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.CM.selectAccount\")",
                "top": "0dp",
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segFromAccount = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "lblDropdownIcon": "O",
                            "lblRecordType": "Label"
                        },
                        [{
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }]
                    ],
                    [{
                            "lblDropdownIcon": "O",
                            "lblRecordType": "Label"
                        },
                        [{
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }, {
                            "imgRecordFieldTypeIcon2": "imagedrag.png",
                            "lblRecordField1": "",
                            "lblRecordField2": "",
                            "lblRecordField3": "",
                            "lblRecordField4": "",
                            "lblRecordFieldTypeIcon1": "r"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segFromAccount",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BulkPaymentsMA",
                    "friendlyName": "flxFromAccountsDropdownList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BulkPaymentsMA",
                    "friendlyName": "flxFromAccountsDropdownHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "45dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountRecordField": "flxAccountRecordField",
                    "flxBottomSeparator": "flxBottomSeparator",
                    "flxDropdownIcon": "flxDropdownIcon",
                    "flxFromAccountsDropdownHeader": "flxFromAccountsDropdownHeader",
                    "flxFromAccountsDropdownList": "flxFromAccountsDropdownList",
                    "flxRecordFieldType": "flxRecordFieldType",
                    "flxRecordFieldTypeIcon1": "flxRecordFieldTypeIcon1",
                    "flxRecordFieldTypeIcon2": "flxRecordFieldTypeIcon2",
                    "flxRecordType": "flxRecordType",
                    "flxTopSeparator": "flxTopSeparator",
                    "imgRecordFieldTypeIcon2": "imgRecordFieldTypeIcon2",
                    "lblDropdownIcon": "lblDropdownIcon",
                    "lblRecordField1": "lblRecordField1",
                    "lblRecordField2": "lblRecordField2",
                    "lblRecordField3": "lblRecordField3",
                    "lblRecordField4": "lblRecordField4",
                    "lblRecordFieldTypeIcon1": "lblRecordFieldTypeIcon1",
                    "lblRecordType": "lblRecordType"
                },
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoAccountsFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "5dp",
                "clipBounds": true,
                "height": "172dp",
                "id": "flxNoAccountsFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "sknFFFFFF",
                "top": "0dp",
                "width": "94%",
                "zIndex": 10,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAccountsFrom.setDefaultUnit(kony.flex.DP);
            var lblNoAccountsFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoAccountsToTransferFrom\")"
                },
                "centerX": "50%",
                "height": "24dp",
                "id": "lblNoAccountsFrom",
                "isVisible": true,
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoAccountsToTransferFrom\")",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoAccountsFrom.add(lblNoAccountsFrom);
            var flxNoResultsFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNoResultsFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoResultsFrom.setDefaultUnit(kony.flex.DP);
            var lblNoResultsFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoResultsFound\")"
                },
                "centerX": "50%",
                "id": "lblNoResultsFrom",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl424242SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoResultsFound\")",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoResultsFrom.add(lblNoResultsFrom);
            flxFromSegment.add(lblSelectFromAccount, segFromAccount, flxNoAccountsFrom, flxNoResultsFrom);
            flxCreateDetails.add(flxNameDetails, lblFromAccount, flxFromAccount, flxFromWrap, flxFromSegment);
            var lblDefaultCurreny = new kony.ui.Label({
                "height": "17dp",
                "id": "lblDefaultCurreny",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.bulkPayments.defaultDebitCurrency\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDefaultCurrency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxDefaultCurrency",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "8dp",
                "width": "55.89%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDefaultCurrency.setDefaultUnit(kony.flex.DP);
            var lstbDefaultCurrency = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox455574SSP15Px",
                "height": "100%",
                "id": "lstbDefaultCurrency",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknListBox455574SSP15Px",
                "top": "0dp",
                "width": "105%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxDefaultCurrency.add(lstbDefaultCurrency);
            var flxInformationText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "blur": {
                    "enabled": false,
                    "value": 0
                },
                "clipBounds": false,
                "id": "flxInformationText",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "13.88%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "-180dp",
                "width": "260dp",
                "zIndex": 20,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformationText.setDefaultUnit(kony.flex.DP);
            var flxInformation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxInformation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformation.setDefaultUnit(kony.flex.DP);
            var lblInformation = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Info\")"
                },
                "centerY": "50%",
                "id": "lblInformation",
                "isVisible": true,
                "left": "4.44%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Info\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5.55%",
                "skin": "skncursor",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "skncursor"
            });
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "12dp",
                "id": "imgCross",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "right": "5.05%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCross.add(imgCross);
            flxInformation.add(lblInformation, flxCross);
            var flxModeTypeInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxModeTypeInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxModeTypeInfo.setDefaultUnit(kony.flex.DP);
            var RichTextSingleInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "RichTextSingleInfo",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.SINGLE\")",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextMultipleInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "id": "RichTextMultipleInfo",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.MULTIPLE\")",
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxModeTypeInfo.add(RichTextSingleInfo, RichTextMultipleInfo);
            flxInformationText.add(flxInformation, flxModeTypeInfo);
            var flxProcessinModeInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxProcessinModeInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProcessinModeInfo.setDefaultUnit(kony.flex.DP);
            var lblProcessingMode = new kony.ui.Label({
                "id": "lblProcessingMode",
                "isVisible": true,
                "left": "8.50%",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.ProcessingMode\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "17dp",
                "id": "flxInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "42%",
                "isModalContainer": false,
                "skin": "bbsknCircleD8D8D8",
                "top": "0dp",
                "width": "17dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "height": "100%",
                "id": "imgInfo",
                "isVisible": false,
                "left": "0",
                "skin": "slImage",
                "src": "info_grey_2.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Specify the type of business that you are enrolling into online banking"
            });
            var lblInfo = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "lblInfo",
                "isVisible": true,
                "left": "0",
                "skin": "bbsknlblinfoicon",
                "text": "i",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfo.add(imgInfo, lblInfo);
            flxProcessinModeInfo.add(lblProcessingMode, flxInfo);
            var flxProcessingMode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxProcessingMode",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "8dp",
                "width": "55.98%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProcessingMode.setDefaultUnit(kony.flex.DP);
            var lstbProcessingMode = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox424242SSP15px",
                "height": "100%",
                "id": "lstbProcessingMode",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblMulti", "Multiple"],
                    ["lblSingle", "Single"]
                ],
                "selectedKey": "lblMulti",
                "skin": "bbSknListBox424242SSP15px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxProcessingMode.add(lstbProcessingMode);
            var flxTextProcessingMode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "30.49%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxTextProcessingMode",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "8dp",
                "width": "55.98%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTextProcessingMode.setDefaultUnit(kony.flex.DP);
            var txtProcessingMode = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "100%",
                "id": "txtProcessingMode",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "CopyslTextBox0b8f036a4265846",
                "text": "Single",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxTextProcessingMode.add(txtProcessingMode);
            var lblExecutionDate = new kony.ui.Label({
                "height": "17dp",
                "id": "lblExecutionDate",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.exceutionDate\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45dp",
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "88.68%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var flxExecutionDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxExecutionDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "2dp",
                "width": "63.48%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExecutionDate.setDefaultUnit(kony.flex.DP);
            var calExecutionDate = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": [null, null, null, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "height": "100%",
                "id": "calExecutionDate",
                "isVisible": true,
                "left": "0dp",
                "placeholder": "dd/mm/yyyy",
                "skin": "sknBBCal42424215px",
                "top": "0dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxExecutionDate.add(calExecutionDate);
            flxDate.add(flxExecutionDate);
            var lblDescription = new kony.ui.Label({
                "height": "17dp",
                "id": "lblDescription",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.Bulkpayments.Description\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTemplateDescription = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxTemplateDescription",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "8dp",
                "width": "56.55%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateDescription.setDefaultUnit(kony.flex.DP);
            var tbxTemplateDescription = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "tbxTemplateDescription",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "34dp",
                "maxTextLength": 35,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.PaymentReference\")",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBorder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015pxNoborder"
            });
            flxTemplateDescription.add(tbxTemplateDescription);
            var lblValidDescription = new kony.ui.Label({
                "height": "17dp",
                "id": "lblValidDescription",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.bulkPayments.validDescription\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBottomSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBottomSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "50dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeperator.setDefaultUnit(kony.flex.DP);
            flxBottomSeperator.add();
            var createFlowFormActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "centerX": "50%",
                "height": "111dp",
                "id": "createFlowFormActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnBack": {
                        "centerY": "viz.val_cleared",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "top": "0dp",
                        "width": "170dp",
                        "zIndex": 1
                    },
                    "btnCancel": {
                        "centerY": "viz.val_cleared",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "top": "0dp",
                        "width": "170dp",
                        "zIndex": 1
                    },
                    "btnNext": {
                        "centerY": "viz.val_cleared",
                        "height": "41dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.next\")",
                        "left": "viz.val_cleared",
                        "right": "0dp",
                        "top": "0dp",
                        "width": "170dp",
                        "zIndex": 1
                    },
                    "btnOption": {
                        "centerY": "viz.val_cleared",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "top": "0dp",
                        "width": "170dp",
                        "zIndex": 1
                    },
                    "flxButtons": {
                        "centerY": "50%",
                        "left": "2.50%",
                        "right": "2.50%"
                    },
                    "flxMain": {
                        "height": "100%"
                    },
                    "formActionsNew": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCreateUI.add(flxHeader, flxTopSeparator, lblInvalidDescription, flxCreateDetails, lblDefaultCurreny, flxDefaultCurrency, flxInformationText, flxProcessinModeInfo, flxProcessingMode, flxTextProcessingMode, lblExecutionDate, flxDate, lblDescription, flxTemplateDescription, lblValidDescription, flxBottomSeperator, createFlowFormActionsNew);
            flxTemplate.add(flxCreateUI);
            var flxCreateBulkRequest = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCreateBulkRequest",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateBulkRequest.setDefaultUnit(kony.flex.DP);
            var flxBulkRequest = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBulkRequest",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBulkRequest.setDefaultUnit(kony.flex.DP);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSummary",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummary.setDefaultUnit(kony.flex.DP);
            var flxSummaryHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSummaryHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryHeader.setDefaultUnit(kony.flex.DP);
            var lblSummaryHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblSummaryHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.summary\")",
                "top": "15dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select & Edit Recipients"
            });
            var flxEditSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEditSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "94%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "12dp",
                "width": "4%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditSummary.setDefaultUnit(kony.flex.DP);
            var lblEditSummary = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblEditSummary",
                "isVisible": true,
                "left": 0,
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": "12dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All Removed Recipients"
            });
            flxEditSummary.add(lblEditSummary);
            flxSummaryHeader.add(lblSummaryHeader, flxEditSummary);
            var flxSummaryHeaderSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSummaryHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0j48d32149b3848",
                "top": "10dp",
                "width": "95%",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryHeaderSeparator.setDefaultUnit(kony.flex.DP);
            flxSummaryHeaderSeparator.add();
            var flxTemplateNameSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTemplateNameSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "20dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateNameSummary.setDefaultUnit(kony.flex.DP);
            var lblTemplateNameKey = new kony.ui.Label({
                "id": "lblTemplateNameKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.templateNameWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblTemplateNameValue = new kony.ui.Label({
                "id": "lblTemplateNameValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxTemplateNameSummary.add(lblTemplateNameKey, lblTemplateNameValue);
            var flxFromAccountSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFromAccountSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromAccountSummary.setDefaultUnit(kony.flex.DP);
            var lblFromAccountKey = new kony.ui.Label({
                "id": "lblFromAccountKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.stopChecks.FromAccount:\")",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblFromAccountIcon = new kony.ui.Label({
                "centerY": "33.30%",
                "height": "14dp",
                "id": "lblFromAccountIcon",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLblOLBFontIcons003E7512pxbordere3e3e3",
                "text": "r",
                "width": "17dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFromAccountValue = new kony.ui.Label({
                "id": "lblFromAccountValue",
                "isVisible": true,
                "left": "27%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxFromAccountSummary.add(lblFromAccountKey, lblFromAccountIcon, lblFromAccountValue);
            var flxExecutionDateSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxExecutionDateSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExecutionDateSummary.setDefaultUnit(kony.flex.DP);
            var lblExecutionDateKey = new kony.ui.Label({
                "id": "lblExecutionDateKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.executionDateWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblExecutionDateValue = new kony.ui.Label({
                "id": "lblExecutionDateValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var flxExecutionDateCreateBulkReq = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20%",
                "clipBounds": false,
                "focusSkin": "sknFocusBorder4A90E2",
                "id": "flxExecutionDateCreateBulkReq",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "25%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "0dp",
                "width": "63.48%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExecutionDateCreateBulkReq.setDefaultUnit(kony.flex.DP);
            var calExecutionDateCreateBulkReq = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": [null, null, null, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "height": "100%",
                "id": "calExecutionDateCreateBulkReq",
                "isVisible": true,
                "left": "0dp",
                "placeholder": "dd/mm/yyyy",
                "skin": "sknBBCal42424215px",
                "top": "0dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxExecutionDateCreateBulkReq.add(calExecutionDateCreateBulkReq);
            flxExecutionDateSummary.add(lblExecutionDateKey, lblExecutionDateValue, flxExecutionDateCreateBulkReq);
            var flxProcessingSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxProcessingSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProcessingSummary.setDefaultUnit(kony.flex.DP);
            var lblProcessingModeKey = new kony.ui.Label({
                "id": "lblProcessingModeKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.paymnets.processingDateWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblProcessingModeValue = new kony.ui.Label({
                "id": "lblProcessingModeValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxProcessingSummary.add(lblProcessingModeKey, lblProcessingModeValue);
            var flxDefaultDebitCurrency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxDefaultDebitCurrency",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDefaultDebitCurrency.setDefaultUnit(kony.flex.DP);
            var lblDefaultDebitCurrencyKey = new kony.ui.Label({
                "id": "lblDefaultDebitCurrencyKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.defaultDebitCurrency\")",
                "top": "0dp",
                "width": "23%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblDefaultDebitCurrencyValue = new kony.ui.Label({
                "id": "lblDefaultDebitCurrencyValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N /  A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxDefaultDebitCurrency.add(lblDefaultDebitCurrencyKey, lblDefaultDebitCurrencyValue);
            var flxTotalAmountSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTotalAmountSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalAmountSummary.setDefaultUnit(kony.flex.DP);
            var lblTotalAmountKey = new kony.ui.Label({
                "id": "lblTotalAmountKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "text": "Toatal Amount with Currency Code:",
                "top": "0dp",
                "width": "23%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblTotalAmountValue = new kony.ui.Label({
                "id": "lblTotalAmountValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N /  A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxTotalAmountSummary.add(lblTotalAmountKey, lblTotalAmountValue);
            var flxTransactionsSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTransactionsSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionsSummary.setDefaultUnit(kony.flex.DP);
            var lblTotalTransactionsKey = new kony.ui.Label({
                "id": "lblTotalTransactionsKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.numberofTransactionsWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblTotalTransactionsValue = new kony.ui.Label({
                "id": "lblTotalTransactionsValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxTransactionsSummary.add(lblTotalTransactionsKey, lblTotalTransactionsValue);
            var flxDescriptionSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxDescriptionSummary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDescriptionSummary.setDefaultUnit(kony.flex.DP);
            var lblDescriptionKey = new kony.ui.Label({
                "id": "lblDescriptionKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.paymentDescriptionWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblDescriptionValue = new kony.ui.Label({
                "id": "lblDescriptionValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxDescriptionSummary.add(lblDescriptionKey, lblDescriptionValue);
            var flxSummarySeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSummarySeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0j48d32149b3848",
                "top": "15dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummarySeparator.setDefaultUnit(kony.flex.DP);
            flxSummarySeparator.add();
            flxSummary.add(flxSummaryHeader, flxSummaryHeaderSeparator, flxTemplateNameSummary, flxFromAccountSummary, flxExecutionDateSummary, flxProcessingSummary, flxDefaultDebitCurrency, flxTotalAmountSummary, flxTransactionsSummary, flxDescriptionSummary, flxSummarySeparator);
            var flxEditBeneficiariesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEditBeneficiariesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditBeneficiariesHeader.setDefaultUnit(kony.flex.DP);
            var lblSelectEdit = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblSelectEdit",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.select&editBeneficiaries\")",
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select & Edit Recipients"
            });
            var flxEditDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEditDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "94%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "12dp",
                "width": "4%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditDetails.setDefaultUnit(kony.flex.DP);
            var lblEdit = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblEdit",
                "isVisible": true,
                "left": 0,
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": "12dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All Removed Recipients"
            });
            flxEditDetails.add(lblEdit);
            var flxDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDropdown",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "94%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "6%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropdown.setDefaultUnit(kony.flex.DP);
            var lblDropDown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblDropDown",
                "isVisible": true,
                "left": 0,
                "skin": "sknLblFontTypeIcon1a98ff12pxOther",
                "text": "O",
                "top": "12dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All Removed Recipients"
            });
            flxDropdown.add(lblDropDown);
            flxEditBeneficiariesHeader.add(lblSelectEdit, flxEditDetails, flxDropdown);
            var flxSearchSortSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSearchSortSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0j48d32149b3848",
                "top": "12dp",
                "width": "95%",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchSortSeparator.setDefaultUnit(kony.flex.DP);
            flxSearchSortSeparator.add();
            var flxError = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var lblErrorMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblErrorMsg",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLabelSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.EditAmoumterror\")",
                "top": "12dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "The entry was invalid. Please try again."
            });
            flxError.add(lblErrorMsg);
            var flxViewAllRecipients = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxViewAllRecipients",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewAllRecipients.setDefaultUnit(kony.flex.DP);
            var lblAddBeneficiariesText = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblAddBeneficiariesText",
                "isVisible": true,
                "left": "25dp",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.AddedBeneficiareisforTemplate\")",
                "top": "12dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            var lblCount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblCount",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSP42424215Px",
                "text": "()",
                "top": "12dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var lblViewRemovedBeneficiaries = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "centerX": "58.70%",
                "id": "lblViewRemovedBeneficiaries",
                "isVisible": true,
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.viewAllRemovedBeneficiaries\")",
                "top": "12dp",
                "width": "240dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All Removed Recipients"
            });
            flxViewAllRecipients.add(lblAddBeneficiariesText, lblCount, lblViewRemovedBeneficiaries);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "80dp",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var flxSearchBeneficiaries = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80%",
                "id": "flxSearchBeneficiaries",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.66%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "98%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchBeneficiaries.setDefaultUnit(kony.flex.DP);
            var flxSearchBeneficiariesBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxSearchBeneficiariesBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "10dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchBeneficiariesBox.setDefaultUnit(kony.flex.DP);
            var imgSearchIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgSearchIcon",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "top": "0",
                "width": "17dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSearchBox = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "bbSknTbx949494SSP15pxItalic",
                "height": "100%",
                "id": "tbxSearchBox",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "45dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.SearchPlaceholder\")",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBorder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "95%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015pxNoborder"
            });
            var imgClearIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgClearIcon",
                "isVisible": false,
                "right": "1%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "top": "0",
                "width": "22dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchBeneficiariesBox.add(imgSearchIcon, tbxSearchBox, imgClearIcon);
            flxSearchBeneficiaries.add(flxSearchBeneficiariesBox);
            flxSearch.add(flxSearchBeneficiaries);
            var flxApplyChanges = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "125dp",
                "id": "flxApplyChanges",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "13dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplyChanges.setDefaultUnit(kony.flex.DP);
            var lblUpdateHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblUpdateHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.updateinBulk\")",
                "top": "50dp",
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Update in bulk for selected recipients"
            });
            var lblAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblAmount",
                "isVisible": true,
                "left": "2%",
                "skin": "sknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.changeamount\")",
                "top": "50dp",
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Change Amount to :"
            });
            var lblPaymentReference = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblPaymentReference",
                "isVisible": true,
                "left": "30%",
                "skin": "sknSSPRegular727272op10015px",
                "text": "Change Payment Reference :",
                "top": "50dp",
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Change from Account to :"
            });
            var flxOr = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxOr",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "200dp",
                "isModalContainer": false,
                "right": "27%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOr.setDefaultUnit(kony.flex.DP);
            var imgOr = new kony.ui.Image2({
                "centerY": "50%",
                "height": "30dp",
                "id": "imgOr",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "or_circle.png",
                "top": "50dp",
                "width": "30dp",
                "zIndex": 50
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparatorLine = new kony.ui.Label({
                "centerX": "50%",
                "height": "70%",
                "id": "lblSeparatorLine",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "text": ".",
                "top": "15%",
                "width": "1dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOr.add(imgOr, lblSeparatorLine);
            var btnApplyChanges = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NewTransfer\")"
                },
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40px",
                "id": "btnApplyChanges",
                "isVisible": true,
                "left": "50dp",
                "right": "0dp",
                "skin": "sknBtnSSPffffff15pxBg0273e3",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.Applychanges\")",
                "top": "50dp",
                "width": "230dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px",
                "toolTip": "Apply Changes"
            });
            var tbxAmount = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxAmount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "2%",
                "secureTextEntry": false,
                "skin": "bbSknTbx0bd40381970e641fontgrey",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "69dp",
                "width": "280dp",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var tbxPaymentReference = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPaymentReference",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "30%",
                "secureTextEntry": false,
                "skin": "bbSknTbx0bd40381970e641fontgrey",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "75dp",
                "width": "280dp",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var btnRemove = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NewTransfer\")"
                },
                "focusSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "height": "40px",
                "id": "btnRemove",
                "isVisible": true,
                "left": "50dp",
                "right": "0dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.Remove\")",
                "top": "50dp",
                "width": "230dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Remove"
            });
            var lblRemoveBeneficiaries = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblRemoveBeneficiaries",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.removeFromBulkReq\")",
                "top": "50dp",
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Remove Recipients from bulk transfer"
            });
            flxApplyChanges.add(lblUpdateHeader, lblAmount, lblPaymentReference, flxOr, btnApplyChanges, tbxAmount, tbxPaymentReference, btnRemove, lblRemoveBeneficiaries);
            var flxApplyChangesTemplate = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "150dp",
                "id": "flxApplyChangesTemplate",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "13dp",
                "width": "94.62%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplyChangesTemplate.setDefaultUnit(kony.flex.DP);
            var blUpdateHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "blUpdateHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.updateinBulk\")",
                "top": "50dp",
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Update in bulk for selected recipients"
            });
            var lblChangeCurrency = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblChangeCurrency",
                "isVisible": true,
                "left": "1.39%",
                "skin": "sknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.Bulkpayements.changeCurrencyTo\")",
                "top": 58,
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Change Amount to :"
            });
            var lblChangeAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblChangeAmount",
                "isVisible": true,
                "left": "14.84%",
                "skin": "sknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.changeamount\")",
                "top": "58dp",
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Change Amount to :"
            });
            var lblFeesPaid = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblFeesPaid",
                "isVisible": true,
                "left": "31.06%",
                "skin": "sknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.FeesPaidBy\")",
                "top": "58dp",
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Change from Account to :"
            });
            var lblPaymentRef = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblPaymentRef",
                "isVisible": true,
                "left": "43.53%",
                "skin": "sknSSPRegular727272op10015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.PaymentReference\")",
                "top": "58dp",
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Change Amount to :"
            });
            var flxChangeCurrency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "16dp",
                "clipBounds": true,
                "height": "40px",
                "id": "flxChangeCurrency",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.39%",
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "82dp",
                "width": "11.98%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxChangeCurrency.setDefaultUnit(kony.flex.DP);
            var lstbChangeCurrency = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox455574SSP15Px",
                "height": "100%",
                "id": "lstbChangeCurrency",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblMulti", "Multiple"],
                    ["lblSingle", "Single"]
                ],
                "selectedKey": "lblMulti",
                "skin": "bbSknListBox455574SSP15Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxChangeCurrency.add(lstbChangeCurrency);
            var tbxChangeAmount = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxChangeAmount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "14.84%",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215Px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "82dp",
                "width": "14.76%",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 3, 1, 3],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var flxFeesPaid = new kony.ui.FlexContainer({
                "bottom": "16dp",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFeesPaid",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "31.06%",
                "isModalContainer": false,
                "right": 630,
                "skin": "sknBorderE3E3E3",
                "top": "82dp",
                "width": "11.10%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesPaid.setDefaultUnit(kony.flex.DP);
            var lstbFeesPaid = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox455574SSP15Px",
                "height": "100%",
                "id": "lstbFeesPaid",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblMulti", "Multiple"],
                    ["lblSingle", "Single"]
                ],
                "selectedKey": "lblMulti",
                "skin": "bbSknListBox455574SSP15Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFeesPaid.add(lstbFeesPaid);
            var tbxPaymentRef = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPaymentRef",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "43.53%",
                "maxTextLength": 35,
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215Px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "82dp",
                "width": "17%",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 3, 1, 3],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblPaymentReferenceValidDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblPaymentReferenceValidDesc",
                "isVisible": true,
                "left": "43.50%",
                "skin": "ICSknSSPRegular727272op10013px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.bulkPayments.validDescription\")",
                "top": "125dp",
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Change from Account to :"
            });
            var btnApplyBeneficiaryChange = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NewTransfer\")"
                },
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40px",
                "id": "btnApplyBeneficiaryChange",
                "isVisible": true,
                "left": "62%",
                "right": 0,
                "skin": "sknBtnSSPffffff15pxBg0273e3",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.Applychanges\")",
                "top": "82dp",
                "width": "11.79%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px",
                "toolTip": "Apply Changes"
            });
            var flxOrSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxOrSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "200dp",
                "isModalContainer": false,
                "right": "27%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOrSeperator.setDefaultUnit(kony.flex.DP);
            var imgTemplateOr = new kony.ui.Image2({
                "centerY": "50%",
                "height": "30dp",
                "id": "imgTemplateOr",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "or_circle.png",
                "top": "50dp",
                "width": "30dp",
                "zIndex": 50
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTemplateSeparatorLine = new kony.ui.Label({
                "centerX": "50%",
                "height": "70%",
                "id": "lblTemplateSeparatorLine",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "text": ".",
                "top": "15%",
                "width": "1dp",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOrSeperator.add(imgTemplateOr, lblTemplateSeparatorLine);
            var lblRemoveTemplateBeneficiaries = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblRemoveTemplateBeneficiaries",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.removeFromBulkTemplate\")",
                "top": "50dp",
                "width": "500dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Remove Recipients from bulk transfer"
            });
            var btnTemplateRemove = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NewTransfer\")"
                },
                "focusSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "height": "40px",
                "id": "btnTemplateRemove",
                "isVisible": true,
                "left": "50dp",
                "right": "0dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.Remove\")",
                "top": "50dp",
                "width": "230dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Remove"
            });
            flxApplyChangesTemplate.add(blUpdateHeader, lblChangeCurrency, lblChangeAmount, lblFeesPaid, lblPaymentRef, flxChangeCurrency, tbxChangeAmount, flxFeesPaid, tbxPaymentRef, lblPaymentReferenceValidDesc, btnApplyBeneficiaryChange, flxOrSeperator, lblRemoveTemplateBeneficiaries, btnTemplateRemove);
            var flxViewOnlySeletced = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxViewOnlySeletced",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewOnlySeletced.setDefaultUnit(kony.flex.DP);
            var lblViewOnlySelected = new kony.ui.Label({
                "id": "lblViewOnlySelected",
                "isVisible": true,
                "left": "85dp",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.viewonlyselected\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View only selected"
            });
            var flxStatus = new kony.ui.FlexContainer({
                "bottom": "20dp",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "70dp",
                "skin": "slFbox",
                "width": "55dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatus.setDefaultUnit(kony.flex.DP);
            var lblStatus = new kony.ui.Label({
                "centerX": "50.81%",
                "centerY": "50.00%",
                "height": "100%",
                "id": "lblStatus",
                "isVisible": true,
                "left": "85dp",
                "right": 0,
                "skin": "skna0a0a0fonticon45px",
                "text": "m",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStatus.add(lblStatus);
            flxViewOnlySeletced.add(lblViewOnlySelected, flxStatus);
            var flxSortSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSortSeparator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSortSeparator.setDefaultUnit(kony.flex.DP);
            flxSortSeparator.add();
            var flxSort = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSort",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf5f5f5Border10px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSort.setDefaultUnit(kony.flex.DP);
            var flxBeneficiaryName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxBeneficiaryName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryName.setDefaultUnit(kony.flex.DP);
            var lblBeneficiaryName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.FromAccount\")"
                },
                "centerY": "50%",
                "id": "lblBeneficiaryName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.beneficiary\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortName = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortName",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "4dp",
                "skin": "sknImgPointer",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBeneficiaryName.add(lblBeneficiaryName, imgSortName);
            var flxCurrency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxCurrency",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.10%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "17.50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrency.setDefaultUnit(kony.flex.DP);
            var lblCurrency = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Amount\")"
                },
                "centerY": "50%",
                "id": "lblCurrency",
                "isVisible": true,
                "right": "0%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.Currency\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortCurrency = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortCurrency",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCurrency.add(lblCurrency, imgSortCurrency);
            var flxAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "15.50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var lblSortAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Status\")"
                },
                "centerY": "50%",
                "id": "lblSortAmount",
                "isVisible": true,
                "left": "30%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortAmount = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortAmount",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmount.add(lblSortAmount, imgSortAmount);
            var flxFeesPaidBy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxFeesPaidBy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5.40%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "23%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesPaidBy.setDefaultUnit(kony.flex.DP);
            var lblFeesPaidBy = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Date\")"
                },
                "centerY": "50%",
                "id": "lblFeesPaidBy",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.Europe.FeesPaidBy\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortFees = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortFees",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesPaidBy.add(lblFeesPaidBy, imgSortFees);
            var flxSelectAll = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSelectAll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.30%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "10%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAll.setDefaultUnit(kony.flex.DP);
            var lblSelectAll = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.settings.accessibility.checkbox\")"
                },
                "id": "lblSelectAll",
                "isVisible": true,
                "left": "0%",
                "skin": "sknFontIconCheckBoxSelected",
                "text": "D",
                "width": "25px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelectAll.add(lblSelectAll);
            flxSort.add(flxBeneficiaryName, flxCurrency, flxAmount, flxFeesPaidBy, flxSelectAll);
            var flxSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegment.setDefaultUnit(kony.flex.DP);
            var TabBodyNewBeneficiaries = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "id": "TabBodyNewBeneficiaries",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "bottom": "0dp",
                        "isVisible": true
                    },
                    "segTemplates": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxSegment.add(TabBodyNewBeneficiaries);
            var flxNoRecipients = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "441dp",
                "id": "flxNoRecipients",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "0dp",
                "width": "100%",
                "zIndex": 7,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoRecipients.setDefaultUnit(kony.flex.DP);
            var imgInfoNoRecipients = new kony.ui.Image2({
                "height": "50dp",
                "id": "imgInfoNoRecipients",
                "isVisible": true,
                "left": "4%",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "32dp",
                "width": "6.30%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxNoRecipientsMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "No transactions found."
                },
                "id": "rtxNoRecipientsMessage",
                "isVisible": true,
                "left": "12.60%",
                "skin": "sknRtxSSPLight42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.norecipientfound\")",
                "top": "41dp",
                "width": "87.94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoRecipients.add(imgInfoNoRecipients, rtxNoRecipientsMessage);
            var flxNoTransactions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "441dp",
                "id": "flxNoTransactions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "0dp",
                "width": "100%",
                "zIndex": 7,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoTransactions.setDefaultUnit(kony.flex.DP);
            var imgViewTemplateInfo = new kony.ui.Image2({
                "height": "50dp",
                "id": "imgViewTemplateInfo",
                "isVisible": true,
                "left": "4%",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "32dp",
                "width": "6.30%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxNoPaymentMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "No transactions found."
                },
                "id": "rtxNoPaymentMessage",
                "isVisible": true,
                "left": "12.60%",
                "skin": "sknRtxSSPLight42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.noTransactions\")",
                "top": "41dp",
                "width": "87.94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblScheduleAPayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPayMakeTransfer\")"
                },
                "id": "lblScheduleAPayment",
                "isVisible": true,
                "left": "12.60%",
                "skin": "sknSSP3343ABpx24",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPayMakeTransfer\")",
                "top": "107dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "MAKE TRANSFER"
            });
            flxNoTransactions.add(imgViewTemplateInfo, rtxNoPaymentMessage, lblScheduleAPayment);
            var flxRowSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxRowSeperator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0j48d32149b3848",
                "top": "0dp",
                "width": "100%",
                "zIndex": 7,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRowSeperator.setDefaultUnit(kony.flex.DP);
            flxRowSeperator.add();
            flxContent.add(flxSummary, flxEditBeneficiariesHeader, flxSearchSortSeparator, flxError, flxViewAllRecipients, flxSearch, flxApplyChanges, flxApplyChangesTemplate, flxViewOnlySeletced, flxSortSeparator, flxSort, flxSegment, flxNoRecipients, flxNoTransactions, flxRowSeperator);
            flxBulkRequest.add(flxContent);
            flxCreateBulkRequest.add(flxBulkRequest);
            var flxBeneficiaryUI = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBeneficiaryUI",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBeneficiaryUI.setDefaultUnit(kony.flex.DP);
            var flxSummary1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSummary1",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummary1.setDefaultUnit(kony.flex.DP);
            var flxSummaryHeaderVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSummaryHeaderVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryHeaderVerifyPage.setDefaultUnit(kony.flex.DP);
            var lblSummaryHeader0 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblSummaryHeader0",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Summary",
                "top": "15dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select & Edit Recipients"
            });
            var flxEditSummary0 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEditSummary0",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "25dp",
                "width": "5%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditSummary0.setDefaultUnit(kony.flex.DP);
            var lblEditSummary0 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblEditSummary0",
                "isVisible": true,
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All Removed Recipients"
            });
            flxEditSummary0.add(lblEditSummary0);
            flxSummaryHeaderVerifyPage.add(lblSummaryHeader0, flxEditSummary0);
            var flxSummaryHeaderSeparatorVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSummaryHeaderSeparatorVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "18dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "CopyslFbox0j48d32149b3848",
                "top": "10dp",
                "width": "96.50%",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummaryHeaderSeparatorVerifyPage.setDefaultUnit(kony.flex.DP);
            flxSummaryHeaderSeparatorVerifyPage.add();
            var flxTemplateNameSummaryVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTemplateNameSummaryVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "20dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateNameSummaryVerifyPage.setDefaultUnit(kony.flex.DP);
            var lblTemplateNameKeyVerifyPage = new kony.ui.Label({
                "id": "lblTemplateNameKeyVerifyPage",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.templateNameWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblTemplateNameValueVerifyPage = new kony.ui.Label({
                "id": "lblTemplateNameValueVerifyPage",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxTemplateNameSummaryVerifyPage.add(lblTemplateNameKeyVerifyPage, lblTemplateNameValueVerifyPage);
            var flxFromAccountSummaryVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFromAccountSummaryVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromAccountSummaryVerifyPage.setDefaultUnit(kony.flex.DP);
            var lblFromAccountKeyVerifyPage = new kony.ui.Label({
                "id": "lblFromAccountKeyVerifyPage",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.FromAccountColon\")",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblFromAccountIconVerifyPage = new kony.ui.Label({
                "centerY": "33.30%",
                "height": "18dp",
                "id": "lblFromAccountIconVerifyPage",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLblOLBFontIcons003E7512pxbordere3e3e3",
                "text": "r",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFromAccountValueVerifyPage = new kony.ui.Label({
                "id": "lblFromAccountValueVerifyPage",
                "isVisible": true,
                "left": "27%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxFromAccountSummaryVerifyPage.add(lblFromAccountKeyVerifyPage, lblFromAccountIconVerifyPage, lblFromAccountValueVerifyPage);
            var flxExecutionDateSummaryVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxExecutionDateSummaryVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExecutionDateSummaryVerifyPage.setDefaultUnit(kony.flex.DP);
            var lblExecutionDateKey0 = new kony.ui.Label({
                "id": "lblExecutionDateKey0",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.executionDateWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblExecutionDateValueVerifyPage = new kony.ui.Label({
                "id": "lblExecutionDateValueVerifyPage",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxExecutionDateSummaryVerifyPage.add(lblExecutionDateKey0, lblExecutionDateValueVerifyPage);
            var flxProcessingSummaryVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxProcessingSummaryVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProcessingSummaryVerifyPage.setDefaultUnit(kony.flex.DP);
            var lblProcessingModeKey0 = new kony.ui.Label({
                "id": "lblProcessingModeKey0",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.paymnets.processingDateWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblProcessingModeValue0 = new kony.ui.Label({
                "id": "lblProcessingModeValue0",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxProcessingSummaryVerifyPage.add(lblProcessingModeKey0, lblProcessingModeValue0);
            var flxTotalCurrencySummaryVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTotalCurrencySummaryVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalCurrencySummaryVerifyPage.setDefaultUnit(kony.flex.DP);
            var lblCurrencyCodeKey = new kony.ui.Label({
                "id": "lblCurrencyCodeKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.defaultDebitCurrency\")",
                "top": "0dp",
                "width": "23%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblCurrencyCodeValue = new kony.ui.Label({
                "id": "lblCurrencyCodeValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N /  A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxTotalCurrencySummaryVerifyPage.add(lblCurrencyCodeKey, lblCurrencyCodeValue);
            var flxTotalAmountSummaryVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTotalAmountSummaryVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalAmountSummaryVerifyPage.setDefaultUnit(kony.flex.DP);
            var lblTotalAmountKey0 = new kony.ui.Label({
                "id": "lblTotalAmountKey0",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkpayments.batchAmountWithColon\")",
                "top": "0dp",
                "width": "23%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblTotalAmountValue0 = new kony.ui.Label({
                "id": "lblTotalAmountValue0",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N /  A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxTotalAmountSummaryVerifyPage.add(lblTotalAmountKey0, lblTotalAmountValue0);
            var flxTransactionsSummaryVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTransactionsSummaryVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionsSummaryVerifyPage.setDefaultUnit(kony.flex.DP);
            var lblTotalTransactionsKey0 = new kony.ui.Label({
                "id": "lblTotalTransactionsKey0",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.numberofTransactionsWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblTotalTransactionsVal = new kony.ui.Label({
                "id": "lblTotalTransactionsVal",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxTransactionsSummaryVerifyPage.add(lblTotalTransactionsKey0, lblTotalTransactionsVal);
            var flxDescriptionSummaryVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxDescriptionSummaryVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0.50%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDescriptionSummaryVerifyPage.setDefaultUnit(kony.flex.DP);
            var lblDescriptionKey0 = new kony.ui.Label({
                "id": "lblDescriptionKey0",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.paymentDescriptionWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblDescriptionValue0 = new kony.ui.Label({
                "id": "lblDescriptionValue0",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "N / A",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxDescriptionSummaryVerifyPage.add(lblDescriptionKey0, lblDescriptionValue0);
            var flxSummarySeparatorVerifyPage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSummarySeparatorVerifyPage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0j48d32149b3848",
                "top": "15dp",
                "width": "95%",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSummarySeparatorVerifyPage.setDefaultUnit(kony.flex.DP);
            flxSummarySeparatorVerifyPage.add();
            flxSummary1.add(flxSummaryHeaderVerifyPage, flxSummaryHeaderSeparatorVerifyPage, flxTemplateNameSummaryVerifyPage, flxFromAccountSummaryVerifyPage, flxExecutionDateSummaryVerifyPage, flxProcessingSummaryVerifyPage, flxTotalCurrencySummaryVerifyPage, flxTotalAmountSummaryVerifyPage, flxTransactionsSummaryVerifyPage, flxDescriptionSummaryVerifyPage, flxSummarySeparatorVerifyPage);
            var flxAddBeneficiaryOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddBeneficiaryOptions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddBeneficiaryOptions.setDefaultUnit(kony.flex.DP);
            var flxBenHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBenHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBenHeader.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "lblHeader",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.selectBeneficiary\")",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBenHeader.add(lblHeader);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "7dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxBenListingMethod = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBenListingMethod",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "4dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBenListingMethod.setDefaultUnit(kony.flex.DP);
            var flxMethod = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMethod",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "21dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMethod.setDefaultUnit(kony.flex.DP);
            var lblMethod = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Method One"
                },
                "bottom": "41dp",
                "id": "lblMethod",
                "isVisible": true,
                "left": "197dp",
                "skin": "sknSSP4176a415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.selectExistingBeneficiaries\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgMethod = new kony.ui.Image2({
                "height": "15dp",
                "id": "imgMethod",
                "isVisible": true,
                "left": "2dp",
                "skin": "slImage",
                "src": "arrow_right.png",
                "top": "23dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMethod.add(lblMethod, imgMethod);
            var flxMethodSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "10dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxMethodSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "30dp",
                "width": "1dp",
                "zIndex": 3,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMethodSeparator.setDefaultUnit(kony.flex.DP);
            flxMethodSeparator.add();
            var flxMethod2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMethod2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "21dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMethod2.setDefaultUnit(kony.flex.DP);
            var lblMethod2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Method Two"
                },
                "bottom": "41dp",
                "id": "lblMethod2",
                "isVisible": true,
                "left": "197dp",
                "skin": "sknSSP4176a415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.AddNewBeneficiary\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgMethod2 = new kony.ui.Image2({
                "height": "15dp",
                "id": "imgMethod2",
                "isVisible": true,
                "left": "2dp",
                "skin": "slImage",
                "src": "arrow_right.png",
                "top": "23dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMethod2.add(lblMethod2, imgMethod2);
            flxBenListingMethod.add(flxMethod, flxMethodSeparator, flxMethod2);
            flxAddBeneficiaryOptions.add(flxBenHeader, flxSeparator, flxBenListingMethod);
            var flxFullSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxFullSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFullSeparator.setDefaultUnit(kony.flex.DP);
            flxFullSeparator.add();
            var flxSubHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSubHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubHeader.setDefaultUnit(kony.flex.DP);
            var lblTitle1 = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "lblTitle1",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.addedBeneficiaries\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEditBeneficiary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEditBeneficiary",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "12dp",
                "width": "5%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditBeneficiary.setDefaultUnit(kony.flex.DP);
            var lblEditBeneficiary = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblEditBeneficiary",
                "isVisible": true,
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All Removed Recipients"
            });
            flxEditBeneficiary.add(lblEditBeneficiary);
            flxSubHeader.add(lblTitle1, flxEditBeneficiary);
            var flxSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "7dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            var flxAddedBen = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddedBen",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddedBen.setDefaultUnit(kony.flex.DP);
            var flxSearchBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "80dp",
                "id": "flxSearchBox",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchBox.setDefaultUnit(kony.flex.DP);
            var flxSearchBeneficiaries1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxSearchBeneficiaries1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.66%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "96%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchBeneficiaries1.setDefaultUnit(kony.flex.DP);
            var flxSearchBeneficiaries2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxSearchBeneficiaries2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchBeneficiaries2.setDefaultUnit(kony.flex.DP);
            var imgSearchIcon1 = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgSearchIcon1",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "top": "0",
                "width": "17dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSearchBox1 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "bbSknTbx949494SSP15pxItalic",
                "height": "100%",
                "id": "tbxSearchBox1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "45dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.billpay.searchForKeywords\")",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBorder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "95%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015pxNoborder"
            });
            var imgClearIcon1 = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgClearIcon1",
                "isVisible": false,
                "right": "1%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "top": "0",
                "width": "22dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchBeneficiaries2.add(imgSearchIcon1, tbxSearchBox1, imgClearIcon1);
            flxSearchBeneficiaries1.add(flxSearchBeneficiaries2);
            flxSearchBox.add(flxSearchBeneficiaries1);
            var flxTabletAccountsSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTabletAccountsSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabletAccountsSeparator.setDefaultUnit(kony.flex.DP);
            flxTabletAccountsSeparator.add();
            var flxViewRecipients = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxViewRecipients",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewRecipients.setDefaultUnit(kony.flex.DP);
            var flxViewRecipientName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxViewRecipientName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "22%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewRecipientName.setDefaultUnit(kony.flex.DP);
            var btnViewRecipientName = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtnFont455574SSP15Px",
                "height": "100%",
                "id": "btnViewRecipientName",
                "isVisible": true,
                "left": "0%",
                "skin": "sknBtnAccountSummaryUnselectedTransfer424242",
                "i18n_text": "kony.i18n.getLocalizedString(\"knoy.mb.externalBank.BenificiaryName\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortViewRecipientName = new kony.ui.Image2({
                "centerY": "50%",
                "height": "14dp",
                "id": "imgSortViewRecipientName",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "12dp",
                "skin": "slImage",
                "src": "sorting.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewRecipientName.add(btnViewRecipientName, imgSortViewRecipientName);
            var flxViewBankName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxViewBankName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "22%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewBankName.setDefaultUnit(kony.flex.DP);
            var btnViewBankName = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtnFont455574SSP15Px",
                "height": "100%",
                "id": "btnViewBankName",
                "isVisible": true,
                "left": "3dp",
                "skin": "sknBtnAccountSummaryUnselectedTransfer424242",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.Amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortViewBankName = new kony.ui.Image2({
                "centerY": "50%",
                "height": "14dp",
                "id": "imgSortViewBankName",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "12dp",
                "skin": "slImage",
                "src": "sorting.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewBankName.add(btnViewBankName, imgSortViewBankName);
            var flxViewAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxViewAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "20%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewAmount.setDefaultUnit(kony.flex.DP);
            var btnViewAmount = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtnFont455574SSP15Px",
                "height": "100%",
                "id": "btnViewAmount",
                "isVisible": true,
                "left": "8dp",
                "skin": "sknBtnAccountSummaryUnselectedTransfer424242",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.FeesPaidBy\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortViewAmount = new kony.ui.Image2({
                "centerY": "50%",
                "height": "14dp",
                "id": "imgSortViewAmount",
                "imageWhenFailed": "sortingfinal.png",
                "imageWhileDownloading": "sortingfinal.png",
                "isVisible": true,
                "left": "12dp",
                "skin": "slImage",
                "src": "sorting.png",
                "width": "14dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewAmount.add(btnViewAmount, imgSortViewAmount);
            var flxViewAction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxViewAction",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "7%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "13%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewAction.setDefaultUnit(kony.flex.DP);
            var btnViewAction = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "bbSknBtnFont455574SSP15Px",
                "height": "100%",
                "id": "btnViewAction",
                "isVisible": true,
                "left": "8dp",
                "skin": "sknBtnAccountSummaryUnselectedTransfer424242",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Actions\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewAction.add(btnViewAction);
            flxViewRecipients.add(flxViewRecipientName, flxViewBankName, flxViewAmount, flxViewAction);
            var TabBodyNewAddedBen = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "id": "TabBodyNewAddedBen",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "bottom": "0dp",
                        "isVisible": false
                    },
                    "segTemplates": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxEmptyBen = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": true,
                "id": "flxEmptyBen",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmptyBen.setDefaultUnit(kony.flex.DP);
            var imgWarningIcon = new kony.ui.Image2({
                "height": "36px",
                "id": "imgWarningIcon",
                "isVisible": true,
                "left": "2.51%",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0",
                "width": "36px"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountsInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.i18n.common.noAccountsAdded\")"
                },
                "id": "lblAccountsInfo",
                "isVisible": true,
                "left": "88dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.noBeneficiaries\")",
                "top": "6dp",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEmptyBen.add(imgWarningIcon, lblAccountsInfo);
            flxAddedBen.add(flxSearchBox, flxTabletAccountsSeparator, flxViewRecipients, TabBodyNewAddedBen, flxEmptyBen);
            var addBenFormActions = new com.InfinityOLB.Resources.formActionsNew({
                "centerX": "50%",
                "height": "111dp",
                "id": "addBenFormActions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnBack": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40px",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "30px",
                        "top": "0px",
                        "width": "170px",
                        "zIndex": 1
                    },
                    "btnCancel": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40px",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "30px",
                        "top": "0px",
                        "width": "170px",
                        "zIndex": 1
                    },
                    "btnNext": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40px",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.next\")",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "0px",
                        "top": "0px",
                        "width": "170px",
                        "zIndex": 1
                    },
                    "btnOption": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40px",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "30px",
                        "top": "0px",
                        "width": "170px",
                        "zIndex": 1
                    },
                    "flxButtons": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "width": "94.97%"
                    },
                    "formActionsNew": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBeneficiaryUI.add(flxSummary1, flxAddBeneficiaryOptions, flxFullSeparator, flxSubHeader, flxSeparator2, flxAddedBen, addBenFormActions);
            var flxExistingBeneficiaries = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxExistingBeneficiaries",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExistingBeneficiaries.setDefaultUnit(kony.flex.DP);
            var flxExistingBenHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxExistingBenHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExistingBenHeader.setDefaultUnit(kony.flex.DP);
            var lblHeaderBen = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "lblHeaderBen",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.selectExistingBeneficiaries\")",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExistingBenHeader.add(lblHeaderBen);
            var flxSeperator4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator4.setDefaultUnit(kony.flex.DP);
            var lblSample = new kony.ui.Label({
                "id": "lblSample",
                "isVisible": true,
                "left": "1.58%",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Name\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeperator4.add(lblSample);
            var flxSearchBar = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "70dp",
                "id": "flxSearchBar",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "98%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchBar.setDefaultUnit(kony.flex.DP);
            var flxBoxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxBoxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "10dp",
                "width": "75%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoxSearch.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgSearch",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "top": "0",
                "width": "17dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "bbSknTbx455574SSP15px",
                "height": "100%",
                "id": "tbxSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "45dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.SearchPlaceholder\")",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBorder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "90%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015pxNoborder"
            });
            var imgClear = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgClear",
                "isVisible": true,
                "right": "1%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "top": "0",
                "width": "22dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBoxSearch.add(imgSearch, tbxSearch, imgClear);
            var flxViewOnlySeletcedBen = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxViewOnlySeletcedBen",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "21%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewOnlySeletcedBen.setDefaultUnit(kony.flex.DP);
            var lblViewOnlySelectedBen = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblViewOnlySelectedBen",
                "isVisible": true,
                "right": "80dp",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.viewonlyselected\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View only selected"
            });
            var flxStatus1 = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxStatus1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "55dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatus1.setDefaultUnit(kony.flex.DP);
            var lblStatus1 = new kony.ui.Label({
                "centerX": "50.81%",
                "centerY": "50.00%",
                "height": "100%",
                "id": "lblStatus1",
                "isVisible": true,
                "left": "85dp",
                "right": 0,
                "skin": "skna0a0a0fonticon45px",
                "text": "m",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStatus1.add(lblStatus1);
            flxViewOnlySeletcedBen.add(lblViewOnlySelectedBen, flxStatus1);
            flxSearchBar.add(flxBoxSearch, flxViewOnlySeletcedBen);
            var flxSeperatorBen = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorBen",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorBen.setDefaultUnit(kony.flex.DP);
            var lblSampleBenSeperator = new kony.ui.Label({
                "id": "lblSampleBenSeperator",
                "isVisible": true,
                "left": "1.58%",
                "text": "Name",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeperatorBen.add(lblSampleBenSeperator);
            var flxAddRecipientsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddRecipientsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRecipientsContainer.setDefaultUnit(kony.flex.DP);
            var TabBodyNewBen = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TabBodyNewBen",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAddRecipientsContainer.add(TabBodyNewBen);
            var flxAddRecipientDetailsErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxAddRecipientDetailsErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRecipientDetailsErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgTemplateRecordsError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgTemplateRecordsError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTemplateRecordsError = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "50%",
                "id": "lblTemplateRecordsError",
                "isVisible": true,
                "left": "25dp",
                "skin": "sknlblee0005SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTemplateRecordsErrorSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTemplateRecordsErrorSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateRecordsErrorSeperator.setDefaultUnit(kony.flex.DP);
            flxTemplateRecordsErrorSeperator.add();
            flxAddRecipientDetailsErrorMessage.add(imgTemplateRecordsError, lblTemplateRecordsError, flxTemplateRecordsErrorSeperator);
            flxExistingBeneficiaries.add(flxExistingBenHeader, flxSeperator4, flxSearchBar, flxSeperatorBen, flxAddRecipientsContainer, flxAddRecipientDetailsErrorMessage);
            var flxAddNewBeneficiaries = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddNewBeneficiaries",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 8,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddNewBeneficiaries.setDefaultUnit(kony.flex.DP);
            var flxAddMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAddMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "0dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddMain.setDefaultUnit(kony.flex.DP);
            var flxAddManuallyHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxAddManuallyHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddManuallyHeader.setDefaultUnit(kony.flex.DP);
            var lblAddHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "STEP 1 : RECIPIENT DETAILS"
                },
                "centerY": "50%",
                "id": "lblAddHeader",
                "isVisible": true,
                "left": "0%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.provideNewBeneficiaryDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxStep1Seperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxStep1Seperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "49dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStep1Seperator.setDefaultUnit(kony.flex.DP);
            flxStep1Seperator.add();
            flxAddManuallyHeader.add(lblAddHeader, flxStep1Seperator);
            var lblPaymentRefInvalidDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblPaymentRefInvalidDesc",
                "isVisible": false,
                "left": "0%",
                "skin": "ICSknLblErrorNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.bulkPayments.invalidDescription\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddType = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "70dp",
                "id": "flxAddType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddType.setDefaultUnit(kony.flex.DP);
            var lblAddType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.SelectRecipientType\")"
                },
                "id": "lblAddType",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.beneficiaryAccountIsWith\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddTypeRadioButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "35dp",
                "id": "flxAddTypeRadioButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35dp",
                "width": "45.16%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddTypeRadioButtons.setDefaultUnit(kony.flex.DP);
            var flxAddTypeRadio1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAddTypeRadio1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxAddTypeRadio1.setDefaultUnit(kony.flex.DP);
            var imgAdd1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgAdd1",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblFontTypeIcon3343e820pxMOD",
                "text": "M",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddTypeRadio1.add(imgAdd1);
            var lblRadioAdd1Opt1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Individual\")"
                },
                "centerY": "43%",
                "id": "lblRadioAdd1Opt1",
                "isVisible": true,
                "left": "5dp",
                "right": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.infinityBank\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddTypeRadio2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAddTypeRadio2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxAddTypeRadio2.setDefaultUnit(kony.flex.DP);
            var imgAdd2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgAdd2",
                "isVisible": true,
                "left": "3dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddTypeRadio2.add(imgAdd2);
            var lblRadioAddOpt2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblRadioAddOpt2",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.externalBank\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddTypeRadioButtons.add(flxAddTypeRadio1, lblRadioAdd1Opt1, flxAddTypeRadio2, lblRadioAddOpt2);
            flxAddType.add(lblAddType, flxAddTypeRadioButtons);
            var flxBankAccountType = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "70dp",
                "id": "flxBankAccountType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankAccountType.setDefaultUnit(kony.flex.DP);
            var lblType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.SelectRecipientType\")"
                },
                "id": "lblType",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountType\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRecipientTypeRadioButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "35dp",
                "id": "flxRecipientTypeRadioButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32dp",
                "width": "45.16%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientTypeRadioButtons.setDefaultUnit(kony.flex.DP);
            var flxTypeRadio1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTypeRadio1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxTypeRadio1.setDefaultUnit(kony.flex.DP);
            var imgTypeRadio1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgTypeRadio1",
                "isVisible": false,
                "skin": "slImage",
                "src": "radiobtn_active_small.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRadioBtnRecipientType1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgRadioBtnRecipientType1",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblFontTypeIcon3343e820pxMOD",
                "text": "M",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTypeRadio1.add(imgTypeRadio1, imgRadioBtnRecipientType1);
            var lblRadioOpt1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Individual\")"
                },
                "centerY": "43%",
                "id": "lblRadioOpt1",
                "isVisible": true,
                "left": "5dp",
                "right": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.TransfersEurope.Domestic\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTypeRadio2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTypeRadio2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxTypeRadio2.setDefaultUnit(kony.flex.DP);
            var imgTypeRadio2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgTypeRadio2",
                "isVisible": false,
                "skin": "slImage",
                "src": "icon_radiobtn.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRadioBtnRecipientType2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgRadioBtnRecipientType2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTypeRadio2.add(imgTypeRadio2, imgRadioBtnRecipientType2);
            var lblRadioOpt2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblRadioOpt2",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.TransfersEurope.International\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRecipientTypeRadioButtons.add(flxTypeRadio1, lblRadioOpt1, flxTypeRadio2, lblRadioOpt2);
            flxBankAccountType.add(lblType, flxRecipientTypeRadioButtons);
            var flxPayeeNameAndNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayeeNameAndNumber",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeNameAndNumber.setDefaultUnit(kony.flex.DP);
            var flxInvalidIbanError = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInvalidIbanError",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInvalidIbanError.setDefaultUnit(kony.flex.DP);
            var lblInvalidIBANInfinity = new kony.ui.Label({
                "id": "lblInvalidIBANInfinity",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknLabelSSPFF000015Px",
                "text": "label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInvalidIbanError.add(lblInvalidIBANInfinity);
            var flxRecipientName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRecipientName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientName.setDefaultUnit(kony.flex.DP);
            var lblRecipientName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblRecipientName",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.TransferEurope.beneficairyNameColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxRecipientName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblRecipientName",
                        "role": "textbox"
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxRecipientName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.UnifiedAddBeneficiary.EnterPayeeName\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "25dp",
                "width": "96.65%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxRecipientName.add(lblRecipientName, tbxRecipientName);
            var flxRecipientDetailsInfinity = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRecipientDetailsInfinity",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientDetailsInfinity.setDefaultUnit(kony.flex.DP);
            var flxRecipientAccountNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRecipientAccountNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientAccountNumber.setDefaultUnit(kony.flex.DP);
            var lblRecipientAccountNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblRecipientAccountNumber",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.accountNumWithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxRecipAccNumber = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblReciepentAccountNumber",
                        "role": "textbox"
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxRecipAccNumber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.UnifiedAddBeneficiary.AccountNumber\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "25dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxRecipientAccountNumber.add(lblRecipientAccountNumber, tbxRecipAccNumber);
            flxRecipientDetailsInfinity.add(flxRecipientAccountNumber);
            flxPayeeNameAndNumber.add(flxInvalidIbanError, flxRecipientName, flxRecipientDetailsInfinity);
            var flxSwiftCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSwiftCode",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftCode.setDefaultUnit(kony.flex.DP);
            var lblInvalidSwift = new kony.ui.Label({
                "id": "lblInvalidSwift",
                "isVisible": false,
                "left": "0%",
                "skin": "sknLabelSSPFF000015Px",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSwftCode = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "75dp",
                "id": "flxSwftCode",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwftCode.setDefaultUnit(kony.flex.DP);
            var lblSwiftCode = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblSwiftCode",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.swiftcode\")",
                "top": "6dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSwiftCode = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxSwiftCode",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.BICSWIFT\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "30dp",
                "width": "48.32%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxSwftCode.add(lblSwiftCode, tbxSwiftCode);
            flxSwiftCode.add(lblInvalidSwift, flxSwftCode);
            var flxRecipientBankName = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85dp",
                "id": "flxRecipientBankName",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientBankName.setDefaultUnit(kony.flex.DP);
            var lblRecipientBankName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblRecipientBankName",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.beneficiaryBankName\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxRecipientBankName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxRecipientBankName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.payments.enterBeneficiaryBankName\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "48.32%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxRecipientBankName.add(lblRecipientBankName, tbxRecipientBankName);
            var flxRecipientDetailsExternal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRecipientDetailsExternal",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientDetailsExternal.setDefaultUnit(kony.flex.DP);
            var flxAccountType = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "65dp",
                "id": "flxAccountType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountType.setDefaultUnit(kony.flex.DP);
            var lblAccountType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.SelectRecipientType\")"
                },
                "id": "lblAccountType",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.accountType\")",
                "top": "3dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountTypeRadioButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAccountTypeRadioButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountTypeRadioButtons.setDefaultUnit(kony.flex.DP);
            var flxAccTypeRadio1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAccTypeRadio1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxAccTypeRadio1.setDefaultUnit(kony.flex.DP);
            var imgRadioBtnACCType1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgRadioBtnACCType1",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblFontTypeIcon3343e820pxMOD",
                "text": "M",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccTypeRadio1.add(imgRadioBtnACCType1);
            var lblAccTypeRadio1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Individual\")"
                },
                "centerY": "43%",
                "id": "lblAccTypeRadio1",
                "isVisible": true,
                "left": "5dp",
                "right": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.TransfersEurope.Domestic\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccTypeRadio2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAccTypeRadio2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxAccTypeRadio2.setDefaultUnit(kony.flex.DP);
            var imgRadioBtnACCType2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgRadioBtnACCType2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccTypeRadio2.add(imgRadioBtnACCType2);
            var lblAccTypeRadio2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblAccTypeRadio2",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.TransfersEurope.International\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountTypeRadioButtons.add(flxAccTypeRadio1, lblAccTypeRadio1, flxAccTypeRadio2, lblAccTypeRadio2);
            flxAccountType.add(lblAccountType, flxAccountTypeRadioButtons);
            var flxRecipientAccNumExt = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "75dp",
                "id": "flxRecipientAccNumExt",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientAccNumExt.setDefaultUnit(kony.flex.DP);
            var lblRecipientAccountNumberExt = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblRecipientAccountNumberExt",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.beneficiaryAccNo\")",
                "top": "6dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxRecipAccNumberExt = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxRecipAccNumberExt",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.EnterBeneficiaryLocalAccountNumberorIBAN\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "30dp",
                "width": "48.32%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxRecipientAccNumExt.add(lblRecipientAccountNumberExt, tbxRecipAccNumberExt);
            var flxSwift = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "75dp",
                "id": "flxSwift",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwift.setDefaultUnit(kony.flex.DP);
            var lblSwift = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblSwift",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.SWIFTBIC\")",
                "top": "6dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSwift = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxSwift",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Enterhere\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "30dp",
                "width": "48.32%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxSwift.add(lblSwift, tbxSwift);
            flxRecipientDetailsExternal.add(flxAccountType, flxRecipientAccNumExt, flxSwift);
            var flxRecipientDetailsExisting = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRecipientDetailsExisting",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientDetailsExisting.setDefaultUnit(kony.flex.DP);
            var flxRecipientNameExisting = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxRecipientNameExisting",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "20dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientNameExisting.setDefaultUnit(kony.flex.DP);
            var lblNameKey = new kony.ui.Label({
                "id": "lblNameKey",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "text": "Beneficiary Name:",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblNameValue = new kony.ui.Label({
                "id": "lblNameValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "Micheal Mack",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxRecipientNameExisting.add(lblNameKey, lblNameValue);
            var flxAccountNumberExisting = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAccountNumberExisting",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountNumberExisting.setDefaultUnit(kony.flex.DP);
            var lblAccountKey = new kony.ui.Label({
                "id": "lblAccountKey",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.beneficiaryAccIBAN\")",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblAccountValue = new kony.ui.Label({
                "id": "lblAccountValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "2333544488899666",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxAccountNumberExisting.add(lblAccountKey, lblAccountValue);
            var flxBankNameExisting = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxBankNameExisting",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankNameExisting.setDefaultUnit(kony.flex.DP);
            var lblBankNameKey = new kony.ui.Label({
                "id": "lblBankNameKey",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.addBen.bankName\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblBankNameValue = new kony.ui.Label({
                "id": "lblBankNameValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "Banko Santander",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxBankNameExisting.add(lblBankNameKey, lblBankNameValue);
            var flxSwiftExisting = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxSwiftExisting",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftExisting.setDefaultUnit(kony.flex.DP);
            var lblSwiftKey = new kony.ui.Label({
                "id": "lblSwiftKey",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "text": "Swift/BIC:",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblSwiftValue = new kony.ui.Label({
                "id": "lblSwiftValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "44557788963",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxSwiftExisting.add(lblSwiftKey, lblSwiftValue);
            flxRecipientDetailsExisting.add(flxRecipientNameExisting, flxAccountNumberExisting, flxBankNameExisting, flxSwiftExisting);
            var flxPayeeField = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayeeField",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "15dp",
                "width": "100%",
                "zIndex": 12,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeField.setDefaultUnit(kony.flex.DP);
            var flxPayeeDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayeeDetails",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeDetails.setDefaultUnit(kony.flex.DP);
            var flxPayeeDetailWarning = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "58dp",
                "id": "flxPayeeDetailWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "18dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetailWarning.setDefaultUnit(kony.flex.DP);
            var imgPayeeDetailWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgPayeeDetailWarning",
                "isVisible": true,
                "left": "0dp",
                "src": "info_blue.png",
                "top": "0",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayeeDetailWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblPayeeDetailWarning",
                "isVisible": true,
                "left": "30dp",
                "right": "10dp",
                "skin": "sknSSPregular42424213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfers.addnewpayeedetailinfo\")",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeDetailWarning.add(imgPayeeDetailWarning, lblPayeeDetailWarning);
            var flxPayeeDetailRow1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPayeeDetailRow1",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "24dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeDetailRow1.setDefaultUnit(kony.flex.DP);
            var flxPayeeDetail1 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxPayeeDetail1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetail1.setDefaultUnit(kony.flex.DP);
            var lblPayeeDetail1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayeeDetail1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "SWIFT BIC:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLookUp = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblLookUp",
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Look up BIC/SWIFT code"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLookUp",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3.35%",
                "top": "1dp",
                "width": "60dp",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookUp.setDefaultUnit(kony.flex.DP);
            var lblLookUp = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblLookUp",
                "isVisible": true,
                "skin": "ICSknLabelSSPRegular4981B015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.LookUp\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLookUp.add(lblLookUp);
            var tbxPayeeDetail1 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPayeeDetail1",
                        "role": "textbox"
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPayeeDetail1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Enter SWIFT BIC",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "25dp",
                "width": "96.65%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxPayeeDetail1.add(lblPayeeDetail1, flxLookUp, tbxPayeeDetail1);
            var flxPayeeDetail2 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxPayeeDetail2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetail2.setDefaultUnit(kony.flex.DP);
            var lblPayeeDetail2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayeeDetail2",
                "isVisible": true,
                "left": "0%",
                "skin": "ICSknLblSSP72727215px",
                "text": "Bank Name:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxPayeeDetail2 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPayeeDetail2",
                        "role": "textbox"
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPayeeDetail2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "Enter bank name",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "25dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxPayeeDetail2.add(lblPayeeDetail2, tbxPayeeDetail2);
            flxPayeeDetailRow1.add(flxPayeeDetail1, flxPayeeDetail2);
            var flxPayeeDetailRow2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayeeDetailRow2",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "24dp",
                "width": "100%",
                "zIndex": 2,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeDetailRow2.setDefaultUnit(kony.flex.DP);
            var flxPayeeDetail3 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxPayeeDetail3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetail3.setDefaultUnit(kony.flex.DP);
            var lblPayeeDetail3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayeeDetail3",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.bankClearingCode\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLookUp2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblLookUp",
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Look up BIC/SWIFT code"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLookUp2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3.35%",
                "top": "1dp",
                "width": "60dp",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookUp2.setDefaultUnit(kony.flex.DP);
            var lblLookUp2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblLookUp2",
                "isVisible": true,
                "skin": "ICSknLabelSSPRegular4981B015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.LookUp\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLookUp2.add(lblLookUp2);
            var tbxPayeeDetail3 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPayeeDetail3",
                        "role": "textbox"
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPayeeDetail3",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.payments.enterBankClearingCode\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "25dp",
                "width": "96.65%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxPayeeDetail3.add(lblPayeeDetail3, flxLookUp2, tbxPayeeDetail3);
            var flxPayeeDetail4 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxPayeeDetail4",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetail4.setDefaultUnit(kony.flex.DP);
            var lblPayeeDetail4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayeeDetail4",
                "isVisible": true,
                "left": "3.35%",
                "skin": "ICSknLblSSP72727215px",
                "text": "Bank Name:",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxPayeeDetail4 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPayeeDetail4",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3.35%",
                "maxTextLength": 35,
                "placeholder": "Enter bank name",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "25dp",
                "width": "96.65%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxPayeeDetail4.add(lblPayeeDetail4, tbxPayeeDetail4);
            var flxPayeeDetail5 = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "80dp",
                "id": "flxPayeeDetail5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetail5.setDefaultUnit(kony.flex.DP);
            var lblPayeeDetail5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayeeDetail5",
                "isVisible": true,
                "left": "0%",
                "skin": "ICSknLblSSP72727215px",
                "text": "Clearing Identifier Code:",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPayeeDetail5Dropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPayeeDetail5",
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPayeeDetail5Dropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "25dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetail5Dropdown.setDefaultUnit(kony.flex.DP);
            var lblSelectedPayeeDetail5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSelectedPayeeDetail5",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.selectIdentifierCode\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayeeDetail5DropdownIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblPayeeDetail5DropdownIcon",
                "isVisible": true,
                "right": "15dp",
                "skin": "sknLblOlbFontIcons003E7514Px",
                "text": "O",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeDetail5Dropdown.add(lblSelectedPayeeDetail5, lblPayeeDetail5DropdownIcon);
            var flxPayeeDetail5List = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "option"
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "82dp",
                "horizontalScrollIndicator": true,
                "id": "flxPayeeDetail5List",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCbebebeShadow",
                "top": "66dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 105
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetail5List.setDefaultUnit(kony.flex.DP);
            var segPayeeDetail5List = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblListValue": ""
                }],
                "groupCells": false,
                "id": "segPayeeDetail5List",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "segTransparant",
                "rowSkin": "segTransparant",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ResourcesMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxListDropdown": "flxListDropdown",
                    "lblListValue": "lblListValue"
                },
                "width": "100%",
                "zIndex": 105,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeDetail5List.add(segPayeeDetail5List);
            flxPayeeDetail5.add(lblPayeeDetail5, flxPayeeDetail5Dropdown, flxPayeeDetail5List);
            flxPayeeDetailRow2.add(flxPayeeDetail3, flxPayeeDetail4, flxPayeeDetail5);
            var flxPayeeDetailRow3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayeeDetailRow3",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16dp",
                "width": "90%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeDetailRow3.setDefaultUnit(kony.flex.DP);
            var flxPayeeDetail6 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "80dp",
                "id": "flxPayeeDetail6",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetail6.setDefaultUnit(kony.flex.DP);
            var lblPayeeDetail6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "17dp",
                "id": "lblPayeeDetail6",
                "isVisible": true,
                "left": "0%",
                "skin": "ICSknLabelSSPRegular72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfers.StreetNamewithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxPayeeDetail6 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPayeeDetail6",
                        "role": "textbox"
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPayeeDetail6",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "maxTextLength": 140,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfers.enterStreetName\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "25dp",
                "width": "96.65%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "lblPlaceholder15"
            });
            flxPayeeDetail6.add(lblPayeeDetail6, tbxPayeeDetail6);
            var flxPayeeDetail7 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80dp",
                "id": "flxPayeeDetail7",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetail7.setDefaultUnit(kony.flex.DP);
            var lblPayeeDetail7 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "17dp",
                "id": "lblPayeeDetail7",
                "isVisible": true,
                "left": "0%",
                "skin": "ICSknLabelSSPRegular72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfers.TownNamewithColon\")",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxPayeeDetail7 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPayeeDetail7",
                        "role": "textbox"
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPayeeDetail7",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "maxTextLength": 35,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfers.enterTownName\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "25dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "lblPlaceholder15"
            });
            flxPayeeDetail7.add(lblPayeeDetail7, tbxPayeeDetail7);
            flxPayeeDetailRow3.add(flxPayeeDetail6, flxPayeeDetail7);
            var flxPayeeDetailRow4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayeeDetailRow4",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeDetailRow4.setDefaultUnit(kony.flex.DP);
            var flxPayeeDetail8 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80dp",
                "id": "flxPayeeDetail8",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "47%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeDetail8.setDefaultUnit(kony.flex.DP);
            var lblPayeeDetail8 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayeeDetail8",
                "isVisible": true,
                "left": "0%",
                "skin": "ICSknLabelSSPRegular72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.countryWithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxPayeeDetail8 = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPayeeDetail8",
                        "role": "button"
                    }
                },
                "focusSkin": "ICSknlbxSSPR42424215px",
                "height": "40dp",
                "id": "lbxPayeeDetail8",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["lb1", "Enter country"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "selectedKey": "lb1",
                "skin": "sknlbxalto33333315pxBordere3e3e32pxRadius",
                "top": "25dp",
                "width": "96.65%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "multiSelect": false
            });
            flxPayeeDetail8.add(lblPayeeDetail8, lbxPayeeDetail8);
            flxPayeeDetailRow4.add(flxPayeeDetail8);
            flxPayeeDetails.add(flxPayeeDetailWarning, flxPayeeDetailRow1, flxPayeeDetailRow2, flxPayeeDetailRow3, flxPayeeDetailRow4);
            flxPayeeField.add(flxPayeeDetails);
            var flxCurrencyAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCurrencyAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrencyAmount.setDefaultUnit(kony.flex.DP);
            var lblCurrencySymbol = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.City\")"
                },
                "id": "lblCurrencySymbol",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.currency\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxCurrency = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblCurrencySymbol",
                        "role": "button"
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxCurrency",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["key1", "$"],
                    ["Key2", "Rup"]
                ],
                "selectedKey": "key1",
                "skin": "sknLbxSSP42424215PxBorder727272",
                "top": "25dp",
                "width": "12%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLbxSSP42424215PxBorder4A90E2",
                "multiSelect": false
            });
            var tbxCurrency = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Zipcode"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxCurrency",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "$",
                "right": "30dp",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "12%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            var lblAmountName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Zipcode"
                },
                "id": "lblAmountName",
                "isVisible": true,
                "left": "14%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPayee.review.amount\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAmountValue = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblAmountName",
                        "role": "textbox"
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxAmountValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "14%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.enterAmountHere\")",
                "right": "30dp",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "25dp",
                "width": "34.32%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxCurrencyAmount.add(lblCurrencySymbol, lbxCurrency, tbxCurrency, lblAmountName, tbxAmountValue);
            var flxPaymentMethodField = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentMethodField",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "24dp",
                "width": "100%",
                "zIndex": 12,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentMethodField.setDefaultUnit(kony.flex.DP);
            var flxPaymentMethod = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "30dp",
                "id": "flxPaymentMethod",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 9,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethod.setDefaultUnit(kony.flex.DP);
            var lblPaymentMethod = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPaymentMethod",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.PaymentMethod\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaymentMethodInfoIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "17dp",
                "id": "flxPaymentMethodInfoIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "2dp",
                "width": "17dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethodInfoIcon.setDefaultUnit(kony.flex.DP);
            var imgPaymentMethodInfoIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "17dp",
                "id": "imgPaymentMethodInfoIcon",
                "isVisible": true,
                "left": "0",
                "right": "0dp",
                "skin": "sknLblFontIconInfo",
                "text": "T",
                "top": "0",
                "width": "17dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentMethodInfoIcon.add(imgPaymentMethodInfoIcon);
            var flxPaymentMethodInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPaymentMethodInfo",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "-135dp",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "20dp",
                "width": "400dp",
                "zIndex": 20,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethodInfo.setDefaultUnit(kony.flex.DP);
            var flxPaymentMethodInfoHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "59dp",
                "id": "flxPaymentMethodInfoHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethodInfoHeader.setDefaultUnit(kony.flex.DP);
            var lblPaymentMethodInfoHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblPaymentMethodInfoHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.paymentMethods\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaymentMethodInfoCloseIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxPaymentMethodInfoCloseIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "12dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethodInfoCloseIcon.setDefaultUnit(kony.flex.DP);
            var imgPaymentMethodInfoCloseIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgPaymentMethodInfoCloseIcon",
                "isVisible": true,
                "src": "bbcloseicon.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentMethodInfoCloseIcon.add(imgPaymentMethodInfoCloseIcon);
            flxPaymentMethodInfoHeader.add(lblPaymentMethodInfoHeader, flxPaymentMethodInfoCloseIcon);
            var flxPaymentMethodInfoData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxPaymentMethodInfoData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethodInfoData.setDefaultUnit(kony.flex.DP);
            var lblPaymentMethodInfo1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblPaymentMethodInfo1",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSPregular42424213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.paymentMethodInfo1\")",
                "top": "0dp",
                "width": "388dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentMethodInfoData.add(lblPaymentMethodInfo1);
            flxPaymentMethodInfo.add(flxPaymentMethodInfoHeader, flxPaymentMethodInfoData);
            flxPaymentMethod.add(lblPaymentMethod, flxPaymentMethodInfoIcon, flxPaymentMethodInfo);
            var flxPaymentMethodOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPaymentMethodOptions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethodOptions.setDefaultUnit(kony.flex.DP);
            var flxPaymentMethod1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxPaymentMethod1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "110dp",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 1,
                        "1380": 1
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethod1.setDefaultUnit(kony.flex.DP);
            var flxPaymentMethodOption1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentMethodOption1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethodOption1.setDefaultUnit(kony.flex.DP);
            var lblPaymentMethodOption1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblPaymentMethodOption1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblRadioBtnSelectedFontIcon003e7520px",
                "text": "M",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentMethodOption1.add(lblPaymentMethodOption1);
            var lblPaymentMethod1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPaymentMethod1",
                "isVisible": true,
                "left": "26dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.unified.paymentMethodHeader2\")",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentMethod1.add(flxPaymentMethodOption1, lblPaymentMethod1);
            var flxPaymentMethod2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxPaymentMethod2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "150dp",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 1,
                        "1380": 1
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethod2.setDefaultUnit(kony.flex.DP);
            var flxPaymentMethodOption2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentMethodOption2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentMethodOption2.setDefaultUnit(kony.flex.DP);
            var lblPaymentMethodOption2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "tagName": "span"
                },
                "id": "lblPaymentMethodOption2",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblRadioBtnUnelectedFontIcona0a0a020px",
                "text": "L",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentMethodOption2.add(lblPaymentMethodOption2);
            var lblPaymentMethod2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPaymentMethod2",
                "isVisible": true,
                "left": "26dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.unified.paymentMethodHeader11\")",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentMethod2.add(flxPaymentMethodOption2, lblPaymentMethod2);
            flxPaymentMethodOptions.add(flxPaymentMethod1, flxPaymentMethod2);
            flxPaymentMethodField.add(flxPaymentMethod, flxPaymentMethodOptions);
            var flxFeesPaidByInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "blur": {
                    "enabled": false,
                    "value": 0
                },
                "clipBounds": false,
                "height": "190dp",
                "id": "flxFeesPaidByInfo",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "11.41%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "-170dp",
                "width": "390dp",
                "zIndex": 20,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesPaidByInfo.setDefaultUnit(kony.flex.DP);
            var flxFeesInformation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxFeesInformation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesInformation.setDefaultUnit(kony.flex.DP);
            var lblInformation0 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Info\")"
                },
                "centerY": "50%",
                "id": "lblInformation0",
                "isVisible": true,
                "left": "4.44%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.WireTransfers.Information\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross0 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCross0",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5.55%",
                "skin": "skncursor",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "skncursor"
            });
            flxCross0.setDefaultUnit(kony.flex.DP);
            var imgCross0 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "12dp",
                "id": "imgCross0",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "right": "5.05%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCross0.add(imgCross0);
            flxFeesInformation.add(lblInformation0, flxCross0);
            var flxPaidByTypeInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaidByTypeInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaidByTypeInfo.setDefaultUnit(kony.flex.DP);
            var RichTextMe = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "height": "34dp",
                "id": "RichTextMe",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.Bulkpayments.FeesPaidByMe\")",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextBeneficiary = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "height": "34dp",
                "id": "RichTextBeneficiary",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.FeesPaidByBeneficiary\")",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextShared1 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "height": "38dp",
                "id": "RichTextShared1",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPaymnets. FeesPaidByShared1\")",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextShared2 = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "height": "38dp",
                "id": "RichTextShared2",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.FeesPaidByShared2\")",
                "top": "-6dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaidByTypeInfo.add(RichTextMe, RichTextBeneficiary, RichTextShared1, RichTextShared2);
            flxFeesPaidByInfo.add(flxFeesInformation, flxPaidByTypeInfo);
            var flxFeesPaidByOptions = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "75dp",
                "id": "flxFeesPaidByOptions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesPaidByOptions.setDefaultUnit(kony.flex.DP);
            var flxPaidbyLabelWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaidbyLabelWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaidbyLabelWrapper.setDefaultUnit(kony.flex.DP);
            var lblFeesPaidByHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.SelectRecipientType\")"
                },
                "id": "lblFeesPaidByHeader",
                "isVisible": true,
                "left": "0%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.feesPaidByQuestion\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInfoicon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "17dp",
                "id": "flxInfoicon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "17dp",
                "width": "17dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfoicon.setDefaultUnit(kony.flex.DP);
            var imgInfo0 = new kony.ui.Image2({
                "height": "100%",
                "id": "imgInfo0",
                "isVisible": false,
                "left": "0",
                "skin": "slImage",
                "src": "info_grey_2.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Specify the type of business that you are enrolling into online banking"
            });
            var lblInfo0 = new kony.ui.Label({
                "centerY": "50%",
                "height": "18dp",
                "id": "lblInfo0",
                "isVisible": true,
                "left": "0",
                "right": "0dp",
                "skin": "sknLblFontIconInfo",
                "text": "T",
                "top": "0",
                "width": "17dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfoicon.add(imgInfo0, lblInfo0);
            flxPaidbyLabelWrapper.add(lblFeesPaidByHeader, flxInfoicon);
            var flxFeesPaidRadioButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFeesPaidRadioButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesPaidRadioButtons.setDefaultUnit(kony.flex.DP);
            var flxFeesTypeRadio1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFeesTypeRadio1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxFeesTypeRadio1.setDefaultUnit(kony.flex.DP);
            var imgFees1Type1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgFees1Type1",
                "isVisible": false,
                "skin": "slImage",
                "src": "radiobtn_active_small.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgFees1Type2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgFees1Type2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblFontTypeIcon3343e820pxMOD",
                "text": "M",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesTypeRadio1.add(imgFees1Type1, imgFees1Type2);
            var lblFeesOpt1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Individual\")"
                },
                "centerY": "43%",
                "id": "lblFeesOpt1",
                "isVisible": true,
                "left": "5dp",
                "right": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.unified.feesPaidByHeader1\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFeesTypeRadio2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFeesTypeRadio2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxFeesTypeRadio2.setDefaultUnit(kony.flex.DP);
            var imgFees2Type1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgFees2Type1",
                "isVisible": false,
                "skin": "slImage",
                "src": "icon_radiobtn.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgFees2Type2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgFees2Type2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesTypeRadio2.add(imgFees2Type1, imgFees2Type2);
            var lblFeesOpt2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblFeesOpt2",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.unified.feesPaidByHeader2\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFeesTypeRadio3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFeesTypeRadio3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxFeesTypeRadio3.setDefaultUnit(kony.flex.DP);
            var imgFees3Type1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgFees3Type1",
                "isVisible": false,
                "skin": "slImage",
                "src": "icon_radiobtn.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgFees3Type2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgFees3Type2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesTypeRadio3.add(imgFees3Type1, imgFees3Type2);
            var lblFeesOpt3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblFeesOpt3",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.unified.feesPaidByHeader3\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesPaidRadioButtons.add(flxFeesTypeRadio1, lblFeesOpt1, flxFeesTypeRadio2, lblFeesOpt2, flxFeesTypeRadio3, lblFeesOpt3);
            var flxInformationText0 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "blur": {
                    "enabled": false,
                    "value": 0
                },
                "clipBounds": false,
                "height": "250dp",
                "id": "flxInformationText0",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "10.30%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "-245dp",
                "width": "390dp",
                "zIndex": 20,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformationText0.setDefaultUnit(kony.flex.DP);
            var flxInformation0 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxInformation0",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformation0.setDefaultUnit(kony.flex.DP);
            var lblInformationDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Info\")"
                },
                "centerY": "50%",
                "id": "lblInformationDetails",
                "isVisible": true,
                "left": "4.44%",
                "skin": "sknLblSSP42424215px",
                "text": "Information",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCross1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5.55%",
                "skin": "skncursor",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "skncursor"
            });
            flxCross1.setDefaultUnit(kony.flex.DP);
            var imgCross1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "12dp",
                "id": "imgCross1",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "right": "5.05%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCross1.add(imgCross1);
            flxInformation0.add(lblInformationDetails, flxCross1);
            var flxFeesTypeInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFeesTypeInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesTypeInfo.setDefaultUnit(kony.flex.DP);
            var RichTextMeInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "This will be used as default account for your transactions. You can also change this default account. "
                },
                "height": "40dp",
                "id": "RichTextMeInfo",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.BulkPayments.infoFeesPaidMe\")",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextBenInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "This will be used as default account for your transactions. You can also change this default account. "
                },
                "height": "40dp",
                "id": "RichTextBenInfo",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.BulkPayments.infoFeesPaidBeneficiary\")",
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextSharedInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "This will be used as default account for your transactions. You can also change this default account. "
                },
                "bottom": "0dp",
                "height": "20dp",
                "id": "RichTextSharedInfo",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.BulkPayments.infoFeesPaidShared\")",
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextSharedPayerInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "This will be used as default account for your transactions. You can also change this default account. "
                },
                "bottom": "0dp",
                "height": "20dp",
                "id": "RichTextSharedPayerInfo",
                "isVisible": true,
                "left": "20%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.BulkPayments.infoFeesPaidSharedPayer\")",
                "top": "-2dp",
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextSharedPayeeInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "This will be used as default account for your transactions. You can also change this default account. "
                },
                "height": "40dp",
                "id": "RichTextSharedPayeeInfo",
                "isVisible": true,
                "left": "17.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.BulkPayments.infoFeesPaidSharedPayee\")",
                "top": "10dp",
                "width": "78%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesTypeInfo.add(RichTextMeInfo, RichTextBenInfo, RichTextSharedInfo, RichTextSharedPayerInfo, RichTextSharedPayeeInfo);
            flxInformationText0.add(flxInformation0, flxFeesTypeInfo);
            flxFeesPaidByOptions.add(flxPaidbyLabelWrapper, flxFeesPaidRadioButtons, flxInformationText0);
            var flxInvalidIntermediaryBic = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInvalidIntermediaryBic",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInvalidIntermediaryBic.setDefaultUnit(kony.flex.DP);
            var lblInvalidIntermediaryBic = new kony.ui.Label({
                "id": "lblInvalidIntermediaryBic",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblErrorNew",
                "text": "Invalid BIC",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInvalidIntermediaryBic.add(lblInvalidIntermediaryBic);
            var flxIntermediaryBicAndPurposeCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxIntermediaryBicAndPurposeCode",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "24dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxIntermediaryBicAndPurposeCode.setDefaultUnit(kony.flex.DP);
            var flxIntermediaryBic = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "65dp",
                "id": "flxIntermediaryBic",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxIntermediaryBic.setDefaultUnit(kony.flex.DP);
            var lblIntermediaryBic = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblIntermediaryBic",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.intermediatoryBIC\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxIntermediaryBic = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblIntermediaryBic",
                        "role": "textbox"
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxIntermediaryBic",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Enter intermediary BIC",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "25dp",
                "width": "96.65%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxIntermediaryBic.add(lblIntermediaryBic, tbxIntermediaryBic);
            var flxPurposeCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "65dp",
                "id": "flxPurposeCode",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPurposeCode.setDefaultUnit(kony.flex.DP);
            var lblPurposeCode = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPurposeCode",
                "isVisible": true,
                "left": "0%",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfers.PurposeCodeOptional\")",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPurposeCodeDropdown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPurposeCode",
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPurposeCodeDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                "top": "25dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPurposeCodeDropdown.setDefaultUnit(kony.flex.DP);
            var lblSelectedPurposeCode = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSelectedPurposeCode",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfers.SelectPurposeCode\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPurposeCodeDropdownIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblPurposeCodeDropdownIcon",
                "isVisible": true,
                "right": "15dp",
                "skin": "sknLblOlbFontIcons003E7514Px",
                "text": "O",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPurposeCodeDropdown.add(lblSelectedPurposeCode, lblPurposeCodeDropdownIcon);
            var flxPurposeCodeList = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "option"
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "82dp",
                "horizontalScrollIndicator": true,
                "id": "flxPurposeCodeList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlxSCbebebeShadow",
                "top": "66dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 20
            }, {
                "paddingInPixel": false
            }, {});
            flxPurposeCodeList.setDefaultUnit(kony.flex.DP);
            var segPurposeCodeList = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblListValue": ""
                }],
                "groupCells": false,
                "id": "segPurposeCodeList",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "segTransparant",
                "rowSkin": "segTransparant",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ResourcesMA",
                    "friendlyName": "flxListDropdown"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxListDropdown": "flxListDropdown",
                    "lblListValue": "lblListValue"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPurposeCodeList.add(segPurposeCodeList);
            flxPurposeCode.add(lblPurposeCode, flxPurposeCodeDropdown, flxPurposeCodeList);
            flxIntermediaryBicAndPurposeCode.add(flxIntermediaryBic, flxPurposeCode);
            var flxPaymentRef = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPaymentRef",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentRef.setDefaultUnit(kony.flex.DP);
            var lblPaymentRefName = new kony.ui.Label({
                "id": "lblPaymentRefName",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.transfersEurope.referenceColon\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxPaymentRefValue = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-describedby": "lblPaymentRefValidDesc",
                        "aria-labelledby": "lblPaymentRefName",
                        "role": "textbox"
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPaymentRefValue",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "maxTextLength": 35,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"kony.mb.common.EnterHere\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "48.32%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [10, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            var lblPaymentRefValidDesc = new kony.ui.Label({
                "id": "lblPaymentRefValidDesc",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.bulkPayments.validDescription\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentRef.add(lblPaymentRefName, tbxPaymentRefValue, lblPaymentRefValidDesc);
            var flxAddToList = new kony.ui.FlexContainer({
                "bottom": "5dp",
                "clipBounds": true,
                "height": "80dp",
                "id": "flxAddToList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddToList.setDefaultUnit(kony.flex.DP);
            var lblSelect = new kony.ui.Label({
                "centerY": "50%",
                "height": "32dp",
                "id": "lblSelect",
                "isVisible": true,
                "left": "0%",
                "skin": "skn0273e320pxolbfonticons",
                "text": "D",
                "width": "32dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddToList = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "centerY": "50%",
                "id": "lblAddToList",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.addBeneficiaryToList\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddToList.add(lblSelect, lblAddToList);
            var flxEndSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "5dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEndSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndSeperator.setDefaultUnit(kony.flex.DP);
            flxEndSeperator.add();
            var addNewBeneficiaryFormActions = new com.InfinityOLB.Resources.formActionsNew({
                "height": "111dp",
                "id": "addNewBeneficiaryFormActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnBack": {
                        "bottom": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "top": "0px",
                        "width": "170dp",
                        "zIndex": 1
                    },
                    "btnCancel": {
                        "bottom": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "top": "0px",
                        "width": "170dp",
                        "zIndex": 1
                    },
                    "btnNext": {
                        "bottom": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.next\")",
                        "left": "viz.val_cleared",
                        "right": "0dp",
                        "top": "0px",
                        "width": "170dp",
                        "zIndex": 1
                    },
                    "btnOption": {
                        "bottom": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "top": "0px",
                        "width": "170dp",
                        "zIndex": 1
                    },
                    "flxButtons": {
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "width": "100%"
                    },
                    "formActionsNew": {
                        "centerX": "viz.val_cleared",
                        "isVisible": true,
                        "left": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAddMain.add(flxAddManuallyHeader, lblPaymentRefInvalidDesc, flxAddType, flxBankAccountType, flxPayeeNameAndNumber, flxSwiftCode, flxRecipientBankName, flxRecipientDetailsExternal, flxRecipientDetailsExisting, flxPayeeField, flxCurrencyAmount, flxPaymentMethodField, flxFeesPaidByInfo, flxFeesPaidByOptions, flxInvalidIntermediaryBic, flxIntermediaryBicAndPurposeCode, flxPaymentRef, flxAddToList, flxEndSeperator, addNewBeneficiaryFormActions);
            flxAddNewBeneficiaries.add(flxAddMain);
            var flxViewTemplate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxViewTemplate",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplate.setDefaultUnit(kony.flex.DP);
            var flxViewTemplateContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxViewTemplateContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateContainer.setDefaultUnit(kony.flex.DP);
            var flxContentViewTemplate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContentViewTemplate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentViewTemplate.setDefaultUnit(kony.flex.DP);
            var flxViewTemplateHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxViewTemplateHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateHeader.setDefaultUnit(kony.flex.DP);
            var lblViewTemplateHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkWire.primaryDetails\")",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select & Edit Recipients"
            });
            var flxPrimaryDetailsEdit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrimaryDetailsEdit",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "67.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsEdit.setDefaultUnit(kony.flex.DP);
            var lblPrimaryDetailsEdit = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblPrimaryDetailsEdit",
                "isVisible": true,
                "left": "0dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": "15dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All Removed Recipients"
            });
            flxPrimaryDetailsEdit.add(lblPrimaryDetailsEdit);
            flxViewTemplateHeader.add(lblViewTemplateHeader, flxPrimaryDetailsEdit);
            var flxPrimaryDetailsTopSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPrimaryDetailsTopSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0j48d32149b3848",
                "top": "15dp",
                "width": "95%",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsTopSeperator.setDefaultUnit(kony.flex.DP);
            flxPrimaryDetailsTopSeperator.add();
            var flxViewTemplateError = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxViewTemplateError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateError.setDefaultUnit(kony.flex.DP);
            var lblVTErrorMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblVTErrorMsg",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLabelSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.EditAmoumterror\")",
                "top": "12dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "The entry was invalid. Please try again."
            });
            flxViewTemplateError.add(lblVTErrorMsg);
            var flxPrimaryDetailsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrimaryDetailsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsContainer.setDefaultUnit(kony.flex.DP);
            var flxPrimaryDetailsRow1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrimaryDetailsRow1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsRow1.setDefaultUnit(kony.flex.DP);
            var lblViewTemplateName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateName",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkWire.templateName\")",
                "top": "31dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            var lblViewTemplateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateValue",
                "isVisible": true,
                "left": "10.69%",
                "skin": "sknSSP42424215Px",
                "text": "Template 3",
                "top": "31dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            flxPrimaryDetailsRow1.add(lblViewTemplateName, lblViewTemplateValue);
            var flxPrimaryDetailsRow2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrimaryDetailsRow2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsRow2.setDefaultUnit(kony.flex.DP);
            var lblViewTemplateFromAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateFromAccount",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.stopChecks.FromAccount:\")",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            var flxViewTemplateFromAccountValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxViewTemplateFromAccountValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "11.64%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "27dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateFromAccountValue.setDefaultUnit(kony.flex.DP);
            var lblViewTemplateFromAccountIcon = new kony.ui.Label({
                "height": "22dp",
                "id": "lblViewTemplateFromAccountIcon",
                "isVisible": true,
                "left": "0",
                "right": "0.73%",
                "skin": "sknLblOLBFontIcons003E7512pxbordere3e3e3",
                "text": "r",
                "top": "0",
                "width": "22dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblViewTemplateFromAccountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateFromAccountValue",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP42424215Px",
                "text": "Savings Account Nickname - X4568",
                "top": "0",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            flxViewTemplateFromAccountValue.add(lblViewTemplateFromAccountIcon, lblViewTemplateFromAccountValue);
            flxPrimaryDetailsRow2.add(lblViewTemplateFromAccount, flxViewTemplateFromAccountValue);
            var flxPrimaryDetailsRow3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrimaryDetailsRow3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsRow3.setDefaultUnit(kony.flex.DP);
            var flxViewTemplateExecutionDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "flxViewTemplateExecutionDate",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.executionDateWithColon\")",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            var lblViewTemplateExecutionDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateExecutionDateValue",
                "isVisible": true,
                "left": "11.13%",
                "skin": "sknSSP42424215Px",
                "text": "10/15/2020",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            flxPrimaryDetailsRow3.add(flxViewTemplateExecutionDate, lblViewTemplateExecutionDateValue);
            var flxPrimaryDetailsRow4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrimaryDetailsRow4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsRow4.setDefaultUnit(kony.flex.DP);
            var lblViewTemplateProcessingMode = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateProcessingMode",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.processingMode\")",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            var lblViewTemplateProcessingModeValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateProcessingModeValue",
                "isVisible": true,
                "left": "10%",
                "skin": "sknSSP42424215Px",
                "text": "Template 3",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            flxPrimaryDetailsRow4.add(lblViewTemplateProcessingMode, lblViewTemplateProcessingModeValue);
            var flxPrimaryDetailsRow5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrimaryDetailsRow5",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsRow5.setDefaultUnit(kony.flex.DP);
            var lblViewTemplateTotalAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateTotalAmount",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP42424215Px",
                "text": "Total Amount with Currency code :",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            var lblViewTemplateTotalAmountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateTotalAmountValue",
                "isVisible": true,
                "left": "1.30%",
                "skin": "sknSSP42424215Px",
                "text": "$ 5,23,547",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            flxPrimaryDetailsRow5.add(lblViewTemplateTotalAmount, lblViewTemplateTotalAmountValue);
            var flxPrimaryDetailsRow6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrimaryDetailsRow6",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsRow6.setDefaultUnit(kony.flex.DP);
            var lblViewTemplateTransactionsCount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateTransactionsCount",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP42424215Px",
                "text": "Number of Transactions :",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            var lblViewTemplateTransactionsCountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplateTransactionsCountValue",
                "isVisible": true,
                "left": "6.30%",
                "skin": "sknSSP42424215Px",
                "text": "24",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            flxPrimaryDetailsRow6.add(lblViewTemplateTransactionsCount, lblViewTemplateTransactionsCountValue);
            var flxPrimaryDetailsRow7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "33dp",
                "clipBounds": true,
                "id": "flxPrimaryDetailsRow7",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsRow7.setDefaultUnit(kony.flex.DP);
            var lblViewTemplatePaymentDescription = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplatePaymentDescription",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP42424215Px",
                "text": "Payment Description :",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            var lblViewTemplatePaymentDescriptionValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblViewTemplatePaymentDescriptionValue",
                "isVisible": true,
                "left": "7.80%",
                "skin": "sknSSP42424215Px",
                "text": "November Salary - 2020",
                "top": "27dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            flxPrimaryDetailsRow7.add(lblViewTemplatePaymentDescription, lblViewTemplatePaymentDescriptionValue);
            var flxPrimaryDetailsBottomSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPrimaryDetailsBottomSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0j48d32149b3848",
                "top": "15dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsBottomSeperator.setDefaultUnit(kony.flex.DP);
            flxPrimaryDetailsBottomSeperator.add();
            flxPrimaryDetailsContainer.add(flxPrimaryDetailsRow1, flxPrimaryDetailsRow2, flxPrimaryDetailsRow3, flxPrimaryDetailsRow4, flxPrimaryDetailsRow5, flxPrimaryDetailsRow6, flxPrimaryDetailsRow7, flxPrimaryDetailsBottomSeperator);
            var flxAddedBeneficiaries = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxAddedBeneficiaries",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddedBeneficiaries.setDefaultUnit(kony.flex.DP);
            var lblAddedBeneficiaries = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblAddedBeneficiaries",
                "isVisible": true,
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.addedBeneficiaries\")",
                "top": "12dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Added recipients for bulk wire transfer "
            });
            var lblAddedBeneficiariesCount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblAddedBeneficiariesCount",
                "isVisible": true,
                "left": "20dp",
                "skin": "bblblskn424242Bold",
                "text": "(24)",
                "top": "12dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {});
            var lblEditAddedBeneficiaries = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Tabs.Transfers\")"
                },
                "id": "lblEditAddedBeneficiaries",
                "isVisible": true,
                "left": "54%",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.EditConsent\")",
                "top": "13dp",
                "width": "30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View All Removed Recipients"
            });
            flxAddedBeneficiaries.add(lblAddedBeneficiaries, lblAddedBeneficiariesCount, lblEditAddedBeneficiaries);
            var flxAddedBeneficiariesSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "80dp",
                "id": "flxAddedBeneficiariesSearch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddedBeneficiariesSearch.setDefaultUnit(kony.flex.DP);
            var flxViewTemplateAddedBeneficiaries = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80%",
                "id": "flxViewTemplateAddedBeneficiaries",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "98%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateAddedBeneficiaries.setDefaultUnit(kony.flex.DP);
            var flxViewTemplateSearchBeneficiariesBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxViewTemplateSearchBeneficiariesBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "10dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateSearchBeneficiariesBox.setDefaultUnit(kony.flex.DP);
            var imgViewTemplateSearchIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgViewTemplateSearchIcon",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "top": "0",
                "width": "17dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxViewTemplateSearchIcon = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "bbSknTbx949494SSP15pxItalic",
                "height": "100%",
                "id": "tbxViewTemplateSearchIcon",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "45dp",
                "placeholder": "Search for keywords",
                "secureTextEntry": false,
                "skin": "bbSknTbx949494SSP15pxItalic",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "95%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var imgViewTemplateClearIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgViewTemplateClearIcon",
                "isVisible": false,
                "right": "1%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "top": "0",
                "width": "22dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewTemplateSearchBeneficiariesBox.add(imgViewTemplateSearchIcon, tbxViewTemplateSearchIcon, imgViewTemplateClearIcon);
            flxViewTemplateAddedBeneficiaries.add(flxViewTemplateSearchBeneficiariesBox);
            flxAddedBeneficiariesSearch.add(flxViewTemplateAddedBeneficiaries);
            var flxViewTemplateSortSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxViewTemplateSortSeparator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateSortSeparator.setDefaultUnit(kony.flex.DP);
            flxViewTemplateSortSeparator.add();
            var flxViewTemplateRowTemplate = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxViewTemplateRowTemplate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf5f5f5Border10px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateRowTemplate.setDefaultUnit(kony.flex.DP);
            var flxViewTemplateBenificiaryName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxViewTemplateBenificiaryName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "4.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateBenificiaryName.setDefaultUnit(kony.flex.DP);
            var lblViewTemplateSortBeneficiaryName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.FromAccount\")"
                },
                "centerY": "50%",
                "id": "lblViewTemplateSortBeneficiaryName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.BenName.Title\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgViewTemplateSortBeneficiaryName = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgViewTemplateSortBeneficiaryName",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "4dp",
                "skin": "sknImgPointer",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewTemplateBenificiaryName.add(lblViewTemplateSortBeneficiaryName, imgViewTemplateSortBeneficiaryName);
            var flxViewTemplateAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxViewTemplateAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "4%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateAmount.setDefaultUnit(kony.flex.DP);
            var lblViewTemplateSortAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Status\")"
                },
                "centerY": "50%",
                "id": "lblViewTemplateSortAmount",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgViewTemplateSortAmount = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgViewTemplateSortAmount",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": false,
                "left": "5dp",
                "skin": "sknImgPointer",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewTemplateAmount.add(lblViewTemplateSortAmount, imgViewTemplateSortAmount);
            var flxViewTemplateFeesPaidBy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxViewTemplateFeesPaidBy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "25%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3,
                        "1380": 3
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateFeesPaidBy.setDefaultUnit(kony.flex.DP);
            var lblViewTemplateFeedPaidBy = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Date\")"
                },
                "centerY": "50%",
                "id": "lblViewTemplateFeedPaidBy",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.Europe.FeesPaidBy\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgViewTemplateFeedPaidBy = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgViewTemplateFeedPaidBy",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewTemplateFeesPaidBy.add(lblViewTemplateFeedPaidBy, imgViewTemplateFeedPaidBy);
            flxViewTemplateRowTemplate.add(flxViewTemplateBenificiaryName, flxViewTemplateAmount, flxViewTemplateFeesPaidBy);
            var flxViewTemplateSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxViewTemplateSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateSegment.setDefaultUnit(kony.flex.DP);
            var segmentViewTemplateData = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "2dp",
                "data": [
                    [{
                            "lblHeader": "Label",
                            "lblSelectAll": "",
                            "lblSeparator": "",
                            "lblStatusHeader": "D"
                        },
                        [{
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }]
                    ],
                    [{
                            "lblHeader": "Label",
                            "lblSelectAll": "",
                            "lblSeparator": "",
                            "lblStatusHeader": "D"
                        },
                        [{
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }, {
                            "lblAmount": "$ 45,009",
                            "lblBeneficiaryName": "Eliza Walsh",
                            "lblDropdown": "O",
                            "lblFeesPaidBy": "Banking",
                            "lblIcon": "r",
                            "lblSeparator": ""
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segmentViewTemplateData",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BulkPaymentsMA",
                    "friendlyName": "flxBulkPaymentViewTemplateRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BulkPaymentsMA",
                    "friendlyName": "flxBulkPaymentViewTemplateHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAmount": "flxAmount",
                    "flxBeneficiaryName": "flxBeneficiaryName",
                    "flxBulkPaymentViewTemplateHeader": "flxBulkPaymentViewTemplateHeader",
                    "flxBulkPaymentViewTemplateRow": "flxBulkPaymentViewTemplateRow",
                    "flxDropdown": "flxDropdown",
                    "flxFeesPaidBy": "flxFeesPaidBy",
                    "flxSegBulkPaymentViewTemplateWrapper": "flxSegBulkPaymentViewTemplateWrapper",
                    "flxSelectAll": "flxSelectAll",
                    "flxStatusHeader": "flxStatusHeader",
                    "flxWrapper": "flxWrapper",
                    "lblAmount": "lblAmount",
                    "lblBeneficiaryName": "lblBeneficiaryName",
                    "lblDropdown": "lblDropdown",
                    "lblFeesPaidBy": "lblFeesPaidBy",
                    "lblHeader": "lblHeader",
                    "lblIcon": "lblIcon",
                    "lblSelectAll": "lblSelectAll",
                    "lblSeparator": "lblSeparator",
                    "lblStatusHeader": "lblStatusHeader"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewTemplateSegment.add(segmentViewTemplateData);
            var flxViewTemplateRowSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxViewTemplateRowSeperator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0j48d32149b3848",
                "top": "0dp",
                "width": "100%",
                "zIndex": 7,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateRowSeperator.setDefaultUnit(kony.flex.DP);
            flxViewTemplateRowSeperator.add();
            var flxViewTemplateNoRecipients = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "441dp",
                "id": "flxViewTemplateNoRecipients",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "0dp",
                "width": "100%",
                "zIndex": 7,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplateNoRecipients.setDefaultUnit(kony.flex.DP);
            var imgVTInfoNoRecipients = new kony.ui.Image2({
                "height": "50dp",
                "id": "imgVTInfoNoRecipients",
                "isVisible": true,
                "left": "4%",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "32dp",
                "width": "6.30%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxVTNoRecipientsMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "No transactions found."
                },
                "id": "rtxVTNoRecipientsMessage",
                "isVisible": true,
                "left": "12.60%",
                "skin": "sknRtxSSPLight42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.norecipientfound\")",
                "top": "41dp",
                "width": "87.94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxViewTemplateNoRecipients.add(imgVTInfoNoRecipients, rtxVTNoRecipientsMessage);
            var flxViewTemplatesNoTransactions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "441dp",
                "id": "flxViewTemplatesNoTransactions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "0dp",
                "width": "100%",
                "zIndex": 7,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewTemplatesNoTransactions.setDefaultUnit(kony.flex.DP);
            var imgVTInfo = new kony.ui.Image2({
                "height": "50dp",
                "id": "imgVTInfo",
                "isVisible": true,
                "left": "4%",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "32dp",
                "width": "6.30%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxVTNoPaymentMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "No transactions found."
                },
                "id": "rtxVTNoPaymentMessage",
                "isVisible": true,
                "left": "12.60%",
                "skin": "sknRtxSSPLight42424224Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.noTransactions\")",
                "top": "41dp",
                "width": "87.94%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblVTScheduleAPayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPayMakeTransfer\")"
                },
                "id": "lblVTScheduleAPayment",
                "isVisible": true,
                "left": "12.60%",
                "skin": "sknSSP3343ABpx24",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPayMakeTransfer\")",
                "top": "107dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "MAKE TRANSFER"
            });
            flxViewTemplatesNoTransactions.add(imgVTInfo, rtxVTNoPaymentMessage, lblVTScheduleAPayment);
            flxContentViewTemplate.add(flxViewTemplateHeader, flxPrimaryDetailsTopSeperator, flxViewTemplateError, flxPrimaryDetailsContainer, flxAddedBeneficiaries, flxAddedBeneficiariesSearch, flxViewTemplateSortSeparator, flxViewTemplateRowTemplate, flxViewTemplateSegment, flxViewTemplateRowSeperator, flxViewTemplateNoRecipients, flxViewTemplatesNoTransactions);
            flxViewTemplateContainer.add(flxContentViewTemplate);
            flxViewTemplate.add(flxViewTemplateContainer);
            flxMainContainer.add(flxErrorMessage, flxTemplate, flxCreateBulkRequest, flxBeneficiaryUI, flxExistingBeneficiaries, flxAddNewBeneficiaries, flxViewTemplate);
            var PaginationContainer = new com.InfinityOLB.Resources.Pagination.PaginationContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "PaginationContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "PaginationContainer": {
                        "isVisible": false
                    },
                    "flxPaginationLast": {
                        "isVisible": false
                    },
                    "flxPaginationNext": {
                        "right": "-0.50%"
                    },
                    "imgPaginationLast": {
                        "src": "pagination_last_active.png"
                    },
                    "imgPaginationNext": {
                        "src": "pagination_next_active.png"
                    },
                    "imgPaginationPrevious": {
                        "src": "pagination_back_inactive.png"
                    },
                    "lblPagination": {
                        "left": "1.50%",
                        "right": "1.50%",
                        "text": "1-03 of 03 Records"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "111dp",
                "id": "formActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnBack": {
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "width": "170dp"
                    },
                    "btnCancel": {
                        "height": "40dp",
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "width": "170dp"
                    },
                    "btnNext": {
                        "height": "40dp",
                        "left": "viz.val_cleared",
                        "right": "0dp",
                        "width": "170dp"
                    },
                    "btnOption": {
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "width": "170dp"
                    },
                    "flxButtons": {
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "width": "100%"
                    },
                    "formActionsNew": {
                        "centerX": "50%",
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var CommonFormActionsExt = new com.InfinityOLB.Resources.formActionsNew({
                "height": "100dp",
                "id": "CommonFormActionsExt",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnBack": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "height": "40dp",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "top": "viz.val_cleared",
                        "width": "170px",
                        "zIndex": 3
                    },
                    "btnCancel": {
                        "bottom": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "width": "170px",
                        "zIndex": 1
                    },
                    "btnNext": {
                        "bottom": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "0dp",
                        "text": "Next",
                        "width": "170px"
                    },
                    "btnOption": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "30dp",
                        "top": "viz.val_cleared",
                        "width": "170px",
                        "zIndex": 2
                    },
                    "flxButtons": {
                        "left": "viz.val_cleared",
                        "reverseLayoutDirection": false,
                        "right": "0dp",
                        "width": "100%",
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "flxMain": {
                        "centerX": "viz.val_cleared",
                        "centerY": "40%",
                        "height": "100%",
                        "isVisible": true,
                        "left": "0dp",
                        "reverseLayoutDirection": true,
                        "right": "0px",
                        "top": "0dp",
                        "width": "100%",
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "formActionsNew": {
                        "centerX": "viz.val_cleared",
                        "height": "100dp",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "10dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxButtons = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "103px",
                "id": "flxButtons",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.i18n.common.addAccount\")"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF0f1c2bNoBorder",
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.createBulkRequest\")",
                "width": "12.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px",
                "toolTip": "Confirm"
            });
            var btnDelete = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.modifiy\")"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "40dp",
                "id": "btnDelete",
                "isVisible": true,
                "right": "20dp",
                "skin": "CopysknBtnffffffBorder0ha9a44b3e3574a",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkWire.deleteTemplate\")",
                "width": "12.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Modify"
            });
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Cancel\")"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSecondaryFocusSSP3343a815Px",
                "height": "40dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.viewTemplates\")",
                "width": "12.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            var flxLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "0dp",
                "width": "95.50%",
                "zIndex": 3,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine.setDefaultUnit(kony.flex.DP);
            flxLine.add();
            flxButtons.add(btnContinue, btnDelete, btnBack, flxLine);
            flxTabPaneContainer.add(flxAcknowledgementContainer, flxMainContainer, PaginationContainer, formActionsNew, CommonFormActionsExt, flxButtons);
            flxDashboard.add(flxTabPaneContainer);
            flxContentDashBoard.add(flxDashboard);
            var flxTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTerms",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "87.85%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTerms.setDefaultUnit(kony.flex.DP);
            var lblTitleTerms = new kony.ui.Label({
                "id": "lblTitleTerms",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var browserTnC = new kony.ui.Browser({
                "bottom": "10dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "browserTnC",
                "isVisible": true,
                "left": "20dp",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxTerms.add(lblTitleTerms, browserTnC);
            flxContentContainer.add(flxContentHeader, flxTemplateDetails, flxDisplayErrorMessage, flxAckMessage, flxContentDashBoard, flxTerms);
            flxMain.add(flxMainWrapper, flxskncontainer, flxContentContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxPopupConfirmation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPopupConfirmation",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupConfirmation.setDefaultUnit(kony.flex.DP);
            var flxPopupNew = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "flxPopupNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxComments": {
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "bbcloseicon.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopupConfirmation.add(flxPopupNew);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var flxCancelPopupParent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "260dp",
                "id": "flxCancelPopupParent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopupParent.setDefaultUnit(kony.flex.DP);
            var PopupHeaderUM = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "PopupHeaderUM",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCancelPopupParent.add(PopupHeaderUM);
            flxCancelPopup.add(flxCancelPopupParent);
            var flxLookups = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "1200dp",
                "horizontalScrollIndicator": true,
                "id": "flxLookups",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 3
            }, {
                "paddingInPixel": false
            }, {});
            flxLookups.setDefaultUnit(kony.flex.DP);
            var flxLookupPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxLookupPopup",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "maxHeight": "80%",
                "isModalContainer": true,
                "skin": "ICSknBgffffffBorder3px",
                "top": "100dp",
                "width": "640dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLookupPopup.setDefaultUnit(kony.flex.DP);
            var flxLookupTitle = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxLookupTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookupTitle.setDefaultUnit(kony.flex.DP);
            var lblLookupTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "lblLookupTitle",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular42424215Px",
                "text": "SWIFT BIC Search",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLookupClose = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxLookupClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "12dp",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookupClose.setDefaultUnit(kony.flex.DP);
            var imgLookupCloseIcon = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLookupCloseIcon",
                "isVisible": false,
                "left": "0dp",
                "src": "bbcloseicon_1.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnLookupCloseIcon = new kony.ui.Button({
                "height": "100%",
                "id": "btnLookupCloseIcon",
                "isVisible": true,
                "left": "0",
                "skin": "btnClose",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLookupClose.add(imgLookupCloseIcon, btnLookupCloseIcon);
            flxLookupTitle.add(lblLookupTitle, flxLookupClose);
            var flxPopupTitleSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxPopupTitleSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupTitleSeparator.setDefaultUnit(kony.flex.DP);
            flxPopupTitleSeparator.add();
            var flxLookupDesc = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "43dp",
                "id": "flxLookupDesc",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16dp",
                "width": "96%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookupDesc.setDefaultUnit(kony.flex.DP);
            var lblLookupDescription = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "20dp",
                "id": "lblLookupDescription",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular42424215Px",
                "text": "To find your SWIFT code, please enter bank details then hit search.",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLookupDesc.add(lblLookupDescription);
            var flxLookupErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLookupErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookupErrorMessage.setDefaultUnit(kony.flex.DP);
            var rtxLookupErrorMessage = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "rtxLookupErrorMessage",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknRtxSSPFF000015Px",
                "text": "Error Message\n",
                "top": "8dp",
                "width": "93.30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLookupErrorMessage.add(rtxLookupErrorMessage);
            var flxSearchField1 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxSearchField1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "47%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchField1.setDefaultUnit(kony.flex.DP);
            var lblSearchField1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "17dp",
                "id": "lblSearchField1",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Bank Name:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTxtBoxSearchField1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxTxtBoxSearchField1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTxtBoxSearchField1.setDefaultUnit(kony.flex.DP);
            var txtBoxSearchField1 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "height": "100%",
                "id": "txtBoxSearchField1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "20dp",
                "placeholder": "Enter Bank Name",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "290dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxTxtBoxSearchField1.add(txtBoxSearchField1);
            flxSearchField1.add(lblSearchField1, flxTxtBoxSearchField1);
            var flxSearchField2 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxSearchField2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "47%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchField2.setDefaultUnit(kony.flex.DP);
            var lblSearchField2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "17dp",
                "id": "lblSearchField2",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Branch Name:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTxtBoxSearchField2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxTxtBoxSearchField2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTxtBoxSearchField2.setDefaultUnit(kony.flex.DP);
            var txtBoxSearchField2 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "height": "100%",
                "id": "txtBoxSearchField2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10dp",
                "placeholder": "Enter Branch Name",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "290dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxTxtBoxSearchField2.add(txtBoxSearchField2);
            flxSearchField2.add(lblSearchField2, flxTxtBoxSearchField2);
            var flxSearchField3 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxSearchField3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "47%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchField3.setDefaultUnit(kony.flex.DP);
            var lblSearchField3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "17dp",
                "id": "lblSearchField3",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Country:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTxtBoxSearchField3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxTxtBoxSearchField3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "290dp",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTxtBoxSearchField3.setDefaultUnit(kony.flex.DP);
            var txtBoxSearchField3 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "height": "100%",
                "id": "txtBoxSearchField3",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Enter Country",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxTxtBoxSearchField3.add(txtBoxSearchField3);
            flxSearchField3.add(lblSearchField3, flxTxtBoxSearchField3);
            var flxSearchField4 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxSearchField4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "47%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchField4.setDefaultUnit(kony.flex.DP);
            var lblSearchField4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "17dp",
                "id": "lblSearchField4",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "City:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTxtBoxSearchField4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxTxtBoxSearchField4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "290dp",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTxtBoxSearchField4.setDefaultUnit(kony.flex.DP);
            var txtBoxSearchField4 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "height": "100%",
                "id": "txtBoxSearchField4",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Enter City",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxTxtBoxSearchField4.add(txtBoxSearchField4);
            flxSearchField4.add(lblSearchField4, flxTxtBoxSearchField4);
            var flxSearchButton = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100dp",
                "id": "flxSearchButton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchButton.setDefaultUnit(kony.flex.DP);
            var btnSearch = new kony.ui.Button({
                "focusSkin": "ICSknBtn003E7515PXBrd3PX",
                "height": "40dp",
                "id": "btnSearch",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknBtn003E7515PXBrd3PX",
                "text": "Search",
                "top": "30dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchButton.add(btnSearch);
            var flxSearchResults = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "283dp",
                "id": "flxSearchResults",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "29dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchResults.setDefaultUnit(kony.flex.DP);
            var flxMobLookupHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMobLookupHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxF8F7F8",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMobLookupHeader.setDefaultUnit(kony.flex.DP);
            var flxTopSeparatorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSeparatorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeparatorHeader.setDefaultUnit(kony.flex.DP);
            flxTopSeparatorHeader.add();
            var lblSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "20dp",
                "id": "lblSearch",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLabelSSPRegular42424213px",
                "text": "Search Results",
                "top": "11dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBottomSeparatorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBottomSeparatorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparatorHeader.setDefaultUnit(kony.flex.DP);
            flxBottomSeparatorHeader.add();
            flxMobLookupHeader.add(flxTopSeparatorHeader, lblSearch, flxBottomSeparatorHeader);
            var flxLookupHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxLookupHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxF8F7F8",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookupHeader.setDefaultUnit(kony.flex.DP);
            var CopyflxTopSeparator0b665aa5aac9341 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "CopyflxTopSeparator0b665aa5aac9341",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxTopSeparator0b665aa5aac9341.setDefaultUnit(kony.flex.DP);
            CopyflxTopSeparator0b665aa5aac9341.add();
            var flxColumnHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "38dp",
                "id": "flxColumnHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumnHeader.setDefaultUnit(kony.flex.DP);
            var flxColumn1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxColumn1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "11dp",
                "width": "18%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn1.setDefaultUnit(kony.flex.DP);
            var lblLookupColumn1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "100%",
                "id": "lblLookupColumn1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.bicSlashSwift\")",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn1.add(lblLookupColumn1);
            var flxColumn2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxColumn2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "11dp",
                "width": "58%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn2.setDefaultUnit(kony.flex.DP);
            var lblLookupColumn2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "100%",
                "id": "lblLookupColumn2",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.WireTransfer.BankNameAndAddress\")",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn2.add(lblLookupColumn2);
            flxColumnHeader.add(flxColumn1, flxColumn2);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            flxLookupHeader.add(CopyflxTopSeparator0b665aa5aac9341, flxColumnHeader, flxBottomSeparator);
            var segLookupRecords = new kony.ui.SegmentedUI2({
                "data": [{
                    "lblLookupColumn1Value": "",
                    "lblLookupColumnValue2": "",
                    "lblLookupColumnValue3": ""
                }],
                "groupCells": false,
                "height": "204dp",
                "id": "segLookupRecords",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ResourcesMA",
                    "friendlyName": "flxLookupRecordList"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "40dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxBottomSeparator": "flxBottomSeparator",
                    "flxColumn1Value": "flxColumn1Value",
                    "flxColumn2Value": "flxColumn2Value",
                    "flxColumn3Value": "flxColumn3Value",
                    "flxLookupRecordList": "flxLookupRecordList",
                    "flxLookupRecordValues": "flxLookupRecordValues",
                    "lblLookupColumn1Value": "lblLookupColumn1Value",
                    "lblLookupColumnValue2": "lblLookupColumnValue2",
                    "lblLookupColumnValue3": "lblLookupColumnValue3"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchResults.add(flxMobLookupHeader, flxLookupHeader, segLookupRecords);
            flxLookupPopup.add(flxLookupTitle, flxPopupTitleSeparator, flxLookupDesc, flxLookupErrorMessage, flxSearchField1, flxSearchField2, flxSearchField3, flxSearchField4, flxSearchButton, flxSearchResults);
            flxLookups.add(flxLookupPopup);
            var flxBankClearingLookup = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "1200dp",
                "horizontalScrollIndicator": true,
                "id": "flxBankClearingLookup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 3
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookup.setDefaultUnit(kony.flex.DP);
            var flxBankClearingPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxBankClearingPopup",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "maxHeight": "80%",
                "isModalContainer": true,
                "skin": "ICSknBgffffffBorder3px",
                "top": "100dp",
                "width": "640dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankClearingPopup.setDefaultUnit(kony.flex.DP);
            var flxBankClearingLookupTitle = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxBankClearingLookupTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupTitle.setDefaultUnit(kony.flex.DP);
            var lblBankClearingLookupTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "lblBankClearingLookupTitle",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular42424215Px",
                "text": "Clearing Code Search",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBankClearingLookupClose = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": false,
                "height": "20dp",
                "id": "flxBankClearingLookupClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "12dp",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupClose.setDefaultUnit(kony.flex.DP);
            var imgBankClearingLookupClose = new kony.ui.Image2({
                "height": "100%",
                "id": "imgBankClearingLookupClose",
                "isVisible": false,
                "left": "0dp",
                "src": "bbcloseicon_1.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBankClearingLookupClose = new kony.ui.Button({
                "height": "100%",
                "id": "btnBankClearingLookupClose",
                "isVisible": true,
                "left": "0",
                "skin": "btnClose",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupClose.add(imgBankClearingLookupClose, btnBankClearingLookupClose);
            flxBankClearingLookupTitle.add(lblBankClearingLookupTitle, flxBankClearingLookupClose);
            var flxBankClearingLookupSep1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBankClearingLookupSep1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSep1.setDefaultUnit(kony.flex.DP);
            flxBankClearingLookupSep1.add();
            var flxBankClearingLookupDesc = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "43dp",
                "id": "flxBankClearingLookupDesc",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16dp",
                "width": "96%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupDesc.setDefaultUnit(kony.flex.DP);
            var lblBankClearingLookupDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "20dp",
                "id": "lblBankClearingLookupDesc",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular42424215Px",
                "text": "To find your clearing code, enter the details and click search.",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupDesc.add(lblBankClearingLookupDesc);
            var flxBankClearingLookupErr = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBankClearingLookupErr",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupErr.setDefaultUnit(kony.flex.DP);
            var lblBankClearingLookupErr = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "id": "lblBankClearingLookupErr",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknRtxSSPFF000015Px",
                "text": "Error Message\n",
                "top": "8dp",
                "width": "93.30%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupErr.add(lblBankClearingLookupErr);
            var flxBankClearingLookupSearch1 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxBankClearingLookupSearch1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "47%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSearch1.setDefaultUnit(kony.flex.DP);
            var lblBankClearingLookupSearch1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "17dp",
                "id": "lblBankClearingLookupSearch1",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Bank Clearing Code:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBankClearingLookupTbx1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBankClearingLookupTbx1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupTbx1.setDefaultUnit(kony.flex.DP);
            var tbxBankClearingLookupSearch1 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "height": "100%",
                "id": "tbxBankClearingLookupSearch1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "20dp",
                "placeholder": "Enter Bank Clearing code",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "290dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxBankClearingLookupTbx1.add(tbxBankClearingLookupSearch1);
            flxBankClearingLookupSearch1.add(lblBankClearingLookupSearch1, flxBankClearingLookupTbx1);
            var flxBankClearingLookupOr = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxBankClearingLookupOr",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupOr.setDefaultUnit(kony.flex.DP);
            var lblBankClearingLookupOR = new kony.ui.Label({
                "id": "lblBankClearingLookupOR",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl42424215PX",
                "text": "OR",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupOr.add(lblBankClearingLookupOR);
            var flxBankClearingLookupSearch2 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxBankClearingLookupSearch2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "47%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSearch2.setDefaultUnit(kony.flex.DP);
            var lblBankClearingLookupSearch2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "17dp",
                "id": "lblBankClearingLookupSearch2",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Bank Name:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBankClearingLookupTbx2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBankClearingLookupTbx2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "290dp",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupTbx2.setDefaultUnit(kony.flex.DP);
            var tbxBankClearingLookupSearch2 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "height": "100%",
                "id": "tbxBankClearingLookupSearch2",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Enter Bank Name",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxBankClearingLookupTbx2.add(tbxBankClearingLookupSearch2);
            flxBankClearingLookupSearch2.add(lblBankClearingLookupSearch2, flxBankClearingLookupTbx2);
            var flxBankClearingLookupSearch3 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxBankClearingLookupSearch3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "47%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 6,
                        "1366": 6,
                        "1380": 6
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSearch3.setDefaultUnit(kony.flex.DP);
            var lblBankClearingLookupSearch3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "17dp",
                "id": "lblBankClearingLookupSearch3",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Branch Name/City:",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBankClearingLookupTbx3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBankClearingLookupTbx3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "290dp",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupTbx3.setDefaultUnit(kony.flex.DP);
            var tbxBankClearingLookupSearch3 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "height": "100%",
                "id": "tbxBankClearingLookupSearch3",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Enter Branch Name/City",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px"
            });
            flxBankClearingLookupTbx3.add(tbxBankClearingLookupSearch3);
            flxBankClearingLookupSearch3.add(lblBankClearingLookupSearch3, flxBankClearingLookupTbx3);
            var flxBankClearingLookupSearchBtn = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBankClearingLookupSearchBtn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSearchBtn.setDefaultUnit(kony.flex.DP);
            var btnBankClearingLookupSearch = new kony.ui.Button({
                "focusSkin": "ICSknBtn003E7515PXBrd3PX",
                "height": "40dp",
                "id": "btnBankClearingLookupSearch",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknBtn003E7515PXBrd3PX",
                "text": "Search",
                "top": "30dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSearchBtn.add(btnBankClearingLookupSearch);
            var flxBankClearingLookupSearchRes = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBankClearingLookupSearchRes",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "29dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12,
                        "1380": 12
                    }
                },
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSearchRes.setDefaultUnit(kony.flex.DP);
            var flxBankClearingLookupMobHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBankClearingLookupMobHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxF8F7F8",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupMobHeader.setDefaultUnit(kony.flex.DP);
            var flxBankClearingLookupSep2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBankClearingLookupSep2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSep2.setDefaultUnit(kony.flex.DP);
            flxBankClearingLookupSep2.add();
            var lblBankClearingLookupMobSearch = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "20dp",
                "id": "lblBankClearingLookupMobSearch",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLabelSSPRegular42424213px",
                "text": "Search Results",
                "top": "11dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBankClearingLookupSep3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBankClearingLookupSep3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSep3.setDefaultUnit(kony.flex.DP);
            flxBankClearingLookupSep3.add();
            flxBankClearingLookupMobHeader.add(flxBankClearingLookupSep2, lblBankClearingLookupMobSearch, flxBankClearingLookupSep3);
            var flxBankClearingLookupHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBankClearingLookupHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "ICSknFlxF8F7F8",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupHeader.setDefaultUnit(kony.flex.DP);
            var flxBankClearingLookupSep4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBankClearingLookupSep4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSep4.setDefaultUnit(kony.flex.DP);
            flxBankClearingLookupSep4.add();
            var flxBankClearingLookupSeaarchHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "38dp",
                "id": "flxBankClearingLookupSeaarchHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSeaarchHeader.setDefaultUnit(kony.flex.DP);
            var flxBankClearingLookupCol1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxBankClearingLookupCol1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "11dp",
                "width": "18%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupCol1.setDefaultUnit(kony.flex.DP);
            var lblBankClearingLookupCol1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "100%",
                "id": "lblBankClearingLookupCol1",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular42424215Px",
                "text": "Clearing Code",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupCol1.add(lblBankClearingLookupCol1);
            var flxBankClearingLookupCol2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxBankClearingLookupCol2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "11dp",
                "width": "58%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupCol2.setDefaultUnit(kony.flex.DP);
            var lblBankClearingLookupCol2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "height": "100%",
                "id": "lblBankClearingLookupCol2",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknSSPRegular42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.WireTransfer.BankNameAndAddress\")",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupCol2.add(lblBankClearingLookupCol2);
            flxBankClearingLookupSeaarchHeader.add(flxBankClearingLookupCol1, flxBankClearingLookupCol2);
            var flxBankClearingLookupSep5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBankClearingLookupSep5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxSeparator",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSep5.setDefaultUnit(kony.flex.DP);
            flxBankClearingLookupSep5.add();
            flxBankClearingLookupHeader.add(flxBankClearingLookupSep4, flxBankClearingLookupSeaarchHeader, flxBankClearingLookupSep5);
            var segBankClearingLookup = new kony.ui.SegmentedUI2({
                "data": [{
                    "lblLookupColumn1Value": "",
                    "lblLookupColumnValue2": "",
                    "lblLookupColumnValue3": ""
                }],
                "groupCells": false,
                "height": "204dp",
                "id": "segBankClearingLookup",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ResourcesMA",
                    "friendlyName": "flxLookupRecordList"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "40dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxBottomSeparator": "flxBottomSeparator",
                    "flxColumn1Value": "flxColumn1Value",
                    "flxColumn2Value": "flxColumn2Value",
                    "flxColumn3Value": "flxColumn3Value",
                    "flxLookupRecordList": "flxLookupRecordList",
                    "flxLookupRecordValues": "flxLookupRecordValues",
                    "lblLookupColumn1Value": "lblLookupColumn1Value",
                    "lblLookupColumnValue2": "lblLookupColumnValue2",
                    "lblLookupColumnValue3": "lblLookupColumnValue3"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBankClearingLookupSearchRes.add(flxBankClearingLookupMobHeader, flxBankClearingLookupHeader, segBankClearingLookup);
            flxBankClearingPopup.add(flxBankClearingLookupTitle, flxBankClearingLookupSep1, flxBankClearingLookupDesc, flxBankClearingLookupErr, flxBankClearingLookupSearch1, flxBankClearingLookupOr, flxBankClearingLookupSearch2, flxBankClearingLookupSearch3, flxBankClearingLookupSearchBtn, flxBankClearingLookupSearchRes);
            flxBankClearingLookup.add(flxBankClearingPopup);
            var BrowserSizeWarning = new com.InfinityOLB.Resources.BrowserSizeWarning({
                "height": "100%",
                "id": "BrowserSizeWarning",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknLoading",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "ResourcesMA",
                "viewType": "BrowserSizeWarning",
                "overrides": {
                    "BrowserSizeWarning": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var BrowserSizeWarning_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmBulkPaymentsTemplate"] && appConfig.componentMetadata["ResourcesMA"]["frmBulkPaymentsTemplate"]["BrowserSizeWarning"]) || {};
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "segmentProps": []
                    },
                    "flxTemplateDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgPrint": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgdownload": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknFlxffffffShadowdddcdc",
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lstbFromAccount": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "right": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "skin": "sknFlxscrollffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "lstbDefaultCurrency": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "segmentProps": []
                    },
                    "lstbProcessingMode": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxDate": {
                        "width": {
                            "type": "string",
                            "value": "94.96%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnCancel": {
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnNext": {
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreateBulkRequest": {
                        "segmentProps": []
                    },
                    "flxSummaryHeader": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblSummaryHeader": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblEditSummary": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblSelectEdit": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblEdit": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblDropDown": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblAddBeneficiariesText": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblCount": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewRemovedBeneficiaries": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblUpdateHeader": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblPaymentReference": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnApplyChanges": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnRemove": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblRemoveBeneficiaries": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "blUpdateHeader": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblChangeCurrency": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblChangeAmount": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblFeesPaid": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentRef": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lstbChangeCurrency": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbFeesPaid": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lblPaymentReferenceValidDesc": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnApplyBeneficiaryChange": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblRemoveTemplateBeneficiaries": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnTemplateRemove": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSort": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxSegment": {
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "lblSummaryHeader0": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblEditSummary0": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMethodSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxMethod2": {
                        "segmentProps": []
                    },
                    "lblEditBeneficiary": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTabletAccountsSeparator": {
                        "segmentProps": []
                    },
                    "addBenFormActions.btnCancel": {
                        "segmentProps": []
                    },
                    "addBenFormActions.btnNext": {
                        "segmentProps": []
                    },
                    "addBenFormActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewBeneficiaries": {
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "lblAddHeader": {
                        "segmentProps": []
                    },
                    "flxStep1Seperator": {
                        "segmentProps": []
                    },
                    "lblPaymentRefInvalidDesc": {
                        "segmentProps": []
                    },
                    "flxAddType": {
                        "segmentProps": []
                    },
                    "lblAddType": {
                        "segmentProps": []
                    },
                    "flxAddTypeRadioButtons": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAddTypeRadio1": {
                        "segmentProps": []
                    },
                    "lblRadioAdd1Opt1": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblRadioAddOpt2": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "flxBankAccountType": {
                        "segmentProps": []
                    },
                    "lblType": {
                        "segmentProps": []
                    },
                    "flxRecipientTypeRadioButtons": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxTypeRadio1": {
                        "segmentProps": []
                    },
                    "lblRadioOpt1": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblRadioOpt2": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblInvalidIBANInfinity": {
                        "segmentProps": []
                    },
                    "flxRecipientName": {
                        "segmentProps": []
                    },
                    "lblRecipientName": {
                        "segmentProps": []
                    },
                    "tbxRecipientName": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxRecipientAccountNumber": {
                        "segmentProps": []
                    },
                    "lblRecipientAccountNumber": {
                        "segmentProps": []
                    },
                    "tbxRecipAccNumber": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblInvalidSwift": {
                        "segmentProps": []
                    },
                    "flxSwftCode": {
                        "segmentProps": []
                    },
                    "tbxSwiftCode": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxRecipientBankName": {
                        "height": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientBankName": {
                        "segmentProps": []
                    },
                    "tbxRecipientBankName": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "segmentProps": []
                    },
                    "lblAccountType": {
                        "segmentProps": []
                    },
                    "flxAccountTypeRadioButtons": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccTypeRadio1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccTypeRadio1": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblAccTypeRadio2": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "flxRecipientAccNumExt": {
                        "segmentProps": []
                    },
                    "lblRecipientAccountNumberExt": {
                        "segmentProps": []
                    },
                    "tbxRecipAccNumberExt": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSwift": {
                        "segmentProps": []
                    },
                    "lblSwift": {
                        "segmentProps": []
                    },
                    "tbxSwift": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeField": {
                        "segmentProps": []
                    },
                    "flxPayeeDetails": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetailWarning": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "imgPayeeDetailWarning": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblPayeeDetailWarning": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetail1": {
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayeeDetail1": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "flxLookUp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblLookUp": {
                        "segmentProps": []
                    },
                    "tbxPayeeDetail1": {
                        "skin": "ICSknTxtE3E3E3Border1pxRad2px424242SSPRegular13px",
                        "segmentProps": []
                    },
                    "flxPayeeDetail2": {
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayeeDetail2": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "tbxPayeeDetail2": {
                        "skin": "ICSknTxtE3E3E3Border1pxRad2px424242SSPRegular13px",
                        "segmentProps": []
                    },
                    "flxPayeeDetail3": {
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayeeDetail3": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "flxLookUp2": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblLookUp2": {
                        "segmentProps": []
                    },
                    "tbxPayeeDetail3": {
                        "skin": "ICSknTxtE3E3E3Border1pxRad2px424242SSPRegular13px",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetail4": {
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayeeDetail4": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "tbxPayeeDetail4": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "ICSknTxtE3E3E3Border1pxRad2px424242SSPRegular13px",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetail5": {
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayeeDetail5": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "flxPayeeDetail5Dropdown": {
                        "segmentProps": []
                    },
                    "flxPayeeDetail5List": {
                        "segmentProps": []
                    },
                    "flxPayeeDetailRow3": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 28,
                        "segmentProps": []
                    },
                    "flxPayeeDetail6": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "tbxPayeeDetail6": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetail7": {
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayeeDetail7": {
                        "segmentProps": []
                    },
                    "tbxPayeeDetail7": {
                        "segmentProps": []
                    },
                    "flxPayeeDetailRow4": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetail8": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblPayeeDetail8": {
                        "segmentProps": []
                    },
                    "lbxPayeeDetail8": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCurrencyAmount": {
                        "segmentProps": []
                    },
                    "lblCurrencySymbol": {
                        "segmentProps": []
                    },
                    "lbxCurrency": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "tbxCurrency": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblAmountName": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "tbxAmountValue": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentMethodField": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentMethod": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentMethodInfoIcon": {
                        "segmentProps": []
                    },
                    "flxPaymentMethodInfo": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentMethodInfoHeader": {
                        "segmentProps": []
                    },
                    "lblPaymentMethodInfo1": {
                        "width": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentMethodOptions": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxPaymentMethod1": {
                        "segmentProps": []
                    },
                    "lblPaymentMethod1": {
                        "segmentProps": []
                    },
                    "flxPaymentMethod2": {
                        "segmentProps": []
                    },
                    "lblPaymentMethod2": {
                        "segmentProps": []
                    },
                    "flxFeesPaidByOptions": {
                        "segmentProps": []
                    },
                    "lblFeesPaidByHeader": {
                        "segmentProps": []
                    },
                    "flxInfoicon": {
                        "segmentProps": []
                    },
                    "flxFeesPaidRadioButtons": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeesTypeRadio1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblFeesOpt1": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblFeesOpt2": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblFeesOpt3": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "flxIntermediaryBicAndPurposeCode": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxIntermediaryBic": {
                        "height": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "lblIntermediaryBic": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "tbxIntermediaryBic": {
                        "segmentProps": []
                    },
                    "flxPurposeCode": {
                        "segmentProps": []
                    },
                    "lblPurposeCode": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "segmentProps": []
                    },
                    "flxPurposeCodeDropdown": {
                        "segmentProps": []
                    },
                    "flxPurposeCodeList": {
                        "segmentProps": []
                    },
                    "flxPaymentRef": {
                        "height": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentRefName": {
                        "segmentProps": []
                    },
                    "tbxPaymentRefValue": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentRefValidDesc": {
                        "segmentProps": []
                    },
                    "flxAddToList": {
                        "segmentProps": []
                    },
                    "lblAddToList": {
                        "segmentProps": []
                    },
                    "flxEndSeperator": {
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnCancel": {
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnNext": {
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplate": {
                        "segmentProps": []
                    },
                    "lblViewTemplateHeader": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblPrimaryDetailsEdit": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblVTErrorMsg": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateName": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateValue": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateFromAccount": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateFromAccountValue": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateExecutionDate": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateExecutionDateValue": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateProcessingMode": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateProcessingModeValue": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTotalAmount": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTotalAmountValue": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTransactionsCount": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTransactionsCountValue": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplatePaymentDescription": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplatePaymentDescriptionValue": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblAddedBeneficiaries": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblAddedBeneficiariesCount": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "lblEditAddedBeneficiaries": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateRowTemplate": {
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateSegment": {
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnBack": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnNext": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "text": "Next",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnOption": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Option",
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxLine": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "text": "© Copyright Infinity Retail Banking. All rights reserved.",
                        "segmentProps": []
                    },
                    "customfooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPopupNew.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxPopupNew.flxPlaceHolder": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopupParent": {
                        "segmentProps": []
                    },
                    "flxLookups": {
                        "segmentProps": []
                    },
                    "flxLookupPopup": {
                        "width": {
                            "type": "string",
                            "value": "93.75%"
                        },
                        "segmentProps": []
                    },
                    "flxLookupTitle": {
                        "segmentProps": []
                    },
                    "lblLookupTitle": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular42424213px",
                        "segmentProps": []
                    },
                    "flxLookupClose": {
                        "height": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "segmentProps": []
                    },
                    "imgLookupCloseIcon": {
                        "segmentProps": []
                    },
                    "flxLookupDesc": {
                        "height": {
                            "type": "string",
                            "value": "56dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblLookupDescription": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular42424213px",
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxLookupErrorMessage": {
                        "segmentProps": []
                    },
                    "rtxLookupErrorMessage": {
                        "skin": "sknRtxSSPFF000013Px",
                        "segmentProps": []
                    },
                    "flxSearchField1": {
                        "height": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblSearchField1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxTxtBoxSearchField1": {
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "txtBoxSearchField1": {
                        "focusSkin": "ICSknTextBoxSSPRegular42424213px",
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "placeholderSkin": "ICSknTextBoxSSPRegular72727213px",
                        "skin": "ICSknTextBoxSSPRegular42424213px",
                        "width": {
                            "type": "string",
                            "value": "93.30%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchField2": {
                        "height": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblSearchField2": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxTxtBoxSearchField2": {
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "txtBoxSearchField2": {
                        "focusSkin": "ICSknTextBoxSSPRegular42424213px",
                        "placeholderSkin": "ICSknTextBoxSSPRegular72727213px",
                        "skin": "ICSknTextBoxSSPRegular42424213px",
                        "width": {
                            "type": "string",
                            "value": "93.30%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchField3": {
                        "height": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblSearchField3": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular42424213px",
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxTxtBoxSearchField3": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "txtBoxSearchField3": {
                        "focusSkin": "ICSknTextBoxSSPRegular42424213px",
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "placeholderSkin": "ICSknTextBoxSSPRegular72727213px",
                        "skin": "ICSknTextBoxSSPRegular42424213px",
                        "width": {
                            "type": "string",
                            "value": "93.30%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchField4": {
                        "height": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblSearchField4": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxTxtBoxSearchField4": {
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.30%"
                        },
                        "segmentProps": []
                    },
                    "txtBoxSearchField4": {
                        "focusSkin": "ICSknTextBoxSSPRegular42424213px",
                        "placeholderSkin": "ICSknTextBoxSSPRegular72727213px",
                        "skin": "ICSknTextBoxSSPRegular42424213px",
                        "segmentProps": []
                    },
                    "flxSearchButton": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnSearch": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknUTFBtnSSPffffff13pxBg0273e3",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchResults": {
                        "height": {
                            "type": "string",
                            "value": "564dp"
                        },
                        "segmentProps": []
                    },
                    "flxMobLookupHeader": {
                        "isCustomLayout": false,
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLookupHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "segLookupRecords": {
                        "segmentProps": []
                    },
                    "flxBankClearingLookup": {
                        "segmentProps": []
                    },
                    "flxBankClearingPopup": {
                        "width": {
                            "type": "string",
                            "value": "93.75%"
                        },
                        "segmentProps": []
                    },
                    "flxBankClearingLookupTitle": {
                        "segmentProps": []
                    },
                    "lblBankClearingLookupTitle": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular42424213px",
                        "segmentProps": []
                    },
                    "flxBankClearingLookupClose": {
                        "height": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "segmentProps": []
                    },
                    "imgBankClearingLookupClose": {
                        "segmentProps": []
                    },
                    "flxBankClearingLookupDesc": {
                        "height": {
                            "type": "string",
                            "value": "56dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblBankClearingLookupDesc": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "height": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular42424213px",
                        "top": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxBankClearingLookupErr": {
                        "segmentProps": []
                    },
                    "lblBankClearingLookupErr": {
                        "skin": "sknRtxSSPFF000013Px",
                        "segmentProps": []
                    },
                    "flxBankClearingLookupSearch1": {
                        "height": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblBankClearingLookupSearch1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxBankClearingLookupTbx1": {
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "tbxBankClearingLookupSearch1": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.30%"
                        },
                        "segmentProps": []
                    },
                    "flxBankClearingLookupSearch2": {
                        "height": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblBankClearingLookupSearch2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLabelSSPRegular42424213px",
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxBankClearingLookupTbx2": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxBankClearingLookupSearch2": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.30%"
                        },
                        "segmentProps": []
                    },
                    "flxBankClearingLookupSearch3": {
                        "height": {
                            "type": "string",
                            "value": "71dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblBankClearingLookupSearch3": {
                        "skin": "ICSknLabelSSPRegular72727213px",
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": []
                    },
                    "flxBankClearingLookupTbx3": {
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.30%"
                        },
                        "segmentProps": []
                    },
                    "tbxBankClearingLookupSearch3": {
                        "segmentProps": []
                    },
                    "flxBankClearingLookupSearchBtn": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnBankClearingLookupSearch": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "ICSknUTFBtnSSPffffff13pxBg0273e3",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "flxBankClearingLookupSearchRes": {
                        "segmentProps": []
                    },
                    "flxBankClearingLookupMobHeader": {
                        "isCustomLayout": false,
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBankClearingLookupHeader": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "segBankClearingLookup": {
                        "height": {
                            "type": "string",
                            "value": "524dp"
                        },
                        "segmentProps": []
                    },
                    "BrowserSizeWarning": {
                        "isVisible": true,
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "bottom": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTemplateDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "127dp"
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknFlxffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateNameTitle": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateName": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalBeneficiariesTitle": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalBeneficiaries": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDomesticTitle": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDomestic": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "lblInternationalTitle": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblInternational": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "445dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "lblInternalTitle": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "91dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblInternal": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "91dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAckMessage": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSP42424217px",
                        "text": "23467686990",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "focusSkin": "sknFlxffffffShadowdddcdc",
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "tbxTemplateName": {
                        "padding": [2, 0, 0, 0],
                        "segmentProps": []
                    },
                    "lstbFromAccount": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "txtTransferFrom": {
                        "right": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": []
                    },
                    "lblTypeIcon": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lstbDefaultCurrency": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxInformationText": {
                        "segmentProps": []
                    },
                    "flxProcessinModeInfo": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "lstbProcessingMode": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxDate": {
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.96%"
                        },
                        "segmentProps": []
                    },
                    "flxExecutionDate": {
                        "width": {
                            "type": "string",
                            "value": "59%"
                        },
                        "segmentProps": []
                    },
                    "calExecutionDate": {
                        "segmentProps": []
                    },
                    "tbxTemplateDescription": {
                        "padding": [2, 0, 0, 0],
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnCancel": {
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnNext": {
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnOption": {
                        "segmentProps": []
                    },
                    "flxCreateBulkRequest": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxContent": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxSummary": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxSummaryHeader": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblSummaryHeader": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxEditSummary": {
                        "left": {
                            "type": "string",
                            "value": "92%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblEditSummary": {
                        "padding": [0, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSummaryHeaderSeparator": {
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateNameKey": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblTemplateNameValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblFromAccountKey": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblFromAccountIcon": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblFromAccountValue": {
                        "left": {
                            "type": "string",
                            "value": "40%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblExecutionDateKey": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblExecutionDateValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxExecutionDateCreateBulkReq": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "calExecutionDateCreateBulkReq": {
                        "segmentProps": []
                    },
                    "lblProcessingModeKey": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblProcessingModeValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDefaultDebitCurrencyKey": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDefaultDebitCurrencyValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountKey": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblTotalTransactionsKey": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblTotalTransactionsValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDescriptionKey": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDescriptionValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxEditBeneficiariesHeader": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblSelectEdit": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxEditDetails": {
                        "left": {
                            "type": "string",
                            "value": "72%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblEdit": {
                        "padding": [0, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblDropDown": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "padding": [0, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchSortSeparator": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "skin": "sknLabelSSPFF000015Px",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxViewAllRecipients": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblAddBeneficiariesText": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCount": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "lblViewRemovedBeneficiaries": {
                        "centerX": {
                            "type": "string",
                            "value": "44%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [0, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchBeneficiariesBox": {
                        "width": {
                            "type": "string",
                            "value": "98.50%"
                        },
                        "segmentProps": []
                    },
                    "tbxSearchBox": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxApplyChanges": {
                        "height": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblUpdateHeader": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "i18n_text": "i18n.bulkwires.changeamount",
                        "isVisible": true,
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentReference": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxOr": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgOr": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "btnApplyChanges": {
                        "i18n_text": "kony.mb.transfers.Apply",
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Apply",
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "tbxPaymentReference": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "btnRemove": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.bulkwires.Remove",
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "text": "Remove",
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblRemoveBeneficiaries": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxApplyChangesTemplate": {
                        "height": {
                            "type": "string",
                            "value": "225dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "blUpdateHeader": {
                        "left": {
                            "type": "string",
                            "value": "1.39%"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblChangeCurrency": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblChangeAmount": {
                        "i18n_text": "i18n.bulkwires.changeamount",
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblFeesPaid": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblPaymentRef": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxChangeCurrency": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lstbChangeCurrency": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "tbxChangeAmount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxFeesPaid": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lstbFeesPaid": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "tbxPaymentRef": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentReferenceValidDesc": {
                        "left": {
                            "type": "string",
                            "value": "30%"
                        },
                        "padding": [0, 0, 0, 0],
                        "top": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnApplyBeneficiaryChange": {
                        "i18n_text": "kony.mb.transfers.Apply",
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Apply",
                        "top": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": []
                    },
                    "flxOrSeperator": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgTemplateOr": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "zIndex": 6,
                        "segmentProps": []
                    },
                    "lblRemoveTemplateBeneficiaries": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_CENTER,
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "btnTemplateRemove": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "i18n_text": "i18n.bulkwires.Remove",
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "text": "Remove",
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblViewOnlySelected": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxStatus": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblStatus": {
                        "centerX": {
                            "type": "string",
                            "value": "51.37%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBeneficiaryName": {
                        "segmentProps": []
                    },
                    "flxCurrency": {
                        "left": {
                            "type": "string",
                            "value": "7.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "16.70%"
                        },
                        "segmentProps": []
                    },
                    "lblCurrency": {
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblSortAmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFeesPaidBy": {
                        "left": {
                            "type": "string",
                            "value": "9.30%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectAll": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-1.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectAll": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "TabBodyNewBeneficiaries": {
                        "segmentProps": []
                    },
                    "flxNoRecipients": {
                        "segmentProps": []
                    },
                    "lblSummaryHeader0": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditSummary0": {
                        "segmentProps": []
                    },
                    "lblEditSummary0": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "i18n_text": "i18n.billPay.Edit",
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP4176a415px",
                        "segmentProps": []
                    },
                    "lblTemplateNameKeyVerifyPage": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateNameValueVerifyPage": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblFromAccountKeyVerifyPage": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "lblFromAccountIconVerifyPage": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblFromAccountValueVerifyPage": {
                        "left": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": []
                    },
                    "lblExecutionDateKey0": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "lblExecutionDateValueVerifyPage": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblProcessingModeKey0": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "lblProcessingModeValue0": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblCurrencyCodeKey": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "lblCurrencyCodeValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountKey0": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalAmountValue0": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalTransactionsKey0": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalTransactionsVal": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblDescriptionKey0": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "lblDescriptionValue0": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxMethod": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblMethod": {
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "imgMethod": {
                        "segmentProps": []
                    },
                    "flxMethodSeparator": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxMethod2": {
                        "segmentProps": []
                    },
                    "lblMethod2": {
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditBeneficiary": {
                        "segmentProps": []
                    },
                    "lblEditBeneficiary": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "i18n_text": "i18n.billPay.Edit",
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP4176a415px",
                        "segmentProps": []
                    },
                    "flxTabletAccountsSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxViewBankName": {
                        "left": {
                            "type": "string",
                            "value": "3.30%"
                        },
                        "segmentProps": []
                    },
                    "btnViewAmount": {
                        "left": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "TabBodyNewAddedBen": {
                        "segmentProps": []
                    },
                    "lblAccountsInfo": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "addBenFormActions.btnCancel": {
                        "segmentProps": []
                    },
                    "addBenFormActions.btnNext": {
                        "segmentProps": []
                    },
                    "addBenFormActions.btnOption": {
                        "segmentProps": []
                    },
                    "addBenFormActions": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxSeperator4": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchBar": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBoxSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "73%"
                        },
                        "segmentProps": []
                    },
                    "tbxSearch": {
                        "segmentProps": []
                    },
                    "flxViewOnlySeletcedBen": {
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "27%"
                        },
                        "segmentProps": []
                    },
                    "lblViewOnlySelectedBen": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxStatus1": {
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblStatus1": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorBen": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipientDetailsErrorMessage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAddNewBeneficiaries": {
                        "segmentProps": []
                    },
                    "flxAddMain": {
                        "segmentProps": []
                    },
                    "lblAddHeader": {
                        "segmentProps": []
                    },
                    "flxStep1Seperator": {
                        "segmentProps": []
                    },
                    "lblPaymentRefInvalidDesc": {
                        "segmentProps": []
                    },
                    "flxAddType": {
                        "segmentProps": []
                    },
                    "flxAddTypeRadioButtons": {
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "flxBankAccountType": {
                        "segmentProps": []
                    },
                    "lblRecipientName": {
                        "segmentProps": []
                    },
                    "tbxRecipientName": {
                        "segmentProps": []
                    },
                    "lblRecipientAccountNumber": {
                        "segmentProps": []
                    },
                    "tbxRecipAccNumber": {
                        "segmentProps": []
                    },
                    "tbxSwiftCode": {
                        "segmentProps": []
                    },
                    "lblRecipientBankName": {
                        "segmentProps": []
                    },
                    "tbxRecipientBankName": {
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "segmentProps": []
                    },
                    "lblRecipientAccountNumberExt": {
                        "segmentProps": []
                    },
                    "tbxRecipAccNumberExt": {
                        "segmentProps": []
                    },
                    "lblSwift": {
                        "segmentProps": []
                    },
                    "tbxSwift": {
                        "segmentProps": []
                    },
                    "lblNameValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountKey": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblBankNameValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeField": {
                        "segmentProps": []
                    },
                    "lblPayeeDetailWarning": {
                        "segmentProps": []
                    },
                    "flxPayeeDetailRow2": {
                        "segmentProps": []
                    },
                    "flxPayeeDetailRow3": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetail6": {
                        "segmentProps": []
                    },
                    "tbxPayeeDetail6": {
                        "segmentProps": []
                    },
                    "tbxPayeeDetail7": {
                        "segmentProps": []
                    },
                    "flxPayeeDetailRow4": {
                        "segmentProps": []
                    },
                    "flxPayeeDetail8": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayeeDetail8": {
                        "segmentProps": []
                    },
                    "lbxPayeeDetail8": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrencySymbol": {
                        "segmentProps": []
                    },
                    "lbxCurrency": {
                        "right": {
                            "type": "number",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxCurrency": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lblAmountName": {
                        "segmentProps": []
                    },
                    "tbxAmountValue": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPaymentMethodField": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentMethodInfoIcon": {
                        "segmentProps": []
                    },
                    "flxFeesPaidByInfo": {
                        "segmentProps": []
                    },
                    "flxFeesPaidByOptions": {
                        "segmentProps": []
                    },
                    "flxInfoicon": {
                        "segmentProps": []
                    },
                    "flxFeesPaidRadioButtons": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxFeesTypeRadio2": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeesTypeRadio3": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxInformationText0": {
                        "left": {
                            "type": "string",
                            "value": "15.30%"
                        },
                        "segmentProps": []
                    },
                    "RichTextSharedPayeeInfo": {
                        "segmentProps": []
                    },
                    "flxIntermediaryBicAndPurposeCode": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "tbxIntermediaryBic": {
                        "segmentProps": []
                    },
                    "flxPaymentRef": {
                        "segmentProps": []
                    },
                    "lblPaymentRefName": {
                        "segmentProps": []
                    },
                    "tbxPaymentRefValue": {
                        "segmentProps": []
                    },
                    "lblPaymentRefValidDesc": {
                        "segmentProps": []
                    },
                    "flxAddToList": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblSelect": {
                        "centerY": {
                            "type": "string",
                            "value": "56%"
                        },
                        "segmentProps": []
                    },
                    "lblAddToList": {
                        "centerY": {
                            "type": "string",
                            "value": "56%"
                        },
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnBack": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnCancel": {
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnNext": {
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnOption": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxViewTemplate": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxContentViewTemplate": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "lblViewTemplateHeader": {
                        "segmentProps": []
                    },
                    "lblPrimaryDetailsEdit": {
                        "padding": [0, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknSSP4176a415px",
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateError": {
                        "segmentProps": []
                    },
                    "lblVTErrorMsg": {
                        "skin": "sknLabelSSPFF000015Px",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateName": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateFromAccount": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateFromAccountValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateExecutionDate": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateExecutionDateValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateProcessingMode": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateProcessingModeValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTotalAmount": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTotalAmountValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTransactionsCount": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTransactionsCountValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplatePaymentDescription": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplatePaymentDescriptionValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAddedBeneficiaries": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblAddedBeneficiaries": {
                        "padding": [0, 0, 1, 0],
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblAddedBeneficiariesCount": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "lblEditAddedBeneficiaries": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP4176a415px",
                        "width": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateBenificiaryName": {
                        "segmentProps": []
                    },
                    "flxViewTemplateAmount": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateSortAmount": {
                        "segmentProps": []
                    },
                    "flxViewTemplateFeesPaidBy": {
                        "segmentProps": []
                    },
                    "segmentViewTemplateData": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateNoRecipients": {
                        "segmentProps": []
                    },
                    "formActionsNew.btnBack": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "formActionsNew.btnCancel": {
                        "segmentProps": []
                    },
                    "formActionsNew.btnNext": {
                        "segmentProps": []
                    },
                    "formActionsNew.btnOption": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnBack": {
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnCancel": {
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnNext": {
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnOption": {
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.flxMain": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDelete": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxLine": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblTitleTerms": {
                        "left": {
                            "type": "string",
                            "value": "27px"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "flxCancelPopupParent": {
                        "segmentProps": []
                    },
                    "flxLookups": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLookupPopup": {
                        "segmentProps": []
                    },
                    "imgLookupCloseIcon": {
                        "segmentProps": []
                    },
                    "flxLookupErrorMessage": {
                        "segmentProps": []
                    },
                    "lblSearchField1": {
                        "segmentProps": []
                    },
                    "txtBoxSearchField1": {
                        "segmentProps": []
                    },
                    "lblSearchField2": {
                        "segmentProps": []
                    },
                    "txtBoxSearchField2": {
                        "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px",
                        "segmentProps": []
                    },
                    "txtBoxSearchField3": {
                        "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px",
                        "segmentProps": []
                    },
                    "txtBoxSearchField4": {
                        "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px",
                        "segmentProps": []
                    },
                    "btnSearch": {
                        "focusSkin": "ICSknUTFBtnSSPffffff15pxBg0273e3",
                        "skin": "ICSknUTFBtnSSPffffff15pxBg0273e3",
                        "segmentProps": []
                    },
                    "flxMobLookupHeader": {
                        "segmentProps": []
                    },
                    "flxLookupHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "segLookupRecords": {
                        "segmentProps": []
                    },
                    "flxBankClearingLookup": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxBankClearingPopup": {
                        "segmentProps": []
                    },
                    "imgBankClearingLookupClose": {
                        "segmentProps": []
                    },
                    "flxBankClearingLookupErr": {
                        "segmentProps": []
                    },
                    "lblBankClearingLookupSearch1": {
                        "segmentProps": []
                    },
                    "tbxBankClearingLookupSearch1": {
                        "segmentProps": []
                    },
                    "tbxBankClearingLookupSearch2": {
                        "segmentProps": []
                    },
                    "tbxBankClearingLookupSearch3": {
                        "segmentProps": []
                    },
                    "btnBankClearingLookupSearch": {
                        "focusSkin": "ICSknUTFBtnSSPffffff15pxBg0273e3",
                        "skin": "ICSknUTFBtnSSPffffff15pxBg0273e3",
                        "segmentProps": []
                    },
                    "flxBankClearingLookupMobHeader": {
                        "segmentProps": []
                    },
                    "flxBankClearingLookupHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "segBankClearingLookup": {
                        "segmentProps": []
                    },
                    "BrowserSizeWarning": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxTemplateDetails": {
                        "bottom": {
                            "type": "number",
                            "value": "10"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50.96%"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateNameTitle": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateName": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalBeneficiariesTitle": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalBeneficiaries": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDomesticTitle": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDomestic": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "lblInternationalTitle": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblInternational": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "lblInternalTitle": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblInternal": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.80%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAckMessage": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "23467686990",
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "focusSkin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCreateUI": {
                        "segmentProps": []
                    },
                    "lstbFromAccount": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "segmentProps": []
                    },
                    "flxFromValue": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "flxTypeIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "segmentProps": []
                    },
                    "lstbDefaultCurrency": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbProcessingMode": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "calExecutionDate": {
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnNext": {
                        "segmentProps": []
                    },
                    "flxCreateBulkRequest": {
                        "segmentProps": []
                    },
                    "lblSummaryHeader": {
                        "i18n_text": "i18n.payments.summary",
                        "segmentProps": []
                    },
                    "flxEditSummary": {
                        "left": {
                            "type": "string",
                            "value": "94%"
                        },
                        "top": {
                            "type": "string",
                            "value": "-18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "8%"
                        },
                        "segmentProps": []
                    },
                    "lblEditSummary": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "calExecutionDateCreateBulkReq": {
                        "segmentProps": []
                    },
                    "lblProcessingModeKey": {
                        "i18n_text": "i18n.paymnets.processingDateWithColon",
                        "segmentProps": []
                    },
                    "flxEditBeneficiariesHeader": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblSelectEdit": {
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxEditDetails": {
                        "left": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "lblEdit": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblDropDown": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "padding": [0, 0, 0, 0],
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchSortSeparator": {
                        "width": {
                            "type": "string",
                            "value": "94.80%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "skin": "sknLabelSSPFF000015Px",
                        "segmentProps": []
                    },
                    "flxViewAllRecipients": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblAddBeneficiariesText": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewRemovedBeneficiaries": {
                        "centerX": {
                            "type": "string",
                            "value": "55%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP4176a415px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchBeneficiariesBox": {
                        "width": {
                            "type": "string",
                            "value": "96.80%"
                        },
                        "segmentProps": []
                    },
                    "flxApplyChanges": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.50%"
                        },
                        "segmentProps": []
                    },
                    "lblUpdateHeader": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "i18n_text": "i18n.bulkwires.changeamount",
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblPaymentReference": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxOr": {
                        "left": {
                            "type": "string",
                            "value": "75%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgOr": {
                        "segmentProps": []
                    },
                    "btnApplyChanges": {
                        "i18n_text": "i18n.bulkwires.Applychanges",
                        "left": {
                            "type": "string",
                            "value": "59%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Apply Changes",
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "tbxPaymentReference": {
                        "segmentProps": []
                    },
                    "btnRemove": {
                        "i18n_text": "i18n.bulkwires.Remove",
                        "left": {
                            "type": "string",
                            "value": "80%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "text": "Remove",
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "lblRemoveBeneficiaries": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "80%"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "flxApplyChangesTemplate": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "blUpdateHeader": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblChangeCurrency": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblChangeAmount": {
                        "i18n_text": "i18n.bulkwires.changeamount",
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblFeesPaid": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblPaymentRef": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lstbChangeCurrency": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "tbxChangeAmount": {
                        "segmentProps": []
                    },
                    "flxFeesPaid": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lstbFeesPaid": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "tbxPaymentRef": {
                        "segmentProps": []
                    },
                    "lblPaymentReferenceValidDesc": {
                        "padding": [0, 0, 0, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnApplyBeneficiaryChange": {
                        "i18n_text": "i18n.bulkwires.Applychanges",
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Apply Changes ",
                        "segmentProps": []
                    },
                    "flxOrSeperator": {
                        "left": {
                            "type": "string",
                            "value": "75%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgTemplateOr": {
                        "segmentProps": []
                    },
                    "lblRemoveTemplateBeneficiaries": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "80%"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "btnTemplateRemove": {
                        "i18n_text": "i18n.bulkwires.Remove",
                        "left": {
                            "type": "string",
                            "value": "80%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "text": "Remove",
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "lblViewOnlySelected": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxStatus": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblStatus": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxBeneficiaryName": {
                        "segmentProps": []
                    },
                    "flxCurrency": {
                        "width": {
                            "type": "string",
                            "value": "16.70%"
                        },
                        "segmentProps": []
                    },
                    "lblCurrency": {
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "left": {
                            "type": "string",
                            "value": "0.50%"
                        },
                        "segmentProps": []
                    },
                    "lblSortAmount": {
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxFeesPaidBy": {
                        "left": {
                            "type": "string",
                            "value": "11%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectAll": {
                        "left": {
                            "type": "string",
                            "value": "-1.50%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblSelectAll": {
                        "height": {
                            "type": "string",
                            "value": "30px"
                        },
                        "top": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30px"
                        },
                        "segmentProps": []
                    },
                    "flxNoRecipients": {
                        "segmentProps": []
                    },
                    "flxNoTransactions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblSummaryHeader0": {
                        "segmentProps": []
                    },
                    "lblEditSummary0": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP4176a415px",
                        "segmentProps": []
                    },
                    "flxSummaryHeaderSeparatorVerifyPage": {
                        "segmentProps": []
                    },
                    "lblProcessingModeKey0": {
                        "i18n_text": "i18n.paymnets.processingDateWithColon",
                        "text": "Processing Date:",
                        "segmentProps": []
                    },
                    "lblEditBeneficiary": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP4176a415px",
                        "segmentProps": []
                    },
                    "flxSeparator2": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxTabletAccountsSeparator": {
                        "segmentProps": []
                    },
                    "flxViewBankName": {
                        "left": {
                            "type": "string",
                            "value": "4.10%"
                        },
                        "width": {
                            "type": "string",
                            "value": "23.90%"
                        },
                        "segmentProps": []
                    },
                    "addBenFormActions.btnNext": {
                        "segmentProps": []
                    },
                    "flxSearchBar": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewOnlySeletcedBen": {
                        "left": {
                            "type": "string",
                            "value": "3.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "lblViewOnlySelectedBen": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxStatus1": {
                        "segmentProps": []
                    },
                    "lblStatus1": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipientDetailsErrorMessage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "CopyslFbox0j0ebf902d97643",
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96.60%"
                        },
                        "segmentProps": []
                    },
                    "flxAddNewBeneficiaries": {
                        "segmentProps": []
                    },
                    "lblPayeeDetail4": {
                        "segmentProps": []
                    },
                    "lblPayeeDetail5": {
                        "segmentProps": []
                    },
                    "flxPayeeDetailRow3": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetail6": {
                        "segmentProps": []
                    },
                    "tbxPayeeDetail6": {
                        "text": "",
                        "segmentProps": []
                    },
                    "tbxPayeeDetail7": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxPayeeDetailRow4": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxPayeeDetail8": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayeeDetail8": {
                        "segmentProps": []
                    },
                    "lbxPayeeDetail8": {
                        "segmentProps": []
                    },
                    "lbxCurrency": {
                        "right": {
                            "type": "number",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxAmountValue": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblPaymentMethodInfoHeader": {
                        "segmentProps": []
                    },
                    "lblPurposeCode": {
                        "segmentProps": []
                    },
                    "flxAddToList": {
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnCancel": {
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnNext": {
                        "segmentProps": []
                    },
                    "flxViewTemplate": {
                        "segmentProps": []
                    },
                    "lblPrimaryDetailsEdit": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP4176a415px",
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryDetailsTopSeperator": {
                        "left": {
                            "type": "string",
                            "value": "20px"
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateError": {
                        "segmentProps": []
                    },
                    "lblVTErrorMsg": {
                        "skin": "sknLabelSSPFF000015Px",
                        "segmentProps": []
                    },
                    "lblViewTemplateName": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateFromAccount": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateFromAccountValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateExecutionDate": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateExecutionDateValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateProcessingMode": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateProcessingModeValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTotalAmount": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTotalAmountValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTransactionsCount": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTransactionsCountValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplatePaymentDescription": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplatePaymentDescriptionValue": {
                        "padding": [0, 0, 1, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAddedBeneficiaries": {
                        "segmentProps": []
                    },
                    "lblAddedBeneficiaries": {
                        "padding": [0, 0, 1, 0],
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblAddedBeneficiariesCount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "padding": [0, 0, 1, 0],
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblEditAddedBeneficiaries": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP4176a415px",
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateBenificiaryName": {
                        "segmentProps": []
                    },
                    "lblViewTemplateSortAmount": {
                        "segmentProps": []
                    },
                    "flxViewTemplateFeesPaidBy": {
                        "segmentProps": []
                    },
                    "segmentViewTemplateData": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateNoRecipients": {
                        "segmentProps": []
                    },
                    "flxViewTemplatesNoTransactions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnBack": {
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "zIndex": 4,
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnCancel": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "zIndex": 3,
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnNext": {
                        "right": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnOption": {
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.flxButtons": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "reverseLayoutDirection": false,
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.flxMain": {
                        "segmentProps": []
                    },
                    "CommonFormActionsExt": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "width": {
                            "type": "string",
                            "value": "215dp"
                        },
                        "segmentProps": []
                    },
                    "btnDelete": {
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "215dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "215dp"
                        },
                        "segmentProps": []
                    },
                    "flxLine": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPopupNew.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "flxCancelPopupParent": {
                        "segmentProps": []
                    },
                    "flxLookups": {
                        "segmentProps": []
                    },
                    "flxLookupPopup": {
                        "segmentProps": []
                    },
                    "imgLookupCloseIcon": {
                        "segmentProps": []
                    },
                    "txtBoxSearchField1": {
                        "segmentProps": []
                    },
                    "txtBoxSearchField2": {
                        "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px",
                        "segmentProps": []
                    },
                    "txtBoxSearchField3": {
                        "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px",
                        "segmentProps": []
                    },
                    "txtBoxSearchField4": {
                        "placeholderSkin": "ICSknTxtBoxPlaceholderSSP94949415px",
                        "segmentProps": []
                    },
                    "btnSearch": {
                        "focusSkin": "ICSknUTFBtnSSPffffff15pxBg0273e3",
                        "skin": "ICSknUTFBtnSSPffffff15pxBg0273e3",
                        "segmentProps": []
                    },
                    "flxMobLookupHeader": {
                        "segmentProps": []
                    },
                    "flxLookupHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "segLookupRecords": {
                        "segmentProps": []
                    },
                    "flxBankClearingLookup": {
                        "segmentProps": []
                    },
                    "flxBankClearingPopup": {
                        "segmentProps": []
                    },
                    "imgBankClearingLookupClose": {
                        "segmentProps": []
                    },
                    "tbxBankClearingLookupSearch1": {
                        "segmentProps": []
                    },
                    "tbxBankClearingLookupSearch2": {
                        "segmentProps": []
                    },
                    "tbxBankClearingLookupSearch3": {
                        "segmentProps": []
                    },
                    "btnBankClearingLookupSearch": {
                        "focusSkin": "ICSknUTFBtnSSPffffff15pxBg0273e3",
                        "skin": "ICSknUTFBtnSSPffffff15pxBg0273e3",
                        "segmentProps": []
                    },
                    "flxBankClearingLookupMobHeader": {
                        "segmentProps": []
                    },
                    "flxBankClearingLookupHeader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "segBankClearingLookup": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "skin": "Copybbsknf0ed23e6160bbb45",
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "1366px"
                        },
                        "segmentProps": []
                    },
                    "flxTemplateDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "49.50%"
                        },
                        "isVisible": false,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "87.30%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateNameTitle": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateName": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalBeneficiariesTitle": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "lblTotalBeneficiaries": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDomesticTitle": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblDomestic": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "lblInternationalTitle": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblInternational": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "lblInternalTitle": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblInternal": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.85%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAckMessage": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "success_green_2.png",
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl424242SSP20Px",
                        "text": "43331575819",
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "flxTabPaneContainer": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "focusSkin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxCreateUI": {
                        "segmentProps": []
                    },
                    "flxCreateDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "tbxTemplateName": {
                        "segmentProps": []
                    },
                    "lstbFromAccount": {
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "segmentProps": []
                    },
                    "txtTransferFrom": {
                        "segmentProps": []
                    },
                    "flxFilterDropdown": {
                        "segmentProps": []
                    },
                    "flxCancelIcon": {
                        "segmentProps": []
                    },
                    "flxTypeIcon": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "segmentProps": []
                    },
                    "lstbDefaultCurrency": {
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbProcessingMode": {
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxDate": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxExecutionDate": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "calExecutionDate": {
                        "skin": "sknBBCal42424215px",
                        "segmentProps": []
                    },
                    "tbxTemplateDescription": {
                        "segmentProps": []
                    },
                    "flxBottomSeperator": {
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnCancel": {
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnNext": {
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnOption": {
                        "segmentProps": []
                    },
                    "lblSummaryHeader": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxEditSummary": {
                        "left": {
                            "type": "string",
                            "value": "94%"
                        },
                        "top": {
                            "type": "string",
                            "value": "-18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "8%"
                        },
                        "segmentProps": []
                    },
                    "lblEditSummary": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sfc6afada351421eb1cd1f8e8d0f619d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxExecutionDateCreateBulkReq": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "calExecutionDateCreateBulkReq": {
                        "skin": "sknBBCal42424215px",
                        "segmentProps": []
                    },
                    "lblSelectEdit": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxEditDetails": {
                        "left": {
                            "type": "string",
                            "value": "79%"
                        },
                        "segmentProps": []
                    },
                    "lblEdit": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sfc6afada351421eb1cd1f8e8d0f619d",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblDropDown": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "padding": [0, 0, 0, 0],
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchSortSeparator": {
                        "width": {
                            "type": "string",
                            "value": "96.10%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblErrorMsg": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknLabelSSPFF000015Px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxViewAllRecipients": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "lblAddBeneficiariesText": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblCount": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewRemovedBeneficiaries": {
                        "centerX": {
                            "type": "string",
                            "value": "58.30%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "padding": [0, 0, 0, 0],
                        "skin": "sfc6afada351421eb1cd1f8e8d0f619d",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchBeneficiariesBox": {
                        "width": {
                            "type": "string",
                            "value": "98.10%"
                        },
                        "segmentProps": []
                    },
                    "flxApplyChanges": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblUpdateHeader": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "i18n_text": "i18n.bulkwires.changeamount",
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblPaymentReference": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxOr": {
                        "left": {
                            "type": "string",
                            "value": "870dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgOr": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "btnApplyChanges": {
                        "i18n_text": "i18n.bulkwires.Applychanges",
                        "left": {
                            "type": "string",
                            "value": "710dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Apply Changes",
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": []
                    },
                    "tbxPaymentReference": {
                        "segmentProps": []
                    },
                    "btnRemove": {
                        "accessibilityConfig": {
                            "a11yLabel": "New Transfer"
                        },
                        "i18n_text": "i18n.bulkwires.Remove",
                        "left": {
                            "type": "string",
                            "value": "950dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "text": "Remove",
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "lblRemoveBeneficiaries": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "945dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "flxApplyChangesTemplate": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "blUpdateHeader": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblChangeCurrency": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblChangeAmount": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblFeesPaid": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblPaymentRef": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSPRegular727272op10015px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lstbChangeCurrency": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "tbxChangeAmount": {
                        "segmentProps": []
                    },
                    "flxFeesPaid": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lstbFeesPaid": {
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "tbxPaymentRef": {
                        "segmentProps": []
                    },
                    "lblPaymentReferenceValidDesc": {
                        "padding": [0, 0, 0, 0],
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnApplyBeneficiaryChange": {
                        "i18n_text": "kony.mb.transfers.Apply",
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Apply Changes",
                        "segmentProps": []
                    },
                    "flxOrSeperator": {
                        "left": {
                            "type": "string",
                            "value": "870dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgTemplateOr": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "lblRemoveTemplateBeneficiaries": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "945dp"
                        },
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "btnTemplateRemove": {
                        "i18n_text": "i18n.bulkwires.Remove",
                        "left": {
                            "type": "string",
                            "value": "950dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "text": "Remove",
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxViewOnlySeletced": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblViewOnlySelected": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxStatus": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "lblStatus": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "30px"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxBeneficiaryName": {
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "left": {
                            "type": "string",
                            "value": "0.10%"
                        },
                        "width": {
                            "type": "string",
                            "value": "14.70%"
                        },
                        "segmentProps": []
                    },
                    "lblSortAmount": {
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxFeesPaidBy": {
                        "left": {
                            "type": "string",
                            "value": "11.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSelectAll": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "-1.20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectAll": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxNoRecipients": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNoTransactions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblSummaryHeader0": {
                        "segmentProps": []
                    },
                    "lblEditSummary0": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                        "padding": [0, 0, 0, 0],
                        "skin": "sfc6afada351421eb1cd1f8e8d0f619d",
                        "segmentProps": []
                    },
                    "lblEditBeneficiary": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sfc6afada351421eb1cd1f8e8d0f619d",
                        "segmentProps": []
                    },
                    "flxTabletAccountsSeparator": {
                        "segmentProps": []
                    },
                    "flxViewBankName": {
                        "left": {
                            "type": "string",
                            "value": "4.10%"
                        },
                        "width": {
                            "type": "string",
                            "value": "23.90%"
                        },
                        "segmentProps": []
                    },
                    "addBenFormActions.btnCancel": {
                        "segmentProps": []
                    },
                    "addBenFormActions.btnOption": {
                        "segmentProps": []
                    },
                    "flxViewOnlySeletcedBen": {
                        "left": {
                            "type": "string",
                            "value": "1.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblViewOnlySelectedBen": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxStatus1": {
                        "segmentProps": []
                    },
                    "lblStatus1": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipientDetailsErrorMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAddNewBeneficiaries": {
                        "segmentProps": []
                    },
                    "lblInvalidIBANInfinity": {
                        "segmentProps": []
                    },
                    "lblInvalidSwift": {
                        "segmentProps": []
                    },
                    "lbxCurrency": {
                        "right": {
                            "type": "number",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "tbxAmountValue": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnCancel": {
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnNext": {
                        "segmentProps": []
                    },
                    "addNewBeneficiaryFormActions.btnOption": {
                        "segmentProps": []
                    },
                    "lblViewTemplateHeader": {
                        "segmentProps": []
                    },
                    "lblPrimaryDetailsEdit": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sfc6afada351421eb1cd1f8e8d0f619d",
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateError": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblVTErrorMsg": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknLabelSSPFF000015Px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateName": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateValue": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateFromAccount": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateFromAccountValue": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateExecutionDate": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateExecutionDateValue": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateProcessingMode": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateProcessingModeValue": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTotalAmount": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTotalAmountValue": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTransactionsCount": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplateTransactionsCountValue": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplatePaymentDescription": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblViewTemplatePaymentDescriptionValue": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sknSSP42424215Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAddedBeneficiaries": {
                        "segmentProps": []
                    },
                    "lblAddedBeneficiaries": {
                        "padding": [0, 0, 0, 0],
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblAddedBeneficiariesCount": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblEditAddedBeneficiaries": {
                        "padding": [0, 0, 0, 0],
                        "skin": "sfc6afada351421eb1cd1f8e8d0f619d",
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxViewTemplateBenificiaryName": {
                        "segmentProps": []
                    },
                    "flxViewTemplateAmount": {
                        "segmentProps": []
                    },
                    "lblViewTemplateSortAmount": {
                        "segmentProps": []
                    },
                    "flxViewTemplateFeesPaidBy": {
                        "segmentProps": []
                    },
                    "flxViewTemplateNoRecipients": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxViewTemplatesNoTransactions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnBack": {
                        "right": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnCancel": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnNext": {
                        "right": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnOption": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.flxButtons": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.flxMain": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "width": {
                            "type": "string",
                            "value": "215dp"
                        },
                        "segmentProps": []
                    },
                    "btnDelete": {
                        "width": {
                            "type": "string",
                            "value": "215dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "width": {
                            "type": "string",
                            "value": "215dp"
                        },
                        "segmentProps": []
                    },
                    "flxLine": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "width": {
                            "type": "string",
                            "value": "1366px"
                        },
                        "segmentProps": []
                    },
                    "flxLoading": {
                        "segmentProps": []
                    },
                    "flxPopupConfirmation": {
                        "segmentProps": []
                    },
                    "flxPopupNew.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopupParent": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheader.topmenu.lblFeedback": {
                    "text": "Feedback"
                },
                "customheader.topmenu.lblHelp": {
                    "text": "Help"
                },
                "flxAcknowledgement": {
                    "successImgWidth": "4.44%",
                    "successMsg": "Your transaction has been successfully submitted\nReference Number 45423792753",
                    "right": "",
                    "top": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": ""
                },
                "flxAcknowledgementNew.flxAckContainer": {
                    "height": "85dp"
                },
                "flxAcknowledgementNew": {
                    "left": "0dp",
                    "width": "100%"
                },
                "flxAcknowledgementNew.flxImgdownload": {
                    "centerX": "",
                    "centerY": "50%",
                    "height": "22dp",
                    "left": "95%",
                    "width": "22dp"
                },
                "flxAcknowledgementNew.imgDownload": {
                    "height": "100%",
                    "src": "bbcloseicon_1.png",
                    "width": "100%"
                },
                "flxAcknowledgementNew.imgPrint": {
                    "src": "bbprint.png"
                },
                "flxAcknowledgementNew.imgTick": {
                    "src": "bulk_billpay_success.png"
                },
                "flxAcknowledgementNew.rTextSuccess": {
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "8.80%",
                    "text": "User has been Successfully Added ."
                },
                "createFlowFormActionsNew.btnBack": {
                    "centerY": "",
                    "left": "",
                    "right": "30dp",
                    "top": "0dp",
                    "width": "170dp",
                    "zIndex": 1
                },
                "createFlowFormActionsNew.btnCancel": {
                    "centerY": "",
                    "left": "",
                    "right": "30dp",
                    "top": "0dp",
                    "width": "170dp",
                    "zIndex": 1
                },
                "createFlowFormActionsNew.btnNext": {
                    "centerY": "",
                    "height": "41dp",
                    "left": "",
                    "right": "0dp",
                    "top": "0dp",
                    "width": "170dp",
                    "zIndex": 1
                },
                "createFlowFormActionsNew.btnOption": {
                    "centerY": "",
                    "left": "",
                    "right": "30dp",
                    "top": "0dp",
                    "width": "170dp",
                    "zIndex": 1
                },
                "createFlowFormActionsNew.flxButtons": {
                    "centerY": "50%",
                    "left": "2.50%",
                    "right": "2.50%"
                },
                "createFlowFormActionsNew.flxMain": {
                    "height": "100%"
                },
                "TabBodyNewBeneficiaries": {
                    "bottom": "0dp"
                },
                "TabBodyNewAddedBen": {
                    "bottom": "0dp"
                },
                "addBenFormActions.btnBack": {
                    "centerX": "",
                    "centerY": "",
                    "height": "40px",
                    "left": "",
                    "right": "30px",
                    "top": "0px",
                    "width": "170px",
                    "zIndex": 1
                },
                "addBenFormActions.btnCancel": {
                    "centerX": "",
                    "centerY": "",
                    "height": "40px",
                    "left": "",
                    "right": "30px",
                    "top": "0px",
                    "width": "170px",
                    "zIndex": 1
                },
                "addBenFormActions.btnNext": {
                    "centerX": "",
                    "centerY": "",
                    "height": "40px",
                    "left": "",
                    "right": "0px",
                    "top": "0px",
                    "width": "170px",
                    "zIndex": 1
                },
                "addBenFormActions.btnOption": {
                    "centerX": "",
                    "centerY": "",
                    "height": "40px",
                    "left": "",
                    "right": "30px",
                    "top": "0px",
                    "width": "170px",
                    "zIndex": 1
                },
                "addBenFormActions.flxButtons": {
                    "centerX": "50%",
                    "left": "",
                    "right": "",
                    "width": "94.97%"
                },
                "addNewBeneficiaryFormActions.btnBack": {
                    "bottom": "",
                    "centerY": "",
                    "height": "40dp",
                    "left": "",
                    "right": "30dp",
                    "top": "0px",
                    "width": "170dp",
                    "zIndex": 1
                },
                "addNewBeneficiaryFormActions.btnCancel": {
                    "bottom": "",
                    "centerY": "",
                    "height": "40dp",
                    "left": "",
                    "right": "30dp",
                    "top": "0px",
                    "width": "170dp",
                    "zIndex": 1
                },
                "addNewBeneficiaryFormActions.btnNext": {
                    "bottom": "",
                    "centerY": "",
                    "height": "40dp",
                    "left": "",
                    "right": "0dp",
                    "top": "0px",
                    "width": "170dp",
                    "zIndex": 1
                },
                "addNewBeneficiaryFormActions.btnOption": {
                    "bottom": "",
                    "centerY": "",
                    "height": "40dp",
                    "left": "",
                    "right": "30dp",
                    "top": "0px",
                    "width": "170dp",
                    "zIndex": 1
                },
                "addNewBeneficiaryFormActions.flxButtons": {
                    "left": "0dp",
                    "right": "",
                    "width": "100%"
                },
                "addNewBeneficiaryFormActions": {
                    "centerX": "",
                    "left": "0dp"
                },
                "PaginationContainer.flxPaginationNext": {
                    "right": "-0.50%"
                },
                "PaginationContainer.imgPaginationLast": {
                    "src": "pagination_last_active.png"
                },
                "PaginationContainer.imgPaginationNext": {
                    "src": "pagination_next_active.png"
                },
                "PaginationContainer.imgPaginationPrevious": {
                    "src": "pagination_back_inactive.png"
                },
                "PaginationContainer.lblPagination": {
                    "left": "1.50%",
                    "right": "1.50%",
                    "text": "1-03 of 03 Records"
                },
                "formActionsNew.btnBack": {
                    "height": "40dp",
                    "left": "",
                    "right": "30dp",
                    "width": "170dp"
                },
                "formActionsNew.btnCancel": {
                    "height": "40dp",
                    "left": "",
                    "right": "30dp",
                    "width": "170dp"
                },
                "formActionsNew.btnNext": {
                    "height": "40dp",
                    "left": "",
                    "right": "0dp",
                    "width": "170dp"
                },
                "formActionsNew.btnOption": {
                    "height": "40dp",
                    "left": "",
                    "right": "30dp",
                    "width": "170dp"
                },
                "formActionsNew.flxButtons": {
                    "left": "0dp",
                    "right": "",
                    "width": "100%"
                },
                "formActionsNew": {
                    "centerX": "50%"
                },
                "CommonFormActionsExt.btnBack": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "50%",
                    "height": "40dp",
                    "left": "",
                    "right": "30dp",
                    "top": "",
                    "width": "170px",
                    "zIndex": 3
                },
                "CommonFormActionsExt.btnCancel": {
                    "bottom": "",
                    "height": "40dp",
                    "left": "",
                    "right": "30dp",
                    "width": "170px",
                    "zIndex": 1
                },
                "CommonFormActionsExt.btnNext": {
                    "bottom": "",
                    "height": "40dp",
                    "left": "",
                    "right": "0dp",
                    "text": "Next",
                    "width": "170px"
                },
                "CommonFormActionsExt.btnOption": {
                    "bottom": "",
                    "centerX": "",
                    "height": "40dp",
                    "left": "",
                    "right": "30dp",
                    "top": "",
                    "width": "170px",
                    "zIndex": 2
                },
                "CommonFormActionsExt.flxButtons": {
                    "left": "",
                    "reverseLayoutDirection": false,
                    "right": "0dp",
                    "width": "100%",
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "CommonFormActionsExt.flxMain": {
                    "centerX": "",
                    "centerY": "40%",
                    "height": "100%",
                    "left": "0dp",
                    "reverseLayoutDirection": true,
                    "right": "0px",
                    "top": "0dp",
                    "width": "100%",
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "CommonFormActionsExt": {
                    "centerX": "",
                    "height": "100dp",
                    "left": "",
                    "right": "",
                    "top": "10dp",
                    "width": "100%"
                },
                "flxPopupNew.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "flxPopupNew.imgClose": {
                    "src": "bbcloseicon.png"
                },
                "BrowserSizeWarning": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(flxHeaderMain, flxFormContent, flxLogout, flxLoading, flxPopupConfirmation, flxCancelPopup, flxLookups, flxBankClearingLookup, BrowserSizeWarning);
        };
        return [{
            "addWidgets": addWidgetsfrmBulkPaymentsTemplate,
            "enabledForIdleTimeout": true,
            "id": "frmBulkPaymentsTemplate",
            "init": controller.AS_Form_gec762c980bd4e4ca24f1b609044ab5c,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_j550cf37c5924c338b095f3244d7b730,
            "postShow": controller.AS_Form_d155753eabd645e88f7492b3dd7a94a1,
            "preShow": function(eventobject) {
                controller.AS_Form_e0c28f49141f4cdbabcb40167881cba2(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "BulkPaymentsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_f61fabdce070462cb7cd8dcec31ea298,
            "retainScrollPosition": true
        }]
    }
});