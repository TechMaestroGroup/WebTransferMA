define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmViewApprovalSignatoryMatrix", function() {
    return function(controller) {
        function addWidgetsfrmViewApprovalSignatoryMatrix() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxLogoAndActionsWrapper": {
                        "width": "1366dp"
                    },
                    "flxMenuContainer": {
                        "width": "100%"
                    },
                    "flxMenuWrapper": {
                        "width": "1366dp"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var lblApprovalMatrixHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Foreign Exchange"
                },
                "id": "lblApprovalMatrixHeader",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Settings.ApprovalMatrix.approvalMatrix\")",
                "top": "20dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxAckHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "78px",
                "id": "flxAckHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "flxBoxPositiveAlert",
                "top": "30dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckHeader.setDefaultUnit(kony.flex.DP);
            var imgCheck = new kony.ui.Image2({
                "centerY": "50%",
                "height": "28dp",
                "id": "imgCheck",
                "isVisible": true,
                "left": "15dp",
                "skin": "slImage",
                "src": "selectgoal.png",
                "top": "5dp",
                "width": "28dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSuccessMessage = new kony.ui.Label({
                "id": "lblSuccessMessage",
                "isVisible": true,
                "left": "48dp",
                "skin": "sknlbl000d19sspSemiBold24px",
                "text": "Request to turn “OFF” approval matrix at customer level has been sent for approval.",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRef = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "8dp",
                "clipBounds": false,
                "height": "20dp",
                "id": "lblRef",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "48dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "80%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            lblRef.setDefaultUnit(kony.flex.DP);
            var lblRefNum = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRefNum",
                "isVisible": true,
                "left": "0dp",
                "skin": "SknLbl64727713pxSSPR",
                "text": "Reference Number:",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRefNumVal = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblRefNumVal",
                "isVisible": true,
                "left": "4dp",
                "skin": "SknLbl64727713pxSSPR",
                "text": "9f286a06-d2b0-4a49-8994-d775a2e235c0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            lblRef.add(lblRefNum, lblRefNumVal);
            flxAckHeader.add(imgCheck, lblSuccessMessage, lblRef);
            var flxAckHeaderOn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "78px",
                "id": "flxAckHeaderOn",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "flxBoxPositiveAlert",
                "top": "30dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckHeaderOn.setDefaultUnit(kony.flex.DP);
            var flximgHeaderOn = new kony.ui.Image2({
                "centerY": "50%",
                "height": "28dp",
                "id": "flximgHeaderOn",
                "isVisible": true,
                "left": "15dp",
                "skin": "slImage",
                "src": "selectgoal.png",
                "top": "5dp",
                "width": "28dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMsgOn = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblMsgOn",
                "isVisible": true,
                "left": "48dp",
                "skin": "sknlbl000d19sspSemiBold24px",
                "text": "You have successfully turned “ON” approval matrix at customer level.",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAckHeaderOn.add(flximgHeaderOn, lblMsgOn);
            var flxAcknowledgementPopup = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxAcknowledgementPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementPopup.setDefaultUnit(kony.flex.DP);
            var imgAckNotification = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "imgAckNotification",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "bulk_billpay_success.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAckNotificationContent = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAckNotificationContent",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSPReg24px",
                "text": "Approval Rule has been successfully created. ",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgAckClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "25dp",
                "id": "imgAckClose",
                "imageWhileDownloading": "closeicon.png",
                "isVisible": true,
                "left": "100dp",
                "right": "0dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAcknowledgementPopup.add(imgAckNotification, lblAckNotificationContent, imgAckClose);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "warning_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl42424224px",
                "text": "Approval Rule has been successfully created. ",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgWarningClose = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgWarningClose",
                "isVisible": false,
                "left": "0dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning, imgWarningClose);
            var flxContractContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "80px",
                "id": "flxContractContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContractContainer.setDefaultUnit(kony.flex.DP);
            var flxAccountName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountName.setDefaultUnit(kony.flex.DP);
            var lblAccountNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.account\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNameValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Checking Account….6737",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountName.add(lblAccountNameHeader, lblAccountNameValue);
            var flxCustomerName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerName.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.customerName\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerHeaderValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerHeaderValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Kony India Pvt Limited-kalyani1SB",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerName.add(lblCustomerNameHeader, lblCustomerHeaderValue);
            var flxCustomerID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerID",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerID.setDefaultUnit(kony.flex.DP);
            var lblCustomerIDHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.lblCustomerID\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerIDValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "34256452388",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerID.add(lblCustomerIDHeader, lblCustomerIDValue);
            var flxContract = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxContract",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContract.setDefaultUnit(kony.flex.DP);
            var lblContractHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.contract\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblContractValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Corp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContract.add(lblContractHeader, lblContractValue);
            flxContractContainer.add(flxAccountName, flxCustomerName, flxCustomerID, flxContract);
            var flxApprovalMatrixContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxApprovalMatrixContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "88%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixContainer.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "55dp",
                "id": "flxHeaderContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainer.setDefaultUnit(kony.flex.DP);
            var lblCustomerLevelHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerLevelHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.customerLevellbl\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderSeparator",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAccountLevelMatrix = new kony.ui.Button({
                "centerY": "50.00%",
                "height": "30dp",
                "id": "btnAccountLevelMatrix",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.accountLevelbtn\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxHeaderSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "0.50%",
                "id": "flxHeaderSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "48dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSeperator.setDefaultUnit(kony.flex.DP);
            flxHeaderSeperator.add();
            flxHeaderContainer.add(lblCustomerLevelHeader, lblHeaderSeparator, btnAccountLevelMatrix, flxHeaderSeperator);
            var flxApprovalModeSwitch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "62dp",
                "id": "flxApprovalModeSwitch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalModeSwitch.setDefaultUnit(kony.flex.DP);
            var flxApprovalMode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "55dp",
                "id": "flxApprovalMode",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "50%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMode.setDefaultUnit(kony.flex.DP);
            var lblApprovalMode = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblApprovalMode",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.approvalType\")",
                "top": 15,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApporvalModeValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblApporvalModeValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.Signatory\")",
                "top": 15,
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalMode.add(lblApprovalMode, lblApporvalModeValue);
            var flxApprovalMatrixOnOff = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "55dp",
                "id": "flxApprovalMatrixOnOff",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0",
                "width": "60%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixOnOff.setDefaultUnit(kony.flex.DP);
            var imgTurnOnOfApprovalCustLevl = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgTurnOnOfApprovalCustLevl",
                "isVisible": true,
                "right": 20,
                "src": "includetoggle.png",
                "top": "10dp",
                "width": "50dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTurnOnOfApprovalCustLevl = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTurnOnOfApprovalCustLevl",
                "isVisible": true,
                "left": "15dp",
                "right": "20dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.ApprovalMatrixEnable\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyswitchApprovals0acdb297b017e4a = new kony.ui.Switch({
                "centerY": "50%",
                "height": "32dp",
                "id": "CopyswitchApprovals0acdb297b017e4a",
                "isVisible": false,
                "right": "100dp",
                "selectedIndex": 1,
                "skin": "sknSwitchDisableMatrix",
                "top": "0",
                "width": "50dp"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixOnOff.add(imgTurnOnOfApprovalCustLevl, lblTurnOnOfApprovalCustLevl, CopyswitchApprovals0acdb297b017e4a);
            var flxSeparatorApprovalMode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "0.50%",
                "id": "flxSeparatorApprovalMode",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "60dp",
                "width": "98%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorApprovalMode.setDefaultUnit(kony.flex.DP);
            flxSeparatorApprovalMode.add();
            flxApprovalModeSwitch.add(flxApprovalMode, flxApprovalMatrixOnOff, flxSeparatorApprovalMode);
            var flxApprovalDetailsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalDetailsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalDetailsContainer.setDefaultUnit(kony.flex.DP);
            var flxFeatuersContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFeatuersContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "30%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeatuersContainer.setDefaultUnit(kony.flex.DP);
            var flxSwitchContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80dp",
                "id": "flxSwitchContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwitchContainer.setDefaultUnit(kony.flex.DP);
            var lblSwitchSeparator = new kony.ui.Label({
                "bottom": "0dp",
                "height": "1dp",
                "id": "lblSwitchSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoApprovalsRequire = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNoApprovalsRequire",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.i18n.approvalMatrix.NoApprovalsRequired\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var switchApprovals = new kony.ui.Switch({
                "centerY": "50%",
                "height": "32dp",
                "id": "switchApprovals",
                "isVisible": true,
                "right": "100dp",
                "selectedIndex": 1,
                "skin": "sknSwitchDisableMatrix",
                "top": "0",
                "width": "50dp"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSwitchContainer.add(lblSwitchSeparator, lblNoApprovalsRequire, switchApprovals);
            var lblFeaturesHeader = new kony.ui.Label({
                "id": "lblFeaturesHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.features\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFeatureSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblFeatureSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "20dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBoxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBoxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "20dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoxSearch.setDefaultUnit(kony.flex.DP);
            var flxSearchimg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSearchimg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "width": "7%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchimg.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgSearch",
                "isVisible": true,
                "skin": "slImage",
                "src": "search.png",
                "width": "40dp",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchimg.add(imgSearch);
            var tbxSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxa0a0a0Ssp15px",
                "height": "99%",
                "id": "tbxSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "42px",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.Searchforfeaturesactions\")",
                "right": "40px",
                "secureTextEntry": false,
                "skin": "ICSknTbxPlaceholderSSP72727215px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "80%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "ICSknTbxPlaceholderSSP72727213px"
            });
            flxBoxSearch.add(flxSearchimg, tbxSearch);
            var lblSearchSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblSearchSeparator",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "20dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFeatureList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFeatureList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeatureList.setDefaultUnit(kony.flex.DP);
            var Features = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "Features",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxBlankLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxBlankLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBlankLine.setDefaultUnit(kony.flex.DP);
            flxBlankLine.add();
            flxFeatureList.add(Features, flxBlankLine);
            flxFeatuersContainer.add(flxSwitchContainer, lblFeaturesHeader, lblFeatureSeparator, flxBoxSearch, lblSearchSeparator, flxFeatureList);
            var flxApprovalRulesContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalRulesContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "30.10%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "69.50%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalRulesContainer.setDefaultUnit(kony.flex.DP);
            var flxFreatureDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFreatureDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFreatureDetails.setDefaultUnit(kony.flex.DP);
            var lblViewEditHeader = new kony.ui.Label({
                "id": "lblViewEditHeader",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.ManageRule\")",
                "top": "20dp",
                "width": "20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSelectedFeature = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSelectedFeature",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "20dp",
                "width": "85%",
                "zIndex": 2,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectedFeature.setDefaultUnit(kony.flex.DP);
            var lblSelectedFeatureValue = new kony.ui.Label({
                "id": "lblSelectedFeatureValue",
                "isVisible": true,
                "left": 10,
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Transfer to own account within same fine",
                "top": "0dp",
                "width": "50%",
                "blur": {
                    "enabled": false,
                    "value": 0
                }
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFeatureTitle = new kony.ui.Label({
                "id": "lblFeatureTitle",
                "isVisible": true,
                "right": "0dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.feature\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSelectedFeature.add(lblSelectedFeatureValue, lblFeatureTitle);
            flxFreatureDetails.add(lblViewEditHeader, flxSelectedFeature);
            var lblViewEditHeaderSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblViewEditHeaderSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "20dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApprovalMatrixAccountWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalMatrixAccountWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixAccountWrapper.setDefaultUnit(kony.flex.DP);
            var segApprovalMatrix = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "data": [
                    [{
                            "btnEditMatrix": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                            "lblApprovalLimits": "Label",
                            "lblApprovalRule": "Label",
                            "lblApprovers": "Label",
                            "lblFeatureAction": "Label",
                            "lblNumOfApprovers": "Label",
                            "lblSeparator2": "",
                            "lblSeparator3": ""
                        },
                        [{
                            "imgNoRecordsIcon": "info_grey.png",
                            "imgRowExpand": "arrow_down.png",
                            "lblApprovalLimitsValue": "Label",
                            "lblApproverRequired": "Label",
                            "lblNoApprovalRulesDefined": "No  approval rules set for this feature action",
                            "lblSeparator1": ""
                        }]
                    ],
                    [{
                            "btnEditMatrix": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                            "lblApprovalLimits": "Label",
                            "lblApprovalRule": "Label",
                            "lblApprovers": "Label",
                            "lblFeatureAction": "Label",
                            "lblNumOfApprovers": "Label",
                            "lblSeparator2": "",
                            "lblSeparator3": ""
                        },
                        [{
                            "imgNoRecordsIcon": "info_grey.png",
                            "imgRowExpand": "arrow_down.png",
                            "lblApprovalLimitsValue": "Label",
                            "lblApproverRequired": "Label",
                            "lblNoApprovalRulesDefined": "No  approval rules set for this feature action",
                            "lblSeparator1": ""
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segApprovalMatrix",
                "isVisible": false,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxSegApprovalMatrixRow"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixSection"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnEditMatrix": "btnEditMatrix",
                    "flxApprovalMatrixSection": "flxApprovalMatrixSection",
                    "flxHeaderLowerHalf": "flxHeaderLowerHalf",
                    "flxHeaderUpperHalf": "flxHeaderUpperHalf",
                    "flxLimit1": "flxLimit1",
                    "flxNoRecords": "flxNoRecords",
                    "flxSegApprovalMatrixRow": "flxSegApprovalMatrixRow",
                    "imgNoRecordsIcon": "imgNoRecordsIcon",
                    "imgRowExpand": "imgRowExpand",
                    "lblApprovalLimits": "lblApprovalLimits",
                    "lblApprovalLimitsValue": "lblApprovalLimitsValue",
                    "lblApprovalRule": "lblApprovalRule",
                    "lblApproverRequired": "lblApproverRequired",
                    "lblApprovers": "lblApprovers",
                    "lblFeatureAction": "lblFeatureAction",
                    "lblNoApprovalRulesDefined": "lblNoApprovalRulesDefined",
                    "lblNumOfApprovers": "lblNumOfApprovers",
                    "lblSeparator1": "lblSeparator1",
                    "lblSeparator2": "lblSeparator2",
                    "lblSeparator3": "lblSeparator3"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPTRMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPTRMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "11dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPTRMain.setDefaultUnit(kony.flex.DP);
            var flxPerTransactionRules = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPerTransactionRules",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPerTransactionRules.setDefaultUnit(kony.flex.DP);
            var flxPTRHeaderUpper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPTRHeaderUpper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "50dp",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPTRHeaderUpper.setDefaultUnit(kony.flex.DP);
            var lblPTRFeatureAction = new kony.ui.Label({
                "bottom": "15dp",
                "id": "lblPTRFeatureAction",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBBLabelSSPSB42424216px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.PerTransactionRules\")",
                "top": "15dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnPTRCreateMatrix = new kony.ui.Button({
                "bottom": "15dp",
                "focusSkin": "bbSknBtn4176A4TransparentBgSSP15px",
                "height": "20dp",
                "id": "btnPTRCreateMatrix",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176A4TransparentBgSSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.CreateRule\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnPTREditRule = new kony.ui.Button({
                "bottom": "15dp",
                "focusSkin": "bbSknBtn4176A4TransparentBgSSP15px",
                "height": "20dp",
                "id": "btnPTREditRule",
                "isVisible": false,
                "right": "20dp",
                "skin": "bbSknBtn4176A4TransparentBgSSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.EditRule\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPTRHeaderUpper.add(lblPTRFeatureAction, btnPTRCreateMatrix, btnPTREditRule);
            var flxPTRApprovalPending = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxPTRApprovalPending",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPTRApprovalPending.setDefaultUnit(kony.flex.DP);
            var imgPTRApprovalPending = new kony.ui.Image2({
                "height": "24dp",
                "id": "imgPTRApprovalPending",
                "isVisible": true,
                "left": "20dp",
                "src": "warning_yellow.png",
                "top": "0dp",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPTRApprovalPending = new kony.ui.Label({
                "id": "lblPTRApprovalPending",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvalMatrix.pendingChangesRequireApprovalCustomer\")",
                "top": "3dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPTRApprovalPending.add(imgPTRApprovalPending, lblPTRApprovalPending);
            var lblPTRSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblPTRSeparator1",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPTRHeaderLower = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPTRHeaderLower",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "43dp",
                "isModalContainer": false,
                "skin": "sknFlxBackgroundfbfbfb",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPTRHeaderLower.setDefaultUnit(kony.flex.DP);
            var lblPTRApprovalLimits = new kony.ui.Label({
                "id": "lblPTRApprovalLimits",
                "isVisible": true,
                "left": "3.33%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.ApprovalRange\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPTRApprovers = new kony.ui.Label({
                "id": "lblPTRApprovers",
                "isVisible": true,
                "left": "25%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.approvalRequired\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPTRHeaderLower.add(lblPTRApprovalLimits, lblPTRApprovers);
            var lblPTRSeparator2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblPTRSeparator2",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPTRApprovalListValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPTRApprovalListValues",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPTRApprovalListValues.setDefaultUnit(kony.flex.DP);
            var lblPTRValueSeparatorDup = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "bottom": "0dp",
                "centerX": "50%",
                "height": "1px",
                "id": "lblPTRValueSeparatorDup",
                "isVisible": false,
                "skin": "sknSeparatore3e3e3",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPTRApprovalListValues.add(lblPTRValueSeparatorDup);
            flxPerTransactionRules.add(flxPTRHeaderUpper, flxPTRApprovalPending, lblPTRSeparator1, flxPTRHeaderLower, lblPTRSeparator2, flxPTRApprovalListValues);
            var flxPTRNoRecords = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "35dp",
                "clipBounds": true,
                "id": "flxPTRNoRecords",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35dp",
                "width": "80%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPTRNoRecords.setDefaultUnit(kony.flex.DP);
            var imgPTRNoRecordsIcon = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgPTRNoRecordsIcon",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "30dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPTRNoApprovalRulesDefined = new kony.ui.Label({
                "id": "lblPTRNoApprovalRulesDefined",
                "isVisible": true,
                "left": "40dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalmatrix.customerlevelrule\")",
                "top": "5dp",
                "width": "80%",
                "zIndex": 100
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPTRNoRecords.add(imgPTRNoRecordsIcon, lblPTRNoApprovalRulesDefined);
            var lblPTRSeparator3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblPTRSeparator3",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPTRMain.add(flxPerTransactionRules, flxPTRNoRecords, lblPTRSeparator3);
            var flxDailyLimitsMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDailyLimitsMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "11dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyLimitsMain.setDefaultUnit(kony.flex.DP);
            var flxDailyLimitsRules = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDailyLimitsRules",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyLimitsRules.setDefaultUnit(kony.flex.DP);
            var flxDailyLimitsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDailyLimitsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "50dp",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyLimitsHeader.setDefaultUnit(kony.flex.DP);
            var lblDailyLimitsFeatureAction = new kony.ui.Label({
                "bottom": "15dp",
                "id": "lblDailyLimitsFeatureAction",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBBLabelSSPSB42424216px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.DailyTransactionRules\")",
                "top": "15dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCreateDailyLimitsMatrix = new kony.ui.Button({
                "bottom": "15dp",
                "focusSkin": "bbSknBtn4176A4TransparentBgSSP15px",
                "height": "20dp",
                "id": "btnCreateDailyLimitsMatrix",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176A4TransparentBgSSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.CreateRule\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEditDailyLimitsMatrix = new kony.ui.Button({
                "bottom": "15dp",
                "focusSkin": "bbSknBtn4176A4TransparentBgSSP15px",
                "height": "20dp",
                "id": "btnEditDailyLimitsMatrix",
                "isVisible": false,
                "right": "20dp",
                "skin": "bbSknBtn4176A4TransparentBgSSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.EditRule\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyLimitsHeader.add(lblDailyLimitsFeatureAction, btnCreateDailyLimitsMatrix, btnEditDailyLimitsMatrix);
            var flxDailyLimitsApprovalPending = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxDailyLimitsApprovalPending",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyLimitsApprovalPending.setDefaultUnit(kony.flex.DP);
            var imgDailyLimitsApprovalPending = new kony.ui.Image2({
                "height": "24dp",
                "id": "imgDailyLimitsApprovalPending",
                "isVisible": true,
                "left": "20dp",
                "src": "warning_yellow.png",
                "top": "0dp",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDailyLimitsApprovalPending = new kony.ui.Label({
                "id": "lblDailyLimitsApprovalPending",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvalMatrix.pendingChangesRequireApprovalCustomer\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyLimitsApprovalPending.add(imgDailyLimitsApprovalPending, lblDailyLimitsApprovalPending);
            var lblDailyLimitsSeparator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblDailyLimitsSeparator",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDailyLimitsHeaderLower = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDailyLimitsHeaderLower",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "43dp",
                "isModalContainer": false,
                "skin": "sknFlxBackgroundfbfbfb",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyLimitsHeaderLower.setDefaultUnit(kony.flex.DP);
            var lblDailyLimitsApprovalLimit = new kony.ui.Label({
                "id": "lblDailyLimitsApprovalLimit",
                "isVisible": true,
                "left": "3.33%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.ApprovalRange\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDailyLimitsApprovers = new kony.ui.Label({
                "id": "lblDailyLimitsApprovers",
                "isVisible": true,
                "left": "25%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.approvalRequired\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyLimitsHeaderLower.add(lblDailyLimitsApprovalLimit, lblDailyLimitsApprovers);
            var lblDailyLimitsSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblDailyLimitsSeparator1",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDailyApprovalListValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDailyApprovalListValues",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyApprovalListValues.setDefaultUnit(kony.flex.DP);
            var lblDailyValueSeparatorDup = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "height": "1px",
                "id": "lblDailyValueSeparatorDup",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": "1dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDailyLimitsDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDailyLimitsDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "95dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "46dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyLimitsDetails.setDefaultUnit(kony.flex.DP);
            flxDailyLimitsDetails.add();
            flxDailyApprovalListValues.add(lblDailyValueSeparatorDup, flxDailyLimitsDetails);
            flxDailyLimitsRules.add(flxDailyLimitsHeader, flxDailyLimitsApprovalPending, lblDailyLimitsSeparator, flxDailyLimitsHeaderLower, lblDailyLimitsSeparator1, flxDailyApprovalListValues);
            var flxDailyLimitsNoRecords = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "35dp",
                "clipBounds": true,
                "id": "flxDailyLimitsNoRecords",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35dp",
                "width": "80%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyLimitsNoRecords.setDefaultUnit(kony.flex.DP);
            var imgDailyLimitsNoRecordsIcon = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgDailyLimitsNoRecordsIcon",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "30dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDailyLimitsNoApprovalRulesDefined = new kony.ui.Label({
                "id": "lblDailyLimitsNoApprovalRulesDefined",
                "isVisible": true,
                "left": "40dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalmatrix.customerlevelrule\")",
                "top": "5dp",
                "width": "80%",
                "zIndex": 100
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyLimitsNoRecords.add(imgDailyLimitsNoRecordsIcon, lblDailyLimitsNoApprovalRulesDefined);
            var lblDailyLimitsSeparator3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblDailyLimitsSeparator3",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDailyLimitsMain.add(flxDailyLimitsRules, flxDailyLimitsNoRecords, lblDailyLimitsSeparator3);
            var flxWeeklyLimitsMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWeeklyLimitsMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsMain.setDefaultUnit(kony.flex.DP);
            var flxWeeklyLimitsRules = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWeeklyLimitsRules",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsRules.setDefaultUnit(kony.flex.DP);
            var flxWeeklyLimitsHeaderUpper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWeeklyLimitsHeaderUpper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "50dp",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsHeaderUpper.setDefaultUnit(kony.flex.DP);
            var lblWeeklyLimitsFeatureAction = new kony.ui.Label({
                "bottom": "15dp",
                "id": "lblWeeklyLimitsFeatureAction",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBBLabelSSPSB42424216px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.WeeklyTransactionRules\")",
                "top": "15dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnWeeklyLimitsCreateMatrix = new kony.ui.Button({
                "bottom": "15dp",
                "focusSkin": "bbSknBtn4176A4TransparentBgSSP15px",
                "height": "20dp",
                "id": "btnWeeklyLimitsCreateMatrix",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176A4TransparentBgSSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.CreateRule\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnWeeklyLimitsEditMatrix = new kony.ui.Button({
                "bottom": "15dp",
                "focusSkin": "bbSknBtn4176A4TransparentBgSSP15px",
                "height": "20dp",
                "id": "btnWeeklyLimitsEditMatrix",
                "isVisible": false,
                "right": "20dp",
                "skin": "bbSknBtn4176A4TransparentBgSSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.EditRule\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsHeaderUpper.add(lblWeeklyLimitsFeatureAction, btnWeeklyLimitsCreateMatrix, btnWeeklyLimitsEditMatrix);
            var flxWeeklyLimitsApprovalPending = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxWeeklyLimitsApprovalPending",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsApprovalPending.setDefaultUnit(kony.flex.DP);
            var imgWeeklyLimitsApprovalPending = new kony.ui.Image2({
                "height": "24dp",
                "id": "imgWeeklyLimitsApprovalPending",
                "isVisible": true,
                "left": "20dp",
                "src": "warning_yellow.png",
                "top": "0dp",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWeeklyLimitsApprovalPending = new kony.ui.Label({
                "id": "lblWeeklyLimitsApprovalPending",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvalMatrix.pendingChangesRequireApprovalCustomer\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsApprovalPending.add(imgWeeklyLimitsApprovalPending, lblWeeklyLimitsApprovalPending);
            var lblWeeklyLimitsSeparator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblWeeklyLimitsSeparator",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWeeklyLimitsHeaderLower = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWeeklyLimitsHeaderLower",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "43dp",
                "isModalContainer": false,
                "skin": "sknFlxBackgroundfbfbfb",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsHeaderLower.setDefaultUnit(kony.flex.DP);
            var lblWeeklyApprovalLimits = new kony.ui.Label({
                "id": "lblWeeklyApprovalLimits",
                "isVisible": true,
                "left": "3.33%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.ApprovalRange\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWeeklyLimitsApprovers = new kony.ui.Label({
                "id": "lblWeeklyLimitsApprovers",
                "isVisible": true,
                "left": "25%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.approvalRequired\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsHeaderLower.add(lblWeeklyApprovalLimits, lblWeeklyLimitsApprovers);
            var lblWeeklyLimitsSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblWeeklyLimitsSeparator1",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWeeklyApprovalListValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWeeklyApprovalListValues",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyApprovalListValues.setDefaultUnit(kony.flex.DP);
            flxWeeklyApprovalListValues.add();
            flxWeeklyLimitsRules.add(flxWeeklyLimitsHeaderUpper, flxWeeklyLimitsApprovalPending, lblWeeklyLimitsSeparator, flxWeeklyLimitsHeaderLower, lblWeeklyLimitsSeparator1, flxWeeklyApprovalListValues);
            var flxWeeklyLimitsNoRecords = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "35dp",
                "clipBounds": true,
                "id": "flxWeeklyLimitsNoRecords",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "35dp",
                "width": "80%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsNoRecords.setDefaultUnit(kony.flex.DP);
            var imgWeeklyLimitsNoRecordsIcon = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgWeeklyLimitsNoRecordsIcon",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "30dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWeeklyLimitsNoApprovalRulesDefined = new kony.ui.Label({
                "id": "lblWeeklyLimitsNoApprovalRulesDefined",
                "isVisible": true,
                "left": "40dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalmatrix.customerlevelrule\")",
                "top": "5dp",
                "width": "80%",
                "zIndex": 100
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsNoRecords.add(imgWeeklyLimitsNoRecordsIcon, lblWeeklyLimitsNoApprovalRulesDefined);
            var lblWeeklyLimitsSeparator3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblWeeklyLimitsSeparator3",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWeeklyLimitsMain.add(flxWeeklyLimitsRules, flxWeeklyLimitsNoRecords, lblWeeklyLimitsSeparator3);
            var flxNoApprovalMatrixData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxNoApprovalMatrixData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "53dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoApprovalMatrixData.setDefaultUnit(kony.flex.DP);
            var lblNoApprovalMatrixData = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblNoApprovalMatrixData",
                "isVisible": true,
                "left": "151dp",
                "skin": "bbSknLbl424242SSP20PxBold",
                "text": "Label",
                "top": "40dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoApprovalMatrixData.add(lblNoApprovalMatrixData);
            flxApprovalMatrixAccountWrapper.add(segApprovalMatrix, flxPTRMain, flxDailyLimitsMain, flxWeeklyLimitsMain, flxNoApprovalMatrixData);
            var flxApprovalMatrixAccountWrapper1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalMatrixAccountWrapper1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixAccountWrapper1.setDefaultUnit(kony.flex.DP);
            flxApprovalMatrixAccountWrapper1.add();
            var flxApprovalNonMonetaryAccountWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalNonMonetaryAccountWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalNonMonetaryAccountWrapper.setDefaultUnit(kony.flex.DP);
            var flxNonMonetaryMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNonMonetaryMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "11dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryMain.setDefaultUnit(kony.flex.DP);
            var flxPerNonMonetaryRules = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPerNonMonetaryRules",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPerNonMonetaryRules.setDefaultUnit(kony.flex.DP);
            var flxNonMontaryHeaderUpper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNonMontaryHeaderUpper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "50dp",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMontaryHeaderUpper.setDefaultUnit(kony.flex.DP);
            var lblNonMonetaryFeatureAction = new kony.ui.Label({
                "bottom": "15dp",
                "id": "lblNonMonetaryFeatureAction",
                "isVisible": false,
                "left": "20dp",
                "skin": "sknBBLabelSSPSB42424216px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Settings.ApprovalMatrix.perTransactionLimit\")",
                "top": "15dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNonMonetaryApprovalPending = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxNonMonetaryApprovalPending",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApprovalPending.setDefaultUnit(kony.flex.DP);
            var imgNonMonetaryApprovalPending = new kony.ui.Image2({
                "centerY": "50%",
                "height": "24dp",
                "id": "imgNonMonetaryApprovalPending",
                "isVisible": true,
                "left": "20dp",
                "src": "warning_yellow.png",
                "top": "0dp",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNonMonetaryApprovalPending = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNonMonetaryApprovalPending",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvalMatrix.pendingChangesRequireApprovalCustomer\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApprovalPending.add(imgNonMonetaryApprovalPending, lblNonMonetaryApprovalPending);
            var btnNonMonetaryCreateMatrix = new kony.ui.Button({
                "bottom": "15dp",
                "focusSkin": "bbSknBtn4176A4TransparentBgSSP15px",
                "height": "20dp",
                "id": "btnNonMonetaryCreateMatrix",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176A4TransparentBgSSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.CreateRule\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnNonMonetaryEditRule = new kony.ui.Button({
                "bottom": "15dp",
                "focusSkin": "bbSknBtn4176A4TransparentBgSSP15px",
                "height": "20dp",
                "id": "btnNonMonetaryEditRule",
                "isVisible": false,
                "right": "20dp",
                "skin": "bbSknBtn4176A4TransparentBgSSP15px",
                "text": "Edit Rule",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNonMontaryHeaderUpper.add(lblNonMonetaryFeatureAction, flxNonMonetaryApprovalPending, btnNonMonetaryCreateMatrix, btnNonMonetaryEditRule);
            var lblNonMonetarySeparator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblNonMonetarySeparator",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": 0,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNonMonetaryHeaderLower = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNonMonetaryHeaderLower",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "43dp",
                "isModalContainer": false,
                "skin": "sknFlxBackgroundfbfbfb",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryHeaderLower.setDefaultUnit(kony.flex.DP);
            var lblMonetaryApprovers = new kony.ui.Label({
                "id": "lblMonetaryApprovers",
                "isVisible": true,
                "left": "3.33%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.approvalRequired\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMonetaryApproverslimits = new kony.ui.Label({
                "id": "lblMonetaryApproverslimits",
                "isVisible": false,
                "left": "25%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.approvalRequired\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNonMonetaryHeaderLower.add(lblMonetaryApprovers, lblMonetaryApproverslimits);
            var lblNonMonetarySeparator0 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "centerX": "50%",
                "height": "1px",
                "id": "lblNonMonetarySeparator0",
                "isVisible": true,
                "skin": "sknSeparatore3e3e3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNonMonetaryApprovalListValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNonMonetaryApprovalListValues",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApprovalListValues.setDefaultUnit(kony.flex.DP);
            var flxNonMonetaryApproval = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "50dp",
                "id": "flxNonMonetaryApproval",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApproval.setDefaultUnit(kony.flex.DP);
            var lblNonMonetaryRequiredValue = new kony.ui.Label({
                "id": "lblNonMonetaryRequiredValue",
                "isVisible": true,
                "left": "3.33%",
                "skin": "sknlbla0a0a015px",
                "text": "Label",
                "top": "15dp",
                "width": "15%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNonMonetaryRowExpandIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxNonMonetaryRowExpandIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "slFbox",
                "top": "15dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryRowExpandIcon.setDefaultUnit(kony.flex.DP);
            var imgNonMonetaryRowExandIcon = new kony.ui.Image2({
                "height": "100%",
                "id": "imgNonMonetaryRowExandIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "dropdown_expand.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNonMonetaryRowExpandIcon.add(imgNonMonetaryRowExandIcon);
            flxNonMonetaryApproval.add(lblNonMonetaryRequiredValue, flxNonMonetaryRowExpandIcon);
            var flxNonMonetaryDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNonMonetaryDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSkn4176A4LeftBdr5px",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryDetails.setDefaultUnit(kony.flex.DP);
            var lblNonMonetarySeparatorUp = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": " "
                },
                "centerX": "50%",
                "height": "1dp",
                "id": "lblNonMonetarySeparatorUp",
                "isVisible": true,
                "skin": "ICSknLabelBgDBDBDB",
                "text": " ",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNonMonetaryApprovalDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxNonMonetaryApprovalDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApprovalDetails.setDefaultUnit(kony.flex.DP);
            var lblPTRApprovalRequiredValueDetails = new kony.ui.Label({
                "id": "lblPTRApprovalRequiredValueDetails",
                "isVisible": true,
                "left": "3.33%",
                "skin": "sknlbla0a0a015px",
                "text": "Label",
                "top": "15dp",
                "width": "15%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgNonMonetaryRowExpandDetails = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgNonMonetaryRowExpandDetails",
                "isVisible": true,
                "right": "30dp",
                "skin": "slImage",
                "src": "arrow_down.png",
                "top": "15dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApprovalDetails.add(lblPTRApprovalRequiredValueDetails, imgNonMonetaryRowExpandDetails);
            var lblSeparatorNonMonetaryDown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": " "
                },
                "centerX": "50%",
                "height": "1dp",
                "id": "lblSeparatorNonMonetaryDown",
                "isVisible": true,
                "skin": "ICSknLabelBgDBDBDB",
                "text": " ",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNonMonetaryHeaderApprovalConditons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNonMonetaryHeaderApprovalConditons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "50dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryHeaderApprovalConditons.setDefaultUnit(kony.flex.DP);
            var lblNonMonetaryApprovalConditons = new kony.ui.Label({
                "bottom": "5dp",
                "id": "lblNonMonetaryApprovalConditons",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBBLabelSSPSB42424216px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.approvalcondition\")",
                "top": "25dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNonMonetaryHeaderApprovalConditons.add(lblNonMonetaryApprovalConditons);
            var flxNonMonetaryApprovalMatrixDetail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNonMonetaryApprovalMatrixDetail",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApprovalMatrixDetail.setDefaultUnit(kony.flex.DP);
            var flxNonMonetaryApprovalCondition = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNonMonetaryApprovalCondition",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApprovalCondition.setDefaultUnit(kony.flex.DP);
            var lblApproveIfNonMonetary = new kony.ui.Label({
                "id": "lblApproveIfNonMonetary",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknSSPRegular42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvals.ApproveIf\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApprovalCondition.add(lblApproveIfNonMonetary);
            flxNonMonetaryApprovalMatrixDetail.add(flxNonMonetaryApprovalCondition);
            var flxNonMonetaryApprovalConditionDetail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNonMonetaryApprovalConditionDetail",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApprovalConditionDetail.setDefaultUnit(kony.flex.DP);
            flxNonMonetaryApprovalConditionDetail.add();
            flxNonMonetaryDetails.add(lblNonMonetarySeparatorUp, flxNonMonetaryApprovalDetails, lblSeparatorNonMonetaryDown, flxNonMonetaryHeaderApprovalConditons, flxNonMonetaryApprovalMatrixDetail, flxNonMonetaryApprovalConditionDetail);
            var lblNonMonetaryValueSeparator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "randomValue"
                },
                "bottom": "0dp",
                "centerX": "50%",
                "height": "1px",
                "id": "lblNonMonetaryValueSeparator",
                "isVisible": true,
                "left": "0",
                "skin": "sknSeparatore3e3e3",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNonMonetaryApprovalListValues.add(flxNonMonetaryApproval, flxNonMonetaryDetails, lblNonMonetaryValueSeparator);
            flxPerNonMonetaryRules.add(flxNonMontaryHeaderUpper, lblNonMonetarySeparator, flxNonMonetaryHeaderLower, lblNonMonetarySeparator0, flxNonMonetaryApprovalListValues);
            var flxNonMonetaryNoRecords = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": true,
                "id": "flxNonMonetaryNoRecords",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "80%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNonMonetaryNoRecords.setDefaultUnit(kony.flex.DP);
            var imgNonMonetaryNoRecordsIcon = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgNonMonetaryNoRecordsIcon",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0dp",
                "width": "30dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNonMonetaryNoApprovalRulesDefined = new kony.ui.Label({
                "id": "lblNonMonetaryNoApprovalRulesDefined",
                "isVisible": true,
                "left": "40dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.Noapprovalrulessetforthisfeatureaction\")",
                "top": "5dp",
                "width": "80%",
                "zIndex": 100
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNonMonetaryNoRecords.add(imgNonMonetaryNoRecordsIcon, lblNonMonetaryNoApprovalRulesDefined);
            flxNonMonetaryMain.add(flxPerNonMonetaryRules, flxNonMonetaryNoRecords);
            flxApprovalNonMonetaryAccountWrapper.add(flxNonMonetaryMain);
            flxApprovalRulesContainer.add(flxFreatureDetails, lblViewEditHeaderSeparator, flxApprovalMatrixAccountWrapper, flxApprovalMatrixAccountWrapper1, flxApprovalNonMonetaryAccountWrapper);
            var lblFeatuesSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "id": "lblFeatuesSeparator",
                "isVisible": true,
                "left": "30%",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 15
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalDetailsContainer.add(flxFeatuersContainer, flxApprovalRulesContainer, lblFeatuesSeparator);
            var flxBackContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBackContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainer.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparator = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "50dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "top": "0",
                "width": "175dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainer.add(lblBottomSeparator, btnBack);
            flxApprovalMatrixContainer.add(flxHeaderContainer, flxApprovalModeSwitch, flxApprovalDetailsContainer, flxBackContainer);
            var flxSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "1200dp",
                "id": "flxSignatoryGroups",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "88%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var flxHeaderContainerSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxHeaderContainerSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContainerSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var lblCustomerLevelHeaderrSignatoryGroups = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerLevelHeaderrSignatoryGroups",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.SignatoryGroups.viewManage\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeaderSeparatorrSignatoryGroups = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblHeaderSeparatorrSignatoryGroups",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCreateNewGroup = new kony.ui.Button({
                "centerY": "50%",
                "height": "30dp",
                "id": "btnCreateNewGroup",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"konybb.SignaotryGoup.CreateNewGroup\")",
                "top": "0",
                "width": "200dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderContainerSignatoryGroups.add(lblCustomerLevelHeaderrSignatoryGroups, lblHeaderSeparatorrSignatoryGroups, btnCreateNewGroup);
            var flxSearchContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100dp",
                "id": "flxSearchContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchContainer.setDefaultUnit(kony.flex.DP);
            var flxBoxSearchSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxBoxSearchSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "width": "95%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoxSearchSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var flxSearchimgSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSearchimgSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15px",
                "isModalContainer": false,
                "skin": "skne3e3e3Bor",
                "width": "17px",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchimgSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var imgSearchSignatoryGroups = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "40dp",
                "id": "imgSearchSignatoryGroups",
                "isVisible": true,
                "skin": "slImage",
                "src": "search.png",
                "width": "40dp",
                "zIndex": 10
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchimgSignatoryGroups.add(imgSearchSignatoryGroups);
            var tbxSearchSignatoryGroups = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTbxa0a0a0Ssp15px",
                "height": "100%",
                "id": "tbxSearchSignatoryGroups",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "42px",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"konybb.SignatoryGroups.SearchPlaceHolder\")",
                "right": "40px",
                "secureTextEntry": false,
                "skin": "bbSknTbx949494SSP15pxItalic",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "bbSknTbx949494SSP15pxItalic"
            });
            flxBoxSearchSignatoryGroups.add(flxSearchimgSignatoryGroups, tbxSearchSignatoryGroups);
            flxSearchContainer.add(flxBoxSearchSignatoryGroups);
            var flxSegSignatoryGroups = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSegSignatoryGroups",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "145dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegSignatoryGroups.setDefaultUnit(kony.flex.DP);
            var segSignatoryGroups = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgContractSort": "sorting.png",
                            "imgCustomerNameSort": "sorting.png",
                            "lblActionHeader": "Action",
                            "lblBottomSepartor": "-",
                            "lblContractHeader": "Contract",
                            "lblCustomerIDHeader": "Customer ID",
                            "lblCustomerNameHeader": "Customer Name",
                            "lblTopSeparator": "-"
                        },
                        [{
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }]
                    ],
                    [{
                            "imgContractSort": "sorting.png",
                            "imgCustomerNameSort": "sorting.png",
                            "lblActionHeader": "Action",
                            "lblBottomSepartor": "-",
                            "lblContractHeader": "Contract",
                            "lblCustomerIDHeader": "Customer ID",
                            "lblCustomerNameHeader": "Customer Name",
                            "lblTopSeparator": "-"
                        },
                        [{
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }, {
                            "btnAction": "View/Edit Matrix",
                            "lblContract": "Contract",
                            "lblCustomerID": "Customer ID",
                            "lblCustomerName": "Customer Name",
                            "lblNoRecords": "Label",
                            "lblRowSeparator": "-"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segSignatoryGroups",
                "isVisible": true,
                "left": "0dp",
                "minHeight": "250dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixContractRow"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalMatrixMA",
                    "friendlyName": "flxApprovalMatrixContractHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnAction": "btnAction",
                    "flxApprovalMatrixContractHeader": "flxApprovalMatrixContractHeader",
                    "flxApprovalMatrixContractRow": "flxApprovalMatrixContractRow",
                    "flxContract": "flxContract",
                    "flxCustomerName": "flxCustomerName",
                    "flxHeadersContainer": "flxHeadersContainer",
                    "flxNoRecords": "flxNoRecords",
                    "imgContractSort": "imgContractSort",
                    "imgCustomerNameSort": "imgCustomerNameSort",
                    "lblActionHeader": "lblActionHeader",
                    "lblBottomSepartor": "lblBottomSepartor",
                    "lblContract": "lblContract",
                    "lblContractHeader": "lblContractHeader",
                    "lblCustomerID": "lblCustomerID",
                    "lblCustomerIDHeader": "lblCustomerIDHeader",
                    "lblCustomerName": "lblCustomerName",
                    "lblCustomerNameHeader": "lblCustomerNameHeader",
                    "lblNoRecords": "lblNoRecords",
                    "lblRowSeparator": "lblRowSeparator",
                    "lblTopSeparator": "lblTopSeparator"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegSignatoryGroups.add(segSignatoryGroups);
            var flxBackContainerSignatoryGruops = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxBackContainerSignatoryGruops",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackContainerSignatoryGruops.setDefaultUnit(kony.flex.DP);
            var lblBottomSeparatorSignatoryGruops = new kony.ui.Label({
                "bottom": "1dp",
                "height": "1dp",
                "id": "lblBottomSeparatorSignatoryGruops",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblBge3e3e3op100",
                "text": "-",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBackSignatoryGruops = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF4vs",
                "height": "50dp",
                "id": "btnBackSignatoryGruops",
                "isVisible": true,
                "right": "25dp",
                "skin": "ICSknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")",
                "top": "0",
                "width": "175dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackContainerSignatoryGruops.add(lblBottomSeparatorSignatoryGruops, btnBackSignatoryGruops);
            flxSignatoryGroups.add(flxHeaderContainerSignatoryGroups, flxSearchContainer, flxSegSignatoryGroups, flxBackContainerSignatoryGruops);
            flxContent.add(lblApprovalMatrixHeader, flxAckHeader, flxAckHeaderOn, flxAcknowledgementPopup, flxDowntimeWarning, flxContractContainer, flxApprovalMatrixContainer, flxSignatoryGroups);
            flxMain.add(flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "103%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "centerX": "50%",
                        "left": "0dp",
                        "width": "103%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxProfileDeletePopUp = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "102%",
                "id": "flxProfileDeletePopUp",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeletePopUp.setDefaultUnit(kony.flex.DP);
            var flxProfileDelete = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "268dp",
                "id": "flxProfileDelete",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "28.35%",
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "260dp",
                "width": "43.26%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDelete.setDefaultUnit(kony.flex.DP);
            var flxprofileDeleteHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxprofileDeleteHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofileDeleteHeader.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeSupplyFinance.Delete\")"
                },
                "id": "lblProfileDeleteHeader",
                "isVisible": true,
                "left": "3.38%",
                "skin": "sknlbl18pxbold",
                "text": "Delete Picture",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxprofiledeleteClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxprofiledeleteClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.setDefaultUnit(kony.flex.DP);
            var imgProfileDeleteClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "imgProfileDeleteClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxprofiledeleteClose.add(imgProfileDeleteClose);
            flxprofileDeleteHeader.add(lblProfileDeleteHeader, flxprofiledeleteClose);
            var flxProfileDeleteSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxProfileDeleteSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteSeperator.setDefaultUnit(kony.flex.DP);
            flxProfileDeleteSeperator.add();
            var flxProfileDeleteContent = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "72dp",
                "id": "flxProfileDeleteContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.setDefaultUnit(kony.flex.DP);
            var lblProfileDeleteContent = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.deletePhoneNum\")"
                },
                "id": "lblProfileDeleteContent",
                "isVisible": true,
                "left": "3.38%",
                "skin": "bbSknLbl424242SSP17Px",
                "text": "Are you sure you want to remove your profile picture?",
                "top": "25px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileDeleteContent.add(lblProfileDeleteContent);
            var flxWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "0%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var flxDisablWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20px",
                "clipBounds": true,
                "height": "62dp",
                "id": "flxDisablWarning",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20px",
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "20dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisablWarning.setDefaultUnit(kony.flex.DP);
            flxDisablWarning.add();
            flxWarning.add(flxDisablWarning);
            var flxProfileDeleteSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxProfileDeleteSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "35dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteSeperator2.setDefaultUnit(kony.flex.DP);
            flxProfileDeleteSeperator2.add();
            var flxProfileDeleteButtons = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": true,
                "height": "90px",
                "id": "flxProfileDeleteButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfileDeleteButtons.setDefaultUnit(kony.flex.DP);
            var btnDeletePopupNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.No\")"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupNo",
                "isVisible": true,
                "left": "35.95%",
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "28.47%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "No"
            });
            var btnDeletePopupYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.Yes\")"
                },
                "bottom": 30,
                "height": "40dp",
                "id": "btnDeletePopupYes",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "28.44%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Yes"
            });
            flxProfileDeleteButtons.add(btnDeletePopupNo, btnDeletePopupYes);
            flxProfileDelete.add(flxprofileDeleteHeader, flxProfileDeleteSeperator, flxProfileDeleteContent, flxWarning, flxProfileDeleteSeperator2, flxProfileDeleteButtons);
            flxProfileDeletePopUp.add(flxProfileDelete);
            flxDialogs.add(flxLogout, flxProfileDeletePopUp);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementPopup": {
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeleteButtons": {
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxFormContent": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    },
                    "lblRefNum": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    },
                    "lblRefNumVal": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    },
                    "flximgHeaderOn": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblMsgOn": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    },
                    "flxAcknowledgementPopup": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgAckClose": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountName": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNameHeader": {
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNameValue": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerName": {
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerNameHeader": {
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerHeaderValue": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxCustomerID": {
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerIDHeader": {
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lblCustomerIDValue": {
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxContract": {
                        "width": {
                            "type": "string",
                            "value": "24%"
                        },
                        "segmentProps": []
                    },
                    "lblContractHeader": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblContractValue": {
                        "width": {
                            "type": "string",
                            "value": "69%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMatrixContainer": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderSeperator": {
                        "segmentProps": []
                    },
                    "flxApprovalMatrixOnOff": {
                        "segmentProps": []
                    },
                    "imgTurnOnOfApprovalCustLevl": {
                        "segmentProps": []
                    },
                    "lblTurnOnOfApprovalCustLevl": {
                        "segmentProps": []
                    },
                    "flxSeparatorApprovalMode": {
                        "segmentProps": []
                    },
                    "flxSearchimg": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "imgSearch": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxSearch": {
                        "height": {
                            "type": "string",
                            "value": "98%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15%"
                        },
                        "placeholderSkin": "bbSknTbx949494SSP15pxNormal",
                        "skin": "bbSknTbx949494SSP15pxNormal",
                        "text": "",
                        "segmentProps": []
                    },
                    "lblSelectedFeatureValue": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "text": "Transfer to own account within same fine",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "segApprovalMatrix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPTRMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblPTRFeatureAction": {
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "btnPTRCreateMatrix": {
                        "segmentProps": []
                    },
                    "btnPTREditRule": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblPTRApprovalLimits": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblPTRApprovers": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxPTRApprovalListValues": {
                        "segmentProps": []
                    },
                    "lblPTRValueSeparatorDup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPTRNoRecords": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblPTRSeparator3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDailyLimitsMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblDailyLimitsFeatureAction": {
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "btnCreateDailyLimitsMatrix": {
                        "segmentProps": []
                    },
                    "btnEditDailyLimitsMatrix": {
                        "segmentProps": []
                    },
                    "lblDailyLimitsApprovalLimit": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "text": "Approval Range",
                        "segmentProps": []
                    },
                    "lblDailyLimitsApprovers": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxDailyLimitsNoRecords": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblDailyLimitsSeparator3": {
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "segmentProps": []
                    },
                    "flxWeeklyLimitsMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblWeeklyLimitsFeatureAction": {
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "btnWeeklyLimitsCreateMatrix": {
                        "segmentProps": []
                    },
                    "btnWeeklyLimitsEditMatrix": {
                        "segmentProps": []
                    },
                    "lblWeeklyApprovalLimits": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "text": "Approval Range",
                        "segmentProps": []
                    },
                    "lblWeeklyLimitsApprovers": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxWeeklyLimitsNoRecords": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblWeeklyLimitsSeparator3": {
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "segmentProps": []
                    },
                    "flxNoApprovalMatrixData": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxApprovalMatrixAccountWrapper1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxNonMonetaryMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblNonMonetaryFeatureAction": {
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "btnNonMonetaryCreateMatrix": {
                        "segmentProps": []
                    },
                    "btnNonMonetaryEditRule": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblMonetaryApprovers": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblMonetaryApproverslimits": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxNonMonetaryApprovalDetails": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblNonMonetaryApprovalConditons": {
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxNonMonetaryNoRecords": {
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "width": {
                            "type": "string",
                            "value": "115%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxFormContent": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblRefNum": {
                        "segmentProps": []
                    },
                    "lblRefNumVal": {
                        "segmentProps": []
                    },
                    "flximgHeaderOn": {
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblMsgOn": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementPopup": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMatrixContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMode": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchimg": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "imgSearch": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxSearch": {
                        "height": {
                            "type": "string",
                            "value": "98%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15%"
                        },
                        "placeholderSkin": "bbSknTbx949494SSP15pxNormal",
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknTbx949494SSP15pxNormal",
                        "segmentProps": []
                    },
                    "Features": {
                        "segmentProps": []
                    },
                    "lblSelectedFeatureValue": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "segApprovalMatrix": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPTRMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPerTransactionRules": {
                        "segmentProps": []
                    },
                    "btnPTRCreateMatrix": {
                        "segmentProps": []
                    },
                    "btnPTREditRule": {
                        "segmentProps": []
                    },
                    "lblPTRApprovalLimits": {
                        "segmentProps": []
                    },
                    "flxPTRApprovalListValues": {
                        "segmentProps": []
                    },
                    "lblPTRValueSeparatorDup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPTRNoRecords": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblPTRSeparator3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDailyLimitsMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblDailyLimitsFeatureAction": {
                        "segmentProps": []
                    },
                    "btnCreateDailyLimitsMatrix": {
                        "segmentProps": []
                    },
                    "btnEditDailyLimitsMatrix": {
                        "segmentProps": []
                    },
                    "lblDailyLimitsApprovalLimit": {
                        "text": "Approval Range",
                        "segmentProps": []
                    },
                    "flxDailyApprovalListValues": {
                        "segmentProps": []
                    },
                    "lblDailyValueSeparatorDup": {
                        "segmentProps": []
                    },
                    "flxDailyLimitsNoRecords": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblDailyLimitsSeparator3": {
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "segmentProps": []
                    },
                    "flxWeeklyLimitsMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "btnWeeklyLimitsCreateMatrix": {
                        "segmentProps": []
                    },
                    "btnWeeklyLimitsEditMatrix": {
                        "segmentProps": []
                    },
                    "lblWeeklyApprovalLimits": {
                        "text": "Approval Range",
                        "segmentProps": []
                    },
                    "flxWeeklyApprovalListValues": {
                        "segmentProps": []
                    },
                    "flxWeeklyLimitsNoRecords": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblWeeklyLimitsSeparator3": {
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMatrixAccountWrapper1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxNonMonetaryMain": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPerNonMonetaryRules": {
                        "segmentProps": []
                    },
                    "btnNonMonetaryCreateMatrix": {
                        "segmentProps": []
                    },
                    "btnNonMonetaryEditRule": {
                        "segmentProps": []
                    },
                    "lblMonetaryApprovers": {
                        "segmentProps": []
                    },
                    "flxNonMonetaryApprovalListValues": {
                        "segmentProps": []
                    },
                    "flxNonMonetaryApproval": {
                        "segmentProps": []
                    },
                    "flxNonMonetaryApprovalDetails": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblNonMonetaryValueSeparator": {
                        "segmentProps": []
                    },
                    "flxNonMonetaryNoRecords": {
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "-37dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "104%"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "1380dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementPopup": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMatrixContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalMode": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgTurnOnOfApprovalCustLevl": {
                        "segmentProps": []
                    },
                    "CopyswitchApprovals0acdb297b017e4a": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSearchimg": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "imgSearch": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "tbxSearch": {
                        "height": {
                            "type": "string",
                            "value": "98%"
                        },
                        "i18n_placeholder": "i18n.SignatoryMatrix.Searchforfeaturesactions",
                        "left": {
                            "type": "string",
                            "value": "15%"
                        },
                        "placeholder": "",
                        "placeholderSkin": "bbSknTbx949494SSP15pxNormal",
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknTbx949494SSP15pxNormal",
                        "segmentProps": []
                    },
                    "flxFeatureList": {
                        "segmentProps": []
                    },
                    "Features": {
                        "segmentProps": []
                    },
                    "lblSelectedFeatureValue": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "segApprovalMatrix": {
                        "data": [
                            [{
                                    "btnEditMatrix": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.billPay.Edit",
                                        "text": "Button"
                                    },
                                    "lblApprovalLimits": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblApprovalRule": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblApprovers": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblFeatureAction": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblNumOfApprovers": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeparator2": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblSeparator3": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "imgNoRecordsIcon": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgRowExpand": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "arrow_down.png"
                                    },
                                    "lblApprovalLimitsValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblApproverRequired": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblNoApprovalRulesDefined": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "No  approval rules set for this feature action"
                                    },
                                    "lblSeparator1": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ],
                            [{
                                    "btnEditMatrix": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "i18nkey": "i18n.billPay.Edit",
                                        "text": "Button"
                                    },
                                    "lblApprovalLimits": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblApprovalRule": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblApprovers": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblFeatureAction": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblNumOfApprovers": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblSeparator2": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblSeparator3": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "imgNoRecordsIcon": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "info_grey.png"
                                    },
                                    "imgRowExpand": {
                                        "@class": "com.viz.ide.model.segment.ImageSegmentData",
                                        "src": "arrow_down.png"
                                    },
                                    "lblApprovalLimitsValue": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblApproverRequired": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "Label"
                                    },
                                    "lblNoApprovalRulesDefined": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": "No  approval rules set for this feature action"
                                    },
                                    "lblSeparator1": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "isVisible": false,
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ApprovalMatrixMA",
                            "friendlyName": "flxSegApprovalMatrixRow"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ApprovalMatrixMA",
                            "friendlyName": "flxApprovalMatrixSection"
                        }),
                        "widgetDataMap": {
                            "btnEditMatrix": "btnEditMatrix",
                            "flxApprovalMatrixSection": "flxApprovalMatrixSection",
                            "flxHeaderLowerHalf": "flxHeaderLowerHalf",
                            "flxHeaderUpperHalf": "flxHeaderUpperHalf",
                            "flxLimit1": "flxLimit1",
                            "flxNoRecords": "flxNoRecords",
                            "flxSegApprovalMatrixRow": "flxSegApprovalMatrixRow",
                            "imgNoRecordsIcon": "imgNoRecordsIcon",
                            "imgRowExpand": "imgRowExpand",
                            "lblApprovalLimits": "lblApprovalLimits",
                            "lblApprovalLimitsValue": "lblApprovalLimitsValue",
                            "lblApprovalRule": "lblApprovalRule",
                            "lblApproverRequired": "lblApproverRequired",
                            "lblApprovers": "lblApprovers",
                            "lblFeatureAction": "lblFeatureAction",
                            "lblNoApprovalRulesDefined": "lblNoApprovalRulesDefined",
                            "lblNumOfApprovers": "lblNumOfApprovers",
                            "lblSeparator1": "lblSeparator1",
                            "lblSeparator2": "lblSeparator2",
                            "lblSeparator3": "lblSeparator3"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ApprovalMatrixMA"
                    },
                    "flxPTRMain": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPerTransactionRules": {
                        "segmentProps": []
                    },
                    "btnPTRCreateMatrix": {
                        "segmentProps": []
                    },
                    "btnPTREditRule": {
                        "segmentProps": []
                    },
                    "lblPTRApprovalLimits": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "lblPTRApprovers": {
                        "left": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxPTRApprovalListValues": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblPTRValueSeparatorDup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPTRNoRecords": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblPTRSeparator3": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxDailyLimitsMain": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblDailyLimitsFeatureAction": {
                        "segmentProps": []
                    },
                    "btnCreateDailyLimitsMatrix": {
                        "segmentProps": []
                    },
                    "btnEditDailyLimitsMatrix": {
                        "segmentProps": []
                    },
                    "lblDailyLimitsApprovalLimit": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "text": "Approval Range",
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "lblDailyLimitsApprovers": {
                        "left": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxDailyApprovalListValues": {
                        "segmentProps": []
                    },
                    "lblDailyValueSeparatorDup": {
                        "segmentProps": []
                    },
                    "flxDailyLimitsDetails": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDailyLimitsNoRecords": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblDailyLimitsSeparator3": {
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "segmentProps": []
                    },
                    "flxWeeklyLimitsMain": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "btnWeeklyLimitsCreateMatrix": {
                        "segmentProps": []
                    },
                    "btnWeeklyLimitsEditMatrix": {
                        "segmentProps": []
                    },
                    "lblWeeklyApprovalLimits": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "text": "Approval Range",
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "lblWeeklyLimitsApprovers": {
                        "left": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxWeeklyApprovalListValues": {
                        "segmentProps": []
                    },
                    "flxWeeklyLimitsNoRecords": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblWeeklyLimitsSeparator3": {
                        "top": {
                            "type": "number",
                            "value": "10"
                        },
                        "segmentProps": []
                    },
                    "flxNoApprovalMatrixData": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxApprovalMatrixAccountWrapper1": {
                        "isVisible": false,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalNonMonetaryAccountWrapper": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxNonMonetaryMain": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPerNonMonetaryRules": {
                        "segmentProps": []
                    },
                    "btnNonMonetaryCreateMatrix": {
                        "i18n_text": "i18n.SignatoryMatrix.CreateRule",
                        "segmentProps": []
                    },
                    "btnNonMonetaryEditRule": {
                        "segmentProps": []
                    },
                    "lblMonetaryApprovers": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "lblMonetaryApproverslimits": {
                        "left": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "400dp"
                        },
                        "segmentProps": []
                    },
                    "flxNonMonetaryApprovalListValues": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxNonMonetaryApproval": {
                        "segmentProps": []
                    },
                    "lblNonMonetarySeparatorUp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNonMonetaryApprovalDetails": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "imgNonMonetaryRowExpandDetails": {
                        "src": "dropdown_collapse.png",
                        "segmentProps": []
                    },
                    "flxNonMonetaryHeaderApprovalConditons": {
                        "segmentProps": []
                    },
                    "lblNonMonetaryApprovalConditons": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxNonMonetaryApprovalMatrixDetail": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxNonMonetaryApprovalCondition": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblApproveIfNonMonetary": {
                        "segmentProps": []
                    },
                    "flxNonMonetaryApprovalConditionDetail": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblNonMonetaryValueSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxNonMonetaryNoRecords": {
                        "segmentProps": []
                    },
                    "lblNonMonetaryNoApprovalRulesDefined": {
                        "i18n_text": "i18n.SignatoryMatrix.Noapprovalrulessetforthisfeatureaction",
                        "segmentProps": []
                    },
                    "flxSignatoryGroups": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDeletePopUp": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "1150dp"
                        },
                        "segmentProps": []
                    },
                    "flxProfileDelete": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                        "width": {
                            "type": "string",
                            "value": "44%"
                        },
                        "segmentProps": []
                    },
                    "flxprofileDeleteHeader": {
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "btnDeletePopupNo": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnDeletePopupYes": {
                        "bottom": {
                            "type": "number",
                            "value": "20"
                        },
                        "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.flxLogoAndActionsWrapper": {
                    "width": "1366dp"
                },
                "customheadernew.flxMenuContainer": {
                    "width": "100%"
                },
                "customheadernew.flxMenuWrapper": {
                    "width": "1366dp"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "Features": {
                    "top": "0dp"
                },
                "customfooternew": {
                    "centerX": "50%",
                    "left": "0dp",
                    "width": "103%"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmViewApprovalSignatoryMatrix,
            "enabledForIdleTimeout": true,
            "id": "frmViewApprovalSignatoryMatrix",
            "init": controller.AS_Form_f4893cabcff345f38f1845d8c57129ec,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_bf07716cc60c4b0cb8046e4a809dd895,
            "preShow": function(eventobject) {
                controller.AS_Form_f0706b662efd4992947c07dd5f70c08c(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ApprovalMatrixMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_c202907cb62b4d03bd67bd755cf336a0,
            "retainScrollPosition": false
        }]
    }
});