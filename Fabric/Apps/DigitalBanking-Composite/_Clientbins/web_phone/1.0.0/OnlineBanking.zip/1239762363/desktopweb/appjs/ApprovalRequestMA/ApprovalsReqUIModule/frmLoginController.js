define("ApprovalRequestMA/ApprovalsReqUIModule/userfrmLoginController", {
    //Type your controller code here 
});
define("ApprovalRequestMA/ApprovalsReqUIModule/frmLoginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** postShow defined for frmLogin **/
    AS_Form_d5e29d5680cb431f8636644facde796c: function AS_Form_d5e29d5680cb431f8636644facde796c(eventobject) {
        var self = this;
        kony.application.showLoadingScreen("", "Authenticating the user");
        var authParams = {
            "UserName": "7644257870",
            "Password": "Kony@1234",
            "loginOptions": {
                "isOfflineEnabled": false
            }
        };
        authClient = KNYMobileFabric.getIdentityService("DbxUserLogin");
        authClient.login(authParams, successCallback, errorCallback);
        const invokeGetCounts = function() {
            var getCountsModel = kony.mvc.MDAApplication.getSharedInstance().modelStore.getModelDefinition("Counts");
            //ACHFilesApprovalsModel.getAll(getAllCompletionCallback);
            var params = {
                "languageCode": kony.i18n.getCurrentLocale().replace("_", "-")
            };
            getCountsModel.customVerb("getCounts", params, getAllCompletionCallback);

            function getAllCompletionCallback(status, data, error) {
                var srh = applicationManager.getServiceResponseHandler();
                var obj = srh.manageResponse(status, data, error);
                if (obj["status"] === true) {
                    presentationSuccessCallback(obj.data);
                } else {
                    presentationFailureCallback(obj.errmsg);
                }
            }
        };
        const fetchInternalAccounts = function() {
            var self = this;
            var accountsRepo = kony.mvc.MDAApplication.getSharedInstance().getRepoManager().getRepository("DigitalArrangements");
            accountsRepo.customVerb('getList', {}, getAllCompletionCallback);

            function getAllCompletionCallback(status, data, error) {
                var srh = applicationManager.getServiceResponseHandler();
                var obj = srh.manageResponse(status, data, error);
                if (obj["status"] === true) {
                    if (obj["data"] && obj["data"]["Accounts"]) {
                        accountspresentationSuccessCallback(obj["data"]["Accounts"]);
                    }
                } else {
                    accountspresentationFailureCallback(obj["errmsg"]);
                }
            }
        };
        const presentationSuccessCallback = function(response) {
            applicationManager.getConfigurationManager().CountResponse = response;
            kony.application.dismissLoadingScreen();
            kony.print(response);
            fetchInternalAccounts();
        };
        const presentationFailureCallback = function(response) {
            alert("Error while Counts Service...");
        };
        const accountspresentationSuccessCallback = function(response) {
            applicationManager.getConfigurationManager().userAccounts = response;
            var ntf = new kony.mvc.Navigation("frmBBApprovalsDashboard");
            ntf.navigate();
        };
        const accountspresentationFailureCallback = function(response) {
            alert("Error while calling accounts Service...");
        };

        function successCallback(resSuccess) {
            kony.application.dismissLoadingScreen();
            kony.print(resSuccess);
            invokeGetCounts();
        }

        function errorCallback(resError) {
            kony.application.dismissLoadingScreen();
            kony.print(resError);
            alert("login is not working...")
        }
    }
});
define("ApprovalRequestMA/ApprovalsReqUIModule/frmLoginController", ["ApprovalRequestMA/ApprovalsReqUIModule/userfrmLoginController", "ApprovalRequestMA/ApprovalsReqUIModule/frmLoginControllerActions"], function() {
    var controller = require("ApprovalRequestMA/ApprovalsReqUIModule/userfrmLoginController");
    var controllerActions = ["ApprovalRequestMA/ApprovalsReqUIModule/frmLoginControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
