define("ArrangementsMA/ServiceRequestsUIModule/frmPrintServiceRequest", function() {
    return function(controller) {
        function addWidgetsfrmPrintServiceRequest() {
            this.setDefaultUnit(kony.flex.DP);
            var flxPrintServiceRequestDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrintServiceRequestDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrintServiceRequestDetails.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxHeader",
                "top": "70dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Header Kony Logo"
                },
                "height": "31dp",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "6%",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "18px",
                "width": "102dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblKonyBank = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "My Checking Account ….XXXX3254"
                },
                "centerY": "50%",
                "id": "lblKonyBank",
                "isVisible": true,
                "right": "6.66%",
                "skin": "sknlbl424242bold17px",
                "text": "My Checking Account ….XXXX3254",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(imgKony, lblKonyBank);
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.back\")"
                },
                "focusSkin": "slButtonGlossRed",
                "id": "btnBack",
                "isVisible": false,
                "left": "6.07%",
                "skin": "Copysknbtnffffff",
                "text": "< Back",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back"
            });
            var lblMyCheckingAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "My Checking Account ….XXXX3254"
                },
                "id": "lblMyCheckingAccount",
                "isVisible": true,
                "left": "1%",
                "skin": "sknlbl424242bold17px",
                "text": "My Checking Account ….XXXX3254",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContentMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContentMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentMain.setDefaultUnit(kony.flex.DP);
            var flxFacilityDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityDetails.setDefaultUnit(kony.flex.DP);
            var flxFacilityHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxFacilityHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityHeader.setDefaultUnit(kony.flex.DP);
            var lblRequestDetails = new kony.ui.Label({
                "id": "lblRequestDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Request Details",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            flxFacilityHeader.add(lblRequestDetails, flxSeparator);
            var flxFacilityContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "340dp",
                "id": "flxFacilityContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": 50,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityContent.setDefaultUnit(kony.flex.DP);
            var lblRequestType = new kony.ui.Label({
                "id": "lblRequestType",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Request Type:",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRequestTypeVal = new kony.ui.Label({
                "id": "lblRequestTypeVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumber = new kony.ui.Label({
                "id": "lblReferenceNumber",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Reference Number:",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumberVal = new kony.ui.Label({
                "id": "lblReferenceNumberVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityName = new kony.ui.Label({
                "id": "lblFacilityName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Facility Name:",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityNameVal = new kony.ui.Label({
                "id": "lblFacilityNameVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoans = new kony.ui.Label({
                "id": "lblNoOfLoans",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Number Of Loans:",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoansVal = new kony.ui.Label({
                "id": "lblNoOfLoansVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalance = new kony.ui.Label({
                "id": "lblOutstandingBalance",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Outstanding Balance:",
                "top": "180dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalanceVal = new kony.ui.Label({
                "id": "lblOutstandingBalanceVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "180dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityDate = new kony.ui.Label({
                "id": "lblMaturityDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Maturity Date :",
                "top": "220dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityDateVal = new kony.ui.Label({
                "id": "lblMaturityDateVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "220dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblStatus = new kony.ui.Label({
                "id": "lblStatus",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Status:",
                "top": "260dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblStatusVal = new kony.ui.Label({
                "id": "lblStatusVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "260dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblComments = new kony.ui.Label({
                "id": "lblComments",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Comments:",
                "top": "300dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCommentsVal = new kony.ui.Label({
                "id": "lblCommentsVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "300dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFacilityContent.add(lblRequestType, lblRequestTypeVal, lblReferenceNumber, lblReferenceNumberVal, lblFacilityName, lblFacilityNameVal, lblNoOfLoans, lblNoOfLoansVal, lblOutstandingBalance, lblOutstandingBalanceVal, lblMaturityDate, lblMaturityDateVal, lblStatus, lblStatusVal, lblComments, lblCommentsVal);
            flxFacilityDetails.add(flxFacilityHeader, flxFacilityContent);
            var flxLoanDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLoanDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanDetails.setDefaultUnit(kony.flex.DP);
            var flxLoanAccountsSegment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLoanAccountsSegment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccountsSegment.setDefaultUnit(kony.flex.DP);
            var lblLoanDetails = new kony.ui.Label({
                "id": "lblLoanDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Loan Details",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSegLoanDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegLoanDetails",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegLoanDetails.setDefaultUnit(kony.flex.DP);
            var segLoanDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Primary Loan-8760"
                        },
                        [{}]
                    ],
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Secondary Loan -1211"
                        },
                        [{}]
                    ],
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "New Loan -1234"
                        },
                        [{}]
                    ]
                ],
                "groupCells": false,
                "id": "segLoanDetails",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxAccountsListCustomView"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxTransfersFromListHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": 0,
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegLoanDetails.add(segLoanDetails);
            var flxAccountDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "184dp",
                "id": "flxAccountDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountDetails.setDefaultUnit(kony.flex.DP);
            var lblCurrAccount = new kony.ui.Label({
                "id": "lblCurrAccount",
                "isVisible": true,
                "left": "305dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Current Account Detail",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewAccount = new kony.ui.Label({
                "id": "lblNewAccount",
                "isVisible": true,
                "left": "677dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "New Account Detail",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccHoldName = new kony.ui.Label({
                "id": "lblAccHoldName",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Account Holder Name:",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHolderNameCV = new kony.ui.Label({
                "id": "lblHolderNameCV",
                "isVisible": true,
                "left": "305dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "John Bailey",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHolderNameNV = new kony.ui.Label({
                "id": "lblHolderNameNV",
                "isVisible": true,
                "left": "677dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Daisy Davis",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumber = new kony.ui.Label({
                "id": "lblAccountNumber",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Account Number:",
                "top": "98dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberCV = new kony.ui.Label({
                "id": "lblAccountNumberCV",
                "isVisible": true,
                "left": "305dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "5678 5555 09867 12",
                "top": "98dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberNV = new kony.ui.Label({
                "id": "lblAccountNumberNV",
                "isVisible": true,
                "left": "677dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "9281 8900 8192 1211",
                "top": "98dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwift = new kony.ui.Label({
                "id": "lblSwift",
                "isVisible": false,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "BIC/SWIFT :",
                "top": "136dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftCV = new kony.ui.Label({
                "id": "lblSwiftCV",
                "isVisible": false,
                "left": "305dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "LB29NWBK60161331926819",
                "top": "136dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSwiftNV = new kony.ui.Label({
                "id": "lblSwiftNV",
                "isVisible": false,
                "left": "677dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "MCRBRUMM000",
                "top": "136dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankName = new kony.ui.Label({
                "id": "lblBankName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Bank Name:",
                "top": "136dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameCV = new kony.ui.Label({
                "id": "lblBankNameCV",
                "isVisible": true,
                "left": "305dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Lloyds Banking Group",
                "top": "136dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameNV = new kony.ui.Label({
                "id": "lblBankNameNV",
                "isVisible": true,
                "left": "677dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Bank of Moscow",
                "top": "136dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeperator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "1dp",
                "id": "lblSeperator",
                "isVisible": true,
                "left": 0,
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "183dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            flxAccountDetails.add(lblCurrAccount, lblNewAccount, lblAccHoldName, lblHolderNameCV, lblHolderNameNV, lblAccountNumber, lblAccountNumberCV, lblAccountNumberNV, lblSwift, lblSwiftCV, lblSwiftNV, lblBankName, lblBankNameCV, lblBankNameNV, lblSeperator, flxSeparator1);
            var flxAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "170dp",
                "id": "flxAddress",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddress.setDefaultUnit(kony.flex.DP);
            var lblExistingAddress = new kony.ui.Label({
                "id": "lblExistingAddress",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "Existing Address:",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExistingAddressVal1 = new kony.ui.Label({
                "id": "lblExistingAddressVal1",
                "isVisible": true,
                "left": "305dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "John Bailey",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExistingAddressVal2 = new kony.ui.Label({
                "id": "lblExistingAddressVal2",
                "isVisible": true,
                "left": "305dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "John Bailey",
                "top": "40dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewAddress = new kony.ui.Label({
                "id": "lblNewAddress",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "New Address:",
                "top": "80dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewAddressVal1 = new kony.ui.Label({
                "id": "lblNewAddressVal1",
                "isVisible": true,
                "left": "305dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "5678 5555 09867 12",
                "top": "80dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNewAddressVal2 = new kony.ui.Label({
                "id": "lblNewAddressVal2",
                "isVisible": true,
                "left": "305dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "5678 5555 09867 12",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUsedFor = new kony.ui.Label({
                "id": "lblUsedFor",
                "isVisible": true,
                "left": "305dp",
                "skin": "ICSknLabelSSPRegular72727215px",
                "text": "Used For:",
                "top": "136dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgInfoIcon = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgInfoIcon",
                "isVisible": true,
                "left": "370dp",
                "src": "info_grey.png",
                "top": "136dp",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPrimaryCommunication = new kony.ui.Label({
                "id": "lblPrimaryCommunication",
                "isVisible": true,
                "left": "400dp",
                "skin": "ICSknLb727272SSP11Px",
                "text": "Primary Communication",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "1dp",
                "id": "lblSeparator1",
                "isVisible": true,
                "left": 0,
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "183dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            flxAddress.add(lblExistingAddress, lblExistingAddressVal1, lblExistingAddressVal2, lblNewAddress, lblNewAddressVal1, lblNewAddressVal2, lblUsedFor, imgInfoIcon, lblPrimaryCommunication, lblSeparator1, flxSeparator3);
            flxLoanAccountsSegment.add(lblLoanDetails, flxSegLoanDetails, flxAccountDetails, flxAddress);
            var flxSupportingDocsMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSupportingDocsMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0dp",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocsMain.setDefaultUnit(kony.flex.DP);
            var flxSupportingDocsTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxSupportingDocsTitle",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocsTitle.setDefaultUnit(kony.flex.DP);
            var lblSupportingDocTitle = new kony.ui.Label({
                "id": "lblSupportingDocTitle",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Supporting Documents",
                "top": "22dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator4.setDefaultUnit(kony.flex.DP);
            flxSeparator4.add();
            flxSupportingDocsTitle.add(lblSupportingDocTitle, flxSeparator4);
            var flxSupportingDocs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSupportingDocs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocs.setDefaultUnit(kony.flex.DP);
            var segSupportingDocs = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgDropDown": "P",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Label"
                        },
                        [{
                            "imgDoc": "pdf_image.png",
                            "lblDocName": "Document1.pdf"
                        }, {
                            "imgDoc": "pdf_image.png",
                            "lblDocName": "Document1.pdf"
                        }, {
                            "imgDoc": "pdf_image.png",
                            "lblDocName": "Document1.pdf"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segSupportingDocs",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxSupportingDocs"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxTransfersFromListHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxContentDocs": "flxContentDocs",
                    "flxDropDown": "flxDropDown",
                    "flxGap": "flxGap",
                    "flxGrpTransfersFromListHeader": "flxGrpTransfersFromListHeader",
                    "flxImgDoc": "flxImgDoc",
                    "flxSupportingDocs": "flxSupportingDocs",
                    "flxTransfersFromListHeader": "flxTransfersFromListHeader",
                    "imgDoc": "imgDoc",
                    "imgDropDown": "imgDropDown",
                    "lblDocName": "lblDocName",
                    "lblSeparator": "lblSeparator",
                    "lblTopSeparator": "lblTopSeparator",
                    "lblTransactionHeader": "lblTransactionHeader"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSupportingDocs.add(segSupportingDocs);
            var flxCheckBoxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxCheckBoxMain",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBoxMain.setDefaultUnit(kony.flex.DP);
            var flxCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "31dp",
                "isModalContainer": false,
                "top": 30,
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBox.setDefaultUnit(kony.flex.DP);
            var lblCheckBox = new kony.ui.Label({
                "id": "lblCheckBox",
                "isVisible": true,
                "left": "0",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "D",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox.add(lblCheckBox);
            var lblCheckMsg = new kony.ui.Label({
                "id": "lblCheckMsg",
                "isVisible": true,
                "left": "65dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "I confirm that my co-borrower is aware of the change. ",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "69dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            flxCheckBoxMain.add(flxCheckBox, lblCheckMsg, flxSeparator2);
            flxSupportingDocsMain.add(flxSupportingDocsTitle, flxSupportingDocs, flxCheckBoxMain);
            flxLoanDetails.add(flxLoanAccountsSegment, flxSupportingDocsMain);
            flxContentMain.add(flxFacilityDetails, flxLoanDetails);
            var flxDisclaimer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDisclaimer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7Border9797971pxRadius3px",
                "top": "5dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisclaimer.setDefaultUnit(kony.flex.DP);
            var rtxDisclaimer = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": " <p style=\"line-height:200%;\"><b>Disclaimer:</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes.</style></p>"
                },
                "bottom": "2dp",
                "id": "rtxDisclaimer",
                "isVisible": true,
                "left": "1%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:200%;\"><b>Disclaimer:</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes.</style></p>",
                "top": "10px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisclaimer.add(rtxDisclaimer);
            var btnBackBottom = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")"
                },
                "focusSkin": "slButtonGlossRed",
                "height": "50px",
                "id": "btnBackBottom",
                "isVisible": false,
                "left": "79dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.BACK\")",
                "top": "40dp",
                "width": "14.60%",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back"
            });
            var flxBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": true,
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var lblCopyRight = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Kony Bank Pvt. Ltd. Copyright 2017. All rightes reserved."
                },
                "id": "lblCopyRight",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab1\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Page 1 of 1"
                },
                "id": "lblPage",
                "isVisible": false,
                "right": "0%",
                "skin": "sknlbl424242bold15px",
                "text": "Page 1 of 1",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBottom.add(lblCopyRight, lblPage);
            flxPrintServiceRequestDetails.add(flxHeader, btnBack, lblMyCheckingAccount, flxContentMain, flxDisclaimer, btnBackBottom, flxBottom);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxPrintServiceRequestDetails": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "lblSeparator1": {
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxPrintServiceRequestDetails": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountDetails": {
                        "segmentProps": []
                    },
                    "lblCurrAccount": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": []
                    },
                    "lblNewAccount": {
                        "left": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccHoldName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Repayment Account Holder Name:",
                        "segmentProps": []
                    },
                    "lblHolderNameCV": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": []
                    },
                    "lblHolderNameNV": {
                        "left": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Repayment Account Number:",
                        "segmentProps": []
                    },
                    "lblAccountNumberCV": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccountNumberNV": {
                        "left": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwift": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftCV": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftNV": {
                        "left": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "segmentProps": []
                    },
                    "lblBankName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBankNameCV": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": []
                    },
                    "lblBankNameNV": {
                        "left": {
                            "type": "string",
                            "value": "526dp"
                        },
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAddress": {
                        "segmentProps": []
                    },
                    "lblExistingAddress": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblExistingAddressVal1": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": []
                    },
                    "lblExistingAddressVal2": {
                        "segmentProps": []
                    },
                    "lblNewAddress": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblNewAddressVal1": {
                        "left": {
                            "type": "string",
                            "value": "277dp"
                        },
                        "segmentProps": []
                    },
                    "lblNewAddressVal2": {
                        "segmentProps": []
                    },
                    "lblUsedFor": {
                        "segmentProps": []
                    },
                    "lblPrimaryCommunication": {
                        "segmentProps": []
                    },
                    "lblSeparator1": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxPrintServiceRequestDetails": {
                        "width": {
                            "type": "string",
                            "value": "1250px"
                        },
                        "segmentProps": []
                    },
                    "lblAccHoldName": {
                        "text": "Repayment Account Holder Name:",
                        "segmentProps": []
                    },
                    "lblAccountNumber": {
                        "text": "Repayment Account Number:",
                        "segmentProps": []
                    },
                    "lblSeperator": {
                        "segmentProps": []
                    },
                    "lblExistingAddress": {
                        "segmentProps": []
                    },
                    "lblNewAddress": {
                        "segmentProps": []
                    },
                    "lblSeparator1": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {}
            this.add(flxPrintServiceRequestDetails);
        };
        return [{
            "addWidgets": addWidgetsfrmPrintServiceRequest,
            "enabledForIdleTimeout": false,
            "id": "frmPrintServiceRequest",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_ja9ddca47cac40fdab8f4de2ee371248,
            "preShow": function(eventobject) {
                controller.AS_Form_e72ce5d68f9b404aab1bd9722295e038(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});