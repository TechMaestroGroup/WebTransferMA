define("ArrangementsMA/MortgageServicesUIModule/frmChangeRepaymentAccountNew", function() {
    return function(controller) {
        function addWidgetsfrmChangeRepaymentAccountNew() {
            this.setDefaultUnit(kony.flex.DP);
            var formChangeRepaymentAccountNew = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formChangeRepaymentAccountNew",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "ICSknFlxF7F8F7Border",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formChangeRepaymentAccountNew",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formChangeRepaymentAccountNew_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmChangeRepaymentAccountNew"] && appConfig.componentMetadata["ResourcesMA"]["frmChangeRepaymentAccountNew"]["formChangeRepaymentAccountNew"]) || {};
            formChangeRepaymentAccountNew.serviceParameters = formChangeRepaymentAccountNew_data.serviceParameters || {};
            formChangeRepaymentAccountNew.customPopupData = formChangeRepaymentAccountNew_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formChangeRepaymentAccountNew.dataFormatting = formChangeRepaymentAccountNew_data.dataFormatting || {};
            formChangeRepaymentAccountNew.dataMapping = formChangeRepaymentAccountNew_data.dataMapping || {};
            formChangeRepaymentAccountNew.conditionalMappingKey = formChangeRepaymentAccountNew_data.conditionalMappingKey || "";
            formChangeRepaymentAccountNew.conditionalMapping = formChangeRepaymentAccountNew_data.conditionalMapping || {};
            formChangeRepaymentAccountNew.pageTitle = formChangeRepaymentAccountNew_data.pageTitle || "Change Repayment Account";
            formChangeRepaymentAccountNew.pageTitlei18n = formChangeRepaymentAccountNew_data.pageTitlei18n || "";
            formChangeRepaymentAccountNew.primaryLinks = formChangeRepaymentAccountNew_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formChangeRepaymentAccountNew.flxMainWrapperzIndex = formChangeRepaymentAccountNew_data.flxMainWrapperzIndex || 2;
            formChangeRepaymentAccountNew.secondaryLinks = formChangeRepaymentAccountNew_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formChangeRepaymentAccountNew.supplementaryLinks = formChangeRepaymentAccountNew_data.supplementaryLinks || [];
            formChangeRepaymentAccountNew.pageTitleVisibility = formChangeRepaymentAccountNew_data.pageTitleVisibility || true;
            formChangeRepaymentAccountNew.logoConfig = formChangeRepaymentAccountNew_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formChangeRepaymentAccountNew.accountText = formChangeRepaymentAccountNew_data.accountText || "";
            formChangeRepaymentAccountNew.logoutConfig = formChangeRepaymentAccountNew_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formChangeRepaymentAccountNew.profileConfig = formChangeRepaymentAccountNew_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formChangeRepaymentAccountNew.activeMenuID = formChangeRepaymentAccountNew_data.activeMenuID || "";
            formChangeRepaymentAccountNew.activeSubMenuID = formChangeRepaymentAccountNew_data.activeSubMenuID || "";
            formChangeRepaymentAccountNew.backFlag = formChangeRepaymentAccountNew_data.backFlag || false;
            formChangeRepaymentAccountNew.hamburgerConfig = formChangeRepaymentAccountNew_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formChangeRepaymentAccountNew.backProperties = formChangeRepaymentAccountNew_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formChangeRepaymentAccountNew.breadCrumbProperties = formChangeRepaymentAccountNew_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formChangeRepaymentAccountNew.genricMessage = formChangeRepaymentAccountNew_data.genricMessage || {};
            formChangeRepaymentAccountNew.sessionTimeOutData = formChangeRepaymentAccountNew_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formChangeRepaymentAccountNew.footerProperties = formChangeRepaymentAccountNew_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formChangeRepaymentAccountNew.copyRight = formChangeRepaymentAccountNew_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxContMainNew = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContMainNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxShadow4645454Bg",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContMainNew.setDefaultUnit(kony.flex.DP);
            var flxRepaymentAccDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxRepaymentAccDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRepaymentAccDetails.setDefaultUnit(kony.flex.DP);
            var lblRepaymentAccDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblRepaymentAccDetails",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.NewRepaymentAccountDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "bottom": "0dp",
                "id": "lblSeparator",
                "isVisible": true,
                "left": "30dp",
                "right": "30dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "width": "94.50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRepaymentAccDetails.add(lblRepaymentAccDetails, lblSeparator);
            var flxAccountList = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountList.setDefaultUnit(kony.flex.DP);
            var flxPleaseNote = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPleaseNote",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPleaseNote.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "30dp",
                "src": "info_grey.png",
                "top": "0dp",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAcctSelection = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAcctSelection",
                "isVisible": true,
                "left": "10dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.AccountSelectionMessage\")",
                "top": "2dp",
                "width": "80%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPleaseNote.add(imgInfo, lblAcctSelection);
            var flxAccountContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountContainer.setDefaultUnit(kony.flex.DP);
            var lblRepaymentAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblRepaymentAccount",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentAccountWithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTextBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTextBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "560dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTextBox.setDefaultUnit(kony.flex.DP);
            var tbxAcctSelection = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "textbox",
                        "tabindex": 0
                    },
                    "a11yLabel": "Repayment Account. Click to select an account"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "id": "tbxAcctSelection",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "placeholder": "Search by Account Number or IBAN",
                "secureTextEntry": false,
                "skin": "ICSknTbxPlaceholderSSP72727213px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "300dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblAccountBal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountBal",
                "isVisible": true,
                "right": "10dp",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "500$",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTextBox.add(tbxAcctSelection, lblAccountBal);
            var flxAccountHolder = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountHolder",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountHolder.setDefaultUnit(kony.flex.DP);
            var lblAcctHoldName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAcctHoldName",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.accountHolderNameWithColon\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValAcctHoldName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblValAcctHoldName",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "jhsdfbjhdf",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountHolder.add(lblAcctHoldName, lblValAcctHoldName);
            var flxSegAccounts = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "220dp",
                "horizontalScrollIndicator": true,
                "id": "flxSegAccounts",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlx464545Rds3Px",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxSegAccounts.setDefaultUnit(kony.flex.DP);
            var segAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Primary Loan-8760"
                        },
                        [{}]
                    ],
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Secondary Loan -1211"
                        },
                        [{}]
                    ],
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "New Loan -1234"
                        },
                        [{}]
                    ]
                ],
                "groupCells": false,
                "id": "segAccounts",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxAccountsListCustomView"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxTransfersFromListHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegAccounts.add(segAccounts);
            flxAccountContainer.add(lblRepaymentAccount, flxTextBox, flxAccountHolder, flxSegAccounts);
            var flxDocumentContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentContainer.setDefaultUnit(kony.flex.DP);
            var flxSuppDocContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSuppDocContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "30dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuppDocContainer.setDefaultUnit(kony.flex.DP);
            var lblSupportingDocuments = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblSupportingDocuments",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.SupportingDocumentsOptional\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSuppInfoicon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {}
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxSuppInfoicon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "top": "8dp",
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuppInfoicon.setDefaultUnit(kony.flex.DP);
            var imgSuppInfoIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Read more information about attaching supporting doc"
                },
                "height": "15dp",
                "id": "imgSuppInfoIcon",
                "isVisible": true,
                "left": "0dp",
                "src": "info_grey.png",
                "top": "1dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSuppInfoicon.add(imgSuppInfoIcon);
            flxSuppDocContainer.add(lblSupportingDocuments, flxSuppInfoicon);
            var flxSuppDocInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "85dp",
                "id": "flxSuppDocInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "250dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowd464545",
                "top": "0dp",
                "width": "300dp",
                "zIndex": 10,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuppDocInfo.setDefaultUnit(kony.flex.DP);
            var lblAttachmentRules = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblAttachmentRules",
                "isVisible": true,
                "left": 5,
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.attachmentRules\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxclose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxclose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "260dp",
                "isModalContainer": false,
                "right": "11dp",
                "top": "0%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxclose.setDefaultUnit(kony.flex.DP);
            var lblClose = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblClose",
                "isVisible": true,
                "right": "11dp",
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "top": 15,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxclose.add(lblClose);
            var lblSuppDocInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "55dp",
                "id": "lblSuppDocInfo",
                "isVisible": true,
                "left": 5,
                "skin": "ICSknBBLabelSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.FileAttachmentErrorMessage\")",
                "top": 25,
                "width": "280dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSuppDocInfo.add(lblAttachmentRules, flxclose, lblSuppDocInfo);
            var uploadFiles3 = new com.InfinityOLB.ArrangementsMA.uploadFiles3({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "uploadFiles3",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "35dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "viewType": "uploadFiles3",
                "overrides": {
                    "uploadFiles3": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var uploadFiles3_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmChangeRepaymentAccountNew"] && appConfig.componentMetadata["ArrangementsMA"]["frmChangeRepaymentAccountNew"]["uploadFiles3"]) || {};
            uploadFiles3.inErrorState = uploadFiles3_data.inErrorState || false;
            uploadFiles3.maxFilesCount = uploadFiles3_data.maxFilesCount || 5;
            uploadFiles3.aaa = uploadFiles3_data.aaa || true;
            flxDocumentContainer.add(flxSuppDocContainer, flxSuppDocInfo, uploadFiles3);
            var lblSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSeparator1",
                "isVisible": true,
                "left": "31dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "10dp",
                "width": "94.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCancelAndContinue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "80dp",
                "id": "flxCancelAndContinue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelAndContinue.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Continue to confirmation"
                },
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.btnContinue\")",
                "top": "10dp",
                "width": "280dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel change repayment account process"
                },
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "175dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.btnCancel\")",
                "top": "10dp",
                "width": "280dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCancelAndContinue.add(btnContinue, btnCancel);
            flxAccountList.add(flxPleaseNote, flxAccountContainer, flxDocumentContainer, lblSeparator1, flxCancelAndContinue);
            flxContMainNew.add(flxRepaymentAccDetails, flxAccountList);
            formChangeRepaymentAccountNew.flxContentTCCenter.add(flxContMainNew);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formChangeRepaymentAccountNew": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxContMainNew": {
                        "skin": "sknFlxffffffShadowd464545",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter"]
                    },
                    "lblRepaymentAccDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxRepaymentAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxRepaymentAccDetails"]
                    },
                    "imgInfo": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxPleaseNote"]
                    },
                    "lblAcctSelection": {
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "252dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxPleaseNote"]
                    },
                    "lblRepaymentAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "flxTextBox": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "tbxAcctSelection": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "59%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxTextBox"]
                    },
                    "lblAccountBal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxTextBox"]
                    },
                    "lblAcctHoldName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxAccountHolder"]
                    },
                    "flxSegAccounts": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "flxSuppDocContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer"]
                    },
                    "lblSupportingDocuments": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocContainer"]
                    },
                    "imgSuppInfoIcon": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocContainer", "flxSuppInfoicon"]
                    },
                    "flxSuppDocInfo": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer"]
                    },
                    "lblAttachmentRules": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "uploadFiles3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer"]
                    },
                    "lblSeparator1": {
                        "isVisible": true,
                        "text": "",
                        "segmentProps": []
                    },
                    "flxCancelAndContinue": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "skin": "slFboxffffff",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Continue",
                        "top": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "81dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxContMainNew": {
                        "skin": "sknFlxffffffShadowd464545",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter"]
                    },
                    "flxRepaymentAccDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew"]
                    },
                    "lblRepaymentAccDetails": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxRepaymentAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxRepaymentAccDetails"]
                    },
                    "flxAccountList": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew"]
                    },
                    "imgInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxPleaseNote"]
                    },
                    "lblAcctSelection": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxPleaseNote"]
                    },
                    "flxAccountContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList"]
                    },
                    "lblRepaymentAccount": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "flxTextBox": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "tbxAcctSelection": {
                        "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxTextBox"]
                    },
                    "lblAccountBal": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxTextBox"]
                    },
                    "flxAccountHolder": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "lblAcctHoldName": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxAccountHolder"]
                    },
                    "lblValAcctHoldName": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxAccountHolder"]
                    },
                    "flxSegAccounts": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91.50%"
                        },
                        "zIndex": 10,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "segAccounts": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxSegAccounts"]
                    },
                    "flxDocumentContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList"]
                    },
                    "lblSupportingDocuments": {
                        "skin": "bbSknLbl42424215pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocContainer"]
                    },
                    "imgSuppInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocContainer", "flxSuppInfoicon"]
                    },
                    "flxSuppDocInfo": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer"]
                    },
                    "lblAttachmentRules": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "lblClose": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocInfo", "flxclose"]
                    },
                    "lblSuppDocInfo": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "238dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "uploadFiles3": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer"]
                    },
                    "lblSeparator1": {
                        "segmentProps": []
                    },
                    "flxCancelAndContinue": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "formChangeRepaymentAccountNew": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxContMainNew": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknFlxffffffShadowd464545",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter"]
                    },
                    "flxRepaymentAccDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew"]
                    },
                    "lblRepaymentAccDetails": {
                        "i18n_text": "i18n.mortgageAccount.NewRepaymentAccountDetails",
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "text": "New Repayment Account Details",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxRepaymentAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "29dp"
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxRepaymentAccDetails"]
                    },
                    "flxAccountList": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew"]
                    },
                    "flxPleaseNote": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList"]
                    },
                    "imgInfo": {
                        "src": "info_grey.png",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxPleaseNote"]
                    },
                    "lblAcctSelection": {
                        "i18n_text": "i18n.mortgageAccount.AccountSelectionMessage",
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Please note that the account selection is from your own account",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxPleaseNote"]
                    },
                    "lblRepaymentAccount": {
                        "i18n_text": "i18n.mortgageAccount.RepaymentAccountWithColon",
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Repayment Account:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "flxTextBox": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "tbxAcctSelection": {
                        "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxTextBox"]
                    },
                    "lblAccountBal": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxTextBox"]
                    },
                    "lblAcctHoldName": {
                        "i18n_text": "i18n.common.accountHolderNameWithColon",
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Account Holder Name:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxAccountHolder"]
                    },
                    "lblValAcctHoldName": {
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxAccountHolder"]
                    },
                    "flxSegAccounts": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknFlx464545Rds3Px",
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "zIndex": 10,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "segAccounts": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxSegAccounts"]
                    },
                    "flxDocumentContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList"]
                    },
                    "lblSupportingDocuments": {
                        "i18n_text": "i18n.accounts.SupportingDocumentsOptional",
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "text": "Supporting Documents (Optional)",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocContainer"]
                    },
                    "flxSuppInfoicon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocContainer"]
                    },
                    "imgSuppInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocContainer", "flxSuppInfoicon"]
                    },
                    "flxSuppDocInfo": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "role": "dialog",
                                "tabindex": -1
                            }
                        },
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "257dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer"]
                    },
                    "lblAttachmentRules": {
                        "i18n_text": "i18n.UnifiedTransfer.attachmentRules",
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Attachment Rules",
                        "top": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "flxclose": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "role": "button",
                                "tabindex": 0
                            },
                            "a11yLabel": "Close this information pop-up"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "lblClose": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            },
                            "a11yHidden": true,
                            "tagName": "span"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "4dp"
                        },
                        "skin": "sknOLBFonts003e7512px",
                        "top": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocInfo", "flxclose"]
                    },
                    "lblSuppDocInfo": {
                        "i18n_text": "i18n.accounts.FileAttachmentErrorMessage",
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "text": "A Maximum of 5 Attachments are allowed. Only PDF, JPEG format are allowed. The file size should not excedd 2MB.",
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "uploadFiles3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxDocumentContainer"]
                    },
                    "lblSeparator1": {
                        "segmentProps": []
                    },
                    "flxCancelAndContinue": {
                        "height": {
                            "type": "string",
                            "value": "91dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "i18n_text": "i18n.TransfersEur.btnContinue",
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "i18n_text": "i18n.TransfersEur.btnCancel",
                        "right": {
                            "type": "string",
                            "value": "206dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxContMainNew": {
                        "skin": "sknFlxffffffShadowd464545",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter"]
                    },
                    "flxRepaymentAccDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "s1bb24340a974e98987aa24654a27407",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew"]
                    },
                    "lblRepaymentAccDetails": {
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "skin": "ICSknlbl424242SSPSemiBold15px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxRepaymentAccDetails"]
                    },
                    "lblSeparator": {
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "left": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSeparatore3e3e3",
                        "text": "Label",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxRepaymentAccDetails"]
                    },
                    "flxTextBox": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer"]
                    },
                    "tbxAcctSelection": {
                        "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxTextBox"]
                    },
                    "lblAccountBal": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxTextBox"]
                    },
                    "lblAcctHoldName": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxAccountHolder"]
                    },
                    "lblValAcctHoldName": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxAccountHolder"]
                    },
                    "segAccounts": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formChangeRepaymentAccountNew", "flxContentTCCenter", "flxContMainNew", "flxAccountList", "flxAccountContainer", "flxSegAccounts"]
                    },
                    "lblSeparator1": {
                        "skin": "sknSeparatore3e3e3",
                        "segmentProps": []
                    },
                    "flxCancelAndContinue": {
                        "height": {
                            "type": "string",
                            "value": "101dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1014dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "left": {
                            "type": "string",
                            "value": "844dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "formChangeRepaymentAccountNew": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "formChangeRepaymentAccountNew.flxContentTCCenter.flxContMainNew.flxAccountList.flxDocumentContainer.uploadFiles3": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formChangeRepaymentAccountNew);
        };
        return [{
            "addWidgets": addWidgetsfrmChangeRepaymentAccountNew,
            "enabledForIdleTimeout": true,
            "id": "frmChangeRepaymentAccountNew",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "preShow": function(eventobject) {
                controller.AS_Form_c32b96ba0a0341f583fc9cceefa81c14(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.ChangeRepaymentAccount\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});