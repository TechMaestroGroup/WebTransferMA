define("PortfolioManagementMA/WealthPortfolioUIModule/frmPastProposal", function() {
    return function(controller) {
        function addWidgetsfrmPastProposal() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.hamburger.myaccounts\")",
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxBack = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "60dp",
                "id": "flxBack",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBack.setDefaultUnit(kony.flex.DP);
            var lblPastProposal = new kony.ui.Label({
                "id": "lblPastProposal",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.pastProposals\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgBack = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25%",
                "id": "imgBack",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "back_icon_blue.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "centerY": "50%",
                "focusSkin": "sknBtn0273e3SSP15px",
                "id": "btnBack",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknBtn0273e3SSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.back\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack.add(lblPastProposal, imgBack, btnBack);
            var flxPastProposal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPastProposal",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPastProposal.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var lblReviewPastProposal = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblReviewPastProposal",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknlbl42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.reviewInvestment\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "2%",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": 49,
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            flxTitle.add(lblReviewPastProposal, flxSeparator);
            var flxSearchandFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90px",
                "id": "flxSearchandFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "50dp",
                "width": "32.80%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchandFilter.setDefaultUnit(kony.flex.DP);
            var lblFilter = new kony.ui.Label({
                "id": "lblFilter",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBBSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.filterWithColon\")",
                "top": "37dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFilterYear = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "44%",
                "id": "flxFilterYear",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "67dp",
                "isModalContainer": false,
                "skin": "CopybbSknFlxBordere",
                "top": "28.50%",
                "width": "77%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterYear.setDefaultUnit(kony.flex.DP);
            var lblFilterYear = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.hamburger.transfers\")"
                },
                "centerY": "50%",
                "id": "lblFilterYear",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.currentYear\")",
                "top": "7dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgFilterUp = new kony.ui.Image2({
                "height": "15%",
                "id": "imgFilterUp",
                "isVisible": true,
                "left": "175dp",
                "src": "listboxuparrow.png",
                "top": "18dp",
                "width": "5%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFilterYear.add(lblFilterYear, imgFilterUp);
            flxSearchandFilter.add(lblFilter, flxFilterYear);
            var flxSeparatorOne = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorOne",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "139dp",
                "width": "32.80%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorOne.setDefaultUnit(kony.flex.DP);
            flxSeparatorOne.add();
            var flxSegData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSegData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "140dp",
                "width": "32.80%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegData.setDefaultUnit(kony.flex.DP);
            var flxPastProposalSegment = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "516px",
                "horizontalScrollIndicator": true,
                "id": "flxPastProposalSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxPastProposalSegment.setDefaultUnit(kony.flex.DP);
            var segProposal = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblContent1": "Released For Training",
                    "lblContent2": "26/11/2020, 6:00 AM",
                    "lblName": "Q4 Investment review and proposal for Digital Advisory portfolio."
                }],
                "groupCells": false,
                "id": "segProposal",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "PortfolioManagementMA",
                    "friendlyName": "flxPastProposal"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxContent1": "flxContent1",
                    "flxContent2": "flxContent2",
                    "flxHead": "flxHead",
                    "flxNews": "flxNews",
                    "flxPastProposal": "flxPastProposal",
                    "flxSeparator": "flxSeparator",
                    "lblContent1": "lblContent1",
                    "lblContent2": "lblContent2",
                    "lblName": "lblName"
                },
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPastProposalSegment.add(segProposal);
            flxSegData.add(flxPastProposalSegment);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "517px",
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "391dp",
                "isModalContainer": false,
                "top": "50dp",
                "width": "67.20%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxSeparatorThree = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorThree",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "516dp",
                "width": "809dp",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorThree.setDefaultUnit(kony.flex.DP);
            flxSeparatorThree.add();
            var lblName = new kony.ui.Label({
                "id": "lblName",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknLbl424242SSPBold30px",
                "text": "Released for Trading",
                "top": "28dp",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDescription = new kony.ui.Label({
                "id": "lblDescription",
                "isVisible": true,
                "left": "35dp",
                "skin": "sknlbl42424215px",
                "text": "Q4 Investment review and proposal for Digital Advisory portfolio.",
                "top": "73dp",
                "width": "73%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDateTime = new kony.ui.Label({
                "id": "lblDateTime",
                "isVisible": true,
                "right": "25dp",
                "skin": "sknBBSSP72727215px",
                "text": "26/11/2020, 6:00 AM",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContent.add(flxSeparatorThree, lblName, lblDescription, lblDateTime);
            var flxSeparatorTwo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "606px",
                "id": "flxSeparatorTwo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "391dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": "50dp",
                "width": "0.01%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorTwo.setDefaultUnit(kony.flex.DP);
            flxSeparatorTwo.add();
            var flxButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "90px",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "width": "67.20%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnViewReport = new kony.ui.Button({
                "centerY": "50%",
                "height": "45%",
                "id": "btnViewReport",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnSSPffffff15pxBg0273e3",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.viewReport\")",
                "top": "0dp",
                "width": "18%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnContactAdvisor = new kony.ui.Button({
                "centerY": "50%",
                "height": "45%",
                "id": "btnContactAdvisor",
                "isVisible": true,
                "left": "467dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.contactAdvisor\")",
                "top": "0dp",
                "width": "18%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(btnViewReport, btnContactAdvisor);
            var flxContextualMenu = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContextualMenu",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "67dp",
                "isModalContainer": false,
                "onTouchEnd": controller.AS_FlexContainer_d5e410b3c47f487f85aa149adc755739,
                "skin": "sknFlxffffffShadowdddcdcBottomRadius",
                "top": "117dp",
                "width": "25.30%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContextualMenu.setDefaultUnit(kony.flex.DP);
            var flxCurrentYear = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40px",
                "id": "flxCurrentYear",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxf9fafb",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrentYear.setDefaultUnit(kony.flex.DP);
            var lblCurrentYear = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPayMakeTransfer\")"
                },
                "centerY": "50%",
                "id": "lblCurrentYear",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.currentYear\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCurrentYear.add(lblCurrentYear);
            var flxPreviousYear = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40px",
                "id": "flxPreviousYear",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPreviousYear.setDefaultUnit(kony.flex.DP);
            var lblPrevYear = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.Pay.PayBills\")"
                },
                "centerY": "50%",
                "id": "lblPrevYear",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.previousYear\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPreviousYear.add(lblPrevYear);
            flxContextualMenu.add(flxCurrentYear, flxPreviousYear);
            flxPastProposal.add(flxTitle, flxSearchandFilter, flxSeparatorOne, flxSegData, flxContent, flxSeparatorTwo, flxButtons, flxContextualMenu);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "130dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnFaqs": {
                        "isVisible": true
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    },
                    "btnPrivacy": {
                        "isVisible": true
                    },
                    "btnTermsAndConditions": {
                        "isVisible": true
                    },
                    "customfooter": {
                        "centerX": "50%",
                        "height": "130dp",
                        "left": "0dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "flxVBar2": {
                        "isVisible": true
                    },
                    "flxVBar3": {
                        "isVisible": true
                    },
                    "flxVBar4": {
                        "isVisible": true
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew, customfooter);
            flxMainContainer.add(flxBack, flxPastProposal, flxFooter);
            flxMain.add(flxMainContainer);
            flxFormContent.add(flxMain);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "Accounts",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxBack": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxFormContent": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBack": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblPastProposal": {
                        "i18n_text": "i18n.wealth.pastProposals",
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "skin": "bbSknLbl424242SSP17Px",
                        "text": "Past Proposals",
                        "top": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "imgBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "15%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "top": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "lblReviewPastProposal": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchandFilter": {
                        "width": {
                            "type": "string",
                            "value": "39.50%"
                        },
                        "segmentProps": []
                    },
                    "lblFilter": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxFilterYear": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "72%"
                        },
                        "segmentProps": []
                    },
                    "lblFilterYear": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgFilterUp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorOne": {
                        "width": {
                            "type": "string",
                            "value": "39.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSegData": {
                        "width": {
                            "type": "string",
                            "value": "39.50%"
                        },
                        "segmentProps": []
                    },
                    "flxPastProposalSegment": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "segProposal": {
                        "data": [{
                            "lblContent1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblContent2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "PortfolioManagementMA",
                            "friendlyName": "flxPastProposal"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxContent1": "flxContent1",
                            "flxContent2": "flxContent2",
                            "flxHead": "flxHead",
                            "flxNews": "flxNews",
                            "flxPastProposal": "flxPastProposal",
                            "flxSeparator": "flxSeparator",
                            "lblContent1": "lblContent1",
                            "lblContent2": "lblContent2",
                            "lblName": "lblName"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "PortfolioManagementMA"
                    },
                    "flxContent": {
                        "left": {
                            "type": "string",
                            "value": "39.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorThree": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblName": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "lblDescription": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "66%"
                        },
                        "segmentProps": []
                    },
                    "lblDateTime": {
                        "left": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorTwo": {
                        "left": {
                            "type": "string",
                            "value": "39.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "reverseLayoutDirection": true,
                        "right": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "60.50%"
                        },
                        "segmentProps": []
                    },
                    "btnViewReport": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "btnContactAdvisor": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "flxContextualMenu": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "-2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "segmentProps": []
                    },
                    "flxBack": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblPastProposal": {
                        "i18n_text": "i18n.wealth.pastProposals",
                        "skin": "bbSknLbl424242SSP17Px",
                        "text": "Past Proposals",
                        "top": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "imgBack": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "15%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "top": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "lblReviewPastProposal": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSearchandFilter": {
                        "width": {
                            "type": "string",
                            "value": "33.30%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterYear": {
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "74%"
                        },
                        "segmentProps": []
                    },
                    "lblFilterYear": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "imgFilterUp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorOne": {
                        "width": {
                            "type": "string",
                            "value": "379dp"
                        },
                        "segmentProps": []
                    },
                    "flxSegData": {
                        "width": {
                            "type": "string",
                            "value": "379dp"
                        },
                        "segmentProps": []
                    },
                    "segProposal": {
                        "data": [{
                            "lblContent1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblContent2": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblName": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "PortfolioManagementMA",
                            "friendlyName": "flxPastProposal"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxContent1": "flxContent1",
                            "flxContent2": "flxContent2",
                            "flxHead": "flxHead",
                            "flxNews": "flxNews",
                            "flxPastProposal": "flxPastProposal",
                            "flxSeparator": "flxSeparator",
                            "lblContent1": "lblContent1",
                            "lblContent2": "lblContent2",
                            "lblName": "lblName"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "PortfolioManagementMA"
                    },
                    "flxContent": {
                        "left": {
                            "type": "string",
                            "value": "378dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "68.60%"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorThree": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "809dp"
                        },
                        "segmentProps": []
                    },
                    "lblName": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "lblDescription": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "lblDateTime": {
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "skin": "ICSkn727272SSPRegular13px",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "27dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorTwo": {
                        "left": {
                            "type": "string",
                            "value": "379dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "reverseLayoutDirection": true,
                        "width": {
                            "type": "string",
                            "value": "68.60%"
                        },
                        "segmentProps": []
                    },
                    "btnViewReport": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnContactAdvisor": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxContextualMenu": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "26.60%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "left": {
                            "type": "string",
                            "value": "-6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxBack": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblPastProposal": {
                        "i18n_text": "i18n.wealth.pastProposals",
                        "text": "Past Proposals",
                        "top": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "imgBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "15%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "top": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "8%"
                        },
                        "top": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "reverseLayoutDirection": true,
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnViewReport": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "btnContactAdvisor": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "130dp",
                    "left": "0dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmPastProposal,
            "enabledForIdleTimeout": true,
            "id": "frmPastProposal",
            "init": controller.AS_Form_caa2bcc8cd254ce5b9afc7517aac5477,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "PortfolioManagementMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});