define("ApprovalRequestMA/ApprovalsReqUIModule/frmApprovalViewDetails", function() {
    return function(controller) {
        function addWidgetsfrmApprovalViewDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderMain.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "headermenu": {
                        "height": "70dp",
                        "right": "6%",
                        "top": "0dp",
                        "width": "94%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderMain.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbsknf8f7f8WithoutBorder",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            var flxOverdraftWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxOverdraftWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverdraftWarning.setDefaultUnit(kony.flex.DP);
            var imgOverDraft = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgOverDraft",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverdraftWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOverdraftWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.OverDraftWarning\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOverdraftWarning.add(imgOverDraft, lblOverdraftWarning, imgCloseWarning);
            var flxOutageWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxOutageWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOutageWarning.setDefaultUnit(kony.flex.DP);
            var imgInfoIconWarning = new kony.ui.Image2({
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgInfoIconWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutageWarning = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblOutageWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "13dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseOutageWarning = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgCloseOutageWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer5vs",
                "src": "icon_close_grey.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOutageWarning.add(imgInfoIconWarning, lblOutageWarning, imgCloseOutageWarning);
            flxMainWrapper.add(flxDowntimeWarning, flxOverdraftWarning, flxOutageWarning);
            var flxskncontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            var flxContentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxContentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "1366dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainer.setDefaultUnit(kony.flex.DP);
            var flxContentHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "75dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var flxBackToPending = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxBackToPending",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "17dp",
                "width": "185dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackToPending.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "height": "19dp",
                "id": "imgBack",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "arrow_left.png",
                "top": "10dp",
                "width": "5dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBackToPending = new kony.ui.Label({
                "id": "lblBackToPending",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknSSP4176a415px",
                "text": "Back to Requests Dashboard",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackToPending.add(imgBack, lblBackToPending);
            var lblContentHeader = new kony.ui.Label({
                "height": "25dp",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.ACHTransactions\")",
                "top": "50dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgDownloadAch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImgDownloadAch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "2%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgDownloadAch.setDefaultUnit(kony.flex.DP);
            var imgDownloadAchTransaction = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgDownloadAchTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbdownloadicon.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgDownloadAch.add(imgDownloadAchTransaction);
            var flxImgPrintAch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImgPrintAch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "93.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "3%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgPrintAch.setDefaultUnit(kony.flex.DP);
            var imgPrintAchTransaction = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgPrintAchTransaction",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "bbprint.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgPrintAch.add(imgPrintAchTransaction);
            flxContentHeader.add(flxBackToPending, lblContentHeader, flxImgDownloadAch, flxImgPrintAch);
            var flxDisplayErrorMessage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "66dp",
                "id": "flxDisplayErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgDisplayError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgDisplayError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDisplayError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblDisplayError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.add(imgDisplayError, lblDisplayError);
            var flxContentDashBoard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContentDashBoard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentDashBoard.setDefaultUnit(kony.flex.DP);
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "4dp",
                "width": "58.19%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var flxTabPaneContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTabPaneContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabPaneContainer.setDefaultUnit(kony.flex.DP);
            var TabPaneNew = new com.InfinityOLB.Resources.TabPaneNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TabPaneNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "MobileCustomDropdown": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": false,
                        "isVisible": false,
                        "zIndex": 1
                    },
                    "MobileCustomDropdown.flxDropdown": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "clipBounds": false,
                        "isVisible": true
                    },
                    "MobileCustomDropdown.flxImage": {
                        "left": "91%"
                    },
                    "MobileCustomDropdown.flxIphoneDropdown": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "4%"
                    },
                    "MobileCustomDropdown.imgDropdown": {
                        "src": "listboxarw.png"
                    },
                    "MobileCustomDropdown.lblView": {
                        "width": "100%"
                    },
                    "MobileCustomDropdown.lblViewType": {
                        "left": "0%",
                        "width": "85%"
                    },
                    "MobileCustomDropdown.segViewTypes": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": true,
                        "zIndex": 15
                    },
                    "PaginationContainer.flxPagination": {
                        "reverseLayoutDirection": true
                    },
                    "PaginationContainer.imgPaginationFirst": {
                        "src": "pagination_inactive.png"
                    },
                    "PaginationContainer.imgPaginationNext": {
                        "src": "pagination_next_active.png"
                    },
                    "PaginationContainer.imgPaginationPrevious": {
                        "src": "pagination_back_inactive.png"
                    },
                    "TabBodyNew": {
                        "isVisible": true,
                        "top": "0dp"
                    },
                    "TabBodyNew.segTemplates": {
                        "isVisible": true,
                        "left": "0dp",
                        "top": "0dp"
                    },
                    "TabSearchBarNew": {
                        "centerY": "viz.val_cleared",
                        "clipBounds": false,
                        "isVisible": true,
                        "zIndex": 1,
                        "layoutType": kony.flex.FREE_FORM
                    },
                    "TabSearchBarNew.MobileCustomDropdown": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "height": "80dp",
                        "isVisible": false,
                        "top": "0dp",
                        "zIndex": 1
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                        "isVisible": false,
                        "left": "4%",
                        "top": "60dp",
                        "width": "92%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxImage": {
                        "clipBounds": false
                    },
                    "TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "bottom": "viz.val_cleared",
                        "height": "40dp",
                        "left": "4%",
                        "minWidth": "viz.val_cleared",
                        "top": "20dp",
                        "width": "100%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.imgDropdown": {
                        "src": "listboxarw.png"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "left": "5%",
                        "minWidth": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "23%"
                    },
                    "TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                        "left": "28%",
                        "right": "viz.val_cleared",
                        "top": "0%",
                        "width": "viz.val_cleared"
                    },
                    "TabSearchBarNew.flxBoxSearch": {
                        "height": "40dp",
                        "left": "0%",
                        "width": "95%"
                    },
                    "TabSearchBarNew.flxDropDown": {
                        "centerY": "47.50%",
                        "height": "50dp",
                        "isVisible": true,
                        "left": "0%",
                        "top": "viz.val_cleared",
                        "zIndex": 1
                    },
                    "TabSearchBarNew.flxOptions": {
                        "height": "100%",
                        "isVisible": false
                    },
                    "TabSearchBarNew.flxSearch": {
                        "isVisible": true,
                        "left": "20dp",
                        "width": "68%"
                    },
                    "TabSearchBarNew.lblView": {
                        "isVisible": true
                    },
                    "TabSearchBarNew.listBoxViewType": {
                        "isVisible": true,
                        "right": "10dp",
                        "width": "67.74%"
                    },
                    "TabSearchBarNew.tbxSearch": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                    },
                    "TabsHeaderNew": {
                        "isVisible": true
                    },
                    "TabsHeaderNew.btnTab4": {
                        "isVisible": false
                    },
                    "TabsHeaderNew.btnTab5": {
                        "isVisible": false
                    },
                    "TabsHeaderNew.btnTab6": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTabPaneContainer.add(TabPaneNew);
            var flxCreateUI = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": true,
                "id": "flxCreateUI",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "Copysknflxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateUI.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var lblTitle = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTitle",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.FillTheDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(lblTitle);
            var flxTopSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "7dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeparator.setDefaultUnit(kony.flex.DP);
            flxTopSeparator.add();
            var NonEditableDetails = new com.InfinityOLB.ApprovalRequestMA.NonEditableDetailsNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "NonEditableDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "98%",
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "NonEditableDetailsNew": {
                        "isVisible": false,
                        "left": "1%",
                        "top": "0dp",
                        "width": "98%"
                    },
                    "btnEdit": {
                        "isVisible": true
                    },
                    "flxBtmSeperator": {
                        "isVisible": true
                    },
                    "flxTitle": {
                        "isVisible": true
                    },
                    "flxTopSepartor": {
                        "isVisible": true
                    },
                    "lblACHTitleText": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCreateDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCreateDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateDetails.setDefaultUnit(kony.flex.DP);
            var flxTemplate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTemplate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplate.setDefaultUnit(kony.flex.DP);
            var lblName = new kony.ui.Label({
                "id": "lblName",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.TemplateName\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTemplateNAme = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxTemplateNAme",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateNAme.setDefaultUnit(kony.flex.DP);
            var tbxTemplateName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "sknTextBoxSSP42424215PxNoBor",
                "height": "100%",
                "id": "tbxTemplateName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "34dp",
                "placeholder": "Template Name",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBor",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015px"
            });
            flxTemplateNAme.add(tbxTemplateName);
            var lblDescription = new kony.ui.Label({
                "id": "lblDescription",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.TemplateDescription\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTemplateDescription = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxTemplateDescription",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateDescription.setDefaultUnit(kony.flex.DP);
            var tbxTemplateDescription = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "sknTextBoxSSP42424215PxNoBor",
                "height": "100%",
                "id": "tbxTemplateDescription",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "34dp",
                "placeholder": "Template Description",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBor",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015px"
            });
            flxTemplateDescription.add(tbxTemplateDescription);
            flxTemplate.add(lblName, flxTemplateNAme, lblDescription, flxTemplateDescription);
            var lblType = new kony.ui.Label({
                "id": "lblType",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.TemplateType\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxType.setDefaultUnit(kony.flex.DP);
            var lstbTemplateType = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox455574SSP15Px",
                "height": "100%",
                "id": "lstbTemplateType",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknListBox455574SSP15Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxType.add(lstbTemplateType);
            var tblRequestType = new kony.ui.Label({
                "id": "tblRequestType",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.RequestType\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRequestType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxRequestType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestType.setDefaultUnit(kony.flex.DP);
            var lstbRequestType = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox455574SSP15Px",
                "height": "100%",
                "id": "lstbRequestType",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknListBox455574SSP15Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxRequestType.add(lstbRequestType);
            flxCreateDetails.add(flxTemplate, lblType, flxType, tblRequestType, flxRequestType);
            var lblCompany = new kony.ui.Label({
                "id": "lblCompany",
                "isVisible": false,
                "left": "2.52%",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Company Name/ID",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCompanyID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxCompanyID",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "right": 425,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCompanyID.setDefaultUnit(kony.flex.DP);
            var lstbCompanyName = new kony.ui.ListBox({
                "focusSkin": "sknListBoxDisableBgf6f6f6Lato15Px",
                "height": "100%",
                "id": "lstbCompanyName",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblSelect", "Select"],
                    ["lblPheonix", "Pheoinx Solutions - 007619340"]
                ],
                "selectedKey": "lblSelect",
                "skin": "sknListBoxDisableBgf6f6f6Lato15Px",
                "top": "0dp",
                "width": "350dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxCompanyID.add(lstbCompanyName);
            var lblPaymentType = new kony.ui.Label({
                "id": "lblPaymentType",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.DebitAccount\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaymentType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxPaymentType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentType.setDefaultUnit(kony.flex.DP);
            var lstbAccount = new kony.ui.ListBox({
                "focusSkin": "bbSknListBox455574SSP15Px",
                "height": "100%",
                "id": "lstbAccount",
                "isVisible": true,
                "left": "0dp",
                "masterData": [
                    ["lblSelect", "Select"],
                    ["lblx7690", "Progress Business Checking - X7690"],
                    ["lblx4710", "Pro Business Checking - X4710"]
                ],
                "selectedKey": "lblSelect",
                "skin": "bbSknListBox455574SSP15Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxPaymentType.add(lstbAccount);
            var flxFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "30dp",
                "width": "94%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrom.setDefaultUnit(kony.flex.DP);
            var lblSelectAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.TransferFrom\")"
                },
                "centerY": "50%",
                "id": "lblSelectAccount",
                "isVisible": false,
                "left": "40dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Pay From",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTypeIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTypeIcon",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "20dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTypeIcon.setDefaultUnit(kony.flex.DP);
            var lblTypeIcon = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblTypeIcon",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblOLBFontIconsvs",
                "text": "g",
                "top": "0",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTypeIcon.add(lblTypeIcon);
            var lblFromAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.TransferFrom\")"
                },
                "centerY": "50%",
                "id": "lblFromAmount",
                "isVisible": false,
                "right": "59dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Transfer From",
                "width": "100dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtTransferFrom = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.SearchByAccountNameOrNumber\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "tbxPlaceholderskna0a0a015px",
                "height": "100%",
                "id": "txtTransferFrom",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.ACH.Select\")",
                "secureTextEntry": false,
                "skin": "tbxPlaceholderskna0a0a015px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%",
                "zIndex": 5
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015px"
            });
            var flxCancelFilterFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxCancelFilterFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxCancelFilterFrom.setDefaultUnit(kony.flex.DP);
            var imgCancelFilterFrom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgCancelFilterFrom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "search_close.png",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            flxCancelFilterFrom.add(imgCancelFilterFrom);
            var flxLoadingContainerFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoadingContainerFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingContainerFrom.setDefaultUnit(kony.flex.DP);
            var flxLoadingIndicatorFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxLoadingIndicatorFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "1%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "36dp",
                "zIndex": 8,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxLoadingIndicatorFrom.setDefaultUnit(kony.flex.DP);
            var imgLoadingIndicatorFrom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.payAPersonDeregister\")"
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgLoadingIndicatorFrom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "rb_4_0_ad_loading_indicator.gif",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Remove"
            });
            flxLoadingIndicatorFrom.add(imgLoadingIndicatorFrom);
            flxLoadingContainerFrom.add(flxLoadingIndicatorFrom);
            flxFrom.add(lblSelectAccount, flxTypeIcon, lblFromAmount, txtTransferFrom, flxCancelFilterFrom, flxLoadingContainerFrom);
            var flxFromSegment = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "5dp",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "300dp",
                "horizontalScrollIndicator": true,
                "id": "flxFromSegment",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFlxscrollffffffShadowCustom",
                "top": "70dp",
                "verticalScrollIndicator": true,
                "width": "94%",
                "zIndex": 10
            }, {
                "paddingInPixel": false
            }, {});
            flxFromSegment.setDefaultUnit(kony.flex.DP);
            var segTransferFrom = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segTransferFrom",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxFromAccountsList"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxTransfersFromListHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountListitem": "flxAccountListitem",
                    "flxAmount": "flxAmount",
                    "flxBankIcon": "flxBankIcon",
                    "flxDropdown": "flxDropdown",
                    "flxFromAccountsList": "flxFromAccountsList",
                    "flxIcons": "flxIcons",
                    "flxSeparator": "flxSeparator",
                    "flxTransfersFromListHeader": "flxTransfersFromListHeader",
                    "imgBankIcon": "imgBankIcon",
                    "imgDropdown": "imgDropdown",
                    "imgIcon": "imgIcon",
                    "lblAccType": "lblAccType",
                    "lblAccountName": "lblAccountName",
                    "lblAmount": "lblAmount",
                    "lblCurrencySymbol": "lblCurrencySymbol",
                    "lblTransactionHeader": "lblTransactionHeader"
                },
                "zIndex": 5,
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoAccountsFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "5dp",
                "clipBounds": true,
                "height": "172dp",
                "id": "flxNoAccountsFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "sknFFFFFF",
                "top": "0dp",
                "width": "94%",
                "zIndex": 10,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoAccountsFrom.setDefaultUnit(kony.flex.DP);
            var lblNoAccountsFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoAccountsToTransferFrom\")"
                },
                "centerX": "50%",
                "height": "24dp",
                "id": "lblNoAccountsFrom",
                "isVisible": true,
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoAccountsToTransferFrom\")",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoAccountsFrom.add(lblNoAccountsFrom);
            var flxNoResultsFrom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxNoResultsFrom",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoResultsFrom.setDefaultUnit(kony.flex.DP);
            var lblNoResultsFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoResultsFound\")"
                },
                "centerX": "50%",
                "id": "lblNoResultsFrom",
                "isVisible": true,
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.NoResultsFound\")",
                "top": "40dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoResultsFrom.add(lblNoResultsFrom);
            flxFromSegment.add(segTransferFrom, flxNoAccountsFrom, flxNoResultsFrom);
            var lblMaxAmt = new kony.ui.Label({
                "id": "lblMaxAmt",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.MaximumTransferAmount\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxMaxAmt = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxMaxAmt",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMaxAmt.setDefaultUnit(kony.flex.DP);
            var lblCurrSymbol = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCurrSymbol",
                "isVisible": true,
                "left": "4%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.currencySymbol\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxMaxAmt = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "sknTextBoxSSP42424215PxNoBor",
                "height": "40dp",
                "id": "tbxMaxAmt",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "8%",
                "placeholder": "0.00",
                "secureTextEntry": false,
                "skin": "sknTextBoxSSP42424215PxNoBor",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": 0,
                "width": "91%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknTextBoxSSP42424215PxNoBor",
                "placeholderSkin": "tbxPlaceholderskna0a0a015px"
            });
            flxMaxAmt.add(lblCurrSymbol, tbxMaxAmt);
            var lblEffectiveDate = new kony.ui.Label({
                "id": "lblEffectiveDate",
                "isVisible": true,
                "left": "2.52%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.EffectiveDate\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45dp",
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "88.68%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var flxEffectiveDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxEffectiveDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEffectiveDate.setDefaultUnit(kony.flex.DP);
            var calEffectiveDate = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": [null, null, null, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "height": "100%",
                "id": "calEffectiveDate",
                "isVisible": true,
                "left": "0dp",
                "placeholder": "dd/mm/yyyy",
                "skin": "sknBBCal42424215px",
                "top": "0dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxEffectiveDate.add(calEffectiveDate);
            var lblNotTodayMsg = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNotTodayMsg",
                "isVisible": true,
                "left": "21dp",
                "skin": "sknLato72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.CannotBeTodaysDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDate.add(flxEffectiveDate, lblNotTodayMsg);
            var flxBottomSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBottomSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "18dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeperator.setDefaultUnit(kony.flex.DP);
            flxBottomSeperator.add();
            var createFlowFormActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "centerX": "50%",
                "height": "111dp",
                "id": "createFlowFormActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                        "left": "viz.val_cleared",
                        "right": "23%",
                        "width": "18%"
                    },
                    "btnNext": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.Proceed\")",
                        "left": "77.35%",
                        "width": "18.99%"
                    },
                    "btnOption": {
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "43.50%",
                        "width": "18%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCreateUI.add(flxHeader, flxTopSeparator, NonEditableDetails, flxCreateDetails, lblCompany, flxCompanyID, lblPaymentType, flxPaymentType, flxFrom, flxFromSegment, lblMaxAmt, flxMaxAmt, lblEffectiveDate, flxDate, flxBottomSeperator, createFlowFormActionsNew);
            var flxACHFilesUpload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "clipBounds": false,
                "id": "flxACHFilesUpload",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFilesUpload.setDefaultUnit(kony.flex.DP);
            var flxACHFilesHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxACHFilesHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFilesHeader.setDefaultUnit(kony.flex.DP);
            var lblUploadFilesHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUploadFilesHeader",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.SelectTheFormatAndUpload\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxACHFilesHeader.add(lblUploadFilesHeader);
            var flxACHFilesSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "7dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxACHFilesSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFilesSeparator.setDefaultUnit(kony.flex.DP);
            flxACHFilesSeparator.add();
            var flxErrorFlow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxErrorFlow",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "94.97%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorFlow.setDefaultUnit(kony.flex.DP);
            var flxErrorUpload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52dp",
                "id": "flxErrorUpload",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorUpload.setDefaultUnit(kony.flex.DP);
            var imgUploadFileError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "30dp",
                "id": "imgUploadFileError",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadFailMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "You have already added all the accounts you have with us."
                },
                "centerY": "50%",
                "id": "lblUploadFailMessage",
                "isVisible": true,
                "left": "70dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.ACHFileErrorMessage\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorUpload.add(imgUploadFileError, lblUploadFailMessage);
            flxErrorFlow.add(flxErrorUpload);
            var lblFormatType = new kony.ui.Label({
                "id": "lblFormatType",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl455574SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.FormatType\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFormatType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxFormatType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "5dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormatType.setDefaultUnit(kony.flex.DP);
            var lstbFormatType = new kony.ui.ListBox({
                "focusSkin": "sknListBoxDisableBgf6f6f6Lato15Px",
                "height": "100%",
                "id": "lstbFormatType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknListBoxDisableBgf6f6f6Lato15Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxFormatType.add(lstbFormatType);
            var lblUploadFile = new kony.ui.Label({
                "id": "lblUploadFile",
                "isVisible": true,
                "left": "2.52%",
                "skin": "bbSknLbl455574SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.UploadFile\")",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadFile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "105dp",
                "id": "flxUploadFile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "isModalContainer": false,
                "skin": "bbsknUploadflxf5f5f5",
                "top": "5dp",
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadFile.setDefaultUnit(kony.flex.DP);
            var imgPlusSign = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "35%",
                "height": "40dp",
                "id": "imgPlusSign",
                "isVisible": true,
                "skin": "slImage",
                "src": "bb_addicon.png",
                "top": "7dp",
                "width": "32dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblClickUpload = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "60%",
                "id": "lblClickUpload",
                "isVisible": true,
                "skin": "bbsknA0A0A015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.ClicktoUpload\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadFile.add(imgPlusSign, lblClickUpload);
            var flxUploadedFileDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxUploadedFileDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFileDetails.setDefaultUnit(kony.flex.DP);
            var flxUploadedFile = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "50dp",
                "id": "flxUploadedFile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.52%",
                "maxWidth": "40%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "0dp",
                "width": 330,
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFile.setDefaultUnit(kony.flex.DP);
            var flxFileTypeImage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFileTypeImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileTypeImage.setDefaultUnit(kony.flex.DP);
            var imgFileType = new kony.ui.Image2({
                "height": "100%",
                "id": "imgFileType",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "pdf_image.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileTypeImage.add(imgFileType);
            var lblFIleName = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFIleName",
                "isVisible": true,
                "left": "60dp",
                "skin": "sknBBLato0273e315px",
                "text": "FileName.Nacha",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgdownload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxImgdownload",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgdownload.setDefaultUnit(kony.flex.DP);
            var imgDownloadFIle = new kony.ui.Image2({
                "centerX": "50%",
                "height": "100%",
                "id": "imgDownloadFIle",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbdownloadicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgdownload.add(imgDownloadFIle);
            flxUploadedFile.add(flxFileTypeImage, lblFIleName, flxImgdownload);
            var btnRemoveFile = new kony.ui.Button({
                "height": "50dp",
                "id": "btnRemoveFile",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBBBtn273e3NoBorder15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.payAPersonDeregister\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedFileDetails.add(flxUploadedFile, btnRemoveFile);
            var flxACHFilesSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxACHFilesSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": 90,
                "width": "94.97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFilesSeparator2.setDefaultUnit(kony.flex.DP);
            flxACHFilesSeparator2.add();
            var flxFilesACHActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFilesACHActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilesACHActions.setDefaultUnit(kony.flex.DP);
            var ACHFilesActions = new com.InfinityOLB.ApprovalRequestMA.formActions({
                "centerX": "50%",
                "height": "111dp",
                "id": "ACHFilesActions",
                "isVisible": false,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "viewType": "ACHFilesActions",
                "overrides": {
                    "formActions": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var ACHFilesActions_data = (appConfig.componentMetadata && appConfig.componentMetadata["ApprovalRequestMA"] && appConfig.componentMetadata["ApprovalRequestMA"]["frmApprovalViewDetails"] && appConfig.componentMetadata["ApprovalRequestMA"]["frmApprovalViewDetails"]["ACHFilesActions"]) || {};
            var filesFormActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "centerX": "50%",
                "height": "111dp",
                "id": "filesFormActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.cancel\")",
                        "left": "viz.val_cleared",
                        "right": "23%",
                        "width": "18%"
                    },
                    "btnNext": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.Proceed\")",
                        "left": "viz.val_cleared",
                        "width": "18%"
                    },
                    "btnOption": {
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "43.50%",
                        "width": "18%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFilesACHActions.add(ACHFilesActions, filesFormActionsNew);
            flxACHFilesUpload.add(flxACHFilesHeader, flxACHFilesSeparator, flxErrorFlow, lblFormatType, flxFormatType, lblUploadFile, flxUploadFile, flxUploadedFileDetails, flxACHFilesSeparator2, flxFilesACHActions);
            flxDashboard.add(flxTabPaneContainer, flxCreateUI, flxACHFilesUpload);
            var dbRightContainerNew = new com.InfinityOLB.Resources.dbRightContainerNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "dbRightContainerNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.10%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "28.68%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "dbRightContainerNew": {
                        "top": "0dp",
                        "width": "28.68%"
                    },
                    "imgBanner": {
                        "src": "nuo_banner_1.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxContentDashBoard.add(flxDashboard, dbRightContainerNew);
            var flxAcknowledgementContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "72dp",
                "id": "flxAcknowledgementContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgement = new com.InfinityOLB.Resources.flxAcknowledgement({
                "centerY": "50%",
                "height": "100%",
                "id": "flxAcknowledgement",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ResourcesMA",
                "viewType": "flxAcknowledgement",
                "overrides": {
                    "flxTickImage": {
                        "width": "4.44%"
                    },
                    "rTextSuccess": {
                        "text": "Your transaction has been successfully submitted\nReference Number 45423792753"
                    },
                    "flxAcknowledgement": {
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAcknowledgement_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmApprovalViewDetails"] && appConfig.componentMetadata["ResourcesMA"]["frmApprovalViewDetails"]["flxAcknowledgement"]) || {};
            var flxAcknowledgementNew = new com.InfinityOLB.Resources.flxAcknowledgementNew({
                "height": "100%",
                "id": "flxAcknowledgementNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxAckContainer": {
                        "height": "72dp"
                    },
                    "flxAcknowledgementNew": {
                        "left": "0dp",
                        "width": "100%"
                    },
                    "flxImgPrint": {
                        "isVisible": false
                    },
                    "flxImgdownload": {
                        "isVisible": false
                    },
                    "flxTickImage": {
                        "height": "34dp",
                        "width": "3%"
                    },
                    "imgDownload": {
                        "isVisible": false,
                        "src": "bbdownloadicon.png"
                    },
                    "imgPrint": {
                        "src": "bbprint.png"
                    },
                    "imgTick": {
                        "left": "10dp",
                        "src": "bulk_billpay_success.png",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "lblRefrenceId": {
                        "top": "35dp"
                    },
                    "lblRefrenceId2": {
                        "isVisible": true,
                        "top": "35dp"
                    },
                    "lblSuccess": {
                        "isVisible": true,
                        "top": "10dp"
                    },
                    "rTextSuccess": {
                        "isVisible": false,
                        "text": "<body> User has been Successfully Added <br> Reference Number 45423792753 </body>"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {
                    "imgTick": {
                        "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS
                    }
                }
            }, {
                "overrides": {}
            });
            flxAcknowledgementContainer.add(flxAcknowledgement, flxAcknowledgementNew);
            var flxTransactionDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "focusSkin": "slfBoxffffffB1R5",
                "id": "flxTransactionDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionDetails.setDefaultUnit(kony.flex.DP);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(imgError, lblError);
            var flxACHFileUploadDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "200dp",
                "id": "flxACHFileUploadDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxACHFileUploadDetails.setDefaultUnit(kony.flex.DP);
            var lblACHfileDetails = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblACHfileDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.YourACHFileDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl424242SSP15Px"
            });
            var flxTopSepartor = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSepartor",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSepartor.setDefaultUnit(kony.flex.DP);
            var imgTopSeparatorEmpty = new kony.ui.Image2({
                "height": "150dp",
                "id": "imgTopSeparatorEmpty",
                "isVisible": false,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopSepartor.add(imgTopSeparatorEmpty);
            var flxFomatType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "slFboxffffff",
                "id": "flxFomatType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": 20,
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFomatType.setDefaultUnit(kony.flex.DP);
            var lblFomatTypeAck = new kony.ui.Label({
                "id": "lblFomatTypeAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.FormatTypeColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var lblFormatTypeValue = new kony.ui.Label({
                "id": "lblFormatTypeValue",
                "isVisible": true,
                "left": "270dp",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Nacha",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl455574SSP15Px"
            });
            flxFomatType.add(lblFomatTypeAck, lblFormatTypeValue);
            var flxFileUploadRequest = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "slFboxffffff",
                "id": "flxFileUploadRequest",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "20dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileUploadRequest.setDefaultUnit(kony.flex.DP);
            var lblRequestTypeAck = new kony.ui.Label({
                "id": "lblRequestTypeAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.RequestTypeColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var lblRequestTypeValue = new kony.ui.Label({
                "id": "lblRequestTypeValue",
                "isVisible": true,
                "left": "270dp",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "PPD",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl455574SSP15Px"
            });
            flxFileUploadRequest.add(lblRequestTypeAck, lblRequestTypeValue);
            var flxFileUploadAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "focusSkin": "slFboxffffff",
                "id": "flxFileUploadAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "20dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileUploadAck.setDefaultUnit(kony.flex.DP);
            var lblUploadedFile = new kony.ui.Label({
                "id": "lblUploadedFile",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.UploadedFileColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var flxUploadedFileAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "50dp",
                "id": "flxUploadedFileAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "270dp",
                "maxWidth": "40%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "0dp",
                "width": 330,
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFileAck.setDefaultUnit(kony.flex.DP);
            var flxFileTypeImageAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFileTypeImageAck",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileTypeImageAck.setDefaultUnit(kony.flex.DP);
            var imgFileTypeAck = new kony.ui.Image2({
                "height": "100%",
                "id": "imgFileTypeAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "pdf_image.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileTypeImageAck.add(imgFileTypeAck);
            var lblFileNameAck = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFileNameAck",
                "isVisible": true,
                "left": "60dp",
                "skin": "sknBBLato0273e315px",
                "text": "FileName.Nacha",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgdownloadAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxImgdownloadAck",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "width": "20dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgdownloadAck.setDefaultUnit(kony.flex.DP);
            var imgDownloadFIleAck = new kony.ui.Image2({
                "centerX": "50%",
                "height": "100%",
                "id": "imgDownloadFIleAck",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbdownloadicon.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgdownloadAck.add(imgDownloadFIleAck);
            flxUploadedFileAck.add(flxFileTypeImageAck, lblFileNameAck, flxImgdownloadAck);
            flxFileUploadAck.add(lblUploadedFile, flxUploadedFileAck);
            flxACHFileUploadDetails.add(lblACHfileDetails, flxTopSepartor, flxFomatType, flxFileUploadRequest, flxFileUploadAck);
            var NonEditableDetailsNew = new com.InfinityOLB.ApprovalRequestMA.NonEditableDetailsNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "NonEditableDetailsNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "5dp",
                "width": "100%",
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "flxBtmSeperator": {
                        "centerX": "50%",
                        "isVisible": true,
                        "top": "13dp",
                        "width": "96.67%"
                    },
                    "flxDetailsHeading": {
                        "height": "50dp"
                    },
                    "flxSupportingDocuments": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT
                    },
                    "flxTopSepartor": {
                        "centerX": "50%",
                        "width": "96.67%"
                    },
                    "lblACHTitleText": {
                        "centerY": "viz.val_cleared",
                        "height": "22dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.template.ACH\")",
                        "top": "12dp"
                    },
                    "segDetails": {
                        "centerX": "viz.val_cleared",
                        "left": "2%",
                        "top": "13dp",
                        "width": "96.50%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxDateContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "122dp",
                "id": "flxDateContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDateContainer.setDefaultUnit(kony.flex.DP);
            var flxEffectiveDateSelect = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "30dp",
                "centerX": "31.27%",
                "clipBounds": false,
                "height": "74dp",
                "id": "flxEffectiveDateSelect",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "40dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "59.26%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEffectiveDateSelect.setDefaultUnit(kony.flex.DP);
            var lblDate = new kony.ui.Label({
                "height": "30dp",
                "id": "lblDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.EffectiveDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDate1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45dp",
                "id": "flxDate1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "2dp",
                "width": "88.68%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate1.setDefaultUnit(kony.flex.DP);
            var flxEffectDate1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxEffectDate1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEffectDate1.setDefaultUnit(kony.flex.DP);
            var calEffectiveDate1 = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": [null, null, null, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "height": "100%",
                "id": "calEffectiveDate1",
                "isVisible": true,
                "left": "0dp",
                "placeholder": "dd/MM/yyyy",
                "skin": "sknBBSSP455574cal15px",
                "top": "0dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxEffectDate1.add(calEffectiveDate1);
            var lblNotTodayDate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNotTodayDate",
                "isVisible": true,
                "left": "21dp",
                "skin": "sknLato72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.CannotBeTodaysDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDate1.add(flxEffectDate1, lblNotTodayDate);
            flxEffectiveDateSelect.add(lblDate, flxDate1);
            var flxDateBottomSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxDateBottomSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "120dp",
                "width": "96.66%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDateBottomSeperator.setDefaultUnit(kony.flex.DP);
            var lblSample1 = new kony.ui.Label({
                "id": "lblSample1",
                "isVisible": true,
                "left": "1.58%",
                "skin": "sknSSP4176a415px",
                "text": "Name",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDateBottomSeperator.add(lblSample1);
            flxDateContainer.add(flxEffectiveDateSelect, flxDateBottomSeperator);
            var flxPaymentInstruction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "96dp",
                "id": "flxPaymentInstruction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentInstruction.setDefaultUnit(kony.flex.DP);
            var lblPayemntInstruction = new kony.ui.Label({
                "id": "lblPayemntInstruction",
                "isVisible": true,
                "left": "1.66%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.SetPaymentInstruction\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var flxPaymentOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPaymentOptions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "22.58%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "60%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentOptions.setDefaultUnit(kony.flex.DP);
            var imgRadiobtn1 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgRadiobtn1",
                "isVisible": true,
                "left": 6,
                "skin": "slImage",
                "src": "radioactivebb.png",
                "top": 18,
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOption1 = new kony.ui.Label({
                "id": "lblOption1",
                "isVisible": true,
                "left": 33,
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Do not process details with amounts of $0.00",
                "top": 19,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRadiobtn2 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgRadiobtn2",
                "isVisible": true,
                "left": 6,
                "skin": "slImage",
                "src": "radioinactivebb.png",
                "top": 44,
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOption2 = new kony.ui.Label({
                "id": "lblOption2",
                "isVisible": true,
                "left": 33,
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Send details with amounts of $0.00 as payments",
                "top": 45,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentOptions.add(imgRadiobtn1, lblOption1, imgRadiobtn2, lblOption2);
            flxPaymentInstruction.add(lblPayemntInstruction, flxPaymentOptions);
            var flxAckPaymentInstruction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "52dp",
                "id": "flxAckPaymentInstruction",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckPaymentInstruction.setDefaultUnit(kony.flex.DP);
            var lblAckPayemntInstruction = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAckPayemntInstruction",
                "isVisible": true,
                "left": "1.66%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.ach.PaymentInstruction\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var lblAckPaymentInstructionValue = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblAckPaymentInstructionValue",
                "isVisible": true,
                "left": "22.58%",
                "skin": "bbSknLbl455574SSP15Px",
                "text": "Do not process details with amounts of $0.00",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            flxAckPaymentInstruction.add(lblAckPayemntInstruction, lblAckPaymentInstructionValue);
            var flxSeperator4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": 0,
                "width": "96.66%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator4.setDefaultUnit(kony.flex.DP);
            var lblSample = new kony.ui.Label({
                "id": "lblSample",
                "isVisible": true,
                "left": "1.58%",
                "skin": "sknSSP4176a415px",
                "text": "Name",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeperator4.add(lblSample);
            var flxTemplateRecordHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "115dp",
                "id": "flxTemplateRecordHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateRecordHeader.setDefaultUnit(kony.flex.DP);
            var lblRecordHeader1 = new kony.ui.Label({
                "id": "lblRecordHeader1",
                "isVisible": true,
                "left": "1.66%",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.CreditorDestinationAccount\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var lblRecordHeader2 = new kony.ui.Label({
                "id": "lblRecordHeader2",
                "isVisible": true,
                "left": "1.66%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.accountInfo\")",
                "top": "70dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknlbla0a0a015px"
            });
            var flxSeperatorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": 50,
                "width": "96.66%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorHeader.setDefaultUnit(kony.flex.DP);
            var lblsampleHeader = new kony.ui.Label({
                "id": "lblsampleHeader",
                "isVisible": true,
                "left": "1.58%",
                "skin": "sknSSP4176a415px",
                "text": "Name",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeperatorHeader.add(lblsampleHeader);
            flxTemplateRecordHeader.add(lblRecordHeader1, lblRecordHeader2, flxSeperatorHeader);
            var flxTemplateRecordsErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxTemplateRecordsErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateRecordsErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgTemplateRecordsError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgTemplateRecordsError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTemplateRecordsError = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "50%",
                "id": "lblTemplateRecordsError",
                "isVisible": true,
                "left": "25dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTemplateRecordsErrorSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTemplateRecordsErrorSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateRecordsErrorSeperator.setDefaultUnit(kony.flex.DP);
            flxTemplateRecordsErrorSeperator.add();
            flxTemplateRecordsErrorMessage.add(imgTemplateRecordsError, lblTemplateRecordsError, flxTemplateRecordsErrorSeperator);
            var TemplateRecordsNew = new com.InfinityOLB.ApprovalRequestMA.TemplateRecordsNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TemplateRecordsNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "TabBodyNew.segTemplates": {
                        "left": "0dp"
                    },
                    "btnAddAdditionalDetailsRow": {
                        "isVisible": false
                    },
                    "btnUpdate": {
                        "centerY": "50%",
                        "left": "0.93%",
                        "right": "3%",
                        "top": "viz.val_cleared"
                    },
                    "flxSeparator": {
                        "width": "100%"
                    },
                    "flxTotalAmount": {
                        "left": "79%",
                        "right": "viz.val_cleared"
                    },
                    "lblColon": {
                        "isVisible": true
                    },
                    "lblCurrSymbol": {
                        "left": "7%"
                    },
                    "lblTotalAmmount": {
                        "centerY": "50%",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.totalAmountWithColon\")"
                    },
                    "lblTotalAmount": {
                        "left": "viz.val_cleared"
                    },
                    "lblTotalAmountCreate": {
                        "left": "13%"
                    },
                    "tbxTotalAmount": {
                        "left": "77%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTransactionDetails.add(flxErrorMessage, flxACHFileUploadDetails, NonEditableDetailsNew, flxDateContainer, flxPaymentInstruction, flxAckPaymentInstruction, flxSeperator4, flxTemplateRecordHeader, flxTemplateRecordsErrorMessage, TemplateRecordsNew);
            var flxRequestCreateEditUpdateEditDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxRequestCreateEditUpdateEditDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "87.80%",
                "zIndex": 3,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestCreateEditUpdateEditDetails.setDefaultUnit(kony.flex.DP);
            var flxTabs = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxTabs",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabs.setDefaultUnit(kony.flex.DP);
            var TabsContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "TabsContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            TabsContent.setDefaultUnit(kony.flex.DP);
            var btnTab1 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnTab1",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnAccountSummarySelected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ApprovalsRequest.UpdatedDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var btnTab2 = new kony.ui.Button({
                "height": "50dp",
                "id": "btnTab2",
                "isVisible": true,
                "skin": "sknBtnAccountSummaryUnselected",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ApprovalsRequest.ExistingDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            TabsContent.add(btnTab1, btnTab2);
            var flxTabsSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxTabsSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabsSeparator.setDefaultUnit(kony.flex.DP);
            flxTabsSeparator.add();
            flxTabs.add(TabsContent, flxTabsSeparator);
            var flxUpdatedAndExistingDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxUpdatedAndExistingDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpdatedAndExistingDetails.setDefaultUnit(kony.flex.DP);
            var lblHeaderDetails = new kony.ui.Label({
                "id": "lblHeaderDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ApprovalsRequest.UpdatedDetails\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUpdatedAndExistingDetailsTopSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxUpdatedAndExistingDetailsTopSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpdatedAndExistingDetailsTopSeparator.setDefaultUnit(kony.flex.DP);
            flxUpdatedAndExistingDetailsTopSeparator.add();
            var segUpdatedAndExistingDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segUpdatedAndExistingDetails",
                "isVisible": true,
                "left": "2%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxNonEditableDetailsAppr"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "13dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxKey": "flxKey",
                    "flxMain": "flxMain",
                    "flxNonEditableDetailsAppr": "flxNonEditableDetailsAppr",
                    "flxValue": "flxValue",
                    "lblColon": "lblColon",
                    "lblIcon": "lblIcon",
                    "lblKey": "lblKey",
                    "lblValue": "lblValue",
                    "lblValueOld": "lblValueOld"
                },
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUpdatedAndExistingDetailsBottomSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxUpdatedAndExistingDetailsBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpdatedAndExistingDetailsBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxUpdatedAndExistingDetailsBottomSeparator.add();
            flxUpdatedAndExistingDetails.add(lblHeaderDetails, flxUpdatedAndExistingDetailsTopSeparator, segUpdatedAndExistingDetails, flxUpdatedAndExistingDetailsBottomSeparator);
            var flxRequestDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRequestDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestDetails.setDefaultUnit(kony.flex.DP);
            var lblCreatedDetails = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblCreatedDetails",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAlertsWarningWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "20px",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxAlertsWarningWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "right": "0px",
                "skin": "CopyCopyslFbox3",
                "top": "20dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAlertsWarningWrapper.setDefaultUnit(kony.flex.DP);
            var imgAlertsWarningImage = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "30dp",
                "id": "imgAlertsWarningImage",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "roadmap_info.png",
                "top": "5dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAlertsWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "20dp",
                "id": "lblAlertsWarning",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknLabelSSP42424215px",
                "text": "Since the rule has been created, there are no existing details",
                "top": "10dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAlertsWarningWrapper.add(imgAlertsWarningImage, lblAlertsWarning);
            var flxCreateRequestInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCreateRequestInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateRequestInfo.setDefaultUnit(kony.flex.DP);
            var flxSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            var lblRecipientInforation = new kony.ui.Label({
                "id": "lblRecipientInforation",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var SegmentRecipientInfoDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "ImgIsUpdatedStatus": "",
                    "lblColon": "",
                    "lblIsUpdatedStatus": "",
                    "lblKey": "",
                    "lblValue": ""
                }],
                "groupCells": false,
                "id": "SegmentRecipientInfoDetails",
                "isVisible": true,
                "left": "2%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxNonEditableRecipientanditsbankDetails"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "10dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "ImgIsUpdatedStatus": "ImgIsUpdatedStatus",
                    "flxFlag": "flxFlag",
                    "flxKey": "flxKey",
                    "flxMain": "flxMain",
                    "flxNonEditableRecipientanditsbankDetails": "flxNonEditableRecipientanditsbankDetails",
                    "flxValue": "flxValue",
                    "lblColon": "lblColon",
                    "lblIsUpdatedStatus": "lblIsUpdatedStatus",
                    "lblKey": "lblKey",
                    "lblValue": "lblValue"
                },
                "width": "96.50%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperatorBankDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorBankDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "8dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorBankDetails.setDefaultUnit(kony.flex.DP);
            flxSeperatorBankDetails.add();
            var lblRecipientBankInfo = new kony.ui.Label({
                "id": "lblRecipientBankInfo",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "text": "Recipient's Bank Information",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var SegmentRecipientBankDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "ImgIsUpdatedStatus": "",
                    "lblColon": "",
                    "lblIsUpdatedStatus": "",
                    "lblKey": "",
                    "lblValue": ""
                }],
                "groupCells": false,
                "id": "SegmentRecipientBankDetails",
                "isVisible": true,
                "left": "20dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxNonEditableRecipientanditsbankDetails"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "10dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "ImgIsUpdatedStatus": "ImgIsUpdatedStatus",
                    "flxFlag": "flxFlag",
                    "flxKey": "flxKey",
                    "flxMain": "flxMain",
                    "flxNonEditableRecipientanditsbankDetails": "flxNonEditableRecipientanditsbankDetails",
                    "flxValue": "flxValue",
                    "lblColon": "lblColon",
                    "lblIsUpdatedStatus": "lblIsUpdatedStatus",
                    "lblKey": "lblKey",
                    "lblValue": "lblValue"
                },
                "width": "96.50%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxBelowSeparatorBankDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBelowSeparatorBankDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBelowSeparatorBankDetails.setDefaultUnit(kony.flex.DP);
            flxBelowSeparatorBankDetails.add();
            var lblRecipientsLinkedWith = new kony.ui.Label({
                "id": "lblRecipientsLinkedWith",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "text": "Recipient Linked With",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUserActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxUserActions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserActions.setDefaultUnit(kony.flex.DP);
            var flxSearchUser = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSearchUser",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "0dp",
                "width": "65%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchUser.setDefaultUnit(kony.flex.DP);
            var flxUserSearchContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxUserSearchContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserSearchContent.setDefaultUnit(kony.flex.DP);
            var lblSearchUser = new kony.ui.Label({
                "id": "lblSearchUser",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtUsersSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtUsersSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "5dp",
                "placeholder": "Search by username, role, or user ID",
                "secureTextEntry": false,
                "skin": "tbxPlaceholderskna0a0a015pxNoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0",
                "width": "90%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxUserSearchContent.add(lblSearchUser, txtUsersSearch);
            var flxUserSearchClear = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxUserSearchClear",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "width": "40dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserSearchClear.setDefaultUnit(kony.flex.DP);
            var lblUserSearchClear = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "lblUserSearchClear",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserSearchClear.add(lblUserSearchClear);
            flxSearchUser.add(flxUserSearchContent, flxUserSearchClear);
            var flxUserFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxUserFilter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff2pxe3e3e3border",
                "top": "0",
                "width": "30%",
                "zIndex": 3,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserFilter.setDefaultUnit(kony.flex.DP);
            var flxFilterContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxFilterContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterContent.setDefaultUnit(kony.flex.DP);
            var lblUserFilter = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUserFilter",
                "isVisible": true,
                "left": "10dp",
                "skin": "ICSknLblSSP64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.View\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUserFilterValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUserFilterValue",
                "isVisible": true,
                "left": "8dp",
                "skin": "sknLblSSP000d1915Px",
                "text": "All",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFilterContent.add(lblUserFilter, lblUserFilterValue);
            var flxUserDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxUserDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0",
                "width": "24dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserDropdown.setDefaultUnit(kony.flex.DP);
            var lblUserDropdown = new kony.ui.Label({
                "height": "100%",
                "id": "lblUserDropdown",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbl6e7081olbfonticons14px",
                "text": "O",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUserDropdown.add(lblUserDropdown);
            var flxFilterDropdownContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFilterDropdownContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "40dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterDropdownContainer.setDefaultUnit(kony.flex.DP);
            var flxFilterByUserRoleContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFilterByUserRoleContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterByUserRoleContainer.setDefaultUnit(kony.flex.DP);
            var lblFilterByUserRole = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFilterByUserRole",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl424242SSPS15Px",
                "text": "Filter by User Role",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFilterByUserRoleContainer.add(lblFilterByUserRole);
            var flxSeperator3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeperator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator3.setDefaultUnit(kony.flex.DP);
            flxSeperator3.add();
            var segFilter = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }, {
                    "lblCheckFeature": "L",
                    "lblFeatureName": "Label"
                }],
                "groupCells": false,
                "id": "segFilter",
                "isVisible": true,
                "left": "15dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "AboutUsMA",
                    "friendlyName": "flxTimePeriodMain"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFeatureRow": "flxFeatureRow",
                    "flxTimePeriodMain": "flxTimePeriodMain",
                    "lblCheckFeature": "lblCheckFeature",
                    "lblFeatureName": "lblFeatureName"
                },
                "width": "90%",
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeperator5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator5.setDefaultUnit(kony.flex.DP);
            flxSeperator5.add();
            var flxButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnCancel2 = new kony.ui.Button({
                "bottom": "10dp",
                "focusSkin": "bbSknBtn4176a4NoBorder",
                "height": "40dp",
                "id": "btnCancel2",
                "isVisible": true,
                "left": "35%",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "top": 10,
                "width": "20%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnApply2 = new kony.ui.Button({
                "bottom": 10,
                "focusSkin": "sknBtnNormalSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnApply2",
                "isVisible": true,
                "left": "2%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LocateUs.APPLY\")",
                "top": 10,
                "width": "40%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(btnCancel2, btnApply2);
            flxFilterDropdownContainer.add(flxFilterByUserRoleContainer, flxSeperator3, segFilter, flxSeperator5, flxButtons);
            flxUserFilter.add(flxFilterContent, flxUserDropdown, flxFilterDropdownContainer);
            flxUserActions.add(flxSearchUser, flxUserFilter);
            var contractListRecipient = new com.InfinityOLB.Approvals.contractListRecipient({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "id": "contractListRecipient",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "flxContract": {
                        "width": "87.50%"
                    },
                    "imgCol1": {
                        "src": "sorting_next.png"
                    },
                    "imgCol2": {
                        "src": "sorting.png"
                    },
                    "imgCol3": {
                        "src": "sorting.png"
                    },
                    "lblCol3": {
                        "text": "Identity Number"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxPagination = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPagination",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0",
                "width": "165dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPagination.setDefaultUnit(kony.flex.DP);
            var flxPaginationNext = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPaginationNext",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "ICSknlFbox0c25ccb78edbc49",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationNext.setDefaultUnit(kony.flex.DP);
            var imgPaginationNext = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"konybb.nextPage\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "24dp",
                "id": "imgPaginationNext",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "pagination_next_active.png",
                "width": "60%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Next"
            });
            flxPaginationNext.add(imgPaginationNext);
            var lblPagination = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "1-20 Transactions"
                },
                "centerY": "50%",
                "id": "lblPagination",
                "isVisible": true,
                "left": "3%",
                "right": "3%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "1 of  10 Pages",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaginationPrevious = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxPaginationPrevious",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "ICSknlFbox0c25ccb78edbc49",
                "top": "0dp",
                "width": "40dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaginationPrevious.setDefaultUnit(kony.flex.DP);
            var imgPaginationPrevious = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"konybb.previousPage\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "24dp",
                "id": "imgPaginationPrevious",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "skin": "slImage",
                "src": "pagination_back_inactive.png",
                "width": "60%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Previous"
            });
            flxPaginationPrevious.add(imgPaginationPrevious);
            flxPagination.add(flxPaginationNext, lblPagination, flxPaginationPrevious);
            flxCreateRequestInfo.add(flxSeperator, lblRecipientInforation, SegmentRecipientInfoDetails, flxSeperatorBankDetails, lblRecipientBankInfo, SegmentRecipientBankDetails, flxBelowSeparatorBankDetails, lblRecipientsLinkedWith, flxUserActions, contractListRecipient, flxPagination);
            flxRequestDetails.add(lblCreatedDetails, flxAlertsWarningWrapper, flxCreateRequestInfo);
            var flxApprovalConditionsDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxApprovalConditionsDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalConditionsDetails.setDefaultUnit(kony.flex.DP);
            var flxApprovalConditionsSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxApprovalConditionsSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0",
                "skin": "sknflxe9ebee",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalConditionsSeparator.setDefaultUnit(kony.flex.DP);
            flxApprovalConditionsSeparator.add();
            var segApprovalConditions = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "CopylblFromGroupHdr0a35c31d780f348": "From Group",
                    "CopylblFromGroupHdr0bf31adf393d744": "From Group",
                    "CopylblFromGroupHdr0c266d737a55145": "From Group",
                    "CopylblFromGroupHdr0c9fa2c53256149": "From Group",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "From Group",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "From Group",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "From Group",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "From Group",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "From Group",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "From Group",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "From Group",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "From Group",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "From Group",
                    "CopylblFromGroupHdr0i5c76f3276544e": "From Group",
                    "CopylblFromGroupHdr0i89f887911cb4d": "From Group",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "Managers",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "Managers",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "Managers",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "Managers",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "Managers",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "Managers",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "Managers",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "Managers",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "Managers",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "Managers",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "Managers",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "Managers",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "Managers",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "Managers",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "Managers",
                    "CopylblORTest0a43062a04e584a": "OR",
                    "CopylblORTest0ada221e5d9074d": "OR",
                    "CopylblORTest0c702b41f96874d": "OR",
                    "CopylblORTest0cd08740e4cdb4d": "OR",
                    "CopylblORTest0d131465445964f": "OR",
                    "CopylblORTest0d19594f3dd8148": "OR",
                    "CopylblORTest0f819674600c043": "OR",
                    "CopylblORTest0fca00ccd696c4f": "OR",
                    "CopylblORTest0g3dbb53be09c4a": "OR",
                    "CopylblORTest0g4bc43e97d0b41": "OR",
                    "CopylblORTest0geda5e12706849": "OR",
                    "CopylblORTest0i704448499074d": "OR",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "4",
                    "CopylblRequiredApprovalsCount0b655698c352349": "4",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "4",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "4",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "4",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "4",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "4",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "4",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "4",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "4",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "4",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "4",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "4",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "4",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "4",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "Required Approvals",
                    "lblANDText1": "AND",
                    "lblANDText2": "AND",
                    "lblANDText3": "AND",
                    "lblANDText4": "AND",
                    "lblCondition1": "Condition 1",
                    "lblCondition2": "Condition 1",
                    "lblCondition3": "Condition 1",
                    "lblCondition4": "Condition 1",
                    "lblCondition5": "Condition 1",
                    "lblDropdown": "d",
                    "lblFromGroupHdr1in1": "From Group",
                    "lblFromGroupHdr1in2": "From Group",
                    "lblFromGroupHdr1in3": "From Group",
                    "lblFromGroupHdr1in4": "From Group",
                    "lblFromGroupHdr1in5": "From Group",
                    "lblFromGroupHdr2in1": "From Group",
                    "lblFromGroupHdr2in2": "From Group",
                    "lblFromGroupHdr2in3": "From Group",
                    "lblFromGroupHdr2in4": "From Group",
                    "lblFromGroupHdr2in5": "From Group",
                    "lblFromGroupSelectedVal1in1": "Managers",
                    "lblFromGroupSelectedVal1in2": "Managers",
                    "lblFromGroupSelectedVal1in3": "Managers",
                    "lblFromGroupSelectedVal1in4": "Managers",
                    "lblFromGroupSelectedVal1in5": "Managers",
                    "lblFromGroupSelectedVal2in1": "Managers",
                    "lblFromGroupSelectedVal2in2": "Managers",
                    "lblFromGroupSelectedVal2in3": "Managers",
                    "lblFromGroupSelectedVal2in4": "Managers",
                    "lblFromGroupSelectedVal2in5": "Managers",
                    "lblLeftKey": "Label",
                    "lblLeftValue": "Label",
                    "lblORTest1in1": "OR",
                    "lblORTest1in2": "OR",
                    "lblORTest1in3": "OR",
                    "lblORTest1in4": "OR",
                    "lblORTest2in1": "OR",
                    "lblORTest2in2": "OR",
                    "lblORTest2in3": "OR",
                    "lblORTest2in4": "OR",
                    "lblRequiredApprovals1in3": "Required Approvals",
                    "lblRequiredApprovalsCount1in1": "4",
                    "lblRequiredApprovalsCount1in2": "4",
                    "lblRequiredApprovalsCount1in3": "4",
                    "lblRequiredApprovalsCount1in4": "4",
                    "lblRequiredApprovalsCount1in5": "4",
                    "lblRequiredApprovalsCount2in1": "4",
                    "lblRequiredApprovalsCount2in2": "4",
                    "lblRequiredApprovalsCount2in3": "4",
                    "lblRequiredApprovalsCount2in4": "4",
                    "lblRequiredApprovalsCount2in5": "4",
                    "lblRequiredApprovalsHdr1in1": "Required Approvals",
                    "lblRequiredApprovalsHdr1in2": "Required Approvals",
                    "lblRequiredApprovalsHdr1in4": "Required Approvals",
                    "lblRequiredApprovalsHdr1in5": "Required Approvals",
                    "lblRequiredApprovalsHdr2in1": "Required Approvals",
                    "lblRequiredApprovalsHdr2in2": "Required Approvals",
                    "lblRequiredApprovalsHdr2in3": "Required Approvals",
                    "lblRequiredApprovalsHdr2in4": "Required Approvals",
                    "lblRequiredApprovalsHdr2in5": "Required Approvals",
                    "lblRightKey": "Label",
                    "lblRightValue": "Label"
                }, {
                    "CopylblFromGroupHdr0a35c31d780f348": "From Group",
                    "CopylblFromGroupHdr0bf31adf393d744": "From Group",
                    "CopylblFromGroupHdr0c266d737a55145": "From Group",
                    "CopylblFromGroupHdr0c9fa2c53256149": "From Group",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "From Group",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "From Group",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "From Group",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "From Group",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "From Group",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "From Group",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "From Group",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "From Group",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "From Group",
                    "CopylblFromGroupHdr0i5c76f3276544e": "From Group",
                    "CopylblFromGroupHdr0i89f887911cb4d": "From Group",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "Managers",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "Managers",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "Managers",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "Managers",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "Managers",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "Managers",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "Managers",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "Managers",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "Managers",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "Managers",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "Managers",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "Managers",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "Managers",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "Managers",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "Managers",
                    "CopylblORTest0a43062a04e584a": "OR",
                    "CopylblORTest0ada221e5d9074d": "OR",
                    "CopylblORTest0c702b41f96874d": "OR",
                    "CopylblORTest0cd08740e4cdb4d": "OR",
                    "CopylblORTest0d131465445964f": "OR",
                    "CopylblORTest0d19594f3dd8148": "OR",
                    "CopylblORTest0f819674600c043": "OR",
                    "CopylblORTest0fca00ccd696c4f": "OR",
                    "CopylblORTest0g3dbb53be09c4a": "OR",
                    "CopylblORTest0g4bc43e97d0b41": "OR",
                    "CopylblORTest0geda5e12706849": "OR",
                    "CopylblORTest0i704448499074d": "OR",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "4",
                    "CopylblRequiredApprovalsCount0b655698c352349": "4",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "4",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "4",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "4",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "4",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "4",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "4",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "4",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "4",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "4",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "4",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "4",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "4",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "4",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "Required Approvals",
                    "lblANDText1": "AND",
                    "lblANDText2": "AND",
                    "lblANDText3": "AND",
                    "lblANDText4": "AND",
                    "lblCondition1": "Condition 1",
                    "lblCondition2": "Condition 1",
                    "lblCondition3": "Condition 1",
                    "lblCondition4": "Condition 1",
                    "lblCondition5": "Condition 1",
                    "lblDropdown": "d",
                    "lblFromGroupHdr1in1": "From Group",
                    "lblFromGroupHdr1in2": "From Group",
                    "lblFromGroupHdr1in3": "From Group",
                    "lblFromGroupHdr1in4": "From Group",
                    "lblFromGroupHdr1in5": "From Group",
                    "lblFromGroupHdr2in1": "From Group",
                    "lblFromGroupHdr2in2": "From Group",
                    "lblFromGroupHdr2in3": "From Group",
                    "lblFromGroupHdr2in4": "From Group",
                    "lblFromGroupHdr2in5": "From Group",
                    "lblFromGroupSelectedVal1in1": "Managers",
                    "lblFromGroupSelectedVal1in2": "Managers",
                    "lblFromGroupSelectedVal1in3": "Managers",
                    "lblFromGroupSelectedVal1in4": "Managers",
                    "lblFromGroupSelectedVal1in5": "Managers",
                    "lblFromGroupSelectedVal2in1": "Managers",
                    "lblFromGroupSelectedVal2in2": "Managers",
                    "lblFromGroupSelectedVal2in3": "Managers",
                    "lblFromGroupSelectedVal2in4": "Managers",
                    "lblFromGroupSelectedVal2in5": "Managers",
                    "lblLeftKey": "Label",
                    "lblLeftValue": "Label",
                    "lblORTest1in1": "OR",
                    "lblORTest1in2": "OR",
                    "lblORTest1in3": "OR",
                    "lblORTest1in4": "OR",
                    "lblORTest2in1": "OR",
                    "lblORTest2in2": "OR",
                    "lblORTest2in3": "OR",
                    "lblORTest2in4": "OR",
                    "lblRequiredApprovals1in3": "Required Approvals",
                    "lblRequiredApprovalsCount1in1": "4",
                    "lblRequiredApprovalsCount1in2": "4",
                    "lblRequiredApprovalsCount1in3": "4",
                    "lblRequiredApprovalsCount1in4": "4",
                    "lblRequiredApprovalsCount1in5": "4",
                    "lblRequiredApprovalsCount2in1": "4",
                    "lblRequiredApprovalsCount2in2": "4",
                    "lblRequiredApprovalsCount2in3": "4",
                    "lblRequiredApprovalsCount2in4": "4",
                    "lblRequiredApprovalsCount2in5": "4",
                    "lblRequiredApprovalsHdr1in1": "Required Approvals",
                    "lblRequiredApprovalsHdr1in2": "Required Approvals",
                    "lblRequiredApprovalsHdr1in4": "Required Approvals",
                    "lblRequiredApprovalsHdr1in5": "Required Approvals",
                    "lblRequiredApprovalsHdr2in1": "Required Approvals",
                    "lblRequiredApprovalsHdr2in2": "Required Approvals",
                    "lblRequiredApprovalsHdr2in3": "Required Approvals",
                    "lblRequiredApprovalsHdr2in4": "Required Approvals",
                    "lblRequiredApprovalsHdr2in5": "Required Approvals",
                    "lblRightKey": "Label",
                    "lblRightValue": "Label"
                }, {
                    "CopylblFromGroupHdr0a35c31d780f348": "From Group",
                    "CopylblFromGroupHdr0bf31adf393d744": "From Group",
                    "CopylblFromGroupHdr0c266d737a55145": "From Group",
                    "CopylblFromGroupHdr0c9fa2c53256149": "From Group",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "From Group",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "From Group",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "From Group",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "From Group",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "From Group",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "From Group",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "From Group",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "From Group",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "From Group",
                    "CopylblFromGroupHdr0i5c76f3276544e": "From Group",
                    "CopylblFromGroupHdr0i89f887911cb4d": "From Group",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "Managers",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "Managers",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "Managers",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "Managers",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "Managers",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "Managers",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "Managers",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "Managers",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "Managers",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "Managers",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "Managers",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "Managers",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "Managers",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "Managers",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "Managers",
                    "CopylblORTest0a43062a04e584a": "OR",
                    "CopylblORTest0ada221e5d9074d": "OR",
                    "CopylblORTest0c702b41f96874d": "OR",
                    "CopylblORTest0cd08740e4cdb4d": "OR",
                    "CopylblORTest0d131465445964f": "OR",
                    "CopylblORTest0d19594f3dd8148": "OR",
                    "CopylblORTest0f819674600c043": "OR",
                    "CopylblORTest0fca00ccd696c4f": "OR",
                    "CopylblORTest0g3dbb53be09c4a": "OR",
                    "CopylblORTest0g4bc43e97d0b41": "OR",
                    "CopylblORTest0geda5e12706849": "OR",
                    "CopylblORTest0i704448499074d": "OR",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "4",
                    "CopylblRequiredApprovalsCount0b655698c352349": "4",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "4",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "4",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "4",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "4",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "4",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "4",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "4",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "4",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "4",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "4",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "4",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "4",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "4",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "Required Approvals",
                    "lblANDText1": "AND",
                    "lblANDText2": "AND",
                    "lblANDText3": "AND",
                    "lblANDText4": "AND",
                    "lblCondition1": "Condition 1",
                    "lblCondition2": "Condition 1",
                    "lblCondition3": "Condition 1",
                    "lblCondition4": "Condition 1",
                    "lblCondition5": "Condition 1",
                    "lblDropdown": "d",
                    "lblFromGroupHdr1in1": "From Group",
                    "lblFromGroupHdr1in2": "From Group",
                    "lblFromGroupHdr1in3": "From Group",
                    "lblFromGroupHdr1in4": "From Group",
                    "lblFromGroupHdr1in5": "From Group",
                    "lblFromGroupHdr2in1": "From Group",
                    "lblFromGroupHdr2in2": "From Group",
                    "lblFromGroupHdr2in3": "From Group",
                    "lblFromGroupHdr2in4": "From Group",
                    "lblFromGroupHdr2in5": "From Group",
                    "lblFromGroupSelectedVal1in1": "Managers",
                    "lblFromGroupSelectedVal1in2": "Managers",
                    "lblFromGroupSelectedVal1in3": "Managers",
                    "lblFromGroupSelectedVal1in4": "Managers",
                    "lblFromGroupSelectedVal1in5": "Managers",
                    "lblFromGroupSelectedVal2in1": "Managers",
                    "lblFromGroupSelectedVal2in2": "Managers",
                    "lblFromGroupSelectedVal2in3": "Managers",
                    "lblFromGroupSelectedVal2in4": "Managers",
                    "lblFromGroupSelectedVal2in5": "Managers",
                    "lblLeftKey": "Label",
                    "lblLeftValue": "Label",
                    "lblORTest1in1": "OR",
                    "lblORTest1in2": "OR",
                    "lblORTest1in3": "OR",
                    "lblORTest1in4": "OR",
                    "lblORTest2in1": "OR",
                    "lblORTest2in2": "OR",
                    "lblORTest2in3": "OR",
                    "lblORTest2in4": "OR",
                    "lblRequiredApprovals1in3": "Required Approvals",
                    "lblRequiredApprovalsCount1in1": "4",
                    "lblRequiredApprovalsCount1in2": "4",
                    "lblRequiredApprovalsCount1in3": "4",
                    "lblRequiredApprovalsCount1in4": "4",
                    "lblRequiredApprovalsCount1in5": "4",
                    "lblRequiredApprovalsCount2in1": "4",
                    "lblRequiredApprovalsCount2in2": "4",
                    "lblRequiredApprovalsCount2in3": "4",
                    "lblRequiredApprovalsCount2in4": "4",
                    "lblRequiredApprovalsCount2in5": "4",
                    "lblRequiredApprovalsHdr1in1": "Required Approvals",
                    "lblRequiredApprovalsHdr1in2": "Required Approvals",
                    "lblRequiredApprovalsHdr1in4": "Required Approvals",
                    "lblRequiredApprovalsHdr1in5": "Required Approvals",
                    "lblRequiredApprovalsHdr2in1": "Required Approvals",
                    "lblRequiredApprovalsHdr2in2": "Required Approvals",
                    "lblRequiredApprovalsHdr2in3": "Required Approvals",
                    "lblRequiredApprovalsHdr2in4": "Required Approvals",
                    "lblRequiredApprovalsHdr2in5": "Required Approvals",
                    "lblRightKey": "Label",
                    "lblRightValue": "Label"
                }, {
                    "CopylblFromGroupHdr0a35c31d780f348": "From Group",
                    "CopylblFromGroupHdr0bf31adf393d744": "From Group",
                    "CopylblFromGroupHdr0c266d737a55145": "From Group",
                    "CopylblFromGroupHdr0c9fa2c53256149": "From Group",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "From Group",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "From Group",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "From Group",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "From Group",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "From Group",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "From Group",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "From Group",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "From Group",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "From Group",
                    "CopylblFromGroupHdr0i5c76f3276544e": "From Group",
                    "CopylblFromGroupHdr0i89f887911cb4d": "From Group",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "Managers",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "Managers",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "Managers",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "Managers",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "Managers",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "Managers",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "Managers",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "Managers",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "Managers",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "Managers",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "Managers",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "Managers",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "Managers",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "Managers",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "Managers",
                    "CopylblORTest0a43062a04e584a": "OR",
                    "CopylblORTest0ada221e5d9074d": "OR",
                    "CopylblORTest0c702b41f96874d": "OR",
                    "CopylblORTest0cd08740e4cdb4d": "OR",
                    "CopylblORTest0d131465445964f": "OR",
                    "CopylblORTest0d19594f3dd8148": "OR",
                    "CopylblORTest0f819674600c043": "OR",
                    "CopylblORTest0fca00ccd696c4f": "OR",
                    "CopylblORTest0g3dbb53be09c4a": "OR",
                    "CopylblORTest0g4bc43e97d0b41": "OR",
                    "CopylblORTest0geda5e12706849": "OR",
                    "CopylblORTest0i704448499074d": "OR",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "4",
                    "CopylblRequiredApprovalsCount0b655698c352349": "4",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "4",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "4",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "4",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "4",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "4",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "4",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "4",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "4",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "4",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "4",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "4",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "4",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "4",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "Required Approvals",
                    "lblANDText1": "AND",
                    "lblANDText2": "AND",
                    "lblANDText3": "AND",
                    "lblANDText4": "AND",
                    "lblCondition1": "Condition 1",
                    "lblCondition2": "Condition 1",
                    "lblCondition3": "Condition 1",
                    "lblCondition4": "Condition 1",
                    "lblCondition5": "Condition 1",
                    "lblDropdown": "d",
                    "lblFromGroupHdr1in1": "From Group",
                    "lblFromGroupHdr1in2": "From Group",
                    "lblFromGroupHdr1in3": "From Group",
                    "lblFromGroupHdr1in4": "From Group",
                    "lblFromGroupHdr1in5": "From Group",
                    "lblFromGroupHdr2in1": "From Group",
                    "lblFromGroupHdr2in2": "From Group",
                    "lblFromGroupHdr2in3": "From Group",
                    "lblFromGroupHdr2in4": "From Group",
                    "lblFromGroupHdr2in5": "From Group",
                    "lblFromGroupSelectedVal1in1": "Managers",
                    "lblFromGroupSelectedVal1in2": "Managers",
                    "lblFromGroupSelectedVal1in3": "Managers",
                    "lblFromGroupSelectedVal1in4": "Managers",
                    "lblFromGroupSelectedVal1in5": "Managers",
                    "lblFromGroupSelectedVal2in1": "Managers",
                    "lblFromGroupSelectedVal2in2": "Managers",
                    "lblFromGroupSelectedVal2in3": "Managers",
                    "lblFromGroupSelectedVal2in4": "Managers",
                    "lblFromGroupSelectedVal2in5": "Managers",
                    "lblLeftKey": "Label",
                    "lblLeftValue": "Label",
                    "lblORTest1in1": "OR",
                    "lblORTest1in2": "OR",
                    "lblORTest1in3": "OR",
                    "lblORTest1in4": "OR",
                    "lblORTest2in1": "OR",
                    "lblORTest2in2": "OR",
                    "lblORTest2in3": "OR",
                    "lblORTest2in4": "OR",
                    "lblRequiredApprovals1in3": "Required Approvals",
                    "lblRequiredApprovalsCount1in1": "4",
                    "lblRequiredApprovalsCount1in2": "4",
                    "lblRequiredApprovalsCount1in3": "4",
                    "lblRequiredApprovalsCount1in4": "4",
                    "lblRequiredApprovalsCount1in5": "4",
                    "lblRequiredApprovalsCount2in1": "4",
                    "lblRequiredApprovalsCount2in2": "4",
                    "lblRequiredApprovalsCount2in3": "4",
                    "lblRequiredApprovalsCount2in4": "4",
                    "lblRequiredApprovalsCount2in5": "4",
                    "lblRequiredApprovalsHdr1in1": "Required Approvals",
                    "lblRequiredApprovalsHdr1in2": "Required Approvals",
                    "lblRequiredApprovalsHdr1in4": "Required Approvals",
                    "lblRequiredApprovalsHdr1in5": "Required Approvals",
                    "lblRequiredApprovalsHdr2in1": "Required Approvals",
                    "lblRequiredApprovalsHdr2in2": "Required Approvals",
                    "lblRequiredApprovalsHdr2in3": "Required Approvals",
                    "lblRequiredApprovalsHdr2in4": "Required Approvals",
                    "lblRequiredApprovalsHdr2in5": "Required Approvals",
                    "lblRightKey": "Label",
                    "lblRightValue": "Label"
                }, {
                    "CopylblFromGroupHdr0a35c31d780f348": "From Group",
                    "CopylblFromGroupHdr0bf31adf393d744": "From Group",
                    "CopylblFromGroupHdr0c266d737a55145": "From Group",
                    "CopylblFromGroupHdr0c9fa2c53256149": "From Group",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "From Group",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "From Group",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "From Group",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "From Group",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "From Group",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "From Group",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "From Group",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "From Group",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "From Group",
                    "CopylblFromGroupHdr0i5c76f3276544e": "From Group",
                    "CopylblFromGroupHdr0i89f887911cb4d": "From Group",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "Managers",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "Managers",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "Managers",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "Managers",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "Managers",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "Managers",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "Managers",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "Managers",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "Managers",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "Managers",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "Managers",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "Managers",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "Managers",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "Managers",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "Managers",
                    "CopylblORTest0a43062a04e584a": "OR",
                    "CopylblORTest0ada221e5d9074d": "OR",
                    "CopylblORTest0c702b41f96874d": "OR",
                    "CopylblORTest0cd08740e4cdb4d": "OR",
                    "CopylblORTest0d131465445964f": "OR",
                    "CopylblORTest0d19594f3dd8148": "OR",
                    "CopylblORTest0f819674600c043": "OR",
                    "CopylblORTest0fca00ccd696c4f": "OR",
                    "CopylblORTest0g3dbb53be09c4a": "OR",
                    "CopylblORTest0g4bc43e97d0b41": "OR",
                    "CopylblORTest0geda5e12706849": "OR",
                    "CopylblORTest0i704448499074d": "OR",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "4",
                    "CopylblRequiredApprovalsCount0b655698c352349": "4",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "4",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "4",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "4",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "4",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "4",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "4",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "4",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "4",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "4",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "4",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "4",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "4",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "4",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "Required Approvals",
                    "lblANDText1": "AND",
                    "lblANDText2": "AND",
                    "lblANDText3": "AND",
                    "lblANDText4": "AND",
                    "lblCondition1": "Condition 1",
                    "lblCondition2": "Condition 1",
                    "lblCondition3": "Condition 1",
                    "lblCondition4": "Condition 1",
                    "lblCondition5": "Condition 1",
                    "lblDropdown": "d",
                    "lblFromGroupHdr1in1": "From Group",
                    "lblFromGroupHdr1in2": "From Group",
                    "lblFromGroupHdr1in3": "From Group",
                    "lblFromGroupHdr1in4": "From Group",
                    "lblFromGroupHdr1in5": "From Group",
                    "lblFromGroupHdr2in1": "From Group",
                    "lblFromGroupHdr2in2": "From Group",
                    "lblFromGroupHdr2in3": "From Group",
                    "lblFromGroupHdr2in4": "From Group",
                    "lblFromGroupHdr2in5": "From Group",
                    "lblFromGroupSelectedVal1in1": "Managers",
                    "lblFromGroupSelectedVal1in2": "Managers",
                    "lblFromGroupSelectedVal1in3": "Managers",
                    "lblFromGroupSelectedVal1in4": "Managers",
                    "lblFromGroupSelectedVal1in5": "Managers",
                    "lblFromGroupSelectedVal2in1": "Managers",
                    "lblFromGroupSelectedVal2in2": "Managers",
                    "lblFromGroupSelectedVal2in3": "Managers",
                    "lblFromGroupSelectedVal2in4": "Managers",
                    "lblFromGroupSelectedVal2in5": "Managers",
                    "lblLeftKey": "Label",
                    "lblLeftValue": "Label",
                    "lblORTest1in1": "OR",
                    "lblORTest1in2": "OR",
                    "lblORTest1in3": "OR",
                    "lblORTest1in4": "OR",
                    "lblORTest2in1": "OR",
                    "lblORTest2in2": "OR",
                    "lblORTest2in3": "OR",
                    "lblORTest2in4": "OR",
                    "lblRequiredApprovals1in3": "Required Approvals",
                    "lblRequiredApprovalsCount1in1": "4",
                    "lblRequiredApprovalsCount1in2": "4",
                    "lblRequiredApprovalsCount1in3": "4",
                    "lblRequiredApprovalsCount1in4": "4",
                    "lblRequiredApprovalsCount1in5": "4",
                    "lblRequiredApprovalsCount2in1": "4",
                    "lblRequiredApprovalsCount2in2": "4",
                    "lblRequiredApprovalsCount2in3": "4",
                    "lblRequiredApprovalsCount2in4": "4",
                    "lblRequiredApprovalsCount2in5": "4",
                    "lblRequiredApprovalsHdr1in1": "Required Approvals",
                    "lblRequiredApprovalsHdr1in2": "Required Approvals",
                    "lblRequiredApprovalsHdr1in4": "Required Approvals",
                    "lblRequiredApprovalsHdr1in5": "Required Approvals",
                    "lblRequiredApprovalsHdr2in1": "Required Approvals",
                    "lblRequiredApprovalsHdr2in2": "Required Approvals",
                    "lblRequiredApprovalsHdr2in3": "Required Approvals",
                    "lblRequiredApprovalsHdr2in4": "Required Approvals",
                    "lblRequiredApprovalsHdr2in5": "Required Approvals",
                    "lblRightKey": "Label",
                    "lblRightValue": "Label"
                }, {
                    "CopylblFromGroupHdr0a35c31d780f348": "From Group",
                    "CopylblFromGroupHdr0bf31adf393d744": "From Group",
                    "CopylblFromGroupHdr0c266d737a55145": "From Group",
                    "CopylblFromGroupHdr0c9fa2c53256149": "From Group",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "From Group",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "From Group",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "From Group",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "From Group",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "From Group",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "From Group",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "From Group",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "From Group",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "From Group",
                    "CopylblFromGroupHdr0i5c76f3276544e": "From Group",
                    "CopylblFromGroupHdr0i89f887911cb4d": "From Group",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "Managers",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "Managers",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "Managers",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "Managers",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "Managers",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "Managers",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "Managers",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "Managers",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "Managers",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "Managers",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "Managers",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "Managers",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "Managers",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "Managers",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "Managers",
                    "CopylblORTest0a43062a04e584a": "OR",
                    "CopylblORTest0ada221e5d9074d": "OR",
                    "CopylblORTest0c702b41f96874d": "OR",
                    "CopylblORTest0cd08740e4cdb4d": "OR",
                    "CopylblORTest0d131465445964f": "OR",
                    "CopylblORTest0d19594f3dd8148": "OR",
                    "CopylblORTest0f819674600c043": "OR",
                    "CopylblORTest0fca00ccd696c4f": "OR",
                    "CopylblORTest0g3dbb53be09c4a": "OR",
                    "CopylblORTest0g4bc43e97d0b41": "OR",
                    "CopylblORTest0geda5e12706849": "OR",
                    "CopylblORTest0i704448499074d": "OR",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "4",
                    "CopylblRequiredApprovalsCount0b655698c352349": "4",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "4",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "4",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "4",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "4",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "4",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "4",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "4",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "4",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "4",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "4",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "4",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "4",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "4",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "Required Approvals",
                    "lblANDText1": "AND",
                    "lblANDText2": "AND",
                    "lblANDText3": "AND",
                    "lblANDText4": "AND",
                    "lblCondition1": "Condition 1",
                    "lblCondition2": "Condition 1",
                    "lblCondition3": "Condition 1",
                    "lblCondition4": "Condition 1",
                    "lblCondition5": "Condition 1",
                    "lblDropdown": "d",
                    "lblFromGroupHdr1in1": "From Group",
                    "lblFromGroupHdr1in2": "From Group",
                    "lblFromGroupHdr1in3": "From Group",
                    "lblFromGroupHdr1in4": "From Group",
                    "lblFromGroupHdr1in5": "From Group",
                    "lblFromGroupHdr2in1": "From Group",
                    "lblFromGroupHdr2in2": "From Group",
                    "lblFromGroupHdr2in3": "From Group",
                    "lblFromGroupHdr2in4": "From Group",
                    "lblFromGroupHdr2in5": "From Group",
                    "lblFromGroupSelectedVal1in1": "Managers",
                    "lblFromGroupSelectedVal1in2": "Managers",
                    "lblFromGroupSelectedVal1in3": "Managers",
                    "lblFromGroupSelectedVal1in4": "Managers",
                    "lblFromGroupSelectedVal1in5": "Managers",
                    "lblFromGroupSelectedVal2in1": "Managers",
                    "lblFromGroupSelectedVal2in2": "Managers",
                    "lblFromGroupSelectedVal2in3": "Managers",
                    "lblFromGroupSelectedVal2in4": "Managers",
                    "lblFromGroupSelectedVal2in5": "Managers",
                    "lblLeftKey": "Label",
                    "lblLeftValue": "Label",
                    "lblORTest1in1": "OR",
                    "lblORTest1in2": "OR",
                    "lblORTest1in3": "OR",
                    "lblORTest1in4": "OR",
                    "lblORTest2in1": "OR",
                    "lblORTest2in2": "OR",
                    "lblORTest2in3": "OR",
                    "lblORTest2in4": "OR",
                    "lblRequiredApprovals1in3": "Required Approvals",
                    "lblRequiredApprovalsCount1in1": "4",
                    "lblRequiredApprovalsCount1in2": "4",
                    "lblRequiredApprovalsCount1in3": "4",
                    "lblRequiredApprovalsCount1in4": "4",
                    "lblRequiredApprovalsCount1in5": "4",
                    "lblRequiredApprovalsCount2in1": "4",
                    "lblRequiredApprovalsCount2in2": "4",
                    "lblRequiredApprovalsCount2in3": "4",
                    "lblRequiredApprovalsCount2in4": "4",
                    "lblRequiredApprovalsCount2in5": "4",
                    "lblRequiredApprovalsHdr1in1": "Required Approvals",
                    "lblRequiredApprovalsHdr1in2": "Required Approvals",
                    "lblRequiredApprovalsHdr1in4": "Required Approvals",
                    "lblRequiredApprovalsHdr1in5": "Required Approvals",
                    "lblRequiredApprovalsHdr2in1": "Required Approvals",
                    "lblRequiredApprovalsHdr2in2": "Required Approvals",
                    "lblRequiredApprovalsHdr2in3": "Required Approvals",
                    "lblRequiredApprovalsHdr2in4": "Required Approvals",
                    "lblRequiredApprovalsHdr2in5": "Required Approvals",
                    "lblRightKey": "Label",
                    "lblRightValue": "Label"
                }, {
                    "CopylblFromGroupHdr0a35c31d780f348": "From Group",
                    "CopylblFromGroupHdr0bf31adf393d744": "From Group",
                    "CopylblFromGroupHdr0c266d737a55145": "From Group",
                    "CopylblFromGroupHdr0c9fa2c53256149": "From Group",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "From Group",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "From Group",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "From Group",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "From Group",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "From Group",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "From Group",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "From Group",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "From Group",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "From Group",
                    "CopylblFromGroupHdr0i5c76f3276544e": "From Group",
                    "CopylblFromGroupHdr0i89f887911cb4d": "From Group",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "Managers",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "Managers",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "Managers",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "Managers",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "Managers",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "Managers",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "Managers",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "Managers",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "Managers",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "Managers",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "Managers",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "Managers",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "Managers",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "Managers",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "Managers",
                    "CopylblORTest0a43062a04e584a": "OR",
                    "CopylblORTest0ada221e5d9074d": "OR",
                    "CopylblORTest0c702b41f96874d": "OR",
                    "CopylblORTest0cd08740e4cdb4d": "OR",
                    "CopylblORTest0d131465445964f": "OR",
                    "CopylblORTest0d19594f3dd8148": "OR",
                    "CopylblORTest0f819674600c043": "OR",
                    "CopylblORTest0fca00ccd696c4f": "OR",
                    "CopylblORTest0g3dbb53be09c4a": "OR",
                    "CopylblORTest0g4bc43e97d0b41": "OR",
                    "CopylblORTest0geda5e12706849": "OR",
                    "CopylblORTest0i704448499074d": "OR",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "4",
                    "CopylblRequiredApprovalsCount0b655698c352349": "4",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "4",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "4",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "4",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "4",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "4",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "4",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "4",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "4",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "4",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "4",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "4",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "4",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "4",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "Required Approvals",
                    "lblANDText1": "AND",
                    "lblANDText2": "AND",
                    "lblANDText3": "AND",
                    "lblANDText4": "AND",
                    "lblCondition1": "Condition 1",
                    "lblCondition2": "Condition 1",
                    "lblCondition3": "Condition 1",
                    "lblCondition4": "Condition 1",
                    "lblCondition5": "Condition 1",
                    "lblDropdown": "d",
                    "lblFromGroupHdr1in1": "From Group",
                    "lblFromGroupHdr1in2": "From Group",
                    "lblFromGroupHdr1in3": "From Group",
                    "lblFromGroupHdr1in4": "From Group",
                    "lblFromGroupHdr1in5": "From Group",
                    "lblFromGroupHdr2in1": "From Group",
                    "lblFromGroupHdr2in2": "From Group",
                    "lblFromGroupHdr2in3": "From Group",
                    "lblFromGroupHdr2in4": "From Group",
                    "lblFromGroupHdr2in5": "From Group",
                    "lblFromGroupSelectedVal1in1": "Managers",
                    "lblFromGroupSelectedVal1in2": "Managers",
                    "lblFromGroupSelectedVal1in3": "Managers",
                    "lblFromGroupSelectedVal1in4": "Managers",
                    "lblFromGroupSelectedVal1in5": "Managers",
                    "lblFromGroupSelectedVal2in1": "Managers",
                    "lblFromGroupSelectedVal2in2": "Managers",
                    "lblFromGroupSelectedVal2in3": "Managers",
                    "lblFromGroupSelectedVal2in4": "Managers",
                    "lblFromGroupSelectedVal2in5": "Managers",
                    "lblLeftKey": "Label",
                    "lblLeftValue": "Label",
                    "lblORTest1in1": "OR",
                    "lblORTest1in2": "OR",
                    "lblORTest1in3": "OR",
                    "lblORTest1in4": "OR",
                    "lblORTest2in1": "OR",
                    "lblORTest2in2": "OR",
                    "lblORTest2in3": "OR",
                    "lblORTest2in4": "OR",
                    "lblRequiredApprovals1in3": "Required Approvals",
                    "lblRequiredApprovalsCount1in1": "4",
                    "lblRequiredApprovalsCount1in2": "4",
                    "lblRequiredApprovalsCount1in3": "4",
                    "lblRequiredApprovalsCount1in4": "4",
                    "lblRequiredApprovalsCount1in5": "4",
                    "lblRequiredApprovalsCount2in1": "4",
                    "lblRequiredApprovalsCount2in2": "4",
                    "lblRequiredApprovalsCount2in3": "4",
                    "lblRequiredApprovalsCount2in4": "4",
                    "lblRequiredApprovalsCount2in5": "4",
                    "lblRequiredApprovalsHdr1in1": "Required Approvals",
                    "lblRequiredApprovalsHdr1in2": "Required Approvals",
                    "lblRequiredApprovalsHdr1in4": "Required Approvals",
                    "lblRequiredApprovalsHdr1in5": "Required Approvals",
                    "lblRequiredApprovalsHdr2in1": "Required Approvals",
                    "lblRequiredApprovalsHdr2in2": "Required Approvals",
                    "lblRequiredApprovalsHdr2in3": "Required Approvals",
                    "lblRequiredApprovalsHdr2in4": "Required Approvals",
                    "lblRequiredApprovalsHdr2in5": "Required Approvals",
                    "lblRightKey": "Label",
                    "lblRightValue": "Label"
                }, {
                    "CopylblFromGroupHdr0a35c31d780f348": "From Group",
                    "CopylblFromGroupHdr0bf31adf393d744": "From Group",
                    "CopylblFromGroupHdr0c266d737a55145": "From Group",
                    "CopylblFromGroupHdr0c9fa2c53256149": "From Group",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "From Group",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "From Group",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "From Group",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "From Group",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "From Group",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "From Group",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "From Group",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "From Group",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "From Group",
                    "CopylblFromGroupHdr0i5c76f3276544e": "From Group",
                    "CopylblFromGroupHdr0i89f887911cb4d": "From Group",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "Managers",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "Managers",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "Managers",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "Managers",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "Managers",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "Managers",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "Managers",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "Managers",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "Managers",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "Managers",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "Managers",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "Managers",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "Managers",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "Managers",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "Managers",
                    "CopylblORTest0a43062a04e584a": "OR",
                    "CopylblORTest0ada221e5d9074d": "OR",
                    "CopylblORTest0c702b41f96874d": "OR",
                    "CopylblORTest0cd08740e4cdb4d": "OR",
                    "CopylblORTest0d131465445964f": "OR",
                    "CopylblORTest0d19594f3dd8148": "OR",
                    "CopylblORTest0f819674600c043": "OR",
                    "CopylblORTest0fca00ccd696c4f": "OR",
                    "CopylblORTest0g3dbb53be09c4a": "OR",
                    "CopylblORTest0g4bc43e97d0b41": "OR",
                    "CopylblORTest0geda5e12706849": "OR",
                    "CopylblORTest0i704448499074d": "OR",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "4",
                    "CopylblRequiredApprovalsCount0b655698c352349": "4",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "4",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "4",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "4",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "4",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "4",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "4",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "4",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "4",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "4",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "4",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "4",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "4",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "4",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "Required Approvals",
                    "lblANDText1": "AND",
                    "lblANDText2": "AND",
                    "lblANDText3": "AND",
                    "lblANDText4": "AND",
                    "lblCondition1": "Condition 1",
                    "lblCondition2": "Condition 1",
                    "lblCondition3": "Condition 1",
                    "lblCondition4": "Condition 1",
                    "lblCondition5": "Condition 1",
                    "lblDropdown": "d",
                    "lblFromGroupHdr1in1": "From Group",
                    "lblFromGroupHdr1in2": "From Group",
                    "lblFromGroupHdr1in3": "From Group",
                    "lblFromGroupHdr1in4": "From Group",
                    "lblFromGroupHdr1in5": "From Group",
                    "lblFromGroupHdr2in1": "From Group",
                    "lblFromGroupHdr2in2": "From Group",
                    "lblFromGroupHdr2in3": "From Group",
                    "lblFromGroupHdr2in4": "From Group",
                    "lblFromGroupHdr2in5": "From Group",
                    "lblFromGroupSelectedVal1in1": "Managers",
                    "lblFromGroupSelectedVal1in2": "Managers",
                    "lblFromGroupSelectedVal1in3": "Managers",
                    "lblFromGroupSelectedVal1in4": "Managers",
                    "lblFromGroupSelectedVal1in5": "Managers",
                    "lblFromGroupSelectedVal2in1": "Managers",
                    "lblFromGroupSelectedVal2in2": "Managers",
                    "lblFromGroupSelectedVal2in3": "Managers",
                    "lblFromGroupSelectedVal2in4": "Managers",
                    "lblFromGroupSelectedVal2in5": "Managers",
                    "lblLeftKey": "Label",
                    "lblLeftValue": "Label",
                    "lblORTest1in1": "OR",
                    "lblORTest1in2": "OR",
                    "lblORTest1in3": "OR",
                    "lblORTest1in4": "OR",
                    "lblORTest2in1": "OR",
                    "lblORTest2in2": "OR",
                    "lblORTest2in3": "OR",
                    "lblORTest2in4": "OR",
                    "lblRequiredApprovals1in3": "Required Approvals",
                    "lblRequiredApprovalsCount1in1": "4",
                    "lblRequiredApprovalsCount1in2": "4",
                    "lblRequiredApprovalsCount1in3": "4",
                    "lblRequiredApprovalsCount1in4": "4",
                    "lblRequiredApprovalsCount1in5": "4",
                    "lblRequiredApprovalsCount2in1": "4",
                    "lblRequiredApprovalsCount2in2": "4",
                    "lblRequiredApprovalsCount2in3": "4",
                    "lblRequiredApprovalsCount2in4": "4",
                    "lblRequiredApprovalsCount2in5": "4",
                    "lblRequiredApprovalsHdr1in1": "Required Approvals",
                    "lblRequiredApprovalsHdr1in2": "Required Approvals",
                    "lblRequiredApprovalsHdr1in4": "Required Approvals",
                    "lblRequiredApprovalsHdr1in5": "Required Approvals",
                    "lblRequiredApprovalsHdr2in1": "Required Approvals",
                    "lblRequiredApprovalsHdr2in2": "Required Approvals",
                    "lblRequiredApprovalsHdr2in3": "Required Approvals",
                    "lblRequiredApprovalsHdr2in4": "Required Approvals",
                    "lblRequiredApprovalsHdr2in5": "Required Approvals",
                    "lblRightKey": "Label",
                    "lblRightValue": "Label"
                }, {
                    "CopylblFromGroupHdr0a35c31d780f348": "From Group",
                    "CopylblFromGroupHdr0bf31adf393d744": "From Group",
                    "CopylblFromGroupHdr0c266d737a55145": "From Group",
                    "CopylblFromGroupHdr0c9fa2c53256149": "From Group",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "From Group",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "From Group",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "From Group",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "From Group",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "From Group",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "From Group",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "From Group",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "From Group",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "From Group",
                    "CopylblFromGroupHdr0i5c76f3276544e": "From Group",
                    "CopylblFromGroupHdr0i89f887911cb4d": "From Group",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "Managers",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "Managers",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "Managers",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "Managers",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "Managers",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "Managers",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "Managers",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "Managers",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "Managers",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "Managers",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "Managers",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "Managers",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "Managers",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "Managers",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "Managers",
                    "CopylblORTest0a43062a04e584a": "OR",
                    "CopylblORTest0ada221e5d9074d": "OR",
                    "CopylblORTest0c702b41f96874d": "OR",
                    "CopylblORTest0cd08740e4cdb4d": "OR",
                    "CopylblORTest0d131465445964f": "OR",
                    "CopylblORTest0d19594f3dd8148": "OR",
                    "CopylblORTest0f819674600c043": "OR",
                    "CopylblORTest0fca00ccd696c4f": "OR",
                    "CopylblORTest0g3dbb53be09c4a": "OR",
                    "CopylblORTest0g4bc43e97d0b41": "OR",
                    "CopylblORTest0geda5e12706849": "OR",
                    "CopylblORTest0i704448499074d": "OR",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "4",
                    "CopylblRequiredApprovalsCount0b655698c352349": "4",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "4",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "4",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "4",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "4",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "4",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "4",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "4",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "4",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "4",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "4",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "4",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "4",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "4",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "Required Approvals",
                    "lblANDText1": "AND",
                    "lblANDText2": "AND",
                    "lblANDText3": "AND",
                    "lblANDText4": "AND",
                    "lblCondition1": "Condition 1",
                    "lblCondition2": "Condition 1",
                    "lblCondition3": "Condition 1",
                    "lblCondition4": "Condition 1",
                    "lblCondition5": "Condition 1",
                    "lblDropdown": "d",
                    "lblFromGroupHdr1in1": "From Group",
                    "lblFromGroupHdr1in2": "From Group",
                    "lblFromGroupHdr1in3": "From Group",
                    "lblFromGroupHdr1in4": "From Group",
                    "lblFromGroupHdr1in5": "From Group",
                    "lblFromGroupHdr2in1": "From Group",
                    "lblFromGroupHdr2in2": "From Group",
                    "lblFromGroupHdr2in3": "From Group",
                    "lblFromGroupHdr2in4": "From Group",
                    "lblFromGroupHdr2in5": "From Group",
                    "lblFromGroupSelectedVal1in1": "Managers",
                    "lblFromGroupSelectedVal1in2": "Managers",
                    "lblFromGroupSelectedVal1in3": "Managers",
                    "lblFromGroupSelectedVal1in4": "Managers",
                    "lblFromGroupSelectedVal1in5": "Managers",
                    "lblFromGroupSelectedVal2in1": "Managers",
                    "lblFromGroupSelectedVal2in2": "Managers",
                    "lblFromGroupSelectedVal2in3": "Managers",
                    "lblFromGroupSelectedVal2in4": "Managers",
                    "lblFromGroupSelectedVal2in5": "Managers",
                    "lblLeftKey": "Label",
                    "lblLeftValue": "Label",
                    "lblORTest1in1": "OR",
                    "lblORTest1in2": "OR",
                    "lblORTest1in3": "OR",
                    "lblORTest1in4": "OR",
                    "lblORTest2in1": "OR",
                    "lblORTest2in2": "OR",
                    "lblORTest2in3": "OR",
                    "lblORTest2in4": "OR",
                    "lblRequiredApprovals1in3": "Required Approvals",
                    "lblRequiredApprovalsCount1in1": "4",
                    "lblRequiredApprovalsCount1in2": "4",
                    "lblRequiredApprovalsCount1in3": "4",
                    "lblRequiredApprovalsCount1in4": "4",
                    "lblRequiredApprovalsCount1in5": "4",
                    "lblRequiredApprovalsCount2in1": "4",
                    "lblRequiredApprovalsCount2in2": "4",
                    "lblRequiredApprovalsCount2in3": "4",
                    "lblRequiredApprovalsCount2in4": "4",
                    "lblRequiredApprovalsCount2in5": "4",
                    "lblRequiredApprovalsHdr1in1": "Required Approvals",
                    "lblRequiredApprovalsHdr1in2": "Required Approvals",
                    "lblRequiredApprovalsHdr1in4": "Required Approvals",
                    "lblRequiredApprovalsHdr1in5": "Required Approvals",
                    "lblRequiredApprovalsHdr2in1": "Required Approvals",
                    "lblRequiredApprovalsHdr2in2": "Required Approvals",
                    "lblRequiredApprovalsHdr2in3": "Required Approvals",
                    "lblRequiredApprovalsHdr2in4": "Required Approvals",
                    "lblRequiredApprovalsHdr2in5": "Required Approvals",
                    "lblRightKey": "Label",
                    "lblRightValue": "Label"
                }, {
                    "CopylblFromGroupHdr0a35c31d780f348": "From Group",
                    "CopylblFromGroupHdr0bf31adf393d744": "From Group",
                    "CopylblFromGroupHdr0c266d737a55145": "From Group",
                    "CopylblFromGroupHdr0c9fa2c53256149": "From Group",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "From Group",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "From Group",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "From Group",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "From Group",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "From Group",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "From Group",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "From Group",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "From Group",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "From Group",
                    "CopylblFromGroupHdr0i5c76f3276544e": "From Group",
                    "CopylblFromGroupHdr0i89f887911cb4d": "From Group",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "Managers",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "Managers",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "Managers",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "Managers",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "Managers",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "Managers",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "Managers",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "Managers",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "Managers",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "Managers",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "Managers",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "Managers",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "Managers",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "Managers",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "Managers",
                    "CopylblORTest0a43062a04e584a": "OR",
                    "CopylblORTest0ada221e5d9074d": "OR",
                    "CopylblORTest0c702b41f96874d": "OR",
                    "CopylblORTest0cd08740e4cdb4d": "OR",
                    "CopylblORTest0d131465445964f": "OR",
                    "CopylblORTest0d19594f3dd8148": "OR",
                    "CopylblORTest0f819674600c043": "OR",
                    "CopylblORTest0fca00ccd696c4f": "OR",
                    "CopylblORTest0g3dbb53be09c4a": "OR",
                    "CopylblORTest0g4bc43e97d0b41": "OR",
                    "CopylblORTest0geda5e12706849": "OR",
                    "CopylblORTest0i704448499074d": "OR",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "4",
                    "CopylblRequiredApprovalsCount0b655698c352349": "4",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "4",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "4",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "4",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "4",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "4",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "4",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "4",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "4",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "4",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "4",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "4",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "4",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "4",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "Required Approvals",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "Required Approvals",
                    "lblANDText1": "AND",
                    "lblANDText2": "AND",
                    "lblANDText3": "AND",
                    "lblANDText4": "AND",
                    "lblCondition1": "Condition 1",
                    "lblCondition2": "Condition 1",
                    "lblCondition3": "Condition 1",
                    "lblCondition4": "Condition 1",
                    "lblCondition5": "Condition 1",
                    "lblDropdown": "d",
                    "lblFromGroupHdr1in1": "From Group",
                    "lblFromGroupHdr1in2": "From Group",
                    "lblFromGroupHdr1in3": "From Group",
                    "lblFromGroupHdr1in4": "From Group",
                    "lblFromGroupHdr1in5": "From Group",
                    "lblFromGroupHdr2in1": "From Group",
                    "lblFromGroupHdr2in2": "From Group",
                    "lblFromGroupHdr2in3": "From Group",
                    "lblFromGroupHdr2in4": "From Group",
                    "lblFromGroupHdr2in5": "From Group",
                    "lblFromGroupSelectedVal1in1": "Managers",
                    "lblFromGroupSelectedVal1in2": "Managers",
                    "lblFromGroupSelectedVal1in3": "Managers",
                    "lblFromGroupSelectedVal1in4": "Managers",
                    "lblFromGroupSelectedVal1in5": "Managers",
                    "lblFromGroupSelectedVal2in1": "Managers",
                    "lblFromGroupSelectedVal2in2": "Managers",
                    "lblFromGroupSelectedVal2in3": "Managers",
                    "lblFromGroupSelectedVal2in4": "Managers",
                    "lblFromGroupSelectedVal2in5": "Managers",
                    "lblLeftKey": "Label",
                    "lblLeftValue": "Label",
                    "lblORTest1in1": "OR",
                    "lblORTest1in2": "OR",
                    "lblORTest1in3": "OR",
                    "lblORTest1in4": "OR",
                    "lblORTest2in1": "OR",
                    "lblORTest2in2": "OR",
                    "lblORTest2in3": "OR",
                    "lblORTest2in4": "OR",
                    "lblRequiredApprovals1in3": "Required Approvals",
                    "lblRequiredApprovalsCount1in1": "4",
                    "lblRequiredApprovalsCount1in2": "4",
                    "lblRequiredApprovalsCount1in3": "4",
                    "lblRequiredApprovalsCount1in4": "4",
                    "lblRequiredApprovalsCount1in5": "4",
                    "lblRequiredApprovalsCount2in1": "4",
                    "lblRequiredApprovalsCount2in2": "4",
                    "lblRequiredApprovalsCount2in3": "4",
                    "lblRequiredApprovalsCount2in4": "4",
                    "lblRequiredApprovalsCount2in5": "4",
                    "lblRequiredApprovalsHdr1in1": "Required Approvals",
                    "lblRequiredApprovalsHdr1in2": "Required Approvals",
                    "lblRequiredApprovalsHdr1in4": "Required Approvals",
                    "lblRequiredApprovalsHdr1in5": "Required Approvals",
                    "lblRequiredApprovalsHdr2in1": "Required Approvals",
                    "lblRequiredApprovalsHdr2in2": "Required Approvals",
                    "lblRequiredApprovalsHdr2in3": "Required Approvals",
                    "lblRequiredApprovalsHdr2in4": "Required Approvals",
                    "lblRequiredApprovalsHdr2in5": "Required Approvals",
                    "lblRightKey": "Label",
                    "lblRightValue": "Label"
                }],
                "groupCells": false,
                "id": "segApprovalConditions",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxApprovalConditionRowTemplate"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e2e9f000",
                "separatorRequired": true,
                "separatorThickness": 2,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "CopyflxConditionInputs0bed9f770135048": "CopyflxConditionInputs0bed9f770135048",
                    "CopyflxConditionInputs0c1de3bff199641": "CopyflxConditionInputs0c1de3bff199641",
                    "CopyflxConditionInputs0c60cea92d4894e": "CopyflxConditionInputs0c60cea92d4894e",
                    "CopyflxConditionInputs0cfe9de9d0aae4d": "CopyflxConditionInputs0cfe9de9d0aae4d",
                    "CopyflxConditionInputs0d0cf8af7098c44": "CopyflxConditionInputs0d0cf8af7098c44",
                    "CopyflxConditionInputs0d45b864120884a": "CopyflxConditionInputs0d45b864120884a",
                    "CopyflxConditionInputs0d55883bea4ee46": "CopyflxConditionInputs0d55883bea4ee46",
                    "CopyflxConditionInputs0da2a42da08234d": "CopyflxConditionInputs0da2a42da08234d",
                    "CopyflxConditionInputs0dc3069f3a6d547": "CopyflxConditionInputs0dc3069f3a6d547",
                    "CopyflxConditionInputs0ddedca3b3ce349": "CopyflxConditionInputs0ddedca3b3ce349",
                    "CopyflxConditionInputs0ef7c0e0699a343": "CopyflxConditionInputs0ef7c0e0699a343",
                    "CopyflxConditionInputs0f3c32aae6a8c43": "CopyflxConditionInputs0f3c32aae6a8c43",
                    "CopyflxConditionInputs0fbc5fa9e399c44": "CopyflxConditionInputs0fbc5fa9e399c44",
                    "CopyflxConditionInputs0hf1a61236e4244": "CopyflxConditionInputs0hf1a61236e4244",
                    "CopyflxConditionInputs0i28f1005ec4344": "CopyflxConditionInputs0i28f1005ec4344",
                    "CopyflxORLabelContainer0a1b0a3b75b914f": "CopyflxORLabelContainer0a1b0a3b75b914f",
                    "CopyflxORLabelContainer0d7ac09d85cc340": "CopyflxORLabelContainer0d7ac09d85cc340",
                    "CopyflxORLabelContainer0f3303601c9ff4a": "CopyflxORLabelContainer0f3303601c9ff4a",
                    "CopyflxORLabelContainer0f3fee085e60a45": "CopyflxORLabelContainer0f3fee085e60a45",
                    "CopyflxORLabelContainer0fb5d5b33c86a45": "CopyflxORLabelContainer0fb5d5b33c86a45",
                    "CopyflxORLabelContainer0ffe57ce952eb43": "CopyflxORLabelContainer0ffe57ce952eb43",
                    "CopyflxORLabelContainer0g024f5a6acbf42": "CopyflxORLabelContainer0g024f5a6acbf42",
                    "CopyflxORLabelContainer0i2aca118922943": "CopyflxORLabelContainer0i2aca118922943",
                    "CopyflxORLabelContainer0i38a9c29868b49": "CopyflxORLabelContainer0i38a9c29868b49",
                    "CopyflxORLabelContainer0i3a769f4f51b4f": "CopyflxORLabelContainer0i3a769f4f51b4f",
                    "CopyflxORLabelContainer0ib64f98d6d3341": "CopyflxORLabelContainer0ib64f98d6d3341",
                    "CopyflxORLabelContainer0j9a4aaabef9b4d": "CopyflxORLabelContainer0j9a4aaabef9b4d",
                    "CopyflxORText0a4ae211e4b6647": "CopyflxORText0a4ae211e4b6647",
                    "CopyflxORText0ad07f904776544": "CopyflxORText0ad07f904776544",
                    "CopyflxORText0c9daa4a38a8447": "CopyflxORText0c9daa4a38a8447",
                    "CopyflxORText0d5e5cc33d39741": "CopyflxORText0d5e5cc33d39741",
                    "CopyflxORText0f219788b2b124c": "CopyflxORText0f219788b2b124c",
                    "CopyflxORText0f7654ff8a35d4a": "CopyflxORText0f7654ff8a35d4a",
                    "CopyflxORText0g92ebd8c1bad4c": "CopyflxORText0g92ebd8c1bad4c",
                    "CopyflxORText0g9d3d71a645048": "CopyflxORText0g9d3d71a645048",
                    "CopyflxORText0gbbe2463b50347": "CopyflxORText0gbbe2463b50347",
                    "CopyflxORText0gc9bfd4c80a444": "CopyflxORText0gc9bfd4c80a444",
                    "CopyflxORText0hbab386c088945": "CopyflxORText0hbab386c088945",
                    "CopyflxORText0j1e949eb7e4743": "CopyflxORText0j1e949eb7e4743",
                    "CopyflxORVerticalLineBottom0a8d62d3b427d41": "CopyflxORVerticalLineBottom0a8d62d3b427d41",
                    "CopyflxORVerticalLineBottom0b80e0147814f44": "CopyflxORVerticalLineBottom0b80e0147814f44",
                    "CopyflxORVerticalLineBottom0ba439e12a17e4f": "CopyflxORVerticalLineBottom0ba439e12a17e4f",
                    "CopyflxORVerticalLineBottom0bf0acd1c8c4f49": "CopyflxORVerticalLineBottom0bf0acd1c8c4f49",
                    "CopyflxORVerticalLineBottom0c7550d71fc6a46": "CopyflxORVerticalLineBottom0c7550d71fc6a46",
                    "CopyflxORVerticalLineBottom0cbf3fc4f52fd4c": "CopyflxORVerticalLineBottom0cbf3fc4f52fd4c",
                    "CopyflxORVerticalLineBottom0e577a6de840b46": "CopyflxORVerticalLineBottom0e577a6de840b46",
                    "CopyflxORVerticalLineBottom0ee4debf848c04b": "CopyflxORVerticalLineBottom0ee4debf848c04b",
                    "CopyflxORVerticalLineBottom0fa81187c016c4c": "CopyflxORVerticalLineBottom0fa81187c016c4c",
                    "CopyflxORVerticalLineBottom0fba311836ebf4f": "CopyflxORVerticalLineBottom0fba311836ebf4f",
                    "CopyflxORVerticalLineBottom0fd4967b1a38b4a": "CopyflxORVerticalLineBottom0fd4967b1a38b4a",
                    "CopyflxORVerticalLineBottom0jd74fd98ffcc48": "CopyflxORVerticalLineBottom0jd74fd98ffcc48",
                    "CopyflxORVerticalLineTop0b4c80aeb2c5946": "CopyflxORVerticalLineTop0b4c80aeb2c5946",
                    "CopyflxORVerticalLineTop0c33eeafd28664c": "CopyflxORVerticalLineTop0c33eeafd28664c",
                    "CopyflxORVerticalLineTop0ca3eba95173641": "CopyflxORVerticalLineTop0ca3eba95173641",
                    "CopyflxORVerticalLineTop0d50b503c14e741": "CopyflxORVerticalLineTop0d50b503c14e741",
                    "CopyflxORVerticalLineTop0d53e1089f58c47": "CopyflxORVerticalLineTop0d53e1089f58c47",
                    "CopyflxORVerticalLineTop0d5fd4b0a0cd044": "CopyflxORVerticalLineTop0d5fd4b0a0cd044",
                    "CopyflxORVerticalLineTop0e76092d96dfe47": "CopyflxORVerticalLineTop0e76092d96dfe47",
                    "CopyflxORVerticalLineTop0fb89becc62684d": "CopyflxORVerticalLineTop0fb89becc62684d",
                    "CopyflxORVerticalLineTop0g364f5a874464f": "CopyflxORVerticalLineTop0g364f5a874464f",
                    "CopyflxORVerticalLineTop0h9b2ca23f24c42": "CopyflxORVerticalLineTop0h9b2ca23f24c42",
                    "CopyflxORVerticalLineTop0ja3619a701d945": "CopyflxORVerticalLineTop0ja3619a701d945",
                    "CopyflxORVerticalLineTop0jcfb2493c0cf43": "CopyflxORVerticalLineTop0jcfb2493c0cf43",
                    "CopylblFromGroupHdr0a35c31d780f348": "CopylblFromGroupHdr0a35c31d780f348",
                    "CopylblFromGroupHdr0bf31adf393d744": "CopylblFromGroupHdr0bf31adf393d744",
                    "CopylblFromGroupHdr0c266d737a55145": "CopylblFromGroupHdr0c266d737a55145",
                    "CopylblFromGroupHdr0c9fa2c53256149": "CopylblFromGroupHdr0c9fa2c53256149",
                    "CopylblFromGroupHdr0d9c88a46bb9047": "CopylblFromGroupHdr0d9c88a46bb9047",
                    "CopylblFromGroupHdr0dbf5bc6d42504b": "CopylblFromGroupHdr0dbf5bc6d42504b",
                    "CopylblFromGroupHdr0e81b2c3eeb6c4f": "CopylblFromGroupHdr0e81b2c3eeb6c4f",
                    "CopylblFromGroupHdr0ec2af2efab3f44": "CopylblFromGroupHdr0ec2af2efab3f44",
                    "CopylblFromGroupHdr0ee2a0955bef44f": "CopylblFromGroupHdr0ee2a0955bef44f",
                    "CopylblFromGroupHdr0f2d5abe6ebf046": "CopylblFromGroupHdr0f2d5abe6ebf046",
                    "CopylblFromGroupHdr0f5fdfa857fb043": "CopylblFromGroupHdr0f5fdfa857fb043",
                    "CopylblFromGroupHdr0f9b6d94ef5444c": "CopylblFromGroupHdr0f9b6d94ef5444c",
                    "CopylblFromGroupHdr0g27d6fb2f7a145": "CopylblFromGroupHdr0g27d6fb2f7a145",
                    "CopylblFromGroupHdr0i5c76f3276544e": "CopylblFromGroupHdr0i5c76f3276544e",
                    "CopylblFromGroupHdr0i89f887911cb4d": "CopylblFromGroupHdr0i89f887911cb4d",
                    "CopylblFromGroupSelectedVal0b7b17b28980c4a": "CopylblFromGroupSelectedVal0b7b17b28980c4a",
                    "CopylblFromGroupSelectedVal0bacc2ab5a90845": "CopylblFromGroupSelectedVal0bacc2ab5a90845",
                    "CopylblFromGroupSelectedVal0ca793b73dfbc4c": "CopylblFromGroupSelectedVal0ca793b73dfbc4c",
                    "CopylblFromGroupSelectedVal0cb76e7c8370f48": "CopylblFromGroupSelectedVal0cb76e7c8370f48",
                    "CopylblFromGroupSelectedVal0ce282871721a42": "CopylblFromGroupSelectedVal0ce282871721a42",
                    "CopylblFromGroupSelectedVal0d1819dc798e046": "CopylblFromGroupSelectedVal0d1819dc798e046",
                    "CopylblFromGroupSelectedVal0d2ebd3161e724a": "CopylblFromGroupSelectedVal0d2ebd3161e724a",
                    "CopylblFromGroupSelectedVal0d8fe4e9e55a14f": "CopylblFromGroupSelectedVal0d8fe4e9e55a14f",
                    "CopylblFromGroupSelectedVal0d9dc5006041c4b": "CopylblFromGroupSelectedVal0d9dc5006041c4b",
                    "CopylblFromGroupSelectedVal0ed151ae8ec4e46": "CopylblFromGroupSelectedVal0ed151ae8ec4e46",
                    "CopylblFromGroupSelectedVal0ef8a2dc794454f": "CopylblFromGroupSelectedVal0ef8a2dc794454f",
                    "CopylblFromGroupSelectedVal0g4b29956ec6e42": "CopylblFromGroupSelectedVal0g4b29956ec6e42",
                    "CopylblFromGroupSelectedVal0h3ad54010e7949": "CopylblFromGroupSelectedVal0h3ad54010e7949",
                    "CopylblFromGroupSelectedVal0i3eb274724574d": "CopylblFromGroupSelectedVal0i3eb274724574d",
                    "CopylblFromGroupSelectedVal0j04bc398b9404b": "CopylblFromGroupSelectedVal0j04bc398b9404b",
                    "CopylblORTest0a43062a04e584a": "CopylblORTest0a43062a04e584a",
                    "CopylblORTest0ada221e5d9074d": "CopylblORTest0ada221e5d9074d",
                    "CopylblORTest0c702b41f96874d": "CopylblORTest0c702b41f96874d",
                    "CopylblORTest0cd08740e4cdb4d": "CopylblORTest0cd08740e4cdb4d",
                    "CopylblORTest0d131465445964f": "CopylblORTest0d131465445964f",
                    "CopylblORTest0d19594f3dd8148": "CopylblORTest0d19594f3dd8148",
                    "CopylblORTest0f819674600c043": "CopylblORTest0f819674600c043",
                    "CopylblORTest0fca00ccd696c4f": "CopylblORTest0fca00ccd696c4f",
                    "CopylblORTest0g3dbb53be09c4a": "CopylblORTest0g3dbb53be09c4a",
                    "CopylblORTest0g4bc43e97d0b41": "CopylblORTest0g4bc43e97d0b41",
                    "CopylblORTest0geda5e12706849": "CopylblORTest0geda5e12706849",
                    "CopylblORTest0i704448499074d": "CopylblORTest0i704448499074d",
                    "CopylblRequiredApprovalsCount0a1354b6497d447": "CopylblRequiredApprovalsCount0a1354b6497d447",
                    "CopylblRequiredApprovalsCount0b655698c352349": "CopylblRequiredApprovalsCount0b655698c352349",
                    "CopylblRequiredApprovalsCount0b820a59acc4c45": "CopylblRequiredApprovalsCount0b820a59acc4c45",
                    "CopylblRequiredApprovalsCount0bcc36b12461f4c": "CopylblRequiredApprovalsCount0bcc36b12461f4c",
                    "CopylblRequiredApprovalsCount0bdd5dfb7c61548": "CopylblRequiredApprovalsCount0bdd5dfb7c61548",
                    "CopylblRequiredApprovalsCount0bed42f92aafa44": "CopylblRequiredApprovalsCount0bed42f92aafa44",
                    "CopylblRequiredApprovalsCount0cd29df55690541": "CopylblRequiredApprovalsCount0cd29df55690541",
                    "CopylblRequiredApprovalsCount0d7f7ca2e1e1548": "CopylblRequiredApprovalsCount0d7f7ca2e1e1548",
                    "CopylblRequiredApprovalsCount0dd8362c3deae4b": "CopylblRequiredApprovalsCount0dd8362c3deae4b",
                    "CopylblRequiredApprovalsCount0ef0c531044ab40": "CopylblRequiredApprovalsCount0ef0c531044ab40",
                    "CopylblRequiredApprovalsCount0f21abf7b759740": "CopylblRequiredApprovalsCount0f21abf7b759740",
                    "CopylblRequiredApprovalsCount0f3c2f2226fbd43": "CopylblRequiredApprovalsCount0f3c2f2226fbd43",
                    "CopylblRequiredApprovalsCount0f70804f9df894e": "CopylblRequiredApprovalsCount0f70804f9df894e",
                    "CopylblRequiredApprovalsCount0g289766086cc4c": "CopylblRequiredApprovalsCount0g289766086cc4c",
                    "CopylblRequiredApprovalsCount0he5aa1f2182a4f": "CopylblRequiredApprovalsCount0he5aa1f2182a4f",
                    "CopylblRequiredApprovalsHdr0a517dfea376143": "CopylblRequiredApprovalsHdr0a517dfea376143",
                    "CopylblRequiredApprovalsHdr0a5d679fea6734c": "CopylblRequiredApprovalsHdr0a5d679fea6734c",
                    "CopylblRequiredApprovalsHdr0b182a81fb22b4d": "CopylblRequiredApprovalsHdr0b182a81fb22b4d",
                    "CopylblRequiredApprovalsHdr0bacf9b563be24b": "CopylblRequiredApprovalsHdr0bacf9b563be24b",
                    "CopylblRequiredApprovalsHdr0d134cc2226f742": "CopylblRequiredApprovalsHdr0d134cc2226f742",
                    "CopylblRequiredApprovalsHdr0d8d42e60baaf41": "CopylblRequiredApprovalsHdr0d8d42e60baaf41",
                    "CopylblRequiredApprovalsHdr0e0d22a40bea046": "CopylblRequiredApprovalsHdr0e0d22a40bea046",
                    "CopylblRequiredApprovalsHdr0e9c40ca2a27d44": "CopylblRequiredApprovalsHdr0e9c40ca2a27d44",
                    "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d": "CopylblRequiredApprovalsHdr0ec6d6c6f0f794d",
                    "CopylblRequiredApprovalsHdr0f01805bef52846": "CopylblRequiredApprovalsHdr0f01805bef52846",
                    "CopylblRequiredApprovalsHdr0f25310d6ec0147": "CopylblRequiredApprovalsHdr0f25310d6ec0147",
                    "CopylblRequiredApprovalsHdr0f7e0c8ee132643": "CopylblRequiredApprovalsHdr0f7e0c8ee132643",
                    "CopylblRequiredApprovalsHdr0fcd52a97ea774c": "CopylblRequiredApprovalsHdr0fcd52a97ea774c",
                    "CopylblRequiredApprovalsHdr0ff2e1ee298a148": "CopylblRequiredApprovalsHdr0ff2e1ee298a148",
                    "CopylblRequiredApprovalsHdr0hbe24f202d8241": "CopylblRequiredApprovalsHdr0hbe24f202d8241",
                    "flxANDLabelContainer1": "flxANDLabelContainer1",
                    "flxANDLabelContainer2": "flxANDLabelContainer2",
                    "flxANDLabelContainer3": "flxANDLabelContainer3",
                    "flxANDLabelContainer4": "flxANDLabelContainer4",
                    "flxANDText1": "flxANDText1",
                    "flxANDText2": "flxANDText2",
                    "flxANDText3": "flxANDText3",
                    "flxANDText4": "flxANDText4",
                    "flxAndVerticalLineBottom1": "flxAndVerticalLineBottom1",
                    "flxAndVerticalLineBottom2": "flxAndVerticalLineBottom2",
                    "flxAndVerticalLineBottom3": "flxAndVerticalLineBottom3",
                    "flxAndVerticalLineBottom4": "flxAndVerticalLineBottom4",
                    "flxAndVerticalLineTop1": "flxAndVerticalLineTop1",
                    "flxAndVerticalLineTop2": "flxAndVerticalLineTop2",
                    "flxAndVerticalLineTop3": "flxAndVerticalLineTop3",
                    "flxAndVerticalLineTop4": "flxAndVerticalLineTop4",
                    "flxApprovalConditionRowTemplate": "flxApprovalConditionRowTemplate",
                    "flxApprovalDetailsContainer": "flxApprovalDetailsContainer",
                    "flxCondition1": "flxCondition1",
                    "flxConditionInputs1in1": "flxConditionInputs1in1",
                    "flxConditionInputs1in2": "flxConditionInputs1in2",
                    "flxConditionInputs1in3": "flxConditionInputs1in3",
                    "flxConditionInputs1in4": "flxConditionInputs1in4",
                    "flxConditionInputs1in5": "flxConditionInputs1in5",
                    "flxConditionInputs2in1": "flxConditionInputs2in1",
                    "flxConditionInputs2in2": "flxConditionInputs2in2",
                    "flxConditionInputs2in3": "flxConditionInputs2in3",
                    "flxConditionInputs2in4": "flxConditionInputs2in4",
                    "flxConditionInputs2in5": "flxConditionInputs2in5",
                    "flxConditionSection": "flxConditionSection",
                    "flxContent": "flxContent",
                    "flxCreateApprovalCondition2": "flxCreateApprovalCondition2",
                    "flxCreateApprovalCondition3": "flxCreateApprovalCondition3",
                    "flxCreateApprovalCondition4": "flxCreateApprovalCondition4",
                    "flxCreateApprovalCondition5": "flxCreateApprovalCondition5",
                    "flxDropdown": "flxDropdown",
                    "flxExpandedContent": "flxExpandedContent",
                    "flxLeftContent": "flxLeftContent",
                    "flxMainContent": "flxMainContent",
                    "flxORLabelContaine1in4": "flxORLabelContaine1in4",
                    "flxORLabelContainer1in1": "flxORLabelContainer1in1",
                    "flxORLabelContainer1in2": "flxORLabelContainer1in2",
                    "flxORLabelContainer1in3": "flxORLabelContainer1in3",
                    "flxORLabelContainer2in1": "flxORLabelContainer2in1",
                    "flxORLabelContainer2in2": "flxORLabelContainer2in2",
                    "flxORLabelContainer2in3": "flxORLabelContainer2in3",
                    "flxORLabelContainer2in4": "flxORLabelContainer2in4",
                    "flxORText1in1": "flxORText1in1",
                    "flxORText1in2": "flxORText1in2",
                    "flxORText1in3": "flxORText1in3",
                    "flxORText1in4": "flxORText1in4",
                    "flxORText2in1": "flxORText2in1",
                    "flxORText2in2": "flxORText2in2",
                    "flxORText2in3": "flxORText2in3",
                    "flxORText2in4": "flxORText2in4",
                    "flxORVerticalLineBottom1in1": "flxORVerticalLineBottom1in1",
                    "flxORVerticalLineBottom1in2": "flxORVerticalLineBottom1in2",
                    "flxORVerticalLineBottom1in3": "flxORVerticalLineBottom1in3",
                    "flxORVerticalLineBottom1in4": "flxORVerticalLineBottom1in4",
                    "flxORVerticalLineBottom2in1": "flxORVerticalLineBottom2in1",
                    "flxORVerticalLineBottom2in2": "flxORVerticalLineBottom2in2",
                    "flxORVerticalLineBottom2in3": "flxORVerticalLineBottom2in3",
                    "flxORVerticalLineBottom2in4": "flxORVerticalLineBottom2in4",
                    "flxORVerticalLineTop1in1": "flxORVerticalLineTop1in1",
                    "flxORVerticalLineTop1in2": "flxORVerticalLineTop1in2",
                    "flxORVerticalLineTop1in3": "flxORVerticalLineTop1in3",
                    "flxORVerticalLineTop1in4": "flxORVerticalLineTop1in4",
                    "flxORVerticalLineTop2in1": "flxORVerticalLineTop2in1",
                    "flxORVerticalLineTop2in2": "flxORVerticalLineTop2in2",
                    "flxORVerticalLineTop2in3": "flxORVerticalLineTop2in3",
                    "flxORVerticalLineTop2in4": "flxORVerticalLineTop2in4",
                    "flxRightContent": "flxRightContent",
                    "flxSeparator": "flxSeparator",
                    "lblANDText1": "lblANDText1",
                    "lblANDText2": "lblANDText2",
                    "lblANDText3": "lblANDText3",
                    "lblANDText4": "lblANDText4",
                    "lblCondition1": "lblCondition1",
                    "lblCondition2": "lblCondition2",
                    "lblCondition3": "lblCondition3",
                    "lblCondition4": "lblCondition4",
                    "lblCondition5": "lblCondition5",
                    "lblDropdown": "lblDropdown",
                    "lblFromGroupHdr1in1": "lblFromGroupHdr1in1",
                    "lblFromGroupHdr1in2": "lblFromGroupHdr1in2",
                    "lblFromGroupHdr1in3": "lblFromGroupHdr1in3",
                    "lblFromGroupHdr1in4": "lblFromGroupHdr1in4",
                    "lblFromGroupHdr1in5": "lblFromGroupHdr1in5",
                    "lblFromGroupHdr2in1": "lblFromGroupHdr2in1",
                    "lblFromGroupHdr2in2": "lblFromGroupHdr2in2",
                    "lblFromGroupHdr2in3": "lblFromGroupHdr2in3",
                    "lblFromGroupHdr2in4": "lblFromGroupHdr2in4",
                    "lblFromGroupHdr2in5": "lblFromGroupHdr2in5",
                    "lblFromGroupSelectedVal1in1": "lblFromGroupSelectedVal1in1",
                    "lblFromGroupSelectedVal1in2": "lblFromGroupSelectedVal1in2",
                    "lblFromGroupSelectedVal1in3": "lblFromGroupSelectedVal1in3",
                    "lblFromGroupSelectedVal1in4": "lblFromGroupSelectedVal1in4",
                    "lblFromGroupSelectedVal1in5": "lblFromGroupSelectedVal1in5",
                    "lblFromGroupSelectedVal2in1": "lblFromGroupSelectedVal2in1",
                    "lblFromGroupSelectedVal2in2": "lblFromGroupSelectedVal2in2",
                    "lblFromGroupSelectedVal2in3": "lblFromGroupSelectedVal2in3",
                    "lblFromGroupSelectedVal2in4": "lblFromGroupSelectedVal2in4",
                    "lblFromGroupSelectedVal2in5": "lblFromGroupSelectedVal2in5",
                    "lblLeftKey": "lblLeftKey",
                    "lblLeftValue": "lblLeftValue",
                    "lblORTest1in1": "lblORTest1in1",
                    "lblORTest1in2": "lblORTest1in2",
                    "lblORTest1in3": "lblORTest1in3",
                    "lblORTest1in4": "lblORTest1in4",
                    "lblORTest2in1": "lblORTest2in1",
                    "lblORTest2in2": "lblORTest2in2",
                    "lblORTest2in3": "lblORTest2in3",
                    "lblORTest2in4": "lblORTest2in4",
                    "lblRequiredApprovals1in3": "lblRequiredApprovals1in3",
                    "lblRequiredApprovalsCount1in1": "lblRequiredApprovalsCount1in1",
                    "lblRequiredApprovalsCount1in2": "lblRequiredApprovalsCount1in2",
                    "lblRequiredApprovalsCount1in3": "lblRequiredApprovalsCount1in3",
                    "lblRequiredApprovalsCount1in4": "lblRequiredApprovalsCount1in4",
                    "lblRequiredApprovalsCount1in5": "lblRequiredApprovalsCount1in5",
                    "lblRequiredApprovalsCount2in1": "lblRequiredApprovalsCount2in1",
                    "lblRequiredApprovalsCount2in2": "lblRequiredApprovalsCount2in2",
                    "lblRequiredApprovalsCount2in3": "lblRequiredApprovalsCount2in3",
                    "lblRequiredApprovalsCount2in4": "lblRequiredApprovalsCount2in4",
                    "lblRequiredApprovalsCount2in5": "lblRequiredApprovalsCount2in5",
                    "lblRequiredApprovalsHdr1in1": "lblRequiredApprovalsHdr1in1",
                    "lblRequiredApprovalsHdr1in2": "lblRequiredApprovalsHdr1in2",
                    "lblRequiredApprovalsHdr1in4": "lblRequiredApprovalsHdr1in4",
                    "lblRequiredApprovalsHdr1in5": "lblRequiredApprovalsHdr1in5",
                    "lblRequiredApprovalsHdr2in1": "lblRequiredApprovalsHdr2in1",
                    "lblRequiredApprovalsHdr2in2": "lblRequiredApprovalsHdr2in2",
                    "lblRequiredApprovalsHdr2in3": "lblRequiredApprovalsHdr2in3",
                    "lblRequiredApprovalsHdr2in4": "lblRequiredApprovalsHdr2in4",
                    "lblRequiredApprovalsHdr2in5": "lblRequiredApprovalsHdr2in5",
                    "lblRightKey": "lblRightKey",
                    "lblRightValue": "lblRightValue"
                },
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalConditionsDetails.add(flxApprovalConditionsSeparator, segApprovalConditions);
            flxRequestCreateEditUpdateEditDetails.add(flxTabs, flxUpdatedAndExistingDetails, flxRequestDetails, flxApprovalConditionsDetails);
            var flxApprovalrequestHistorySection = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxApprovalrequestHistorySection",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "87.80%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalrequestHistorySection.setDefaultUnit(kony.flex.DP);
            var flxApprovalsHistoryInformation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalsHistoryInformation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalsHistoryInformation.setDefaultUnit(kony.flex.DP);
            var flxApprovalsHistoryErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxApprovalsHistoryErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalsHistoryErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgApprovalHistoryError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgApprovalHistoryError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApprovalHistoryError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblApprovalHistoryError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxErrorSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxErrorSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorSeperator.setDefaultUnit(kony.flex.DP);
            flxErrorSeperator.add();
            flxApprovalsHistoryErrorMessage.add(imgApprovalHistoryError, lblApprovalHistoryError, flxErrorSeperator);
            var flxApprovalHistoryContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalHistoryContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryContent.setDefaultUnit(kony.flex.DP);
            var flxApprovalHistoryHeading = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxApprovalHistoryHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryHeading.setDefaultUnit(kony.flex.DP);
            var lblApprovalHistoryInformation = new kony.ui.Label({
                "height": "22dp",
                "id": "lblApprovalHistoryInformation",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ApprovalRequests.ApprovalInfo\")",
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApprovalHistoryCollapseArrow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxApprovalHistoryCollapseArrow",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "17dp",
                "width": "20dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryCollapseArrow.setDefaultUnit(kony.flex.DP);
            var lblDropdown = new kony.ui.Label({
                "height": "100%",
                "id": "lblDropdown",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLbl6E7081OlbFonticons20px",
                "text": "P",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryCollapseArrow.add(lblDropdown);
            flxApprovalHistoryHeading.add(lblApprovalHistoryInformation, flxApprovalHistoryCollapseArrow);
            var flxTopSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeperator.setDefaultUnit(kony.flex.DP);
            flxTopSeperator.add();
            var flxApprovalStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": true,
                "id": "flxApprovalStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalStatus.setDefaultUnit(kony.flex.DP);
            var flxApprovalStatusGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalStatusGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalStatusGroup.setDefaultUnit(kony.flex.DP);
            var flxApprovalDetailsStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalDetailsStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalDetailsStatus.setDefaultUnit(kony.flex.DP);
            var lblApprovalStatus = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblApprovalStatus",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.ApprovalStatus\")",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApprovalStatusValue = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblApprovalStatusValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Approved\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl424242SSP15Px"
            });
            flxApprovalDetailsStatus.add(lblApprovalStatus, lblApprovalStatusValue);
            var flxApprovedCountDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovedCountDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovedCountDetails.setDefaultUnit(kony.flex.DP);
            var lblApproveCount = new kony.ui.Label({
                "id": "lblApproveCount",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.approvedWithColon\")",
                "top": "0",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApproveCountVal = new kony.ui.Label({
                "id": "lblApproveCountVal",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "2",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovedCountDetails.add(lblApproveCount, lblApproveCountVal);
            var flxRejectedCountDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRejectedCountDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectedCountDetails.setDefaultUnit(kony.flex.DP);
            var lblRejectCount = new kony.ui.Label({
                "id": "lblRejectCount",
                "isVisible": true,
                "left": 20,
                "skin": "sknlbla0a0a015px",
                "text": "Rejected:",
                "width": "20%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRejectCountVal = new kony.ui.Label({
                "id": "lblRejectCountVal",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRejectedCountDetails.add(lblRejectCount, lblRejectCountVal);
            flxApprovalStatusGroup.add(flxApprovalDetailsStatus, flxApprovedCountDetails, flxRejectedCountDetails);
            var btnPendingAprrovers = new kony.ui.Button({
                "height": "40dp",
                "id": "btnPendingAprrovers",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknBtn003e75BGffffff45PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.pendingApprovers\")",
                "top": "10dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalStatus.add(flxApprovalStatusGroup, btnPendingAprrovers);
            var flxSeparatorBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorBottom.setDefaultUnit(kony.flex.DP);
            flxSeparatorBottom.add();
            var segApprovalDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segApprovalDetails",
                "isVisible": true,
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxApprovalDetailsRowTemplate"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxApprovalDetailsACKHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxApprovalDetailsACKHeader": "flxApprovalDetailsACKHeader",
                    "flxApprovalDetailsRowTemplate": "flxApprovalDetailsRowTemplate",
                    "flxApproveDetails": "flxApproveDetails",
                    "flxHeaderValues": "flxHeaderValues",
                    "flxNoRecords": "flxNoRecords",
                    "flxTopSeperator": "flxTopSeperator",
                    "flxTopSeperator2": "flxTopSeperator2",
                    "imgFlxTopSeparator": "imgFlxTopSeparator",
                    "imgFlxTopSeparator2": "imgFlxTopSeparator2",
                    "lblAction": "lblAction",
                    "lblActionKey": "lblActionKey",
                    "lblComments": "lblComments",
                    "lblCommentsKey": "lblCommentsKey",
                    "lblDateAndTime": "lblDateAndTime",
                    "lblDateAndTimeKey": "lblDateAndTimeKey",
                    "lblNoRecords": "lblNoRecords",
                    "lblSignatoryGroup": "lblSignatoryGroup",
                    "lblSignatoryGroupKey": "lblSignatoryGroupKey",
                    "lblUserID": "lblUserID",
                    "lblUserIDKey": "lblUserIDKey"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryContent.add(flxApprovalHistoryHeading, flxTopSeperator, flxApprovalStatus, flxSeparatorBottom, segApprovalDetails);
            flxApprovalsHistoryInformation.add(flxApprovalsHistoryErrorMessage, flxApprovalHistoryContent);
            flxApprovalrequestHistorySection.add(flxApprovalsHistoryInformation);
            var flxCommonActionsCont = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "80dp",
                "id": "flxCommonActionsCont",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "87.80%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCommonActionsCont.setDefaultUnit(kony.flex.DP);
            var CommonFormActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "centerX": "50%",
                "height": "111dp",
                "id": "CommonFormActionsNew",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnBack": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "height": "41dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "1.50%",
                        "top": "viz.val_cleared",
                        "width": "15%",
                        "zIndex": 3
                    },
                    "btnCancel": {
                        "bottom": "viz.val_cleared",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "1.50%",
                        "width": "15%"
                    },
                    "btnNext": {
                        "bottom": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "right": "1.50%",
                        "width": "15%"
                    },
                    "btnOption": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "1.50%",
                        "top": "viz.val_cleared",
                        "width": "15%",
                        "zIndex": 2
                    },
                    "flxMain": {
                        "centerX": "viz.val_cleared",
                        "height": "100%",
                        "isVisible": true,
                        "left": "0dp",
                        "reverseLayoutDirection": true,
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%",
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "formActionsNew": {
                        "height": "111dp",
                        "isVisible": false,
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxApprovalFormActions = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "80dp",
                "id": "flxApprovalFormActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalFormActions.setDefaultUnit(kony.flex.DP);
            var ApprovalFormActions = new com.InfinityOLB.ApprovalRequestsMA.ApprovalFormActions({
                "height": "80dp",
                "id": "ApprovalFormActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "ApprovalFormActions": {
                        "height": "80dp"
                    },
                    "btnBack": {
                        "centerX": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "1.50%",
                        "width": "97%"
                    },
                    "btnCancel": {
                        "right": "1.50%",
                        "width": "97%"
                    },
                    "btnNext": {
                        "right": "1.50%",
                        "width": "97%"
                    },
                    "btnOption": {
                        "right": "viz.val_cleared",
                        "width": "97%"
                    },
                    "flxMain": {
                        "centerY": "50%",
                        "height": "80dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxApprovalFormActions.add(ApprovalFormActions);
            flxCommonActionsCont.add(CommonFormActionsNew, flxApprovalFormActions);
            var flxAuthenticator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAuthenticator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "4dp",
                "width": "87.86%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAuthenticator.setDefaultUnit(kony.flex.DP);
            var OTPAuthenticator = new com.InfinityOLB.ApprovalRequestMA.OTPAuthenticator({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "OTPAuthenticator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadowBlur8Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA",
                "overrides": {
                    "OTPCode.imgViewCVVCode": {
                        "src": "view.png"
                    },
                    "OTPCode.imgWarning": {
                        "src": "error_yellow.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAuthenticator.add(OTPAuthenticator);
            var flxTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTerms",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "87.85%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTerms.setDefaultUnit(kony.flex.DP);
            var lblTitleTerms = new kony.ui.Label({
                "id": "lblTitleTerms",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var browserTnC = new kony.ui.Browser({
                "bottom": "10dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "browserTnC",
                "isVisible": true,
                "left": "20dp",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxTerms.add(lblTitleTerms, browserTnC);
            flxContentContainer.add(flxContentHeader, flxDisplayErrorMessage, flxContentDashBoard, flxAcknowledgementContainer, flxTransactionDetails, flxRequestCreateEditUpdateEditDetails, flxApprovalrequestHistorySection, flxCommonActionsCont, flxAuthenticator, flxTerms);
            flxMain.add(flxMainWrapper, flxskncontainer, flxContentContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "100dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    },
                    "customfooter": {
                        "centerX": "50%",
                        "height": "100dp",
                        "left": "0%",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "top": "26.60%",
                        "width": "1200dp"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "top": "75dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxTermsAndConditions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "155%",
                "id": "flxTermsAndConditions",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1501,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditions.setDefaultUnit(kony.flex.DP);
            var flxTC = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "760dp",
                "id": "flxTC",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "150dp",
                "width": "795dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTC.setDefaultUnit(kony.flex.DP);
            var flxTermsAndConditionsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTermsAndConditionsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxfbfbfbBorder0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTermsAndConditionsHeader.setDefaultUnit(kony.flex.DP);
            var lblTermsAndConditions = new kony.ui.Label({
                "id": "lblTermsAndConditions",
                "isVisible": true,
                "left": "2.50%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "17dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.08%",
                "skin": "slFbox",
                "width": "15dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "centerY": "50%",
                "height": "15dp",
                "id": "imgClose",
                "isVisible": true,
                "right": "0%",
                "skin": "slImage",
                "src": "icon_close_grey.png",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxClose.add(imgClose);
            flxTermsAndConditionsHeader.add(lblTermsAndConditions, flxClose);
            var flxSeperator1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var flxTCContents = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "560px",
                "horizontalScrollIndicator": true,
                "id": "flxTCContents",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknFFFFFFscroll",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContents.setDefaultUnit(kony.flex.DP);
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            var rtxTC = new kony.ui.RichText({
                "bottom": "10dp",
                "id": "rtxTC",
                "isVisible": true,
                "left": "2.50%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:100%;\">\nBy agreeing that you have read these Terms and Conditions and continuing eStatement/ eNotices enrollment, you signify your agreement to all the terms, conditions, and notices contained or referenced in this document and accept responsibility for your use of the service. If you choose not to agree that you have read these Terms and Conditions, you will not be enrolled in the Service and will have no further responsibility to the Bank.Access to the Service and use of the Service is subject to all applicable federal, state and local laws and regulations. Unauthorized use of the Service or information accessed via the Service is strictly prohibited.\n<br/>\nDescription of eStatements\n<br/>\nEStatements are offered for eligible deposit accounts, allowing you to replace your mailed (paper) statement with an electronic version (PDF) that you can view, save to your computer or print at your convenience. Any legal notices that normally accompany your mailed statement will be delivered to you electronically. The following is a brief description of the various features of the Service and requirements for using the Service. From time to time, we may add to, modify, or delete any feature of the Service at our sole discretion. Please note that by enrolling in eStatements, you will no longer receive a mailed paper statement. However, a monthly paper statement will be available to you upon request by contacting the Bank.\n<br/>\nRegistration for eStatements\nYou must first register and become an Internet Banking customer to use the Service. You must accept these Terms and Conditions to become a registered user of the Service. Your eStatement(s) will be made available to you when you log into the Bank’s Internet Banking Service. When you register for eStatements:\n<br/>\nYou consent to receive your Bank account statement in electronic format and authorize us to electronically deliver your account statement on a monthly statement cycle. Combined customer account statements may no longer be available.\nYour statement will be provided in a readable, printable, and downloadable format. Your eStatement will be available for viewing for a period of up to 12 calendar months beginning with your month of registration. You also agree to waive the mailing of a paper statement from this time forward. You can, however, at any time decline the Service and receive paper statements by mail by contacting us with your termination request. At all times a monthly statement will be available to you at the Bank upon request.\n<br/>\nEligible Accounts For eStatements\nEligible accounts include the following personal or non-personal account types: checking, savings, and money market accounts that have recurring periodic statements. All checking, money market and savings accounts that are related under the primary or secondary account holder’s social security number or Tax Identification Number will be automatically enrolled for eStatements. You will receive eStatements for the accounts you choose when enrolling. If you do not choose an account, you will continue to receive paper statements for that account.\n<br/>\nWe hereby reserve the right in our sole and absolute discretion to limit the approval or availability of and the access to the services set forth in this agreement on any subject account being applied for hereunder to only the individual listed on the bank’s records as the primary account holder of such accounts.\nIf any account which you have applied for and have been approved by the Bank to receive eStatements is a joint account, please be advised that only the primary holder or secondary holder of the account as shown on the statement document will receive and be able to access the eStatement for such account.\nEnrollment For eStatement Delivery\nTo have access to the Service you must log in to our Internet Banking service and choose PROFILE, then ESTATEMENT-EDIT. Follow the instructions on screen to enroll in eStatements. For accounts with multiple owners, only one account owner need enroll the account in the Service. Your current month’s statement may not be available until your next cycle date.\n<br/>\nChange In Terms and Conditions\nThe Bank reserves the right to modify this Agreement at any time. Any modifications shall be effective when they are posted on the Service. You will be notified as soon as possible when any changes are made which materially affect your rights, such as changes regarding how your information is maintained or used. It is your responsibility to review this Agreement including the bank’s Privacy Policy in order to be aware of any such changes.\n<br/>\nTermination\n<br/>\nThis Agreement will be in effect from the date your registration is submitted by you and accepted by the Bank and at all times while you are using the Service. Either you or the Bank may terminate this Agreement and your use of the Service at any time. As a customer of the Bank, you do have the right to have mailed to you a paper statement in place of an electronic one (eStatement). To unsubscribe from the Bank’s eStatement service and begin receiving your paper statement again, you will contact us by calling (605) 698-7621.\n<br/>\n<br/>\nMiscellaneous\nIf any provision of this Agreement is held to be invalid or otherwise unenforceable, the remainder of the provisions shall remain in full force and effect and shall in no way be invalidated or otherwise affected. Headings are for reference only and in no way define, limit, construe, or describe the scope or extent of such section. Our failure to act with respect to a breach by you or others does not waive our right to act with respect to subsequent or similar breaches. This Agreement represents the sole and exclusive agreement between you and the Bank regarding the Service and merges and supersedes all previous and contemporaneous written or oral agreements and understandings regarding the subject matter hereof. The Bank may assign the Service, including this Agreement in whole or in part; however, you may not assign or transfer this Agreement. Should any term or condition be in conflict between this agreement and any document incorporated herein by reference into this Agreement, the Agreement shall control.\nIf you have any questions regarding this Agreement, or the Service, please contact our bank.\nThis service is subject to all terms and conditions as set forth in the Internet Banking Terms and Conditions that you have previously been provided.\n<br/>\n.</style></p>",
                "top": "0px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTCContents.add(flxDummy, rtxTC);
            var flxTCCheckBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTCCheckBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCCheckBox.setDefaultUnit(kony.flex.DP);
            var lblIAccept = new kony.ui.Label({
                "id": "lblIAccept",
                "isVisible": true,
                "left": "6%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.IAcceptTC\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTCContentsCheckbox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxTCContentsCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.50%",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": "0dp",
                "width": "23dp",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTCContentsCheckbox.setDefaultUnit(kony.flex.DP);
            var lblTCContentsCheckBox = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "22dp",
                "id": "lblTCContentsCheckBox",
                "isVisible": true,
                "skin": "sknlblOLBFonts3343A820pxOlbFontIcons",
                "text": "C",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Terms & Conditions"
            });
            flxTCContentsCheckbox.add(lblTCContentsCheckBox);
            flxTCCheckBox.add(lblIAccept, flxTCContentsCheckbox);
            var flxSeperator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxContentsButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 0,
                "clipBounds": true,
                "height": "90px",
                "id": "flxContentsButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "-1dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentsButtons.setDefaultUnit(kony.flex.DP);
            var btnCancel = new kony.ui.Button({
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder3343a81pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Cancel"
            });
            var btnSave = new kony.ui.Button({
                "bottom": 20,
                "centerY": "50%",
                "height": "40dp",
                "id": "btnSave",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Save"
            });
            flxContentsButtons.add(btnCancel, btnSave);
            flxTC.add(flxTermsAndConditionsHeader, flxSeperator1, flxTCContents, flxTCCheckBox, flxSeperator2, flxContentsButtons);
            flxTermsAndConditions.add(flxTC);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "btnNo": {
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "btnYes": {
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "flxCross": {
                        "right": "13dp"
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "icon_close_grey.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxPopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxClose": {
                        "isVisible": true,
                        "right": "0dp"
                    },
                    "flxComments": {
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxPopupContainer": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared",
                        "top": "280dp"
                    },
                    "flxPopupNew": {
                        "isVisible": false,
                        "zIndex": 10
                    },
                    "formActionsNew.btnCancel": {
                        "left": "viz.val_cleared",
                        "right": "190dp",
                        "width": "150dp"
                    },
                    "formActionsNew.btnNext": {
                        "left": "viz.val_cleared",
                        "right": "20dp",
                        "width": "150dp"
                    },
                    "imgClose": {
                        "right": "20dp",
                        "src": "closeicon_1.png"
                    },
                    "lblCommnets": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.myRequests.comments\")"
                    },
                    "trComments": {
                        "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.trComments\")",
                        "left": "30dp",
                        "right": "viz.val_cleared",
                        "top": "12dp",
                        "width": "88.70%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxOverlay = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxOverlay",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Opacity40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverlay.setDefaultUnit(kony.flex.DP);
            flxOverlay.add();
            var flxPendingApprovers = new kony.ui.FlexContainer({
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "600dp",
                "id": "flxPendingApprovers",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "20dp",
                "width": "50%",
                "zIndex": 7000,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApprovers.setDefaultUnit(kony.flex.DP);
            var flxPendingApproversDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxPendingApproversDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApproversDetails.setDefaultUnit(kony.flex.DP);
            var flxPendingApproversHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxPendingApproversHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApproversHeader.setDefaultUnit(kony.flex.DP);
            var lblApprovalDetails = new kony.ui.Label({
                "id": "lblApprovalDetails",
                "isVisible": true,
                "left": "23dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendinApprovers.PendingApprovalDetails\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgPopupclose = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgPopupclose",
                "isVisible": true,
                "right": "10dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "top": "15dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPendingApproversHeader.add(lblApprovalDetails, imgPopupclose);
            var flxSeparator = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxGroupDetails = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "70%",
                "horizontalScrollIndicator": true,
                "id": "flxGroupDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupDetails.setDefaultUnit(kony.flex.DP);
            var flxApprovalLimitHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxApprovalLimitHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxShadow4645454Bg",
                "top": "3dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalLimitHeader.setDefaultUnit(kony.flex.DP);
            var flxPerTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPerTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "190dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPerTransaction.setDefaultUnit(kony.flex.DP);
            var lblPerTransaction = new kony.ui.Label({
                "id": "lblPerTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLbl424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendingApprovers.PerTransactionApprovals\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPerTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxPerTransactionSelected",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "36dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPerTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxPerTransactionSelected.add();
            flxPerTransaction.add(lblPerTransaction, flxPerTransactionSelected);
            var flxDailyTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDailyTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "240dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "125dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyTransaction.setDefaultUnit(kony.flex.DP);
            var lblDailyTransaction = new kony.ui.Label({
                "id": "lblDailyTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLbl424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.dailyTransaction\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDailyTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxDailyTransactionSelected",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "36dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxDailyTransactionSelected.add();
            flxDailyTransaction.add(lblDailyTransaction, flxDailyTransactionSelected);
            var flxWeekelyTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWeekelyTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "395dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "145dp",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeekelyTransaction.setDefaultUnit(kony.flex.DP);
            var lblWeekelyTransaction = new kony.ui.Label({
                "id": "lblWeekelyTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknbbSknLbl424242SSP17Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.weeklyTransaction\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWeeklyTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxWeeklyTransactionSelected",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "30dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxWeeklyTransactionSelected.add();
            flxWeekelyTransaction.add(lblWeekelyTransaction, flxWeeklyTransactionSelected);
            flxApprovalLimitHeader.add(flxPerTransaction, flxDailyTransaction, flxWeekelyTransaction);
            var flxNoteMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNoteMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoteMessage.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgInfoIcon",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInfo = new kony.ui.Label({
                "id": "lblInfo",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl42424215PX",
                "text": "Note: The transaction can be approved by any 2 of the sernior managers (or) any 1 of the admin.",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoteMessage.add(imgInfoIcon, lblInfo);
            var flxMultiContractMsg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMultiContractMsg",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMultiContractMsg.setDefaultUnit(kony.flex.DP);
            var lblMultiContractMsg = new kony.ui.Label({
                "id": "lblMultiContractMsg",
                "isVisible": true,
                "left": "60dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ApprovalRequest.ApprovalRequiredFromMultipleContracts\")",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMultiContractMsg.add(lblMultiContractMsg);
            var flxApproverList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApproverList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApproverList.setDefaultUnit(kony.flex.DP);
            flxApproverList.add();
            flxGroupDetails.add(flxApprovalLimitHeader, flxNoteMessage, flxMultiContractMsg, flxApproverList);
            var flxNoPendingData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "470dp",
                "id": "flxNoPendingData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoPendingData.setDefaultUnit(kony.flex.DP);
            var flxInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfo.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon2 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgInfoIcon2",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoPendingApprovals = new kony.ui.Label({
                "id": "lblNoPendingApprovals",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendingApprovers.noPendingApprovals\")",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfo.add(imgInfoIcon2, lblNoPendingApprovals);
            flxNoPendingData.add(flxInfo);
            var flxPopupBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "90dp",
                "id": "flxPopupBottom",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 500,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupBottom.setDefaultUnit(kony.flex.DP);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalRequestMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            var btnClose = new kony.ui.Button({
                "centerY": "50%",
                "height": "50dp",
                "id": "btnClose",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknBtn003e75BGffffff45PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.close\")",
                "width": "130dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPopupBottom.add(flxBottomSeparator, btnClose);
            flxPendingApproversDetails.add(flxPendingApproversHeader, flxSeparator, flxGroupDetails, flxNoPendingData, flxPopupBottom);
            flxPendingApprovers.add(flxPendingApproversDetails);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.headermenu": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxBackToPending": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPending": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "isVisible": true,
                        "zIndex": 10,
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxDropdown": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxImage": {
                        "left": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.00%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.lblView": {
                        "width": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.lblViewType": {
                        "left": {
                            "type": "string",
                            "value": "13%"
                        },
                        "width": {
                            "type": "string",
                            "value": "77%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown.segViewTypes": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer.flxPagination": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer.flxPaginationFirst": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabBodyNew": {
                        "isVisible": true,
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabBodyNew.segTemplates": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxOptions": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "-96%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblView": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.tbxSearch": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "76%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.flxContentContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetails": {
                        "segmentProps": []
                    },
                    "NonEditableDetails.btnEdit": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxBtmSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTitle": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTopSepartor": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.lblACHTitleText": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lstbTemplateType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbRequestType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbAccount": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "right": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "skin": "sknFlxscrollffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxDate": {
                        "width": {
                            "type": "string",
                            "value": "94.96%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "70"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnNext": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "instanceId": "createFlowFormActionsNew"
                    },
                    "flxErrorFlow": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxUploadedFileDetails": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "filesFormActionsNew.btnCancel": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "70"
                        },
                        "segmentProps": []
                    },
                    "filesFormActionsNew.btnNext": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "filesFormActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "instanceId": "filesFormActionsNew"
                    },
                    "dbRightContainerNew": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": [],
                        "instanceId": "dbRightContainerNew"
                    },
                    "flxAcknowledgementContainer": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgPrint": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgdownload": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "70px"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "slfBoxffffffB1R5",
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxBtmSeperator": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.lblACHTitleText": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentOptions": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAckPaymentInstruction": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAckPaymentInstructionValue": {
                        "left": {
                            "type": "string",
                            "value": "24.58%"
                        },
                        "segmentProps": []
                    },
                    "lblRecordHeader2": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "34dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.flxTotalAmount": {
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmmount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblUpdateDefaultAmount": {
                        "left": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.tbxTotalAmount": {
                        "left": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": []
                    },
                    "flxRequestDetails": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblCreatedDetails": {
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "skin": "sknlblSSP42424213pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "flxAlertsWarningWrapper": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgAlertsWarningImage": {
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "flxCreateRequestInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblRecipientInforation": {
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "skin": "sknlblSSP42424213pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "lblRecipientBankInfo": {
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "skin": "sknlblSSP42424213pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "lblRecipientsLinkedWith": {
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "skin": "sknlblSSP42424213pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "contractListRecipient.flxContract": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalHistoryContent": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "skin": "sknlblSSP42424213pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "flxApprovalStatus": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxApprovalStatusGroup": {
                        "segmentProps": []
                    },
                    "flxApprovalDetailsStatus": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblApprovalStatus": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxApprovedCountDetails": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblApproveCount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxRejectedCountDetails": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblRejectCount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnPendingAprrovers": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.8%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.40%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnBack": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnNext": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnOption": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Option",
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "instanceId": "CommonFormActionsNew"
                    },
                    "flxApprovalFormActions": {
                        "height": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions": {
                        "height": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": [],
                        "instanceId": "ApprovalFormActions"
                    },
                    "ApprovalFormActions.btnBack": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.40%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.40%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnNext": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.40%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnOption": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94.40%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.flxMain": {
                        "height": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "flxAuthenticator": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.btnProceed": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.flxActions": {
                        "height": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.OTPCode.lblSecureAccessCode": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "OTPAuthenticator.flxOTPContainer": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "text": "© Copyright Infinity Retail Banking. All rights reserved.",
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "btnSave": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnNo": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.btnYes": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxClose": {
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "isVisible": false,
                        "segmentProps": [],
                        "instanceId": "flxPopup"
                    },
                    "flxPopup.formActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.formActionsNew.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader.headermenu": {
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxBackToPending": {
                        "segmentProps": []
                    },
                    "imgBack": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPending": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer.flxPagination": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew": {
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                        "right": {
                            "type": "string",
                            "value": "12%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "left": {
                            "type": "string",
                            "value": "70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxOptions": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblView": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "98.50%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetails": {
                        "segmentProps": []
                    },
                    "NonEditableDetails.btnEdit": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxBtmSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTitle": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTopSepartor": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.lblACHTitleText": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "tbxTemplateName": {
                        "padding": [2, 0, 0, 0],
                        "segmentProps": []
                    },
                    "tbxTemplateDescription": {
                        "padding": [2, 0, 0, 0],
                        "segmentProps": []
                    },
                    "lstbTemplateType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbRequestType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbCompanyName": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbAccount": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "txtTransferFrom": {
                        "right": {
                            "type": "number",
                            "value": "3"
                        },
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblCurrSymbol": {
                        "segmentProps": []
                    },
                    "tbxMaxAmt": {
                        "segmentProps": []
                    },
                    "flxDate": {
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.96%"
                        },
                        "segmentProps": []
                    },
                    "calEffectiveDate": {
                        "padding": [5, 0, 5, 0],
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnOption": {
                        "right": {
                            "type": "string",
                            "value": "37.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "lstbFormatType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "filesFormActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "filesFormActionsNew.btnNext": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "filesFormActionsNew.btnOption": {
                        "right": {
                            "type": "string",
                            "value": "37.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "dbRightContainerNew": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": [],
                        "instanceId": "dbRightContainerNew"
                    },
                    "flxAcknowledgementContainer": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxAckContainer": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "10.50%"
                        },
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "focusSkin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblACHfileDetails": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxTopSepartor": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "flxFomatType": {
                        "centerX": {
                            "type": "string",
                            "value": "49.86%"
                        },
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "flxFileUploadRequest": {
                        "centerX": {
                            "type": "string",
                            "value": "49.90%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "flxFileUploadAck": {
                        "centerX": {
                            "type": "string",
                            "value": "49.93%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxBtmSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxSupportingDocuments": {
                        "height": {
                            "type": "string",
                            "value": "37dp"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxTopSepartor": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.lblACHTitleText": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxEffectiveDateSelect": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDateBottomSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "top": {
                            "type": "string",
                            "value": "121dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.60%"
                        },
                        "segmentProps": []
                    },
                    "lblPayemntInstruction": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentOptions": {
                        "left": {
                            "type": "string",
                            "value": "23.58%"
                        },
                        "segmentProps": []
                    },
                    "flxAckPaymentInstruction": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAckPayemntInstruction": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblAckPaymentInstructionValue": {
                        "left": {
                            "type": "string",
                            "value": "23.58%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator4": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.66%"
                        },
                        "segmentProps": []
                    },
                    "lblRecordHeader1": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblRecordHeader2": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.66%"
                        },
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorMessage": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.TabBodyNew.segTemplates": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.btnUpdate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.flxTotalAmount": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "79%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.flxTotalAmountCreate": {
                        "left": {
                            "type": "string",
                            "value": "76%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblAmountColon": {
                        "left": {
                            "type": "string",
                            "value": "77.50%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblColon": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblCurrSymbol": {
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "26%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmount": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmountCreate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblUpdateDefaultAmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.tbxUpdateDefaultAmount": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "14.90%"
                        },
                        "segmentProps": []
                    },
                    "flxRequestCreateEditUpdateEditDetails": {
                        "segmentProps": []
                    },
                    "lblCreatedDetails": {
                        "centerY": {
                            "type": "number",
                            "value": "7"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientInforation": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperatorBankDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientBankInfo": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxBelowSeparatorBankDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientsLinkedWith": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "contractListRecipient.flxContract": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryInformation": {
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxTopSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalDetailsStatus": {
                        "segmentProps": []
                    },
                    "lblApprovalStatus": {
                        "left": {
                            "type": "string",
                            "value": "4.10%"
                        },
                        "segmentProps": []
                    },
                    "lblApproveCount": {
                        "left": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "btnPendingAprrovers": {
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "segApprovalDetails": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnBack": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnOption": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.flxMain": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalFormActions": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnNext": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnOption": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.flxMain": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAuthenticator": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblTitleTerms": {
                        "left": {
                            "type": "string",
                            "value": "27px"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "top": {
                            "type": "string",
                            "value": "378px"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "segmentProps": [],
                        "instanceId": "flxPopup"
                    },
                    "flxOverlay": {
                        "segmentProps": []
                    },
                    "flxPendingApprovers": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalDetails": {
                        "segmentProps": []
                    },
                    "imgPopupclose": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxPerTransaction": {
                        "width": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "flxDailyTransaction": {
                        "left": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": []
                    },
                    "flxWeekelyTransaction": {
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoPendingApprovals": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader.headermenu": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxBackToPending": {
                        "segmentProps": []
                    },
                    "imgBack": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPending": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Back to Approvals Dashboard",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer.flxPagination": {
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabBodyNew.segTemplates": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew": {
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                        "right": {
                            "type": "string",
                            "value": "12%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "left": {
                            "type": "string",
                            "value": "70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxOptions": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblView": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab5": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab6": {
                        "segmentProps": []
                    },
                    "flxCreateUI": {
                        "segmentProps": []
                    },
                    "NonEditableDetails": {
                        "segmentProps": []
                    },
                    "NonEditableDetails.btnEdit": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxBtmSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTitle": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTopSepartor": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.lblACHTitleText": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lstbTemplateType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbRequestType": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbCompanyName": {
                        "padding": [4, 0, 0, 0],
                        "segmentProps": []
                    },
                    "lstbAccount": {
                        "padding": [2, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.98%"
                        },
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.98%"
                        },
                        "segmentProps": []
                    },
                    "lblCurrSymbol": {
                        "segmentProps": []
                    },
                    "tbxMaxAmt": {
                        "segmentProps": []
                    },
                    "calEffectiveDate": {
                        "padding": [6, 0, 5, 0],
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "flxACHFilesUpload": {
                        "segmentProps": []
                    },
                    "dbRightContainerNew.btnAction1": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "focusSkin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxBtmSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxEffectiveDateSelect": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1.67%"
                        },
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorMessage": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "CopyslFbox0j0ebf902d97643",
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96.60%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.btnUpdate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblAmountColon": {
                        "left": {
                            "type": "string",
                            "value": "77.50%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmountCreate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxRequestCreateEditUpdateEditDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxRequestDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblCreatedDetails": {
                        "text": "Created Details",
                        "segmentProps": []
                    },
                    "flxAlertsWarningWrapper": {
                        "segmentProps": []
                    },
                    "imgAlertsWarningImage": {
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "segmentProps": []
                    },
                    "flxCreateRequestInfo": {
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientInforation": {
                        "text": "Recipient Information",
                        "segmentProps": []
                    },
                    "SegmentRecipientInfoDetails": {
                        "segmentProps": []
                    },
                    "flxSeperatorBankDetails": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientBankInfo": {
                        "segmentProps": []
                    },
                    "SegmentRecipientBankDetails": {
                        "segmentProps": []
                    },
                    "flxBelowSeparatorBankDetails": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientsLinkedWith": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxContract": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "contractListRecipient.lblCol3": {
                        "text": "Updated",
                        "segmentProps": []
                    },
                    "flxApprovalConditionsDetails": {
                        "segmentProps": []
                    },
                    "segApprovalConditions": {
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "CopyslFbox0j0ebf902d97643",
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96.60%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalHistoryContent": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxApprovalHistoryHeading": {
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnNext": {
                        "minWidth": {
                            "type": "string",
                            "value": "15%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnOption": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.flxMain": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnBack": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnCancel": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnOption": {
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.flxMain": {
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "top": {
                            "type": "string",
                            "value": "110dp"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.formActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPendingApprovers": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "500dp"
                        },
                        "segmentProps": []
                    },
                    "btnClose": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheader.headermenu": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxBackToPending": {
                        "segmentProps": []
                    },
                    "imgBack": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToPending": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.85%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTabPaneContainer": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "TabPaneNew.MobileCustomDropdown": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.PaginationContainer.flxPagination": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew": {
                        "isVisible": true,
                        "segmentProps": [],
                        "instanceId": "TabPaneNew"
                    },
                    "TabPaneNew.TabSearchBarNew": {
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "isVisible": true,
                        "zIndex": 5,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "100%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                        "right": {
                            "type": "string",
                            "value": "12%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxDropDown": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "70%"
                        },
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.flxSearch": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "68%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblOption0": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblOption1": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.lblView": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab5": {
                        "segmentProps": []
                    },
                    "TabPaneNew.TabsHeaderNew.btnTab6": {
                        "segmentProps": []
                    },
                    "flxCreateUI": {
                        "segmentProps": []
                    },
                    "NonEditableDetails": {
                        "segmentProps": []
                    },
                    "NonEditableDetails.btnEdit": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxBtmSeperator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTitle": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.flxTopSepartor": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "NonEditableDetails.lblACHTitleText": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCreateDetails": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "tbxTemplateName": {
                        "isVisible": true,
                        "skin": "sknTextBoxSSP42424215PxNoBor",
                        "segmentProps": []
                    },
                    "tbxTemplateDescription": {
                        "skin": "sknTextBoxSSP42424215PxNoBor",
                        "segmentProps": []
                    },
                    "lstbTemplateType": {
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbRequestType": {
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "lstbCompanyName": {
                        "padding": [3, 0, 0, 0],
                        "segmentProps": []
                    },
                    "lstbAccount": {
                        "padding": [3, 0, 1, 0],
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.98%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectAccount": {
                        "segmentProps": []
                    },
                    "lblFromAmount": {
                        "segmentProps": []
                    },
                    "txtTransferFrom": {
                        "segmentProps": []
                    },
                    "flxFromSegment": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2.52%"
                        },
                        "top": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.98%"
                        },
                        "segmentProps": []
                    },
                    "tbxMaxAmt": {
                        "skin": "sknTextBoxSSP42424215PxNoBor",
                        "segmentProps": []
                    },
                    "flxDate": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxEffectiveDate": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "calEffectiveDate": {
                        "padding": [6, 0, 5, 0],
                        "skin": "sknBBCal42424215px",
                        "segmentProps": []
                    },
                    "flxBottomSeperator": {
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "createFlowFormActionsNew.btnOption": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "45.50%"
                        },
                        "segmentProps": []
                    },
                    "flxACHFilesUpload": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "segmentProps": []
                    },
                    "flxTransactionDetails": {
                        "focusSkin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "NonEditableDetailsNew.flxBtmSeperator": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDateContainer": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxEffectiveDateSelect": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "1.67%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxDate1": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxEffectDate1": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "calEffectiveDate1": {
                        "skin": "sknBBCal42424215px",
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.flxTotalAmount": {
                        "left": {
                            "type": "string",
                            "value": "79%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblAmountColon": {
                        "left": {
                            "type": "string",
                            "value": "77.50%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmmount": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "23%"
                        },
                        "segmentProps": []
                    },
                    "TemplateRecordsNew.lblTotalAmountCreate": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblCreatedDetails": {
                        "segmentProps": []
                    },
                    "lblAlertsWarning": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxCreateRequestInfo": {
                        "segmentProps": []
                    },
                    "lblRecipientInforation": {
                        "text": "Recipient Information",
                        "segmentProps": []
                    },
                    "lblRecipientBankInfo": {
                        "segmentProps": []
                    },
                    "lblRecipientsLinkedWith": {
                        "segmentProps": []
                    },
                    "contractListRecipient.flxContract": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "contractListRecipient.lblCol3": {
                        "text": "Updated",
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "segmentProps": []
                    },
                    "btnPendingAprrovers": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorBottom": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "segApprovalDetails": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnNext": {
                        "minWidth": {
                            "type": "string",
                            "value": "15%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnOption": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.flxMain": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnNext": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.btnOption": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "ApprovalFormActions.flxMain": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxPopup.flxPopupContainer": {
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "top": {
                            "type": "string",
                            "value": "378px"
                        },
                        "segmentProps": []
                    },
                    "flxPopup.formActionsNew.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxPendingApprovers": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "skin": "sknflxe9ebee",
                        "segmentProps": []
                    },
                    "flxNoteMessage": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon": {
                        "segmentProps": []
                    },
                    "lblInfo": {
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxMultiContractMsg": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxApproverList": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon2": {
                        "segmentProps": []
                    },
                    "lblNoPendingApprovals": {
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "segmentProps": []
                    },
                    "btnClose": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.headermenu": {
                    "height": "70dp",
                    "right": "6%",
                    "top": "0dp",
                    "width": "94%"
                },
                "TabPaneNew.MobileCustomDropdown": {
                    "zIndex": 1
                },
                "TabPaneNew.MobileCustomDropdown.flxImage": {
                    "left": "91%"
                },
                "TabPaneNew.MobileCustomDropdown.flxIphoneDropdown": {
                    "centerX": "",
                    "centerY": "",
                    "left": "4%"
                },
                "TabPaneNew.MobileCustomDropdown.imgDropdown": {
                    "src": "listboxarw.png"
                },
                "TabPaneNew.MobileCustomDropdown.lblView": {
                    "width": "100%"
                },
                "TabPaneNew.MobileCustomDropdown.lblViewType": {
                    "left": "0%",
                    "width": "85%"
                },
                "TabPaneNew.MobileCustomDropdown.segViewTypes": {
                    "zIndex": 15
                },
                "TabPaneNew.PaginationContainer.flxPagination": {
                    "reverseLayoutDirection": true
                },
                "TabPaneNew.PaginationContainer.imgPaginationFirst": {
                    "src": "pagination_inactive.png"
                },
                "TabPaneNew.PaginationContainer.imgPaginationNext": {
                    "src": "pagination_next_active.png"
                },
                "TabPaneNew.PaginationContainer.imgPaginationPrevious": {
                    "src": "pagination_back_inactive.png"
                },
                "TabPaneNew.TabBodyNew": {
                    "top": "0dp"
                },
                "TabPaneNew.TabBodyNew.segTemplates": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "TabPaneNew.TabSearchBarNew": {
                    "centerY": "",
                    "zIndex": 1,
                    "layoutType": kony.flex.FREE_FORM
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown": {
                    "bottom": "",
                    "centerX": "",
                    "height": "80dp",
                    "top": "0dp",
                    "zIndex": 1
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxDropdown": {
                    "left": "4%",
                    "top": "60dp",
                    "width": "92%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.flxIphoneDropdown": {
                    "bottom": "",
                    "height": "40dp",
                    "left": "4%",
                    "minWidth": "",
                    "top": "20dp",
                    "width": "100%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.imgDropdown": {
                    "src": "listboxarw.png"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblView": {
                    "left": "5%",
                    "minWidth": "",
                    "right": "",
                    "top": "0dp",
                    "width": "23%"
                },
                "TabPaneNew.TabSearchBarNew.MobileCustomDropdown.lblViewType": {
                    "left": "28%",
                    "right": "",
                    "top": "0%",
                    "width": ""
                },
                "TabPaneNew.TabSearchBarNew.flxBoxSearch": {
                    "height": "40dp",
                    "left": "0%",
                    "width": "95%"
                },
                "TabPaneNew.TabSearchBarNew.flxDropDown": {
                    "centerY": "47.50%",
                    "height": "50dp",
                    "left": "0%",
                    "top": "",
                    "zIndex": 1
                },
                "TabPaneNew.TabSearchBarNew.flxOptions": {
                    "height": "100%"
                },
                "TabPaneNew.TabSearchBarNew.flxSearch": {
                    "left": "20dp",
                    "width": "68%"
                },
                "TabPaneNew.TabSearchBarNew.listBoxViewType": {
                    "right": "10dp",
                    "width": "67.74%"
                },
                "NonEditableDetails": {
                    "left": "1%",
                    "top": "0dp",
                    "width": "98%"
                },
                "createFlowFormActionsNew.btnCancel": {
                    "left": "",
                    "right": "23%",
                    "width": "18%"
                },
                "createFlowFormActionsNew.btnNext": {
                    "left": "77.35%",
                    "width": "18.99%"
                },
                "createFlowFormActionsNew.btnOption": {
                    "left": "",
                    "right": "43.50%",
                    "width": "18%"
                },
                "ACHFilesActions": {
                    "left": "",
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerY": ""
                },
                "filesFormActionsNew.btnCancel": {
                    "left": "",
                    "right": "23%",
                    "width": "18%"
                },
                "filesFormActionsNew.btnNext": {
                    "left": "",
                    "width": "18%"
                },
                "filesFormActionsNew.btnOption": {
                    "left": "",
                    "right": "43.50%",
                    "width": "18%"
                },
                "dbRightContainerNew": {
                    "top": "0dp",
                    "width": "28.68%"
                },
                "dbRightContainerNew.imgBanner": {
                    "src": "nuo_banner_1.png"
                },
                "flxAcknowledgement": {
                    "successImgWidth": "4.44%",
                    "successMsg": "Your transaction has been successfully submitted\nReference Number 45423792753",
                    "right": "",
                    "top": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": ""
                },
                "flxAcknowledgementNew.flxAckContainer": {
                    "height": "72dp"
                },
                "flxAcknowledgementNew": {
                    "left": "0dp",
                    "width": "100%"
                },
                "flxAcknowledgementNew.flxTickImage": {
                    "height": "34dp",
                    "width": "3%"
                },
                "flxAcknowledgementNew.imgDownload": {
                    "src": "bbdownloadicon.png"
                },
                "flxAcknowledgementNew.imgPrint": {
                    "src": "bbprint.png"
                },
                "flxAcknowledgementNew.imgTick": {
                    "left": "10dp",
                    "src": "bulk_billpay_success.png",
                    "top": "0dp",
                    "width": "100%"
                },
                "flxAcknowledgementNew.lblRefrenceId": {
                    "top": "35dp"
                },
                "flxAcknowledgementNew.lblRefrenceId2": {
                    "top": "35dp"
                },
                "flxAcknowledgementNew.lblSuccess": {
                    "top": "10dp"
                },
                "flxAcknowledgementNew.rTextSuccess": {
                    "text": "<body> User has been Successfully Added <br> Reference Number 45423792753 </body>"
                },
                "NonEditableDetailsNew.flxBtmSeperator": {
                    "centerX": "50%",
                    "top": "13dp",
                    "width": "96.67%"
                },
                "NonEditableDetailsNew.flxDetailsHeading": {
                    "height": "50dp"
                },
                "NonEditableDetailsNew.flxTopSepartor": {
                    "centerX": "50%",
                    "width": "96.67%"
                },
                "NonEditableDetailsNew.lblACHTitleText": {
                    "centerY": "",
                    "height": "22dp",
                    "top": "12dp"
                },
                "NonEditableDetailsNew.segDetails": {
                    "centerX": "",
                    "left": "2%",
                    "top": "13dp",
                    "width": "96.50%"
                },
                "TemplateRecordsNew.TabBodyNew.segTemplates": {
                    "left": "0dp"
                },
                "TemplateRecordsNew.btnUpdate": {
                    "centerY": "50%",
                    "left": "0.93%",
                    "right": "3%",
                    "top": ""
                },
                "TemplateRecordsNew.flxSeparator": {
                    "width": "100%"
                },
                "TemplateRecordsNew.flxTotalAmount": {
                    "left": "79%",
                    "right": ""
                },
                "TemplateRecordsNew.lblCurrSymbol": {
                    "left": "7%"
                },
                "TemplateRecordsNew.lblTotalAmmount": {
                    "centerY": "50%"
                },
                "TemplateRecordsNew.lblTotalAmount": {
                    "left": ""
                },
                "TemplateRecordsNew.lblTotalAmountCreate": {
                    "left": "13%"
                },
                "TemplateRecordsNew.tbxTotalAmount": {
                    "left": "77%"
                },
                "contractListRecipient.flxContract": {
                    "width": "87.50%"
                },
                "contractListRecipient.imgCol1": {
                    "src": "sorting_next.png"
                },
                "contractListRecipient.imgCol2": {
                    "src": "sorting.png"
                },
                "contractListRecipient.imgCol3": {
                    "src": "sorting.png"
                },
                "contractListRecipient.lblCol3": {
                    "text": "Identity Number"
                },
                "CommonFormActionsNew.btnBack": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "50%",
                    "height": "41dp",
                    "left": "",
                    "right": "1.50%",
                    "top": "",
                    "width": "15%",
                    "zIndex": 3
                },
                "CommonFormActionsNew.btnCancel": {
                    "bottom": "",
                    "left": "",
                    "right": "1.50%",
                    "width": "15%"
                },
                "CommonFormActionsNew.btnNext": {
                    "bottom": "",
                    "height": "40dp",
                    "left": "",
                    "minWidth": "",
                    "right": "1.50%",
                    "width": "15%"
                },
                "CommonFormActionsNew.btnOption": {
                    "bottom": "",
                    "centerX": "",
                    "left": "",
                    "right": "1.50%",
                    "top": "",
                    "width": "15%",
                    "zIndex": 2
                },
                "CommonFormActionsNew.flxMain": {
                    "centerX": "",
                    "height": "100%",
                    "left": "0dp",
                    "reverseLayoutDirection": true,
                    "right": "",
                    "top": "0dp",
                    "width": "100%",
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "CommonFormActionsNew": {
                    "height": "111dp",
                    "top": "0dp"
                },
                "ApprovalFormActions": {
                    "height": "80dp"
                },
                "ApprovalFormActions.btnBack": {
                    "centerX": "",
                    "left": "",
                    "right": "1.50%",
                    "width": "97%"
                },
                "ApprovalFormActions.btnCancel": {
                    "right": "1.50%",
                    "width": "97%"
                },
                "ApprovalFormActions.btnNext": {
                    "right": "1.50%",
                    "width": "97%"
                },
                "ApprovalFormActions.btnOption": {
                    "right": "",
                    "width": "97%"
                },
                "ApprovalFormActions.flxMain": {
                    "centerY": "50%",
                    "height": "80dp"
                },
                "OTPAuthenticator.OTPCode.imgViewCVVCode": {
                    "src": "view.png"
                },
                "OTPAuthenticator.OTPCode.imgWarning": {
                    "src": "error_yellow.png"
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "100dp",
                    "left": "0%",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "top": "26.60%",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "top": "75dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.btnNo": {
                    "right": "190dp",
                    "width": "150dp"
                },
                "CustomPopup.btnYes": {
                    "right": "20dp",
                    "width": "150dp"
                },
                "CustomPopup.flxCross": {
                    "right": "13dp"
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "icon_close_grey.png"
                },
                "flxPopup.flxClose": {
                    "right": "0dp"
                },
                "flxPopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "flxPopup.flxPopupContainer": {
                    "centerY": "",
                    "left": "",
                    "right": "",
                    "top": "280dp"
                },
                "flxPopup": {
                    "zIndex": 10
                },
                "flxPopup.formActionsNew.btnCancel": {
                    "left": "",
                    "right": "190dp",
                    "width": "150dp"
                },
                "flxPopup.formActionsNew.btnNext": {
                    "left": "",
                    "right": "20dp",
                    "width": "150dp"
                },
                "flxPopup.imgClose": {
                    "right": "20dp",
                    "src": "closeicon_1.png"
                },
                "flxPopup.trComments": {
                    "left": "30dp",
                    "right": "",
                    "top": "12dp",
                    "width": "88.70%"
                }
            }
            this.add(flxHeaderMain, flxFormContent, flxTermsAndConditions, flxLogout, flxLoading, flxPopup, flxOverlay, flxPendingApprovers);
        };
        return [{
            "addWidgets": addWidgetsfrmApprovalViewDetails,
            "enabledForIdleTimeout": true,
            "id": "frmApprovalViewDetails",
            "init": controller.AS_Form_dca4e0e675dd4fb49de2287a880e9496,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_ea2336f5be604a758b28f272184a3fc5,
            "postShow": controller.AS_Form_b726d996585d4a7da0ded4528b2681c9,
            "preShow": function(eventobject) {
                controller.AS_Form_c9d99d901d04458894ddef999ce34834(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ApprovalRequestMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_e08e138c4c2c439ab07b3539cd1a9ec8,
            "retainScrollPosition": true
        }]
    }
});