define("ArrangementsMA/MortgageServicesUIModule/frmPrintAcknowledge", function() {
    return function(controller) {
        function addWidgetsfrmPrintAcknowledge() {
            this.setDefaultUnit(kony.flex.DP);
            var flxPrintAcknowledge = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrintAcknowledge",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrintAcknowledge.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxHeader",
                "top": "70dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Header Kony Logo"
                },
                "height": "31dp",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "6%",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "18px",
                "width": "102dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblKonyBank = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "My Checking Account ….XXXX3254"
                },
                "centerY": "50%",
                "id": "lblKonyBank",
                "isVisible": true,
                "right": "6.66%",
                "skin": "sknlbl424242bold17px",
                "text": "My Checking Account ….XXXX3254",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(imgKony, lblKonyBank);
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.back\")"
                },
                "focusSkin": "slButtonGlossRed",
                "id": "btnBack",
                "isVisible": false,
                "left": "6.07%",
                "skin": "Copysknbtnffffff",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.back\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back"
            });
            var lblMyCheckingAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "My Checking Account ….XXXX3254"
                },
                "id": "lblMyCheckingAccount",
                "isVisible": true,
                "left": "1%",
                "skin": "sknlbl424242bold17px",
                "text": "My Checking Account ….XXXX3254",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxAckHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAckHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckHeader.setDefaultUnit(kony.flex.DP);
            var lblAcknowledgement = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAcknowledgement",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Acknowledgement\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CopyflxSeparator0e39b3a3294d244 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "CopyflxSeparator0e39b3a3294d244",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxSeparator0e39b3a3294d244.setDefaultUnit(kony.flex.DP);
            CopyflxSeparator0e39b3a3294d244.add();
            flxAckHeader.add(lblAcknowledgement, CopyflxSeparator0e39b3a3294d244);
            var flxLeftContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "270dp",
                "id": "flxLeftContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContent.setDefaultUnit(kony.flex.DP);
            var flxMsg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMsg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "32dp",
                "width": "78%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMsg.setDefaultUnit(kony.flex.DP);
            var lblMsg = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblMsg",
                "isVisible": true,
                "left": 0,
                "skin": "ICSknlbl424242SSP24px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.mortgageAccount.RepaymentDaySucessMessage\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMsg.add(lblMsg);
            var imgGreenTick = new kony.ui.Image2({
                "centerX": "50%",
                "height": "70dp",
                "id": "imgGreenTick",
                "isVisible": true,
                "left": "0",
                "src": "confirmation_tick.png",
                "top": "109dp",
                "width": "70dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceID = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblReferenceID",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP72727220Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.ReferenceId\")",
                "top": "192dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceValue = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblReferenceValue",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabel42424224px",
                "text": "45423792753",
                "top": 214,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftContent.add(flxMsg, imgGreenTick, lblReferenceID, lblReferenceValue);
            flxLeft.add(flxAckHeader, flxLeftContent);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxFacilityDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0ba61b247ab7b42",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityDetails.setDefaultUnit(kony.flex.DP);
            var flxFacilityHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxFacilityHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityHeader.setDefaultUnit(kony.flex.DP);
            var lblFacilityDetails = new kony.ui.Label({
                "id": "lblFacilityDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.displayMortgageFacilityDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            flxFacilityHeader.add(lblFacilityDetails, flxSeparator2);
            var flxFacilityContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "270dp",
                "id": "flxFacilityContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": 50,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityContent.setDefaultUnit(kony.flex.DP);
            var lblFacilityName = new kony.ui.Label({
                "id": "lblFacilityName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.FacilityNameWithColon\")",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityNameVal = new kony.ui.Label({
                "id": "lblFacilityNameVal",
                "isVisible": true,
                "left": "296dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Mortgage Facility Account - 1234 ",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoans = new kony.ui.Label({
                "id": "lblNoOfLoans",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.NoOfLoansWithColon\")",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoansVal = new kony.ui.Label({
                "id": "lblNoOfLoansVal",
                "isVisible": true,
                "left": "296dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "2",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentOutstandingBal = new kony.ui.Label({
                "id": "lblCurrentOutstandingBal",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.CurrentOutstandingBalanceWithColon\")",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentOutstandingBalVal = new kony.ui.Label({
                "id": "lblCurrentOutstandingBalVal",
                "isVisible": true,
                "left": "296dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$38,000.00",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentMaturityDate = new kony.ui.Label({
                "id": "lblCurrentMaturityDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.CurrentMaturityDateWithColon\")",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentMaturityDateVal = new kony.ui.Label({
                "id": "lblCurrentMaturityDateVal",
                "isVisible": true,
                "left": "296dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/01/2030",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFacilityContent.add(lblFacilityName, lblFacilityNameVal, lblNoOfLoans, lblNoOfLoansVal, lblCurrentOutstandingBal, lblCurrentOutstandingBalVal, lblCurrentMaturityDate, lblCurrentMaturityDateVal);
            flxFacilityDetails.add(flxFacilityHeader, flxFacilityContent);
            flxRight.add(flxFacilityDetails);
            var flxLoanPlanDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLoanPlanDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanPlanDetails.setDefaultUnit(kony.flex.DP);
            var flxLoanPlanHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLoanPlanHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanPlanHeader.setDefaultUnit(kony.flex.DP);
            var lblLoanPlanDetails = new kony.ui.Label({
                "id": "lblLoanPlanDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.LoanPlanDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            flxLoanPlanHeader.add(lblLoanPlanDetails, flxSeparator3);
            var segLoanPlanDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "groupCells": false,
                "height": "240dp",
                "id": "segLoanPlanDetails",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoanPlanDetails.add(flxLoanPlanHeader, segLoanPlanDetails);
            var flxDisclaimer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDisclaimer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7Border9797971pxRadius3px",
                "top": "5dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisclaimer.setDefaultUnit(kony.flex.DP);
            var rtxDisclaimer = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": " <p style=\"line-height:200%;\"><b>Disclaimer:</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes.</style></p>"
                },
                "bottom": "2dp",
                "id": "rtxDisclaimer",
                "isVisible": true,
                "left": "1%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:200%;\"><b>Disclaimer:</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes.</style></p>",
                "top": "10px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisclaimer.add(rtxDisclaimer);
            var btnBackBottom = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")"
                },
                "focusSkin": "slButtonGlossRed",
                "height": "50px",
                "id": "btnBackBottom",
                "isVisible": false,
                "left": "79dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.BACK\")",
                "top": "40dp",
                "width": "14.60%",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back"
            });
            var flxBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": true,
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "84%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var lblCopyRight = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Kony Bank Pvt. Ltd. Copyright 2017. All rightes reserved."
                },
                "id": "lblCopyRight",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab1\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Page 1 of 1"
                },
                "id": "lblPage",
                "isVisible": false,
                "right": "0%",
                "skin": "sknlbl424242bold15px",
                "text": "Page 1 of 1",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBottom.add(lblCopyRight, lblPage);
            flxPrintAcknowledge.add(flxHeader, btnBack, lblMyCheckingAccount, flxLeft, flxRight, flxLoanPlanDetails, flxDisclaimer, btnBackBottom, flxBottom);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxPrintAcknowledge": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxPrintAcknowledge": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxPrintAcknowledge": {
                        "width": {
                            "type": "string",
                            "value": "1250px"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "i18n_text": "i18n.common.back",
                        "isVisible": false,
                        "text": "< Back",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgement": {
                        "i18n_text": "i18n.transfers.Acknowledgement",
                        "text": "Acknowledgement",
                        "segmentProps": []
                    },
                    "lblMsg": {
                        "i18n_text": "i18n.mortgageAccount.RepaymentDaySucessMessage",
                        "text": "You have successfully submitted the change repayment day request",
                        "segmentProps": []
                    },
                    "lblReferenceID": {
                        "i18n_text": "i18n.konybb.common.ReferenceId",
                        "text": "Reference ID",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "lblFacilityDetails": {
                        "i18n_text": "i18n.accounts.displayMortgageFacilityDetails",
                        "text": "Mortgage Facility Details",
                        "segmentProps": []
                    },
                    "lblFacilityName": {
                        "i18n_text": "i18n.accounts.FacilityNameWithColon",
                        "segmentProps": []
                    },
                    "lblNoOfLoans": {
                        "i18n_text": "i18n.accounts.NoOfLoansWithColon",
                        "segmentProps": []
                    },
                    "lblCurrentOutstandingBal": {
                        "i18n_text": "i18n.accounts.CurrentOutstandingBalanceWithColon",
                        "segmentProps": []
                    },
                    "lblCurrentMaturityDate": {
                        "i18n_text": "i18n.accounts.CurrentMaturityDateWithColon",
                        "segmentProps": []
                    },
                    "flxLoanPlanDetails": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "84%"
                        },
                        "segmentProps": []
                    },
                    "lblLoanPlanDetails": {
                        "i18n_text": "i18n.accounts.LoanPlanDetails",
                        "text": "Loan Plan Details",
                        "segmentProps": []
                    },
                    "segLoanPlanDetails": {
                        "data": [
                            [{
                                    "lblLoans": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblNextInstallment": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblRepaymentDayNew": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                },
                                [{
                                    "lblLoanName": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblNextInstallment": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    },
                                    "lblRepaymentDayNV": {
                                        "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                        "text": ""
                                    }
                                }]
                            ]
                        ],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxLoanPlan"
                        }),
                        "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "ArrangementsMA",
                            "friendlyName": "flxLoanPlanHeader"
                        }),
                        "widgetDataMap": {
                            "flxContent": "flxContent",
                            "flxLoanPlan": "flxLoanPlan",
                            "flxLoanPlanHeader": "flxLoanPlanHeader",
                            "flxSeparator": "flxSeparator",
                            "flxSeparator2": "flxSeparator2",
                            "lblLoanName": "lblLoanName",
                            "lblLoans": "lblLoans",
                            "lblNextInstallment": "lblNextInstallment",
                            "lblRepaymentDayNV": "lblRepaymentDayNV",
                            "lblRepaymentDayNew": "lblRepaymentDayNew"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "ArrangementsMA"
                    }
                }
            }
            this.compInstData = {}
            this.add(flxPrintAcknowledge);
        };
        return [{
            "addWidgets": addWidgetsfrmPrintAcknowledge,
            "enabledForIdleTimeout": false,
            "id": "frmPrintAcknowledge",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_fb27401063d244ce8c1b65625b727ed9,
            "preShow": function(eventobject) {
                controller.AS_Form_a2c2d5308f7c48ef871b3ab0178276a0(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});