define("PortfolioManagementMA/WealthPortfolioUIModule/frmPortfolioOverview", function() {
    return function(controller) {
        function addWidgetsfrmPortfolioOverview() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.hamburger.myaccounts\")",
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMain1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain1.setDefaultUnit(kony.flex.DP);
            var flxSuccessMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50.03%",
                "clipBounds": false,
                "id": "flxSuccessMessage",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuccessMessage.setDefaultUnit(kony.flex.DP);
            var GenericMessageNew = new com.InfinityOLB.Transfers.GenericMessageNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "GenericMessageNew",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "TransfersMA",
                "viewType": "GenericMessageNew",
                "overrides": {
                    "GenericMessageNew": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var GenericMessageNew_data = (appConfig.componentMetadata && appConfig.componentMetadata["TransfersMA"] && appConfig.componentMetadata["TransfersMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["TransfersMA"]["frmPortfolioOverview"]["GenericMessageNew"]) || {};
            GenericMessageNew.dataMapping = GenericMessageNew_data.dataMapping || {
                "genMsg": "{$.collectionObj.genericMessage}",
                "messageDetails": "{$.collectionObj.message}",
                "successMsg": "{$.collectionObj.genericSuccessMessage}",
                "maxLength": "3",
                "messageType": "{$.collectionObj.messageType}",
                "lblSuccess": "${i18n{kony.i18n.common.cancelledSuccessfully}}"
            };
            flxSuccessMessage.add(GenericMessageNew);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true
                },
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")"
                },
                "bottom": "8dp",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "80dp",
                "right": "50dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "8dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "height": "40dp",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknImgPointer",
                "src": "bbcloseicon.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            var flxPrimaryDetailsRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxPrimaryDetailsRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryDetailsRow.setDefaultUnit(kony.flex.DP);
            var flxTopContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72dp",
                "id": "flxTopContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "isModalContainer": false,
                "top": "10dp",
                "width": "88%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopContainer.setDefaultUnit(kony.flex.DP);
            var flxBackToDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "24dp",
                "id": "flxBackToDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBackToDashboard.setDefaultUnit(kony.flex.DP);
            var lblLeftArrowIcon = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblLeftArrowIcon",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknlblOLBFontsE3E3E320pxOlbFontIcons",
                "text": "R",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgLeftArrow = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgLeftArrow",
                "isVisible": true,
                "left": "0",
                "src": "arrow_left.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBackToDashboard = new kony.ui.Label({
                "id": "lblBackToDashboard",
                "isVisible": true,
                "left": "8dp",
                "skin": "sknLblSSP004BB115Px",
                "top": "2dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackToDashboard.add(lblLeftArrowIcon, imgLeftArrow, lblBackToDashboard);
            var lblHeading = new kony.ui.Label({
                "id": "lblHeading",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabel42424224pxSemiBold",
                "text": "Portfolio Details",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopContainer.add(flxBackToDashboard, lblHeading);
            var flxAccountTypesAndInfo = new kony.ui.FlexContainer({
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAccountTypesAndInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "19%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountTypesAndInfo.setDefaultUnit(kony.flex.DP);
            var flxAccountTypes = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "bottom": "10dp",
                "clipBounds": true,
                "focusSkin": "flxHoverSkinPointer",
                "height": "100%",
                "id": "flxAccountTypes",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0px",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "flxHoverSkinPointer"
            });
            flxAccountTypes.setDefaultUnit(kony.flex.DP);
            var flxImgAccountTypeIcon = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "20px",
                "id": "flxImgAccountTypeIcon",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0px",
                "isModalContainer": false,
                "right": "20px",
                "skin": "slFbox",
                "top": "0dp",
                "width": "20px",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgAccountTypeIcon.setDefaultUnit(kony.flex.DP);
            var imgAccountTypeIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgAccountTypeIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblOLBFontIcons003E7512pxbordere3e3e3",
                "text": "s",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            flxImgAccountTypeIcon.add(imgAccountTypeIcon);
            var lblAccountTypes = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.AccountsDetails.MyCheckingAccount3254\")"
                },
                "centerY": "50%",
                "id": "lblAccountTypes",
                "isVisible": true,
                "left": "0px",
                "skin": "sknLabelSSP0273e315px",
                "text": "Investment Account...3254",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            var imgAccountTypes = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Account Types"
                },
                "centerY": "50%",
                "height": "16dp",
                "id": "imgAccountTypes",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "14dp",
                "skin": "sknImgPointer",
                "src": "arrow_down_1.png",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Type"
            });
            flxAccountTypes.add(flxImgAccountTypeIcon, lblAccountTypes, imgAccountTypes);
            var btnViewAccountInfo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.accounts.viewAccountInfo\")"
                },
                "centerY": "50%",
                "id": "btnViewAccountInfo",
                "isVisible": false,
                "left": "20dp",
                "skin": "sknBtnSSP3343a813px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.viewAccountInfo\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View Account Info"
            });
            flxAccountTypesAndInfo.add(flxAccountTypes, btnViewAccountInfo);
            var flxLeftContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "85dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "58%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContainer.setDefaultUnit(kony.flex.DP);
            var flxPortfolio = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPortfolio",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i527f59b287e40bd849cd109892d4432,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "28.48%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPortfolio.setDefaultUnit(kony.flex.DP);
            var investmentSummary = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "investmentSummary",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            investmentSummary.setDefaultUnit(kony.flex.DP);
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var btnTab1 = new kony.ui.Button({
                "centerY": "50%",
                "height": "100%",
                "id": "btnTab1",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknBtnSSP42424217PxSelectedTab",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.portfolioSummary\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var btnTab2 = new kony.ui.Button({
                "centerY": "50%",
                "height": "100%",
                "id": "btnTab2",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknBtnSSP72727217PxUnSelectedTab",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.accountInfo\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxTitle.add(btnTab1, btnTab2);
            var flxSeparatorInvestment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 1,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorInvestment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorInvestment.setDefaultUnit(kony.flex.DP);
            flxSeparatorInvestment.add();
            var flxAccountInfoValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxAccountInfoValues",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountInfoValues.setDefaultUnit(kony.flex.DP);
            var flxAccountInfoHorizontal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": true,
                "id": "flxAccountInfoHorizontal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountInfoHorizontal.setDefaultUnit(kony.flex.DP);
            var flxPrimaryAccount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrimaryAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryAccount.setDefaultUnit(kony.flex.DP);
            var lblAccountNumber = new kony.ui.Label({
                "id": "lblAccountNumber",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknSSP72727215Pxspending",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.AccountNumber\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPrimaryHolder = new kony.ui.Label({
                "id": "lblPrimaryHolder",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknSSP72727215Pxspending",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.primaryHolder\")",
                "top": "40dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPrimaryHolderValue = new kony.ui.Label({
                "id": "lblPrimaryHolderValue",
                "isVisible": true,
                "left": "180dp",
                "skin": "sknlbl42424215px",
                "text": "Carrie Bryan",
                "top": "40dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxGGroupp = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxGGroupp",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGGroupp.setDefaultUnit(kony.flex.DP);
            var lblAccountNumberValue = new kony.ui.Label({
                "id": "lblAccountNumberValue",
                "isVisible": true,
                "left": "180dp",
                "skin": "sknlbl42424215px",
                "text": "XXXXXXXXXX1234",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgAccountNumber = new kony.ui.Image2({
                "height": "15dp",
                "id": "imgAccountNumber",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "eye_show.png",
                "top": "13dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGGroupp.add(lblAccountNumberValue, imgAccountNumber);
            flxPrimaryAccount.add(lblAccountNumber, lblPrimaryHolder, lblPrimaryHolderValue, flxGGroupp);
            var flxJointAccount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxJointAccount",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "45%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxJointAccount.setDefaultUnit(kony.flex.DP);
            var segmentJointHolders = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblJointAccLabel": "Joint Holder 1:",
                    "lblJointAccName": "David Bryan"
                }, {
                    "lblJointAccLabel": "Joint Holder 2:",
                    "lblJointAccName": "Luka Bryan "
                }, {
                    "lblJointAccLabel": "Joint Holder 3:",
                    "lblJointAccName": "Rose Bryan"
                }],
                "groupCells": false,
                "id": "segmentJointHolders",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "PortfolioManagementMA",
                    "friendlyName": "flxJointHolders"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "ffffff00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxJointAcc": "flxJointAcc",
                    "flxJointAccName": "flxJointAccName",
                    "flxJointHolders": "flxJointHolders",
                    "flxJointList": "flxJointList",
                    "lblJointAccLabel": "lblJointAccLabel",
                    "lblJointAccName": "lblJointAccName"
                },
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxJointAccount.add(segmentJointHolders);
            flxAccountInfoHorizontal.add(flxPrimaryAccount, flxJointAccount);
            flxAccountInfoValues.add(flxAccountInfoHorizontal);
            var flxSeparator3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 1,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator3",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": 20,
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator3.setDefaultUnit(kony.flex.DP);
            flxSeparator3.add();
            var flxGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroup.setDefaultUnit(kony.flex.DP);
            var flxPortofolioValues = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "80dp",
                "id": "flxPortofolioValues",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPortofolioValues.setDefaultUnit(kony.flex.DP);
            var flxMarketValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxMarketValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 20,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "zIndex": 3,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMarketValue.setDefaultUnit(kony.flex.DP);
            var lblMarketValue = new kony.ui.Label({
                "id": "lblMarketValue",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknSSP72727215Pxspending",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.totalValue\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblValueMarketValue = new kony.ui.Label({
                "id": "lblValueMarketValue",
                "isVisible": true,
                "left": "10dp",
                "skin": "IWLabelTitleAccountBalance",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMarketValue.add(lblMarketValue, lblValueMarketValue);
            var lblVerticalSepeartor = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "a"
                },
                "centerY": "50%",
                "height": "50dp",
                "id": "lblVerticalSepeartor",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblBge3e3e3op100",
                "text": "a",
                "top": "0dp",
                "width": "1dp",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxProfitLoss = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxProfitLoss",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxProfitLoss.setDefaultUnit(kony.flex.DP);
            var flxUnrealisedPL = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "30dp",
                "id": "flxUnrealisedPL",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUnrealisedPL.setDefaultUnit(kony.flex.DP);
            var lbllUnrealisedPL = new kony.ui.Label({
                "centerY": "50%",
                "id": "lbllUnrealisedPL",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP72727215Pxspending",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.unrealizedPLColon\")",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUnrealisedPLValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblUnrealisedPLValue",
                "isVisible": true,
                "left": "140dp",
                "skin": "sknIW2F8523",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUnrealisedPL.add(lbllUnrealisedPL, lblUnrealisedPLValue);
            var flxTodayPL = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTodayPL",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTodayPL.setDefaultUnit(kony.flex.DP);
            var lblTodayPL = new kony.ui.Label({
                "centerY": "50%",
                "height": "30dp",
                "id": "lblTodayPL",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSSP72727215Pxspending",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTodayPLValue = new kony.ui.Label({
                "centerY": "50%",
                "height": "30dp",
                "id": "lblTodayPLValue",
                "isVisible": true,
                "left": "140dp",
                "skin": "sknIW2F8523",
                "top": "1dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTodayPL.add(lblTodayPL, lblTodayPLValue);
            flxProfitLoss.add(flxUnrealisedPL, flxTodayPL);
            flxPortofolioValues.add(flxMarketValue, lblVerticalSepeartor, flxProfitLoss);
            var flxSeparator2 = new kony.ui.FlexContainer({
                "bottom": 1,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxdee0e2",
                "top": 0,
                "width": "1dp",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            var flxPortofolioLineChart = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "350dp",
                "id": "flxPortofolioLineChart",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "200dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPortofolioLineChart.setDefaultUnit(kony.flex.DP);
            var investmentLineChart = new com.InfinityOLB.PortfolioManagementMA.investmentLineChart({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "investmentLineChart",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA",
                "viewType": "investmentLineChart",
                "overrides": {
                    "investmentLineChart": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var investmentLineChart_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"]["investmentLineChart"]) || {};
            investmentLineChart.currencySymbol = investmentLineChart_data.currencySymbol || "$";
            investmentLineChart.currentFilter = investmentLineChart_data.currentFilter || "1Y";
            investmentLineChart.date1 = investmentLineChart_data.date1 || "1M";
            investmentLineChart.date2 = investmentLineChart_data.date2 || "1Y";
            investmentLineChart.date3 = investmentLineChart_data.date3 || "5Y";
            investmentLineChart.date4 = investmentLineChart_data.date4 || "YTD";
            flxPortofolioLineChart.add(investmentLineChart);
            flxGroup.add(flxPortofolioValues, flxSeparator2, flxPortofolioLineChart);
            investmentSummary.add(flxTitle, flxSeparatorInvestment, flxAccountInfoValues, flxSeparator3, flxGroup);
            flxPortfolio.add(investmentSummary);
            var flxCashCard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCashCard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0.00%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i527f59b287e40bd849cd109892d4432,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashCard.setDefaultUnit(kony.flex.DP);
            var flxCashBalList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxCashBalList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointerIW",
                "top": "12dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashBalList.setDefaultUnit(kony.flex.DP);
            var flxCashBal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCashBal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCashBal.setDefaultUnit(kony.flex.DP);
            var lblAccountName = new kony.ui.Label({
                "id": "lblAccountName",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl727272SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.cashBalance\")",
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountVal = new kony.ui.Label({
                "id": "lblAccountVal",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP17pxSemibold",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCashBal.add(lblAccountName, lblAccountVal);
            var flxAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "flxHoverSkinPointer",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var lblConvertCurrency = new kony.ui.Label({
                "id": "lblConvertCurrency",
                "isVisible": true,
                "left": "0dp",
                "onTouchEnd": controller.AS_Label_f94461d4896c462ea626b26be4eeceaf,
                "right": "20dp",
                "skin": "sknSSP4176a415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.ConvertCurrency\")",
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTransferCash = new kony.ui.Label({
                "id": "lblTransferCash",
                "isVisible": true,
                "left": "20dp",
                "right": "20dp",
                "skin": "sknSSP4176a415px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.TransferCash\")",
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmount.add(lblConvertCurrency, lblTransferCash);
            flxCashBalList.add(flxCashBal, flxAmount);
            var lblSep = new kony.ui.Label({
                "height": "13dp",
                "id": "lblSep",
                "isVisible": true,
                "left": "20dp",
                "skin": "slLabel",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator1 = new kony.ui.Label({
                "height": "1dp",
                "id": "lblSeparator1",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLble3e3e3",
                "top": "12dp",
                "width": "95%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segmentCashBal = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblBalAmount": "",
                    "lblCashAccountName": "",
                    "lblRerfCashAmount": "",
                    "lblSeparator1": "",
                    "lblVertical": ""
                }],
                "groupCells": false,
                "id": "segmentCashBal",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "PortfolioManagementMA",
                    "friendlyName": "flxCashBalance"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccList": "flxAccList",
                    "flxCashAmount": "flxCashAmount",
                    "flxCashBalAcc": "flxCashBalAcc",
                    "flxCashBalance": "flxCashBalance",
                    "lblBalAmount": "lblBalAmount",
                    "lblCashAccountName": "lblCashAccountName",
                    "lblRerfCashAmount": "lblRerfCashAmount",
                    "lblSeparator1": "lblSeparator1",
                    "lblVertical": "lblVertical"
                },
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCashCard.add(flxCashBalList, lblSep, lblSeparator1, segmentCashBal);
            flxLeftContainer.add(flxPortfolio, flxCashCard);
            var flxRightContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRightContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "reverseLayoutDirection": false,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "60dp",
                "width": "28.60%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainer.setDefaultUnit(kony.flex.DP);
            var flxInstrument = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInstrument",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.10%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i527f59b287e40bd849cd109892d4432,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "40dp",
                "width": "28.48%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInstrument.setDefaultUnit(kony.flex.DP);
            var flxTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16px",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTop.setDefaultUnit(kony.flex.DP);
            var lblInstrument = new kony.ui.Label({
                "id": "lblInstrument",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.instruments\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnViewFavorite = new kony.ui.Button({
                "focusSkin": "bbSknBtn4176a4NoBorder",
                "id": "btnViewFavorite",
                "isVisible": true,
                "right": "20dp",
                "skin": "bbSknBtn4176a4NoBorder",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.viewWatchlist\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTop.add(lblInstrument, btnViewFavorite);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "16dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var instrumentSearch = new com.InfinityOLB.PortfolioManagementMA.instrumentSearch({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "id": "instrumentSearch",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "98%",
                "appName": "PortfolioManagementMA",
                "viewType": "instrumentSearch",
                "overrides": {
                    "instrumentSearch": {
                        "right": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var instrumentSearch_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"]["instrumentSearch"]) || {};
            instrumentSearch.isComponentEnabled = instrumentSearch_data.isComponentEnabled || true;
            instrumentSearch.searchPlaceholder = instrumentSearch_data.searchPlaceholder || "\"{i.i18n.wealth.instrumentSearch}\"";
            instrumentSearch.sknSearchTextBoxNormal = instrumentSearch_data.sknSearchTextBoxNormal || "{\"$.BREAKPTS.BP1\":\"ICSknFlxffffffBordere3e3e31pxRadius2px\",\"default\":\"ICSknFlxffffffBordere3e3e31pxRadius3px\"}";
            instrumentSearch.isSearchEnabled = instrumentSearch_data.isSearchEnabled || true;
            instrumentSearch.sknSearchPlaceHolder = instrumentSearch_data.sknSearchPlaceHolder || "{\"$.BREAKPTS.BP1\":\"ICSknTbxPlaceholderSSP72727213px\",\"default\":\"ICSknTbxPlaceholderSSP72727215px\"}";
            instrumentSearch.segObjService = instrumentSearch_data.segObjService || "WealthOrder";
            instrumentSearch.sknSearchText = instrumentSearch_data.sknSearchText || "{\"$.BREAKPTS.BP1\":\"ICSknTbxSSP42424213px\",\"default\":\"ICSknTbxSSP42424215px\"}";
            instrumentSearch.isSegmentEnabled = instrumentSearch_data.isSegmentEnabled || true;
            instrumentSearch.segObjName = instrumentSearch_data.segObjName || "InstrumentDetails";
            instrumentSearch.sknSearchTextBoxFocus = instrumentSearch_data.sknSearchTextBoxFocus || "{\"$.BREAKPTS.BP1\":\"ICSknFlxffffffBorder003e751pxRadius2px\",\"default\":\"ICSknFlxffffffBorder003e751pxRadius3px\"}";
            instrumentSearch.segOperation = instrumentSearch_data.segOperation || "getInstrumentList";
            instrumentSearch.segCriteria = instrumentSearch_data.segCriteria || "{\"portfolioId\":\"{$.c.portfolioId}\",  \"sortBy\":\"{$.c.sortBy}\",   \"searchByInstrumentName\":\"{$.c.searchByInstrumentName}\"}";
            instrumentSearch.iconSearch = instrumentSearch_data.iconSearch || "{\"vizIcon\": \"e\",\"skin\":\"sknlblSearchfonticon17px0273e3\"}";
            instrumentSearch.iconClear = instrumentSearch_data.iconClear || "{\"vizIcon\": \"J\",\"skin\":\"ICSknLblClearFontIcona0a0a016px\"}";
            instrumentSearch.segIdentifier = instrumentSearch_data.segIdentifier || "S1";
            instrumentSearch.segResponseArray = instrumentSearch_data.segResponseArray || "{$.S1.instrumentList}";
            instrumentSearch.segResponseId = instrumentSearch_data.segResponseId || "L1";
            instrumentSearch.segFields = instrumentSearch_data.segFields || "{    \"One\":{       \"value\":\"description\",       \"type\":\"text\",       \"displayName\":\"\",       \"default\":\"true\"    }, \"Two\":{       \"value\":\"ISIN\",       \"type\":\"text\",       \"displayName\":\"\",       \"default\":\"true\"    }, \"One\":{       \"value\":\"holdingsType\",       \"type\":\"text\",       \"displayName\":\"\",       \"default\":\"true\"    }    }";
            instrumentSearch.sknSearchBackground = instrumentSearch_data.sknSearchBackground || "{\"$.BREAKPTS.BP1\":\"ICSknFlxf7f7f7\",\"default\":\"ICSknFlxffffff\"}";
            flxInstrument.add(flxTop, flxSeparator, instrumentSearch);
            var flxAsset = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAsset",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.10%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i527f59b287e40bd849cd109892d4432,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "15dp",
                "width": "28.48%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAsset.setDefaultUnit(kony.flex.DP);
            var totalAssets = new com.InfinityOLB.PortfolioManagementMA.totalAssets({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "totalAssets",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA",
                "viewType": "totalAssets",
                "overrides": {
                    "totalAssets": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var totalAssets_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"]["totalAssets"]) || {};
            totalAssets.StrokeColors = totalAssets_data.StrokeColors || {
                "data": [{
                    "Colors": "#0475C4"
                }, {
                    "Colors": "#43A2CA"
                }, {
                    "Colors": "#7BCCC4"
                }, {
                    "Colors": "#BAE4BC"
                }, {
                    "Colors": "#E9FED4"
                }, {
                    "Colors": "#E55845"
                }, {
                    "Colors": "#E48444"
                }, {
                    "Colors": "#E8DD46"
                }, {
                    "Colors": "#54D75D"
                }, {
                    "Colors": "#04C477"
                }],
                "schema": [{
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Colors",
                    "columnHeaderType": "text",
                    "columnID": "Colors",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "ff9f31d8746f437c8dd204be1c17e71b"
                }]
            };
            totalAssets.TooltipValues = totalAssets_data.TooltipValues || "assetClass, percentage, marketValue";
            totalAssets.LayoutType = totalAssets_data.LayoutType || "vertical";
            totalAssets.Title = totalAssets_data.Title || "Asset Allocation";
            flxAsset.add(totalAssets);
            var flxAssetAllocation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssetAllocation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssetAllocation.setDefaultUnit(kony.flex.DP);
            var assetAllocation = new com.Infinity.OLB.PortfolioManagementMA.assetAllocation({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "assetAllocation",
                "isVisible": true,
                "left": 0,
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknFlxffffffB",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "viewType": "assetAllocation",
                "overrides": {
                    "assetAllocation": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var assetAllocation_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"]["assetAllocation"]) || {};
            flxAssetAllocation.add(assetAllocation);
            flxRightContainer.add(flxInstrument, flxAsset, flxAssetAllocation);
            flxPrimaryDetailsRow.add(flxTopContainer, flxAccountTypesAndInfo, flxLeftContainer, flxRightContainer);
            var flxAdvisoryMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAdvisoryMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvisoryMain.setDefaultUnit(kony.flex.DP);
            var flxAdvisoryDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAdvisoryDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAdvisoryDetails.setDefaultUnit(kony.flex.DP);
            var flxHealthCheck = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "440dp",
                "id": "flxHealthCheck",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1.10%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i527f59b287e40bd849cd109892d4432,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": 0,
                "width": "50%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHealthCheck.setDefaultUnit(kony.flex.DP);
            var PortfolioHealthCheck = new com.InfinityOLB.PortfolioManagementMA.PortfolioHealthCheck({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "PortfolioHealthCheck",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "viewType": "PortfolioHealthCheck",
                "overrides": {
                    "PortfolioHealthCheck": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var PortfolioHealthCheck_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"]["PortfolioHealthCheck"]) || {};
            PortfolioHealthCheck.serviceCall = PortfolioHealthCheck_data.serviceCall || {
                "ObjectName": "PortfolioHealth",
                "ServiceName": "PortfolioServicing",
                "OperationName": "getPortfolioHealth"
            };
            flxHealthCheck.add(PortfolioHealthCheck);
            var flxStrategy = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxStrategy",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "15dp",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStrategy.setDefaultUnit(kony.flex.DP);
            var myStrategyDetails = new com.Infinity.OLB.PortfolioManagementMA.myStrategyDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "myStrategyDetails",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "viewType": "myStrategyDetails",
                "overrides": {
                    "myStrategyDetails": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var myStrategyDetails_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"]["myStrategyDetails"]) || {};
            flxStrategy.add(myStrategyDetails);
            flxAdvisoryDetails.add(flxHealthCheck, flxStrategy);
            var flxReviewProposal = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "440dp",
                "id": "flxReviewProposal",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "15dp",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_i527f59b287e40bd849cd109892d4432,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": 0,
                "width": "50%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxReviewProposal.setDefaultUnit(kony.flex.DP);
            var investmentProposal = new com.InfinityOLB.PortfolioManagementMA.investmentProposal({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "investmentProposal",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "overrides": {
                    "flxMainNewAdvice": {
                        "isVisible": true
                    },
                    "flxMainNoAdvice": {
                        "isVisible": false
                    },
                    "flxinfo": {
                        "left": "0dp"
                    },
                    "imgAdvice": {
                        "src": "imgnewadvice.png"
                    },
                    "imgInfo": {
                        "centerY": "50%",
                        "left": "6dp",
                        "src": "group_10_copy_4.png"
                    },
                    "imgNoAdvInfo": {
                        "src": "group_10_copy_4.png"
                    },
                    "imgNoNewAdvice": {
                        "src": "imgnewadvice.png"
                    },
                    "lblInvestmentProposal": {
                        "left": "20dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxReviewProposal.add(investmentProposal);
            flxAdvisoryMain.add(flxAdvisoryDetails, flxReviewProposal);
            var flxNewUser = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxNewUser",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewUser.setDefaultUnit(kony.flex.DP);
            var defineStrategy = new com.Infinity.OLB.PortfolioManagementMA.defineStrategy({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "defineStrategy",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "viewType": "defineStrategy",
                "overrides": {
                    "defineStrategy": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var defineStrategy_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"]["defineStrategy"]) || {};
            flxNewUser.add(defineStrategy);
            var flxSecondaryDetailsRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxSecondaryDetailsRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecondaryDetailsRow.setDefaultUnit(kony.flex.DP);
            var flxComponent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "blur": {
                    "enabled": false,
                    "value": 0
                },
                "clipBounds": false,
                "id": "flxComponent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxComponent.setDefaultUnit(kony.flex.DP);
            var lblPortfolio = new kony.ui.Label({
                "bottom": "20dp",
                "id": "lblPortfolio",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.portfolioDetails\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var portfolioDetails = new com.InfinityOLB.PortfolioManagementMA.portfolioDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "portfolioDetails",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA",
                "viewType": "portfolioDetails",
                "overrides": {
                    "portfolioDetails": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var portfolioDetails_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"]["portfolioDetails"]) || {};
            portfolioDetails.sknFilterActiveTab = portfolioDetails_data.sknFilterActiveTab || "sknBtnSSP42424217PxSelectedTab";
            portfolioDetails.searchLabel1 = portfolioDetails_data.searchLabel1 || "\"{i.i18n.wealth.byKeywordsWithColon}\"";
            portfolioDetails.iconSearch = portfolioDetails_data.iconSearch || "{\"img\": \"search.png\"}";
            portfolioDetails.amountFormat = portfolioDetails_data.amountFormat || "{ \"locale\":\"\", \"positiveFormat\" : \"{CS}{D}\", \"negativeFormat\" : \"-{CS}{D}\", \"fractionDigits\":\"2\"}";
            portfolioDetails.tabOneName = portfolioDetails_data.tabOneName || "\"{i.i18n.wealth.holdings}\"";
            portfolioDetails.tabTwoName = portfolioDetails_data.tabTwoName || "\"{i.i18n.common.transactions}\"";
            portfolioDetails.tabThreeName = portfolioDetails_data.tabThreeName || "\"{i.i18n.wealth.orders}\"";
            portfolioDetails.tabFourName = portfolioDetails_data.tabFourName || "\"{i.i18n.wealth.accountsActivity}\"";
            portfolioDetails.tabFiveName = portfolioDetails_data.tabFiveName || "\"{i.i18n.wealth.performance}\"";
            portfolioDetails.tabSixName = portfolioDetails_data.tabSixName || "\"{i.i18n.wealth.reports}\"";
            portfolioDetails.startDate = portfolioDetails_data.startDate || "";
            portfolioDetails.tabThreeAObjService = portfolioDetails_data.tabThreeAObjService || "PortfolioServicing";
            portfolioDetails.settingsObjService = portfolioDetails_data.settingsObjService || "PortfolioServicing";
            portfolioDetails.lstbxObjService = portfolioDetails_data.lstbxObjService || "PortfolioServicing";
            portfolioDetails.cancelReqObjService = portfolioDetails_data.cancelReqObjService || "WealthOrder";
            portfolioDetails.getReportObjService = portfolioDetails_data.getReportObjService || "PortfolioServicing";
            portfolioDetails.downloadReportObjService = portfolioDetails_data.downloadReportObjService || "PortfolioServicing";
            portfolioDetails.sknFilterActiveTabHover = portfolioDetails_data.sknFilterActiveTabHover || "sknBtnSSP42424217PxSelectedTabHover";
            portfolioDetails.iconDownload = portfolioDetails_data.iconDownload || "{\"img\": \"download_blue.png\"}";
            portfolioDetails.dateFormat = portfolioDetails_data.dateFormat || "m/d/Y";
            portfolioDetails.GAobjectServiceName = portfolioDetails_data.GAobjectServiceName || "PortfolioServicing";
            portfolioDetails.tabOneOptions = portfolioDetails_data.tabOneOptions || "AllTheOptions";
            portfolioDetails.tabTwoOptions = portfolioDetails_data.tabTwoOptions || "PrintAndDownload";
            portfolioDetails.tabThreeOptions = portfolioDetails_data.tabThreeOptions || "PrintAndDownload";
            portfolioDetails.tabFourOptions = portfolioDetails_data.tabFourOptions || "PrintAndDownload";
            portfolioDetails.tabFiveOptions = portfolioDetails_data.tabFiveOptions || "PrintAndDownload";
            portfolioDetails.tabSixOptions = portfolioDetails_data.tabSixOptions || "None";
            portfolioDetails.endDate = portfolioDetails_data.endDate || "";
            portfolioDetails.tabThreeAObjName = portfolioDetails_data.tabThreeAObjName || "PortfolioDetails";
            portfolioDetails.settingsObjName = portfolioDetails_data.settingsObjName || "PortfolioDetails";
            portfolioDetails.lstbxObjName = portfolioDetails_data.lstbxObjName || "PortfolioDetails";
            portfolioDetails.cancelReqObjName = portfolioDetails_data.cancelReqObjName || "Order";
            portfolioDetails.getReportOperation = portfolioDetails_data.getReportOperation || "generatePDF";
            portfolioDetails.downloadReportObjName = portfolioDetails_data.downloadReportObjName || "Reports";
            portfolioDetails.tabThreeFilterOptions = portfolioDetails_data.tabThreeFilterOptions || "SearchOnly";
            portfolioDetails.sknFilterInactiveTab = portfolioDetails_data.sknFilterInactiveTab || "sknBtnSSP72727217PxUnSelectedTab";
            portfolioDetails.iconPrint = portfolioDetails_data.iconPrint || "{\"img\": \"print_blue.png\"}";
            portfolioDetails.backendDateFormat = portfolioDetails_data.backendDateFormat || "Y-m-d";
            portfolioDetails.GAobjectName = portfolioDetails_data.GAobjectName || "Reports";
            portfolioDetails.tabOneFilterOptions = portfolioDetails_data.tabOneFilterOptions || "SearchOnly";
            portfolioDetails.tabTwoFilterOptions = portfolioDetails_data.tabTwoFilterOptions || "SearchAndCalendar";
            portfolioDetails.tabFourFilterOptions = portfolioDetails_data.tabFourFilterOptions || "SearchAndListSelectionAndCalendar";
            portfolioDetails.tabFiveFilterOptions = portfolioDetails_data.tabFiveFilterOptions || "CalendarOnly";
            portfolioDetails.tabSixFilterOptions = portfolioDetails_data.tabSixFilterOptions || "None";
            portfolioDetails.tabThreeAOperation = portfolioDetails_data.tabThreeAOperation || "getOrdersDetails";
            portfolioDetails.settingsGetOperation = portfolioDetails_data.settingsGetOperation || "getFieldsOrder";
            portfolioDetails.lstbxOperation = portfolioDetails_data.lstbxOperation || "getCashAccounts";
            portfolioDetails.cancelReqOperation = portfolioDetails_data.cancelReqOperation || "cancelSecurityOrder";
            portfolioDetails.getReportObjName = portfolioDetails_data.getReportObjName || "Reports";
            portfolioDetails.downloadReportOperation = portfolioDetails_data.downloadReportOperation || "generatePDF";
            portfolioDetails.sknFilterInactiveTabHover = portfolioDetails_data.sknFilterInactiveTabHover || "sknBtnSSP72727217PxUnSelectedTabHover";
            portfolioDetails.iconSearchClose = portfolioDetails_data.iconSearchClose || "{\"img\": \"closewealth.png\"}";
            portfolioDetails.GAoperationName = portfolioDetails_data.GAoperationName || "generatePDF";
            portfolioDetails.tabOneRadioOptions = portfolioDetails_data.tabOneRadioOptions || false;
            portfolioDetails.tabTwoRadioOptions = portfolioDetails_data.tabTwoRadioOptions || false;
            portfolioDetails.tabThreeRadioOptions = portfolioDetails_data.tabThreeRadioOptions || true;
            portfolioDetails.tabFourRadioOptions = portfolioDetails_data.tabFourRadioOptions || false;
            portfolioDetails.tabFiveRadioOptions = portfolioDetails_data.tabFiveRadioOptions || false;
            portfolioDetails.tabSixRadioOptions = portfolioDetails_data.tabSixRadioOptions || false;
            portfolioDetails.lstbxCriteria = portfolioDetails_data.lstbxCriteria || "{ \"portfolioId\":\"{$.c.portfolioId}\"}";
            portfolioDetails.settingsUpdateOperation = portfolioDetails_data.settingsUpdateOperation || "updateFieldsOrder";
            portfolioDetails.tabThreeACriteria = portfolioDetails_data.tabThreeACriteria || "{  \"portfolioId\":\"{$.c.portfolioId}\",   \"navPage\":\"{$.c.navPage}\",   \"sortBy\":\"{$.c.sortBy}\",   \"searchByInstrumentName\":\"{$.c.searchByInstrumentName}\",   \"pageSize\":\"{$.c.pageSize}\", \"orderId\":\"{$.c.orderId}\"  , \"pageOffset\":\"{$.c.pageOffset}\", \"sortOrder\":\"{$.c.sortOrder}\", \"type\":\"{$.c.type}\",\"isEuro\":\"{$.c.isEuro}\",\"downloadFormat\":\"{$.c.downloadFormat}\"}";
            portfolioDetails.cancelReqCriteria = portfolioDetails_data.cancelReqCriteria || "{ \"portfolioId\":\"{$.c.portfolioId}\", \"orderId\":\"{$.c.orderId}\", \"assetType\":\"{$.c.assetType}\"}";
            portfolioDetails.getReportCriteria = portfolioDetails_data.getReportCriteria || "{ \"portfolioId\":\"{$.c.portfolioId}\", \"orderId\":\"{$.c.orderId}\"}";
            portfolioDetails.downloadReportCriteria = portfolioDetails_data.downloadReportCriteria || "{ \"portfolioId\":\"{$.c.portfolioId}\", \"orderId\":\"{$.c.orderId}\"}";
            portfolioDetails.tabOneObjService = portfolioDetails_data.tabOneObjService || "PortfolioServicing";
            portfolioDetails.searchLabel2 = portfolioDetails_data.searchLabel2 || "\"{i.i18n.wealth.cashAccountWithColon}\"";
            portfolioDetails.iconSettings = portfolioDetails_data.iconSettings || "{\"img\": \"menu_settings_1.png\"}";
            portfolioDetails.percentageFormat = portfolioDetails_data.percentageFormat || "";
            portfolioDetails.tabTwoObjService = portfolioDetails_data.tabTwoObjService || "PortfolioServicing";
            portfolioDetails.tabThreeBObjService = portfolioDetails_data.tabThreeBObjService || "PortfolioServicing";
            portfolioDetails.tabFourObjService = portfolioDetails_data.tabFourObjService || "PortfolioServicing";
            portfolioDetails.tabFiveObjService = portfolioDetails_data.tabFiveObjService || "PortfolioServicing";
            portfolioDetails.tabSixObjService = portfolioDetails_data.tabSixObjService || "PortfolioServicing";
            portfolioDetails.lstbxIdentifier = portfolioDetails_data.lstbxIdentifier || "cashAccounts";
            portfolioDetails.tabThreeAIdentifier = portfolioDetails_data.tabThreeAIdentifier || "S3";
            portfolioDetails.settingsGetCriteria = portfolioDetails_data.settingsGetCriteria || "{  \"portfolioId\":\"{$.c.portfolioId}\", \"userId\":\"{$.c.userId}\",\"isEuro\":\"{$.c.isEuro}\"}";
            portfolioDetails.tabThreeErrorText = portfolioDetails_data.tabThreeErrorText || "\"{i.i18n.wealth.error.ordersNotFound}\"";
            portfolioDetails.tabOneObjName = portfolioDetails_data.tabOneObjName || "PortfolioDetails";
            portfolioDetails.searchLabel5 = portfolioDetails_data.searchLabel5 || "\"{i.i18n.wealth.byTimePeriod}\"";
            portfolioDetails.tabTwoObjName = portfolioDetails_data.tabTwoObjName || "PortfolioDetails";
            portfolioDetails.tabThreeBObjName = portfolioDetails_data.tabThreeBObjName || "PortfolioDetails";
            portfolioDetails.tabFourObjName = portfolioDetails_data.tabFourObjName || "PortfolioDetails";
            portfolioDetails.tabFiveObjName = portfolioDetails_data.tabFiveObjName || "PortfolioDetails";
            portfolioDetails.tabSixObjName = portfolioDetails_data.tabSixObjName || "Reports";
            portfolioDetails.tabThreeAResponseArray = portfolioDetails_data.tabThreeAResponseArray || "{$.S3.ordersDetails}";
            portfolioDetails.settingsUpdateCriteria = portfolioDetails_data.settingsUpdateCriteria || "{  \"portfolioId\":\"{$.c.portfolioId}\", \"userId\":\"{$.c.userId}\", \"fieldOrder\":\"{$.c.fieldOrder}\",\"isEuro\":\"{$.c.isEuro}\"}";
            portfolioDetails.lstbxResponseArray = portfolioDetails_data.lstbxResponseArray || "";
            portfolioDetails.tabThreeDateFilterLabels = portfolioDetails_data.tabThreeDateFilterLabels || "{i.i18n.wealth.datePicker.previousSevenDays},{i.i18n.wealth.datePicker.previousThirtyDays},{i.i18n.wealth.datePicker.threeMonths},{i.i18n.wealth.datePicker.sixMonths}";
            portfolioDetails.tabOneOperation = portfolioDetails_data.tabOneOperation || "getPortfolioHoldings";
            portfolioDetails.val1PlaceHolder = portfolioDetails_data.val1PlaceHolder || "\"{i.i18n.wealth.placeHolder.searchByInstrument}\"";
            portfolioDetails.tabTwoOperation = portfolioDetails_data.tabTwoOperation || "getTransactionDetails";
            portfolioDetails.tabThreeBOperation = portfolioDetails_data.tabThreeBOperation || "getOrdersDetails";
            portfolioDetails.tabFourOperation = portfolioDetails_data.tabFourOperation || "getAccountActivity";
            portfolioDetails.tabFiveOperation = portfolioDetails_data.tabFiveOperation || "getPortfolioPerformance";
            portfolioDetails.tabSixOperation = portfolioDetails_data.tabSixOperation || "getReportAndDownloadTypes";
            portfolioDetails.lstbxResponseId = portfolioDetails_data.lstbxResponseId || "";
            portfolioDetails.tabThreeAResponseId = portfolioDetails_data.tabThreeAResponseId || "L3";
            portfolioDetails.tabThreeDateFilterKeys = portfolioDetails_data.tabThreeDateFilterKeys || "7D,30D,3M,6M";
            portfolioDetails.tabThreeSearchPlaceholder = portfolioDetails_data.tabThreeSearchPlaceholder || "\"{i.i18n.wealth.placeHolder.searchByInstrumentISINOrderType}\"";
            portfolioDetails.tabOneCriteria = portfolioDetails_data.tabOneCriteria || "{  \"portfolioId\":\"{$.c.portfolioId}\",  \"userId\":\"{$.c.userId}\", \"fieldOrder\":\"{$.c.fieldOrder}\",  \"navPage\":\"{$.c.navPage}\",   \"sortBy\":\"{$.c.sortBy}\",   \"searchByInstrumentName\":\"{$.c.searchByInstrumentName}\",   \"pageSize\":\"{$.c.pageSize}\",   \"pageOffset\":\"{$.c.pageOffset}\", \"sortOrder\":\"{$.c.sortOrder}\",\"isEuro\":\"{$.c.isEuro}\",\"downloadFormat\":\"{$.c.downloadFormat}\", \"isIncludeOrders\":\"{$.c.isIncludeOrders}\" }";
            portfolioDetails.iconColumnSort = portfolioDetails_data.iconColumnSort || "{\"img\": \"sorting.png\"}";
            portfolioDetails.searchLabel4 = portfolioDetails_data.searchLabel4 || "\"{i.i18n.wealth.history}\"";
            portfolioDetails.tabTwoCriteria = portfolioDetails_data.tabTwoCriteria || "{  \"portfolioId\":\"{$.c.portfolioId}\",   \"navPage\":\"{$.c.navPage}\",   \"sortBy\":\"{$.c.sortBy}\",   \"searchByInstrumentName\":\"{$.c.searchByInstrumentName}\",   \"pageSize\":\"{$.c.pageSize}\",   \"pageOffset\":\"{$.c.pageOffset}\", \"startDate\":\"{$.c.startDate}\", \"endDate\":\"{$.c.endDate}\", \"sortOrder\":\"{$.c.sortOrder}\",\"isEuro\":\"{$.c.isEuro}\",\"downloadFormat\":\"{$.c.downloadFormat}\"}";
            portfolioDetails.tabThreeBCriteria = portfolioDetails_data.tabThreeBCriteria || "{  \"portfolioId\":\"{$.c.portfolioId}\",   \"navPage\":\"{$.c.navPage}\",   \"sortBy\":\"{$.c.sortBy}\",   \"searchByInstrumentName\":\"{$.c.searchByInstrumentName}\",   \"pageSize\":\"{$.c.pageSize}\", \"orderId\":\"{$.c.orderId}\"  , \"pageOffset\":\"{$.c.pageOffset}\", \"sortOrder\":\"{$.c.sortOrder}\", \"type\":\"{$.c.type}\",\"startDate\":\"{$.c.startDate}\",\"endDate\":\"{$.c.endDate}\",\"isEuro\":\"{$.c.isEuro}\",\"downloadFormat\":\"{$.c.downloadFormat}\"}";
            portfolioDetails.tabFourCriteria = portfolioDetails_data.tabFourCriteria || "{  \"portfolioId\":\"{$.c.portfolioId}\",   \"navPage\":\"{$.c.navPage}\",   \"sortBy\":\"{$.c.sortBy}\",   \"searchByInstrumentName\":\"{$.c.searchByInstrumentName}\",  \"accountId\":\"{$.c.accountId}\"  , \"listType\":\"{$.c.listType}\", \"pageOffset\":\"{$.c.pageOffset}\", \"pageSize\":\"{$.c.pageSize}\", \"sortOrder\":\"{$.c.sortOrder}\", \"dateFrom\":\"{$.c.dateFrom}\", \"dateTo\":\"{$.c.dateTo}\",\"isEuro\":\"{$.c.isEuro}\",\"downloadFormat\":\"{$.c.downloadFormat}\"}";
            portfolioDetails.tabFiveCriteria = portfolioDetails_data.tabFiveCriteria || "{ \"portfolioId\":\"{$.c.portfolioId}\", \"navPage\":\"{$.c.navPage}\", \"sortBy\":\"{$.c.sortBy}\", \"sortOrder\":\"{$.c.sortOrder}\", \"pageSize\":\"{$.c.pageSize}\", \"pageOffset\":\"{$.c.pageOffset}\", \"dateFrom\":\"{$.c.dateFrom}\", \"dateTo\":\"{$.c.dateTo}\", \"duration\":\"{$.c.duration}\",  \"benchMarkIndex\":\"{$.c.benchMarkIndex}\",\"isEuro\":\"{$.c.isEuro}\", \"currencyId\":\"{$.c.currencyId}\"}";
            portfolioDetails.tabSixCriteria = portfolioDetails_data.tabSixCriteria || "{ \"portfolioId\":\"{$.c.portfolioId}\", \"navPage\":\"{$.c.navPage}\",\"downloadFormat\":\"{$.c.downloadFormat}\"}";
            portfolioDetails.tabThreeAFields = portfolioDetails_data.tabThreeAFields || "{     \"One\": {         \"value\": \"description\",         \"type\": \"text\",         \"displayName\": \"{i.i18n.wealth.watchlist.instrument}\",         \"default\": \"false\"     },     \"Two\": {         \"value\": \"orderReference\",         \"type\": \"orderId\",         \"displayName\": \"{i.i18n.konybb.common.referenceId}\",         \"default\": \"false\"     },     \"Three\": {         \"value\": \"tradeDate\",         \"type\": \"date\",         \"displayName\": \"{i.i18n.konybb.Common.Date}\",         \"default\": \"false\"     },     \"Four\": {         \"value\": \"orderType\",         \"type\": \"text\",         \"displayName\": \"{i.i18n.common.Type}\",         \"default\": \"false\"     },     \"Five\": {         \"value\": \"quantity\",         \"type\": \"textAmount\",   \"displayName\": \"{i.i18n.wealth.accountActivity.quantity}\",         \"default\": \"false\"     },     \"Six\": {         \"value\": \"limitPrice\",         \"type\": \"normalAmount\",   \"currency\": \"instrumentCurrency\",        \"displayName\": \"{i.i18n.wealth.orders.limitPrice}\",         \"default\": \"false\"     },     \"Seven\": {         \"value\": \"stopPrice\",         \"type\": \"normalAmount\",         \"displayName\": \"{i.i18n.wealth.orders.stopPrice}\",      \"currency\": \"instrumentCurrency\",     \"default\": \"false\"     },     \"Eight\": {         \"value\": \"status\",         \"type\": \"text\",         \"displayName\": \"{i.i18n.common.status}\",         \"default\": \"false\"     } }";
            portfolioDetails.tabOneIdentifier = portfolioDetails_data.tabOneIdentifier || "S1";
            portfolioDetails.iconColumnSortAsc = portfolioDetails_data.iconColumnSortAsc || "{\"img\": \"sorting_previous.png\"}";
            portfolioDetails.searchLabel3 = portfolioDetails_data.searchLabel3 || "\"{i.i18n.wealth.openOrders}\"";
            portfolioDetails.tabTwoIdentifier = portfolioDetails_data.tabTwoIdentifier || "S2";
            portfolioDetails.tabThreeBIdentifier = portfolioDetails_data.tabThreeBIdentifier || "S3";
            portfolioDetails.tabFourIdentifier = portfolioDetails_data.tabFourIdentifier || "S4";
            portfolioDetails.tabFiveIdentifier = portfolioDetails_data.tabFiveIdentifier || "S5";
            portfolioDetails.tabSixIdentifier = portfolioDetails_data.tabSixIdentifier || "S6";
            portfolioDetails.tabThreeADockFirstColumn = portfolioDetails_data.tabThreeADockFirstColumn || true;
            portfolioDetails.tabThreeDateFilterDefaultKey = portfolioDetails_data.tabThreeDateFilterDefaultKey || "30D";
            portfolioDetails.tabOneResponseArray = portfolioDetails_data.tabOneResponseArray || "{$.S1.portfolioHoldings}";
            portfolioDetails.iconColumnSortDesc = portfolioDetails_data.iconColumnSortDesc || "{\"img\": \"sorting_next.png\"}";
            portfolioDetails.tabTwoResponseArray = portfolioDetails_data.tabTwoResponseArray || "{$.S2.portfolioTransactions}";
            portfolioDetails.tabThreeBResponseArray = portfolioDetails_data.tabThreeBResponseArray || "{$.S3.ordersDetails}";
            portfolioDetails.tabFourResponseArray = portfolioDetails_data.tabFourResponseArray || "{$.S4.accountActivityList}";
            portfolioDetails.tabFiveResponseArray = portfolioDetails_data.tabFiveResponseArray || "{$.S5.sortedMonthlyOverview}";
            portfolioDetails.tabSixResponseArray = portfolioDetails_data.tabSixResponseArray || "";
            portfolioDetails.tabThreeAContextualMenuRequired = portfolioDetails_data.tabThreeAContextualMenuRequired || true;
            portfolioDetails.tabThreePerformanceConfig = portfolioDetails_data.tabThreePerformanceConfig || "";
            portfolioDetails.sknRowSeperator = portfolioDetails_data.sknRowSeperator || "ICSknLabelBgDBDBDB";
            portfolioDetails.tabOneResponseId = portfolioDetails_data.tabOneResponseId || "L1";
            portfolioDetails.iconCalendar = portfolioDetails_data.iconCalendar || "{\"img\": \"search_blue.png\"}";
            portfolioDetails.tabTwoResponseId = portfolioDetails_data.tabTwoResponseId || "L2";
            portfolioDetails.tabThreeBResponseId = portfolioDetails_data.tabThreeBResponseId || "";
            portfolioDetails.tabFourResponseId = portfolioDetails_data.tabFourResponseId || "L4";
            portfolioDetails.tabFiveResponseId = portfolioDetails_data.tabFiveResponseId || "L5";
            portfolioDetails.tabSixResponseId = portfolioDetails_data.tabSixResponseId || "L6";
            portfolioDetails.tabThreeAContextMenuLabel = portfolioDetails_data.tabThreeAContextMenuLabel || "Modify,Cancel";
            portfolioDetails.statusOptionsCode = portfolioDetails_data.statusOptionsCode || "Completed,Rejected,Open,Cancelled";
            portfolioDetails.iconRadioActive = portfolioDetails_data.iconRadioActive || "{\"img\": \"radiobtn_active.png\"}";
            portfolioDetails.tabOneFields = portfolioDetails_data.tabOneFields || "{\"One\":{\"value\":\"description\",\"type\":\"text\",\"displayName\":\"{i.i18n.wealth.watchlist.instrument}\",\"default\":\"true\"},\"Two\":{\"value\":\"quantity\",\"type\":\"textAmount\",\"displayName\":\"{i.i18n.wealth.accountActivity.quantity}\",\"default\":\"true\"},\"Three\":{\"value\":\"marketPrice\",\"type\":\"normalAmount\",\"displayName\":\"{i.i18n.wealth.latestPrice}\",\"currency\":\"secCCy\",\"default\":\"true\"},\"Four\":{\"value\":\"costPrice\",\"type\":\"normalAmount\",\"currency\":\"secCCy\",\"displayName\":\"{i.i18n.wealth.averageCost}\",\"default\":\"true\"},\"Five\":{\"value\":\"marketValue\",\"type\":\"normalAmount\",\"currency\":\"referenceCurrency\",\"displayName\":\"{i.i18n.wealth.holdings.marketValue}\",\"default\":\"true\"},\"Six\":{\"value\":\"weightPercentage\",\"type\":\"percentage\",\"displayName\":\"{i.i18n.wealth.holdings.weight}\",\"default\":\"true\"},\"Seven\":{\"value\":\"unrealPLMkt\",\"type\":\"amount\",\"currency\":\"referenceCurrency\",\"displayName\":\"{i.i18n.wealth.sortUnrealizedPL}\",\"default\":\"true\"},\"Eight\":{\"value\":\"assetClass\",\"type\":\"text\",\"displayName\":\"{i.i18n.wealth.assetClass}\",\"default\":\"false\"},\"Nine\":{\"value\":\"subAssetClass\",\"type\":\"text\",\"displayName\":\"{i.i18n.wealth.subAssetClass}\",\"default\":\"false\"},\"Ten\":{\"value\":\"region\",\"type\":\"text\",\"displayName\":\"{i.i18n.wealth.region}\",\"default\":\"false\"},\"Eleven\":{\"value\":\"sector\",\"type\":\"text\",\"displayName\":\"{i.i18n.wealth.sector}\",\"default\":\"false\"},\"Twelve\":{\"value\":\"secCCy\",\"type\":\"text\",\"displayName\":\"{i.i18n.wealth.watchlist.currency}\",\"default\":\"false\"},\"Thirteen\":{\"value\":\"exchangeRate\",\"type\":\"textAmount\",\"displayName\":\"{i.i18n.ForeignExchange.ExchangeRate}\",\"default\":\"false\"},\"Fourteen\":{\"value\":\"marketValPOS\",\"type\":\"normalAmount\",\"currency\":\"secCCy\",\"displayName\":\"{i.i18n.wealth.marketValuePosCcy}\",\"default\":\"false\"},\"Fifteen\":{\"value\":\"costValue\",\"type\":\"normalAmount\",\"currency\":\"referenceCurrency\",\"displayName\":\"{i.i18n.wealth.costValue}\",\"default\":\"false\"},\"Sixteen\":{\"value\":\"costExchangeRate\",\"type\":\"normalAmount\",\"currency\":\"referenceCurrency\",\"displayName\":\"{i.i18n.wealth.costExchangeRate}\",\"default\":\"false\"},\"Seventeen\":{\"value\":\"unRealizedPLPercentage\",\"type\":\"colorpercentage\",\"displayName\":\"{i.i18n.wealth.holdings.unrealisedPL}\",\"default\":\"false\"},\"Eighteen\":{\"value\":\"dailyPL\",\"type\":\"amount\",\"currency\":\"secCCy\",\"displayName\":\"{i.i18n.wealth.holdings.dailyPL}\",\"default\":\"false\"},\"Nineteen\":{\"value\":\"dailyPLPercentage\",\"type\":\"colorpercentage\",\"displayName\":\"{i.i18n.wealth.holdings.dailyPLPercent}\",\"default\":\"false\"}}";
            portfolioDetails.tabTwoFields = portfolioDetails_data.tabTwoFields || "{     \"One\": {         \"value\": \"description\",         \"type\": \"text\",         \"displayName\": \"{i.i18n.wealth.watchlist.instrument}\",         \"default\": \"false\"     },     \"Two\": {         \"value\": \"tradeDate\",         \"type\": \"date\",         \"displayName\": \"{i.i18n.wealth.tradeDate}\",         \"default\": \"false\"     },     \"Three\": {         \"value\": \"orderType\",         \"type\": \"text\",         \"displayName\": \"{i.i18n.common.Type}\",         \"default\": \"false\"     },     \"Four\": {         \"value\": \"quantity\",         \"type\": \"textAmount\",         \"displayName\": \"{i.i18n.wealth.qty}\",         \"default\": \"false\"     },     \"Five\": {         \"value\": \"limitPrice\",         \"type\": \"normalAmount\",     \"currency\": \"instrumentCurrency\",     \"displayName\": \"{i.i18n.wealth.price}\",         \"default\": \"false\"     },     \"Six\": {         \"value\": \"instrumentAmount\",         \"type\": \"normalAmount\",   \"currency\": \"referenceCurrency\",            \"displayName\": \"{i.i18n.wealth.amount}\",         \"default\": \"false\"     },     \"Seven\": {         \"value\": \"exchangeRate\",         \"type\": \"textAmount\",      \"currency\": \"referenceCurrency\",   \"displayName\": \"{i.i18n.ForeignExchange.ExchangeRate}\",         \"default\": \"false\"     },     \"Eight\": {         \"value\": \"netAmount\",         \"type\": \"normalAmount\",      \"currency\": \"instrumentCurrency\",      \"displayName\": \"{i.i18n.wealth.instrumentAmount}\",         \"default\": \"false\"     },     \"Nine\": {         \"value\": \"valueDate\",         \"type\": \"date\",         \"displayName\": \"{i.i18n.wealth.valueDate}\",         \"default\": \"false\"     },     \"Ten\": {         \"value\": \"fees\",         \"type\": \"normalAmount\",   \"currency\": \"feesCurrency\",            \"displayName\": \"{i.i18n.wealth.fees}\",         \"default\": \"false\"     },     \"Eleven\": {         \"value\": \"total\",         \"type\": \"normalAmount\",      \"currency\": \"referenceCurrency\",   \"displayName\": \"{i.i18n.wealth.total}\",         \"default\": \"false\"     } }";
            portfolioDetails.tabSixFields = portfolioDetails_data.tabSixFields || "";
            portfolioDetails.tabThreeBFields = portfolioDetails_data.tabThreeBFields || "{     \"One\": {         \"value\": \"description\",         \"type\": \"text\",         \"displayName\": \"{i.i18n.wealth.watchlist.instrument}\",         \"default\": \"false\"     },     \"Two\": {         \"value\": \"orderReference\",         \"type\": \"orderId\",         \"displayName\": \"{i.i18n.konybb.common.referenceId}\",         \"default\": \"false\"     },     \"Three\": {         \"value\": \"tradeDate\",         \"type\": \"date\",         \"displayName\": \"{i.i18n.konybb.Common.Date}\",         \"default\": \"false\"     },     \"Four\": {         \"value\": \"orderType\",         \"type\": \"text\",         \"displayName\": \"{i.i18n.common.Type}\",         \"default\": \"false\"     },     \"Five\": {         \"value\": \"quantity\",         \"type\": \"textAmount\",   \"displayName\": \"{i.i18n.wealth.accountActivity.quantity}\",         \"default\": \"false\"     },     \"Six\": {         \"value\": \"orderExecutionPrice\",         \"type\": \"normalAmount\",         \"displayName\": \"{i.i18n.wealth.price}\",       \"currency\": \"instrumentCurrency\",    \"default\": \"false\"     },     \"Seven\": {         \"value\": \"status\",         \"type\": \"text\",         \"displayName\": \"{i.i18n.common.status}\",         \"default\": \"false\"     } }";
            portfolioDetails.tabFourFields = portfolioDetails_data.tabFourFields || "{     \"One\": {         \"value\": \"bookingDate\",         \"type\": \"date\",         \"displayName\": \"{i.i18n.wealth.bookingDate}\",         \"default\": \"false\"     },     \"Two\": {         \"value\": \"displayName\",         \"type\": \"text\",         \"displayName\": \"{i.i18n.common.Type}\",         \"default\": \"false\"     },     \"Three\": {         \"value\": \"shortName\",         \"type\": \"text\",         \"displayName\": \"{i.i18n.wealth.watchlist.instrument}\",         \"default\": \"false\"     },     \"Four\": {         \"value\": \"quantity\",   \"displayName\": \"{i.i18n.wealth.accountActivity.quantity}\",      \"type\": \"textAmount\",        \"default\": \"false\"     },     \"Five\": {         \"value\": \"amount\",         \"type\": \"normalAmount\",  \"currency\": \"currencyId\",   \"displayName\": \"{i.i18n.wealth.watchlist.change}\",   \"default\": \"false\"     },     \"Six\": {         \"value\": \"valueDate\",         \"type\": \"date\",         \"displayName\": \"{i.i18n.wealth.valueDate}\",         \"default\": \"false\"     },     \"Seven\": {         \"value\": \"balance\",         \"type\": \"normalAmount\",     \"currency\": \"currencyId\",       \"displayName\": \"{i.i18n.wealth.accountBalance}\",         \"default\": \"false\"     } }";
            portfolioDetails.tabFiveFields = portfolioDetails_data.tabFiveFields || "{\"One\":{\"value\":\"dateTime\",\"type\":\"date\",\"displayName\":\"{i.i18n.konybb.Common.Date}\",\"default\":\"false\"},\"Two\":{\"value\":\"percentageChange\",\"type\":\"colorpercentage\",\"displayName\":\"{i.i18n.wealth.portfolioReturn}\",\"default\":\"false\"},\"Three\":{\"value\":\"portfolioReturn\",\"type\":\"normalAmount\",\"currency\":\"referenceCurrency\",\"displayName\":\"{i.i18n.wealth.performance.portfolioValue}\",\"default\":\"false\"},\"Four\":{\"value\":\"benchMarkIndex\",\"type\":\"colorpercentage\",\"displayName\":\"{i.i18n.wealth.benchmarkReturn}\",\"default\":\"false\"}}";
            portfolioDetails.tabThreeAContextMenuAction = portfolioDetails_data.tabThreeAContextMenuAction || "frmPlaceOrder,Cancel";
            portfolioDetails.statusOptionsImage = portfolioDetails_data.statusOptionsImage || "green.png,red.png,orange.png,grey.png";
            portfolioDetails.iconRadioInactive = portfolioDetails_data.iconRadioInactive || "{\"img\": \"radio_btn_inactive.png\"}";
            portfolioDetails.sknTableLabelHeader = portfolioDetails_data.sknTableLabelHeader || "ICSknSSPRegular72727213px";
            portfolioDetails.tabOneDockFirstColumn = portfolioDetails_data.tabOneDockFirstColumn || true;
            portfolioDetails.tabTwoDockFirstColumn = portfolioDetails_data.tabTwoDockFirstColumn || true;
            portfolioDetails.tabFourDockFirstColumn = portfolioDetails_data.tabFourDockFirstColumn || false;
            portfolioDetails.tabFiveDockFirstColumn = portfolioDetails_data.tabFiveDockFirstColumn || false;
            portfolioDetails.tabSixDockFirstColumn = portfolioDetails_data.tabSixDockFirstColumn || false;
            portfolioDetails.tabThreeBDockFirstColumn = portfolioDetails_data.tabThreeBDockFirstColumn || true;
            portfolioDetails.tabThreeAErrorText = portfolioDetails_data.tabThreeAErrorText || "\"{i.i18n.wealth.error.noOpenOrder}\"";
            portfolioDetails.sknTableLabelField = portfolioDetails_data.sknTableLabelField || "slLabel0d8a72616b3cc47";
            portfolioDetails.tabOneContextualMenuRequired = portfolioDetails_data.tabOneContextualMenuRequired || true;
            portfolioDetails.tabFourContextualMenuRequired = portfolioDetails_data.tabFourContextualMenuRequired || false;
            portfolioDetails.tabFiveContextualMenuRequired = portfolioDetails_data.tabFiveContextualMenuRequired || false;
            portfolioDetails.tabSixContexualMenuRequi = portfolioDetails_data.tabSixContexualMenuRequi || true;
            portfolioDetails.tabTwoContextualMenuRequired = portfolioDetails_data.tabTwoContextualMenuRequired || false;
            portfolioDetails.tabThreeBContextualMenuRequired = portfolioDetails_data.tabThreeBContextualMenuRequired || false;
            portfolioDetails.tabThreeAContextMenuPermission = portfolioDetails_data.tabThreeAContextMenuPermission || "{\"entitlement_keys\":[\"WEALTH_ORDER_MANAGEMENT&&WEALTH_ORDER_MGMT_ORDER_EDIT\",\"WEALTH_ORDER_MANAGEMENT&&WEALTH_ORDER_MGMT_ORDER_CANCEL\"]}";
            portfolioDetails.tabThreeAFeatures = portfolioDetails_data.tabThreeAFeatures || "{\"entitlement_keys\":[\"WEALTH_ORDER_MANAGEMENT&&WEALTH_ORDER_MGMT_OPEN_ORDER_VIEW\"]}";
            portfolioDetails.sknActionButtons = portfolioDetails_data.sknActionButtons || "flxHoverSkinPointer";
            portfolioDetails.tabOneContextMenuLabel = portfolioDetails_data.tabOneContextMenuLabel || "View,Buy,Sell";
            portfolioDetails.tabOneErrorText = portfolioDetails_data.tabOneErrorText || "\"{i.i18n.wealth.error.noHoldingsForThePortfolio}\"";
            portfolioDetails.tabTwoErrorText = portfolioDetails_data.tabTwoErrorText || "\"{i.i18n.wealth.error.noTransaction}\"";
            portfolioDetails.tabFourErrorText = portfolioDetails_data.tabFourErrorText || "\"{i.i18n.wealth.error.noAccountMovement}\"";
            portfolioDetails.tabFiveErrorText = portfolioDetails_data.tabFiveErrorText || "\"{i.i18n.wealth.error.detailsNotFound}\"";
            portfolioDetails.tabSixErrorText = portfolioDetails_data.tabSixErrorText || "";
            portfolioDetails.tabThreeBErrorText = portfolioDetails_data.tabThreeBErrorText || "\"{i.i18n.wealth.error.noHistoryOrder}\"";
            portfolioDetails.tabThreeBFeatures = portfolioDetails_data.tabThreeBFeatures || "{\"entitlement_keys\":[\"WEALTH_ORDER_MANAGEMENT&&WEALTH_ORDER_MGMT_ORDER_HISTORY_VIEW\"]}";
            portfolioDetails.sknSearchLabel = portfolioDetails_data.sknSearchLabel || "sknlbla0a0a015px";
            portfolioDetails.tabOneContextMenuAction = portfolioDetails_data.tabOneContextMenuAction || "frmProductDetails,frmPlaceOrder,frmPlaceOrder";
            portfolioDetails.tabTwoDateFilterLabels = portfolioDetails_data.tabTwoDateFilterLabels || "{i.i18n.wealth.datePicker.previousSevenDays},{i.i18n.wealth.datePicker.previousThirtyDays},{i.i18n.wealth.datePicker.threeMonths},{i.i18n.wealth.datePicker.sixMonths}";
            portfolioDetails.tabFourDateFilterLabels = portfolioDetails_data.tabFourDateFilterLabels || "{i.i18n.wealth.datePicker.previousSevenDays},{i.i18n.wealth.datePicker.previousThirtyDays},{i.i18n.wealth.datePicker.threeMonths},{i.i18n.wealth.datePicker.sixMonths}";
            portfolioDetails.tabFiveDateFilterLabels = portfolioDetails_data.tabFiveDateFilterLabels || "{i.i18n.wealth.datePicker.oneYear},{i.i18n.wealth.datePicker.YTD},{i.i18n.wealth.datePicker.sinceInception}";
            portfolioDetails.tabSixDateFilterLabels = portfolioDetails_data.tabSixDateFilterLabels || "{i.i18n.wealth.datePicker.previousThirtyDays},{i.i18n.wealth.datePicker.threeMonths},{i.i18n.wealth.datePicker.sixMonths},{i.i18n.wealth.datePicker.oneYear}";
            portfolioDetails.sknSearchTextbox = portfolioDetails_data.sknSearchTextbox || "skne3e3e3br3pxradius";
            portfolioDetails.tabOneDateFilterLabels = portfolioDetails_data.tabOneDateFilterLabels || "";
            portfolioDetails.tabTwoDateFilterKeys = portfolioDetails_data.tabTwoDateFilterKeys || "7D,30D,3M,6M";
            portfolioDetails.tabFourDateFilterKeys = portfolioDetails_data.tabFourDateFilterKeys || "7D,30D,3M,6M";
            portfolioDetails.tabFiveDateFilterKeys = portfolioDetails_data.tabFiveDateFilterKeys || "1Y,YTD,sinceInception";
            portfolioDetails.tabSixDateFilterKeys = portfolioDetails_data.tabSixDateFilterKeys || "30D,3M,6M,1Y";
            portfolioDetails.tabThreeBContextMenuLabel = portfolioDetails_data.tabThreeBContextMenuLabel || "";
            portfolioDetails.tabTwoSearchPlaceholder = portfolioDetails_data.tabTwoSearchPlaceholder || "\"{i.i18n.wealth.placeHolder.searchByInstrumentISINTransactionType}\"";
            portfolioDetails.tabFourSearchPlaceholder = portfolioDetails_data.tabFourSearchPlaceholder || "\"{i.i18n.wealth.placeHolder.searchByAccountMovementType}\"";
            portfolioDetails.tabFiveSearchPlaceholder = portfolioDetails_data.tabFiveSearchPlaceholder || "\"{i.i18n.wealth.placeHolder.searchByInstrument}\"";
            portfolioDetails.tabSixSearchPlaceholder = portfolioDetails_data.tabSixSearchPlaceholder || "\"{i.i18n.wealth.placeHolder.searchByInstrument}\"";
            portfolioDetails.sknSearchActiveTextbox = portfolioDetails_data.sknSearchActiveTextbox || "ICSknFlxffffffBorder003e751pxRadius3px";
            portfolioDetails.tabOneDateFilterKeys = portfolioDetails_data.tabOneDateFilterKeys || "";
            portfolioDetails.tabThreeBContextMenuAction = portfolioDetails_data.tabThreeBContextMenuAction || "";
            portfolioDetails.tabOneSearchPlaceholder = portfolioDetails_data.tabOneSearchPlaceholder || "\"{i.i18n.wealth.placeHolder.searchByInstrument}\"";
            portfolioDetails.sknSearchDropdown = portfolioDetails_data.sknSearchDropdown || "sknlbxaltoffffffB1R2";
            portfolioDetails.tabTwoDateFilterDefaultKey = portfolioDetails_data.tabTwoDateFilterDefaultKey || "30D";
            portfolioDetails.tabFourDateFilterDefaultKey = portfolioDetails_data.tabFourDateFilterDefaultKey || "30D";
            portfolioDetails.tabFiveDateFilterDefaultKey = portfolioDetails_data.tabFiveDateFilterDefaultKey || "1Y";
            portfolioDetails.tabSixDateFilterDefaultKey = portfolioDetails_data.tabSixDateFilterDefaultKey || "30D";
            portfolioDetails.tabThreeBContextMenuPermission = portfolioDetails_data.tabThreeBContextMenuPermission || "";
            portfolioDetails.sknSearchActiveDropdown = portfolioDetails_data.sknSearchActiveDropdown || "sknlbxaltoffffffB1R2";
            portfolioDetails.tabOneDateFilterDefaultKey = portfolioDetails_data.tabOneDateFilterDefaultKey || "";
            portfolioDetails.tabTwoPerformanceConfig = portfolioDetails_data.tabTwoPerformanceConfig || "";
            portfolioDetails.tabFourPerformanceConfig = portfolioDetails_data.tabFourPerformanceConfig || "";
            portfolioDetails.tabFivePerformanceConfig = portfolioDetails_data.tabFivePerformanceConfig || "{ \"lblOneName\": \"{i.i18n.wealth.performanceConfig.portfolio}\", \"lblTwoName\": \"{i.i18n.wealth.performanceConfig.benchmark}\", \"firstColorCode\": \"#003E75\", \"secondColorCode\": \"#FFAF00\", \"firstImageName\": \"portfolio.png\", \"secondImageName\": \"benchmark.png\", \"graphRequired\": \"Yes\" }";
            portfolioDetails.tabSixPerformanceConfig = portfolioDetails_data.tabSixPerformanceConfig || "{ \"lbl01\": \"{i.i18n.wealth.performanceConfig.language}\", \"lbl02\": \"{i.i18n.wealth.byTimePeriod}\",\"lbl03\": \"{i.i18n.Transfers.Report}\",\"lbl04\": \"{i.i18n.wealth.performanceConfig.downloadStatements}\",\"firstColorCode\": \"#424242\",\"secondColorCode\": \"#003e75\", \"img1\": \"calender.png\",\"img2\":\"download.png\"}";
            portfolioDetails.sknSearchCalendar = portfolioDetails_data.sknSearchCalendar || "sknCalTransactions";
            portfolioDetails.tabOnePerformanceConfig = portfolioDetails_data.tabOnePerformanceConfig || "";
            portfolioDetails.tabTwoFeatures = portfolioDetails_data.tabTwoFeatures || "{\"entitlement_keys\":[\"WEALTH_PORTFOLIO_DETAILS&&WEALTH_PORTFOLIO_DETAILS_TRANSACTIONS_VIEW\"]}";
            portfolioDetails.tabFourFeatures = portfolioDetails_data.tabFourFeatures || "{\"entitlement_keys\":[\"WEALTH_PORTFOLIO_DETAILS&&WEALTH_PORTFOLIO_DETAILS_ACCOUNT_SUMMARY_VIEW\"]}";
            portfolioDetails.tabSixFeaturesdownloadReport = portfolioDetails_data.tabSixFeaturesdownloadReport || "{\"entitlement_keys\":[\"WEALTH_REPORT_MANAGEMENT&&WEALTH_REPORT_MANAGEMENT_REPORT_DOWNLOAD\"]}";
            portfolioDetails.tabFiveFeatures = portfolioDetails_data.tabFiveFeatures || "{\"entitlement_keys\":[\"WEALTH_PORTFOLIO_DETAILS&&WEALTH_PORTFOLIO_DETAILS_PERFORMANCE_VIEW\"]}";
            portfolioDetails.sknSearchActiveCalendar = portfolioDetails_data.sknSearchActiveCalendar || "sknCalTransactions";
            portfolioDetails.tabOneFeatures = portfolioDetails_data.tabOneFeatures || "{\"entitlement_keys\":[\"WEALTH_PORTFOLIO_DETAILS&&WEALTH_PORTFOLIO_DETAILS_HOLDINGS_VIEW\"]}";
            portfolioDetails.tabSixFeaturesgenerateReport = portfolioDetails_data.tabSixFeaturesgenerateReport || "{\"entitlement_keys\":[\"WEALTH_REPORT_MANAGEMENT&&WEALTH_REPORT_MANAGEMENT_REPORT_CREATE\"]}";
            portfolioDetails.tabOneContextMenuPermission = portfolioDetails_data.tabOneContextMenuPermission || "{\"entitlement_keys\":[\"WEALTH_PRODUCT_DETAILS&&WEALTH_PRODUCT_DETAILS_INSTRUMENT_VIEW\",\"WEALTH_ORDER_MANAGEMENT&&WEALTH_ORDER_MGMT_BUY_ORDER_CREATE\",\"WEALTH_ORDER_MANAGEMENT&&WEALTH_ORDER_MGMT_SELL_ORDER_CREATE\"]}";
            portfolioDetails.sknPositiveAmount = portfolioDetails_data.sknPositiveAmount || "IWLabelGreenText15Px";
            portfolioDetails.sknNegativeAmount = portfolioDetails_data.sknNegativeAmount || "sknlblff000015px";
            portfolioDetails.sknDate = portfolioDetails_data.sknDate || "slLabel0d8a72616b3cc47";
            portfolioDetails.sknPercentage = portfolioDetails_data.sknPercentage || "slLabel0d8a72616b3cc47";
            flxComponent.add(lblPortfolio, portfolioDetails);
            flxSecondaryDetailsRow.add(flxComponent);
            flxMain1.add(flxSuccessMessage, flxDowntimeWarning, flxPrimaryDetailsRow, flxAdvisoryMain, flxNewUser, flxSecondaryDetailsRow);
            var flxAccountList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "80dp",
                "width": "320dp",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountList.setDefaultUnit(kony.flex.DP);
            var accountListMenu = new com.InfinityOLB.PortfolioManagementMA.accountListMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountListMenu",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "PortfolioManagementMA",
                "overrides": {
                    "accountListMenu": {
                        "top": "0dp"
                    },
                    "flxAccountListActionsSegment": {
                        "isVisible": true,
                        "top": "-3dp"
                    },
                    "segAccountListActions": {
                        "data": [{
                            "lblSeparator": "Separator",
                            "lblUsers": "Make Transfer from"
                        }, {
                            "lblSeparator": "Separator",
                            "lblUsers": "Pay a Bill from"
                        }, {
                            "lblSeparator": "Separator",
                            "lblUsers": "Pay a Person from"
                        }, {
                            "lblSeparator": "Separator",
                            "lblUsers": "Order Check"
                        }, {
                            "lblSeparator": "Separator",
                            "lblUsers": "Edit Account"
                        }, {
                            "lblSeparator": "Separator",
                            "lblUsers": "Download Statement"
                        }, {
                            "lblSeparator": "Separator",
                            "lblUsers": "Settings & Alerts"
                        }]
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            accountListMenu.segAccountListActions.onRowClick = controller.AS_Segment_f8230ec451054fb19421e8f0af77c246;
            flxAccountList.add(accountListMenu);
            flxMain.add(flxMain1, flxAccountList);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "130dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnFaqs": {
                        "isVisible": true
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    },
                    "btnPrivacy": {
                        "isVisible": true
                    },
                    "btnTermsAndConditions": {
                        "isVisible": true
                    },
                    "customfooter": {
                        "centerX": "50%",
                        "height": "130dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "flxVBar2": {
                        "isVisible": true
                    },
                    "flxVBar3": {
                        "isVisible": true
                    },
                    "flxVBar4": {
                        "isVisible": true
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew, customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxMoveArea = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMoveArea",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0d9b2be6b1e0247",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMoveArea.setDefaultUnit(kony.flex.DP);
            flxMoveArea.add();
            var settings = new com.InfinityOLB.PortfolioManagementMA.settings({
                "height": "100%",
                "id": "settings",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA",
                "viewType": "settings",
                "overrides": {
                    "settings": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var settings_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"]["settings"]) || {};
            settings.displayNames = settings_data.displayNames || "Quantity,Latest Price,Average Cost,Market Value,Weight%,Unrealised P&L,Asset Class,Sub Asset Class,Region,Sector,Currency,Exchange Rate,Market Value(pos ccy),Cost Value,Cost Exchange Rate,Unrealised P&L %,Daily P&L,Daily P&L %";
            settings.selectedColumns = settings_data.selectedColumns || "0,1,2,3,4,5";
            var Downloads = new com.InfinityOLB.PortfolioManagementMA.Downloads({
                "height": "100%",
                "id": "Downloads",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "PortfolioManagementMA",
                "viewType": "Downloads",
                "overrides": {
                    "Downloads": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "retainFlexPositionProperties": false,
                "retainContentAlignment": false,
                "retainFlowHorizontalAlignment": false,
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var Downloads_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmPortfolioOverview"]["Downloads"]) || {};
            var flxCancelPopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "140%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0i94559a2949d45",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1200,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopupCancel = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "height": "268px",
                "id": "CustomPopupCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "250dp",
                "width": "43%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "top": "250dp",
                        "width": "43%"
                    },
                    "btnNo": {
                        "left": "5.48%",
                        "right": "viz.val_cleared"
                    },
                    "btnYes": {
                        "right": "4.89%"
                    },
                    "flxCross": {
                        "height": "30dp",
                        "right": "16dp",
                        "width": "30dp",
                        "zIndex": 5
                    },
                    "imgCross": {
                        "centerX": "52%",
                        "height": "15dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.orders.popupHeader\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.orders.cancelOrder\")",
                        "width": "80%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(CustomPopupCancel);
            flxCancelPopup.add(flxPopup);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "Accounts",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxSuccessMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarning": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryDetailsRow": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypesAndInfo": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "height": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "width": {
                            "type": "string",
                            "value": "34%"
                        },
                        "segmentProps": []
                    },
                    "flxImgAccountTypeIcon": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "imgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "lblAccountTypes": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "imgAccountTypes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "btnViewAccountInfo": {
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPortfolio": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCashCard": {
                        "left": {
                            "type": "string",
                            "value": "0.00%"
                        },
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxInstrument": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAsset": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAdvisoryDetails": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxHealthCheck": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxReviewProposal": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSecondaryDetailsRow": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxComponent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "number",
                            "value": "10"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "left": {
                            "type": "string",
                            "value": "8px"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxSuccessMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarning": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryDetailsRow": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypesAndInfo": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "31%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "skin": "sf776a4eae274fa7acd4697a573c9f79",
                        "top": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxImgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "imgAccountTypeIcon": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPortfolio": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slfBoxffffffB1R5",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "investmentSummary": {
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "btnTab1": {
                        "skin": "sknBtnSSP42424217PxSelectedTab",
                        "segmentProps": []
                    },
                    "btnTab2": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknBtnSSP72727217PxUnSelectedTab",
                        "segmentProps": []
                    },
                    "imgAccountNumber": {
                        "height": {
                            "type": "string",
                            "value": "15px"
                        },
                        "width": {
                            "type": "string",
                            "value": "25px"
                        },
                        "segmentProps": []
                    },
                    "flxGroup": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPortofolioValues": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMarketValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "number",
                            "value": "20"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "lblVerticalSepeartor": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxProfitLoss": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxUnrealisedPL": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lbllUnrealisedPL": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "lblUnrealisedPLValue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxTodayPL": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblTodayPL": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblTodayPLValue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxSeparator2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxPortofolioLineChart": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxCashCard": {
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxInstrument": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "instrumentSearch": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAsset": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAssetAllocation": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAdvisoryMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAdvisoryDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxHealthCheck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "440dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "PortfolioHealthCheck": {
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxStrategy": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "440dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "flxReviewProposal": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "investmentProposal.flxMainNewAdvice": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "investmentProposal.flxMainNoAdvice": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNewUser": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "number",
                            "value": "15"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxSecondaryDetailsRow": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxComponent": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblPortfolio": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "accountListMenu": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "instanceId": "accountListMenu"
                    },
                    "accountListMenu.flxAccountListActionsSegment": {
                        "top": {
                            "type": "string",
                            "value": "-18dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "Downloads": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "segmentProps": []
                    },
                    "CustomPopupCancel": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxMain1": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSuccessMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "flxPrimaryDetailsRow": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblLeftArrowIcon": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgLeftArrow": {
                        "left": {
                            "type": "string",
                            "value": "-5dp"
                        },
                        "segmentProps": []
                    },
                    "lblBackToDashboard": {
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "lblHeading": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypesAndInfo": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                        "top": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "384dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxImgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "imgAccountTypeIcon": {
                        "segmentProps": []
                    },
                    "lblAccountTypes": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "sknLblSSP000d1915Px",
                        "segmentProps": []
                    },
                    "imgAccountTypes": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "144dp"
                        },
                        "segmentProps": []
                    },
                    "flxPortfolio": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnTab2": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxGroup": {
                        "segmentProps": []
                    },
                    "flxProfitLoss": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblUnrealisedPLValue": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxSeparator2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxCashCard": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "104dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.80%"
                        },
                        "segmentProps": []
                    },
                    "flxInstrument": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknFlxffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "instrumentSearch": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxAsset": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknFlxffffffShadowdddcdc",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAdvisoryMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxAdvisoryDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxHealthCheck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "flxStrategy": {
                        "height": {
                            "type": "string",
                            "value": "440dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "flxReviewProposal": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "skin": "sknFlxffffffShadowdddcdc",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "flxNewUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "175dp"
                        },
                        "isCustomLayout": true,
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxSecondaryDetailsRow": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxComponent": {
                        "segmentProps": []
                    },
                    "lblPortfolio": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "382dp"
                        },
                        "segmentProps": []
                    },
                    "accountListMenu": {
                        "top": {
                            "type": "string",
                            "value": "-15dp"
                        },
                        "segmentProps": [],
                        "instanceId": "accountListMenu"
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    },
                    "Downloads": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxSuccessMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "flxPrimaryDetailsRow": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxTopContainer": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "imgLeftArrow": {
                        "left": {
                            "type": "string",
                            "value": "-5dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblBackToDashboard": {
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypesAndInfo": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "ICSknFlxffffffBordere3e3e31pxRadius3px",
                        "top": {
                            "type": "string",
                            "value": "84dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "384dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypes": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "hoverSkin": ""
                    },
                    "flxImgAccountTypeIcon": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountTypes": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "sknLblSSP000d1915Px",
                        "segmentProps": []
                    },
                    "imgAccountTypes": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeftContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "144dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxPortfolio": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxProfitLoss": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "flxSeparator2": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxCashCard": {
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "104dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "33.70%"
                        },
                        "segmentProps": []
                    },
                    "flxInstrument": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "instrumentSearch": {
                        "accessibilityConfig": {},
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAsset": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAdvisoryMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxAdvisoryDetails": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "left": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "64%"
                        },
                        "segmentProps": []
                    },
                    "flxHealthCheck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "flxStrategy": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "440dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "49%"
                        },
                        "segmentProps": []
                    },
                    "flxReviewProposal": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "flxNewUser": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxSecondaryDetailsRow": {
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxComponent": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountList": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "384dp"
                        },
                        "segmentProps": []
                    },
                    "accountListMenu": {
                        "top": {
                            "type": "string",
                            "value": "-15dp"
                        },
                        "segmentProps": [],
                        "instanceId": "accountListMenu"
                    },
                    "Downloads": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnNo": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopupCancel.btnYes": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "GenericMessageNew": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "investmentLineChart": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "instrumentSearch": {
                    "right": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "totalAssets": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "assetAllocation": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "PortfolioHealthCheck": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "myStrategyDetails": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "investmentProposal.flxinfo": {
                    "left": "0dp"
                },
                "investmentProposal.imgAdvice": {
                    "src": "imgnewadvice.png"
                },
                "investmentProposal.imgInfo": {
                    "centerY": "50%",
                    "left": "6dp",
                    "src": "group_10_copy_4.png"
                },
                "investmentProposal.imgNoAdvInfo": {
                    "src": "group_10_copy_4.png"
                },
                "investmentProposal.imgNoNewAdvice": {
                    "src": "imgnewadvice.png"
                },
                "investmentProposal.lblInvestmentProposal": {
                    "left": "20dp"
                },
                "defineStrategy": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "portfolioDetails": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "accountListMenu": {
                    "top": "0dp"
                },
                "accountListMenu.flxAccountListActionsSegment": {
                    "top": "-3dp"
                },
                "accountListMenu.segAccountListActions": {
                    "data": [{
                        "lblSeparator": "Separator",
                        "lblUsers": "Make Transfer from"
                    }, {
                        "lblSeparator": "Separator",
                        "lblUsers": "Pay a Bill from"
                    }, {
                        "lblSeparator": "Separator",
                        "lblUsers": "Pay a Person from"
                    }, {
                        "lblSeparator": "Separator",
                        "lblUsers": "Order Check"
                    }, {
                        "lblSeparator": "Separator",
                        "lblUsers": "Edit Account"
                    }, {
                        "lblSeparator": "Separator",
                        "lblUsers": "Download Statement"
                    }, {
                        "lblSeparator": "Separator",
                        "lblUsers": "Settings & Alerts"
                    }]
                },
                "customfooter": {
                    "centerX": "50%",
                    "height": "130dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "settings": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "Downloads": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "CustomPopupCancel": {
                    "centerX": "50%",
                    "centerY": "",
                    "top": "250dp",
                    "width": "43%"
                },
                "CustomPopupCancel.btnNo": {
                    "left": "5.48%",
                    "right": ""
                },
                "CustomPopupCancel.btnYes": {
                    "right": "4.89%"
                },
                "CustomPopupCancel.flxCross": {
                    "height": "30dp",
                    "right": "16dp",
                    "width": "30dp",
                    "zIndex": 5
                },
                "CustomPopupCancel.imgCross": {
                    "centerX": "52%",
                    "height": "15dp"
                },
                "CustomPopupCancel.lblPopupMessage": {
                    "width": "80%"
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopup.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                }
            }
            this.add(flxHeader, flxFormContent, flxMoveArea, settings, Downloads, flxCancelPopup, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmPortfolioOverview,
            "enabledForIdleTimeout": true,
            "id": "frmPortfolioOverview",
            "init": controller.AS_Form_df5e413531994d989e771403adf86762,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "PortfolioManagementMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});