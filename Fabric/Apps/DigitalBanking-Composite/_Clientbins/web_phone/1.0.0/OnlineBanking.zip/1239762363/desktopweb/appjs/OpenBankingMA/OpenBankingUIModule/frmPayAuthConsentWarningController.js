define("OpenBankingMA/OpenBankingUIModule/userfrmPayAuthConsentWarningController", ['CommonUtilities', 'OLBConstants', 'FormControllerUtility', 'ViewConstants', 'CampaignUtility'], function(CommonUtilities, OLBConstants, FormControllerUtility, ViewConstants, CampaignUtility) {
    const fontIcons = {
            'failure': '\u006C',
            'success': '\u0059'
        },
        skins = {
            'failure': 'ICSknFontIconE4253848px',
            'success': 'ICSknFontIconSet3CA491648px'
        }
    return {
        frmPayAuthConsentWarningInit: function() {
            this.view.preShow = this.preShowAuthConsentAck;
        },
        preShowAuthConsentAck: function() {
            try {
                var navManager = applicationManager.getNavigationManager();
                var msg = navManager.getCustomInfo("frmConsentWarning");
                var errMsg = navManager.getCustomInfo("frmSelectPaymentWarning");
                this.view.lblCross.text = fontIcons.success;
                this.view.lblCross.skin = skins.success;
                if (kony.i18n.getLocalizedString("i18n.tppconsent.serverError") === msg) {
                    this.view.lblBackTotppMsg.text = kony.i18n.getLocalizedString("i18n.tppconsent.serverErrorMsg");
                    this.view.lblCross.text = fontIcons.failure;
                    this.view.lblCross.skin = skins.failure;
                } else if (kony.i18n.getLocalizedString("i18n.tppConsent.rejectError") === msg) {
                    this.view.lblBackTotppMsg.text = kony.i18n.getLocalizedString("i18n.tppConsent.CancelErrorMsg");
                } else if (kony.i18n.getLocalizedString("i18n.tppconsent.noPermissions") === msg) {
                    this.view.lblBackTotppMsg.text = kony.i18n.getLocalizedString("i18n.tppconsent.noInfoShared");
                } else {
                    this.view.lblBackTotppMsg.text = kony.i18n.getLocalizedString("i18n.tppConsent.CancelErrorMsg");
                }
                if (applicationManager.consentType === "CBP") {
                    this.view.lblBackTotppMsg.text = kony.i18n.getLocalizedString("i18n.tppconsent.noInfoShared");
                }
                if (!kony.sdk.isNullOrUndefined(errMsg)) {
                    var str = errMsg;
                    dataObj = JSON.parse(str);
                    this.view.lblSuccessMessage.text = dataObj[0].message;
                } else {
                    this.view.lblSuccessMessage.text = msg;
                }
                const configManager = applicationManager.getConfigurationManager();
                var timer = configManager.getTppNavigationTimer();
                if (timer === "" || kony.sdk.isNullOrUndefined(timer)) timer = 0;
                this.view.lblInfo.text = kony.i18n.getLocalizedString("i18n.tppconsent.navigationMsg") + " " + timer + " " + kony.i18n.getLocalizedString("i18n.wealth.seconds");
                this.bindevents();
                this.navigateTotpp();
            } catch (error) {
                kony.print("preShowfunc-->" + error);
            }
        },
        ///////********bindevents is used set thewidgets onclick and initialise the data*****////////
        bindevents: function() {
            try {
                this.view.btnContinue.onClick = this.onClickContinue;
                this.view.onDeviceBack = this.dummyfunc;
            } catch (error) {
                kony.print(" bindevents-->" + error);
            }
        },
        dummyfunc: function() {},
        onClickContinue: function() {
            try {
                var accMode = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                    "moduleName": "OpenBankingUIModule",
                    "appName": "OpenBankingMA"
                });
                var status = "";
                if (applicationManager.consentType === "PISP") {
                    status = kony.sdk.isNullOrUndefined(accMode.presentationController.consentStatus) ? "" : accMode.presentationController.consentStatus + "&consentType=PISP";
                } else if (applicationManager.consentType === "CBP") {
                    status = kony.sdk.isNullOrUndefined(accMode.presentationController.consentStatus) ? "" : accMode.presentationController.consentStatus + "&consentType=CBP";
                }
                var url = applicationManager.deeplinkSchemaName + "?status=" + status;
                let authMode = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                    "moduleName": "AuthUIModule",
                    "appName": "AuthenticationMA"
                });
                authMode.presentationController.isTPPNavigation = true;
                applicationManager.gblDeepLink = false;
                kony.application.openURLAsync({
                    url: url,
                    isSameWindow: true
                });
            } catch (Error) {
                kony.print("Exception While getting exiting the application  : " + Error);
            }
        },
        navigateTotpp: function() {
            const configManager = applicationManager.getConfigurationManager();
            var timer = configManager.getTppNavigationTimer();
            if (timer === "" || kony.sdk.isNullOrUndefined(timer)) timer = 0;
            kony.timer.schedule("timer3", this.onClickContinue, timer, false);
        }
    }
});
define("OpenBankingMA/OpenBankingUIModule/frmPayAuthConsentWarningControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for frmPayAuthConsentWarning **/
    AS_Form_bd0d7b32ad704bbfabf5e5dfefb158da: function AS_Form_bd0d7b32ad704bbfabf5e5dfefb158da(eventobject) {
        var self = this;
        this.frmPayAuthConsentWarningInit();
    }
});
define("OpenBankingMA/OpenBankingUIModule/frmPayAuthConsentWarningController", ["OpenBankingMA/OpenBankingUIModule/userfrmPayAuthConsentWarningController", "OpenBankingMA/OpenBankingUIModule/frmPayAuthConsentWarningControllerActions"], function() {
    var controller = require("OpenBankingMA/OpenBankingUIModule/userfrmPayAuthConsentWarningController");
    var controllerActions = ["OpenBankingMA/OpenBankingUIModule/frmPayAuthConsentWarningControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
