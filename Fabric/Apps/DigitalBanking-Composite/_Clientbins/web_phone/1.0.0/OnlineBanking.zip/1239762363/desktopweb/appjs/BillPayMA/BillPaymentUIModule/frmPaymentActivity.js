define("BillPayMA/BillPaymentUIModule/frmPaymentActivity", function() {
    return function(controller) {
        function addWidgetsfrmPaymentActivity() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblPayABill = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblPayABill",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.BillPay\")",
                "top": "30dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var btnSkipRight = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "height": "30dp",
                "id": "btnSkipRight",
                "isVisible": true,
                "left": "20.07%",
                "right": 50,
                "skin": "btnSkipNavigation",
                "text": "Skip to Bill Pay Options",
                "top": "-30dp",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "92.80%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.ErrorServer\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "58.12%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxActivityMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxActivityMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivityMain.setDefaultUnit(kony.flex.DP);
            var flxActivityHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52dp",
                "id": "flxActivityHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActivityHeader.setDefaultUnit(kony.flex.DP);
            var lblActivityHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblActivityHeader",
                "isVisible": true,
                "left": "3%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PaymentActivity\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxActivityHeader.add(lblActivityHeader);
            var flxSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "right": "2%",
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "96%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "140dp",
                "id": "flxDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDetails.setDefaultUnit(kony.flex.DP);
            var flxLeftDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxLeftDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.80%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "46.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftDetails.setDefaultUnit(kony.flex.DP);
            var lblFromTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFromTitle",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.PayeeName:\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFromAccountName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxFromAccountName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromAccountName.setDefaultUnit(kony.flex.DP);
            var flxFromUser = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "25px",
                "id": "flxFromUser",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "4%",
                "skin": "skne3e3e3br3pxradius",
                "top": "12px",
                "width": "25px",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromUser.setDefaultUnit(kony.flex.DP);
            var lblFromUser = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblFromUser",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblFontTypeIcon",
                "text": "L",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromUser.add(lblFromUser);
            var lblAccountName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424213px",
                "text": "Personal Checking...6534",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromAccountName.add(flxFromUser, lblAccountName);
            var lblAccountHolder = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountHolder",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknLblSSP42424213px",
                "text": "Adithya Chelukuri",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLeftDetails.add(lblFromTitle, flxFromAccountName, lblAccountHolder);
            var flxRightDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxRightDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "46.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightDetails.setDefaultUnit(kony.flex.DP);
            var lblAmountDeductedTitle = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Amount Deducted till Date",
                    "tagName": "span"
                },
                "id": "lblAmountDeductedTitle",
                "isVisible": true,
                "left": "21dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.AmountTransferredTillDate:\")",
                "top": "17dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountDeducted = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAmountDeducted",
                "isVisible": true,
                "left": "21dp",
                "skin": "sknLblSSP42424224px",
                "text": "$103.74",
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightDetails.add(lblAmountDeductedTitle, lblAmountDeducted);
            flxDetails.add(flxLeftDetails, flxRightDetails);
            var flxSeparatorDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorDetails.setDefaultUnit(kony.flex.DP);
            flxSeparatorDetails.add();
            var flxSort = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSort",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxF4F4F4",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSort.setDefaultUnit(kony.flex.DP);
            var flxFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxFrom",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "12.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrom.setDefaultUnit(kony.flex.DP);
            var lblFrom = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Bill Date",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblFrom",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.labelBillDate\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortFrom = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortFrom",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer5vs",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort by Bill Date"
            });
            flxFrom.add(lblFrom, imgSortFrom);
            var flxBills = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxBills",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBills.setDefaultUnit(kony.flex.DP);
            var lblBillsKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Bills",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblBillsKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.bills\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBills.add(lblBillsKey);
            var flxDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "12.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var lblDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Paid Date",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.PaidDate\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortDate = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortDate",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer5vs",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort by Paid Date"
            });
            flxDate.add(lblDate, imgSortDate);
            var flxfromaccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxfromaccount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxfromaccount.setDefaultUnit(kony.flex.DP);
            var lblFromAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "From Account",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblFromAccount",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.FromAccount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortFromAccount = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortFromAccount",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer5vs",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Sort By Account"
            });
            flxfromaccount.add(lblFromAccount, imgSortFromAccount);
            var flxAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "12.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var lblAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Amount",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAmount",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortAmount = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortAmount",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer5vs",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmount.add(lblAmount, imgSortAmount);
            var flxStatus = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "right": "20%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "12.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatus.setDefaultUnit(kony.flex.DP);
            var lblStatus = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Status",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblStatus",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.manageUser.Status\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgSortStatus = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Sort"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSortStatus",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknImgPointer5vs",
                "src": "sorting.png",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStatus.add(lblStatus, imgSortStatus);
            flxSort.add(flxFrom, flxBills, flxDate, flxfromaccount, flxAmount, flxStatus);
            var flxSeparatorSort = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorSort",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorSort.setDefaultUnit(kony.flex.DP);
            flxSeparatorSort.add();
            var flxSegment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "div"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSegment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegment.setDefaultUnit(kony.flex.DP);
            var segTransferActivity = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "ul"
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "id": "segTransferActivity",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "BillPayMA",
                    "friendlyName": "flxBillPaymentActivity"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "e9e9e900",
                "separatorRequired": false,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSegment.add(segTransferActivity);
            var flxNoRecords = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "358dp",
                "id": "flxNoRecords",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknffffffnosh",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoRecords.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Info"
                },
                "height": "40dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "30dp",
                "skin": "slImage",
                "src": "info_large.png",
                "top": "30dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxNoRecords = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "No Records found so far."
                },
                "id": "rtxNoRecords",
                "isVisible": true,
                "left": "85dp",
                "skin": "sknRtxSSPLight42424224Px",
                "text": "No Records found so far.\n",
                "top": "35dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoRecords.add(imgInfo, rtxNoRecords);
            flxActivityMain.add(flxActivityHeader, flxSeparator, flxDetails, flxSeparatorDetails, flxSort, flxSeparatorSort, flxSegment, flxNoRecords);
            var flxbtn = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100dp",
                "id": "flxbtn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxbtn.setDefaultUnit(kony.flex.DP);
            var btnbacktopayeelist = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    },
                    "a11yLabel": "Back To Payee List"
                },
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40dp",
                "id": "btnbacktopayeelist",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.BACKTOPAYEELIST\")",
                "top": "22dp",
                "width": "257dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px",
                "toolTip": "Back to Payee List"
            });
            flxbtn.add(btnbacktopayeelist);
            flxLeft.add(flxActivityMain, flxbtn);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxTotalEbillAmountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "clipBounds": false,
                "id": "flxTotalEbillAmountDue",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalEbillAmountDue.setDefaultUnit(kony.flex.DP);
            var flxEbillAMountDueHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDueHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEbillAMountDueHeader.setDefaultUnit(kony.flex.DP);
            var lblTotalEbillAmountDue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblTotalEbillAmountDue",
                "isVisible": true,
                "left": "7.69%",
                "skin": "sknlLblSSPMedium42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.TotalEbillAmountDue\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            flxEbillAMountDueHeader.add(lblTotalEbillAmountDue, flxSeperator);
            var flxEbillAMountDue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxEbillAMountDue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxEbillAMountDue.setDefaultUnit(kony.flex.DP);
            var lblBills = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblBills",
                "isVisible": true,
                "left": "7.69%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.6ebills\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEbillAmountDueValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Add International Account"
                },
                "centerY": "50%",
                "id": "lblEbillAmountDueValue",
                "isVisible": true,
                "right": "7.69%",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$443.00",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEbillAMountDue.add(lblBills, lblEbillAmountDueValue);
            flxTotalEbillAmountDue.add(flxEbillAMountDueHeader, flxEbillAMountDue);
            var flxAddPayeeMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAddPayeeMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayeeMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var flxAddPayee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    },
                    "a11yLabel": "Add Payee"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxAddPayee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayee.setDefaultUnit(kony.flex.DP);
            var lblAddPayee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAddPayee",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.addPayee\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator3.setDefaultUnit(kony.flex.DP);
            flxSeperator3.add();
            flxAddPayee.add(lblAddPayee, flxSeperator3);
            var flxMakeOneTimePayment = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "link",
                        "tabindex": 0
                    },
                    "a11yLabel": "Make One Time Payment"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxMakeOneTimePayment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknFlxHover"
            });
            flxMakeOneTimePayment.setDefaultUnit(kony.flex.DP);
            var lblMakeOneTimePayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblMakeOneTimePayment",
                "isVisible": true,
                "left": "7.69%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.MAKEONETIMEPAYMENT\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMakeOneTimePayment.add(lblMakeOneTimePayment);
            flxAddPayeeMakeOneTimePayment.add(flxAddPayee, flxMakeOneTimePayment);
            flxRight.add(flxTotalEbillAmountDue, flxAddPayeeMakeOneTimePayment);
            flxMainContainer.add(flxLeft, flxRight);
            var flxNote = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxNote",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "35dp",
                "width": "1200px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNote.setDefaultUnit(kony.flex.DP);
            var lblTerms = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "5px",
                "centerX": "50%",
                "id": "lblTerms",
                "isVisible": true,
                "left": "0px",
                "skin": "sknlbla0a0a013px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.BillPay.TermsAndConditions\")",
                "top": "5px",
                "width": "97%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNote.add(lblTerms);
            flxContent.add(flxDowntimeWarning, flxMainContainer, flxNote);
            flxMain.add(lblPayABill, btnSkipRight, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1001,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxDelete = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDelete",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDelete.setDefaultUnit(kony.flex.DP);
            var deletePopup = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "deletePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDelete.add(deletePopup);
            flxDialogs.add(flxLogout, flxDelete);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "i18n_text": "kony.mb.BillPay.BillPay",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayABill": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxActivityMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxActivityHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDetails": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeftDetails": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFromAccountName": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "flxFromUser": {
                        "isVisible": false,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblFromUser": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknLblOLBFontIconsvs",
                        "text": "g",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRightDetails": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "49.50%"
                        },
                        "segmentProps": []
                    },
                    "lblAmountDeductedTitle": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "segmentProps": []
                    },
                    "lblAmountDeducted": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSort": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSeparatorSort": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "segTransferActivity": {
                        "data": [{
                            "lblActivityUser": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "r"
                            },
                            "lblAmount": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$21.3"
                            },
                            "lblAmount1": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "$21.3"
                            },
                            "lblAmountHeader": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Running Balance: "
                            },
                            "lblFrom": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "My Savings Accountâ€¦8765"
                            },
                            "lblFromHeader": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "From:"
                            },
                            "lblSeparator": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": ""
                            },
                            "lblStatus": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Pending"
                            },
                            "lblpaiddate": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "15-Oct-2017"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "BillPayMA",
                            "friendlyName": "flxBillPaymentActivityMobile"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxActivityUser": "flxActivityUser",
                            "flxAmount": "flxAmount",
                            "flxBillPaymentActivityMobile": "flxBillPaymentActivityMobile",
                            "flxFrom": "flxFrom",
                            "flxStatus": "flxStatus",
                            "flxpaiddate": "flxpaiddate",
                            "lblActivityUser": "lblActivityUser",
                            "lblAmount": "lblAmount",
                            "lblAmount1": "lblAmount1",
                            "lblAmountHeader": "lblAmountHeader",
                            "lblFrom": "lblFrom",
                            "lblFromHeader": "lblFromHeader",
                            "lblSeparator": "lblSeparator",
                            "lblStatus": "lblStatus",
                            "lblpaiddate": "lblpaiddate"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "BillPayMA"
                    },
                    "btnbacktopayeelist": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNote": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "segmentProps": []
                    },
                    "deletePopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "lblPayABill": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxActivityMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "lblActivityHeader": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxDetails": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "lblFromTitle": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxFromAccountName": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "flxFromUser": {
                        "isVisible": false,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "lblFromUser": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknLblOLBFontIconsvs",
                        "text": "g",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountName": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblAccountHolder": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblAmountDeductedTitle": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblFrom": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblDate": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblFromAccount": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblStatus": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxbtn": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "btnbacktopayeelist": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "212dp"
                        },
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxNote": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "130%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxFormContent": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "role": "main",
                                "tabindex": -1
                            }
                        },
                        "segmentProps": []
                    },
                    "lblPayABill": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "rtxDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "segmentProps": []
                    },
                    "flxActivityMain": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "flxActivityHeader": {
                        "segmentProps": []
                    },
                    "lblActivityHeader": {
                        "skin": "sknlbl42424217px",
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "segmentProps": []
                    },
                    "flxDetails": {
                        "segmentProps": []
                    },
                    "flxLeftDetails": {
                        "segmentProps": []
                    },
                    "lblFromTitle": {
                        "segmentProps": []
                    },
                    "flxFromAccountName": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxFromUser": {
                        "height": {
                            "type": "string",
                            "value": "25px"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "1px"
                        },
                        "width": {
                            "type": "string",
                            "value": "25px"
                        },
                        "segmentProps": []
                    },
                    "lblFromUser": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknLblOLBFontIconsvs",
                        "text": "g",
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountName": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccountHolder": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblAmountDeductedTitle": {
                        "segmentProps": []
                    },
                    "lblAmountDeducted": {
                        "segmentProps": []
                    },
                    "flxSeparatorDetails": {
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "segmentProps": []
                    },
                    "lblFrom": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "imgSortFrom": {
                        "segmentProps": []
                    },
                    "flxBills": {
                        "segmentProps": []
                    },
                    "lblBillsKey": {
                        "segmentProps": []
                    },
                    "flxDate": {
                        "segmentProps": []
                    },
                    "lblDate": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "imgSortDate": {
                        "segmentProps": []
                    },
                    "flxfromaccount": {
                        "segmentProps": []
                    },
                    "lblFromAccount": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "imgSortFromAccount": {
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "imgSortAmount": {
                        "segmentProps": []
                    },
                    "flxStatus": {
                        "segmentProps": []
                    },
                    "lblStatus": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "imgSortStatus": {
                        "segmentProps": []
                    },
                    "flxSeparatorSort": {
                        "segmentProps": []
                    },
                    "flxSegment": {
                        "segmentProps": []
                    },
                    "segTransferActivity": {
                        "segmentProps": []
                    },
                    "flxNoRecords": {
                        "segmentProps": []
                    },
                    "imgInfo": {
                        "segmentProps": []
                    },
                    "rtxNoRecords": {
                        "segmentProps": []
                    },
                    "flxbtn": {
                        "segmentProps": []
                    },
                    "btnbacktopayeelist": {
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalEbillAmountDue": {
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxEbillAMountDueHeader": {
                        "segmentProps": []
                    },
                    "lblTotalEbillAmountDue": {
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxEbillAMountDue": {
                        "segmentProps": []
                    },
                    "lblBills": {
                        "segmentProps": []
                    },
                    "lblEbillAmountDueValue": {
                        "segmentProps": []
                    },
                    "flxAddPayeeMakeOneTimePayment": {
                        "isVisible": true,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayee": {
                        "segmentProps": []
                    },
                    "lblAddPayee": {
                        "segmentProps": []
                    },
                    "flxSeperator3": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxMakeOneTimePayment": {
                        "segmentProps": []
                    },
                    "lblMakeOneTimePayment": {
                        "segmentProps": []
                    },
                    "flxNote": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "lblTerms": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "tabindex": -1
                            }
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "lblPayABill": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "segmentProps": []
                    },
                    "flxActivityMain": {
                        "skin": "slfBoxffffffB1R5",
                        "segmentProps": []
                    },
                    "lblActivityHeader": {
                        "skin": "sknlbl42424217px",
                        "segmentProps": []
                    },
                    "flxFromAccountName": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxFromUser": {
                        "height": {
                            "type": "string",
                            "value": "25px"
                        },
                        "isVisible": true,
                        "right": {
                            "type": "string",
                            "value": "10px"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "12px"
                        },
                        "width": {
                            "type": "string",
                            "value": "25px"
                        },
                        "segmentProps": []
                    },
                    "lblFromUser": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "sknLblOLBFontIconsvs",
                        "text": "g",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountName": {
                        "skin": "sknlbl424242Lato15pxWeight500",
                        "segmentProps": []
                    },
                    "lblAccountHolder": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknlbl424242Lato15pxWeight500",
                        "top": {
                            "type": "string",
                            "value": "13dp"
                        },
                        "segmentProps": []
                    },
                    "lblFrom": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblDate": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblFromAccount": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "lblStatus": {
                        "skin": "slLabel0d8a72616b3cc47",
                        "segmentProps": []
                    },
                    "flxRight": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.04%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "width": {
                            "type": "string",
                            "value": "28.40%"
                        },
                        "segmentProps": []
                    },
                    "flxTotalEbillAmountDue": {
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayeeMakeOneTimePayment": {
                        "isVisible": true,
                        "skin": "slfBoxffffffB1R5",
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator3": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "segmentProps": []
                    },
                    "flxNote": {
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "height": {
                            "type": "string",
                            "value": "268dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmPaymentActivity,
            "enabledForIdleTimeout": true,
            "id": "frmPaymentActivity",
            "init": controller.AS_Form_a19bcdd8799d467f9847f8d0f8b28825,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "title": "My Bills - Manage Payees",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "BillPayMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});