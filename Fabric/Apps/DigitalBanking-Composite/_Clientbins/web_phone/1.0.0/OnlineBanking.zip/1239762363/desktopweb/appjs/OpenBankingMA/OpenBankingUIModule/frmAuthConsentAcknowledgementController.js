define("OpenBankingMA/OpenBankingUIModule/userfrmAuthConsentAcknowledgementController", ['CommonUtilities', 'OLBConstants', 'FormControllerUtility', 'ViewConstants', 'CampaignUtility'], function(CommonUtilities, OLBConstants, FormControllerUtility, ViewConstants, CampaignUtility) {
    return {
        frmAuthConsentAcknowledgementInit: function() {
            this.view.preShow = this.preShowAuthConsentAck;
        },
        preShowAuthConsentAck: function() {
            try {
                var navManager = applicationManager.getNavigationManager();
                var errCode = navManager.getCustomInfo("errCode");
                if ("12505" === errCode) {
                    this.view.imgGreenTick.src = "in_progress.png";
                    this.view.lblSuccessMessage.text = kony.i18n.getLocalizedString("i18n.tppConsent.additionalApprovalsRequired");
                    this.view.lblBackTotppMsg.text = kony.i18n.getLocalizedString("i18n.tppConsent.additionalApprovalsMsg");
                } else {
                    this.view.imgGreenTick.src = "successful.png";
                    this.view.lblBackTotppMsg.text = kony.i18n.getLocalizedString("i18n.tppconsent.redirectingBack");
                    if (applicationManager.consentType === "PISP") {
                        this.view.lblSuccessMessage.text = kony.i18n.getLocalizedString("i18n.tppconsent.successMsg");
                    } else if (applicationManager.consentType === "CBP") {
                        this.view.lblSuccessMessage.text = kony.i18n.getLocalizedString("i18n.tppConsent.approvedSuccessMsg");
                    }
                }
                const configManager = applicationManager.getConfigurationManager();
                var timer = configManager.getTppNavigationTimer();
                if (timer === "" || kony.sdk.isNullOrUndefined(timer)) timer = 0;
                this.view.lblInfo.text = kony.i18n.getLocalizedString("i18n.tppconsent.navigationMsg") + " " + timer + " " + kony.i18n.getLocalizedString("i18n.wealth.seconds");
                this.bindevents();
                this.navigateTotpp();
            } catch (error) {
                kony.print("preShowfunc-->" + error);
            }
        },
        ///////********bindevents is used set thewidgets onclick and initialise the data*****////////
        bindevents: function() {
            try {
                this.view.btnContinue.onClick = this.onClickContinue;
                this.view.onDeviceBack = this.dummyfunc;
            } catch (error) {
                kony.print(" bindevents-->" + error);
            }
        },
        dummyfunc: function() {},
        onClickContinue: function() {
            try {
                var accMode = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                    "moduleName": "OpenBankingUIModule",
                    "appName": "OpenBankingMA"
                });
                var status = "";
                if (applicationManager.consentType === "PISP") {
                    status = kony.sdk.isNullOrUndefined(accMode.presentationController.consentStatus) ? "" : accMode.presentationController.consentStatus + "&consentType=PISP";
                } else if (applicationManager.consentType === "CBP") {
                    status = kony.sdk.isNullOrUndefined(accMode.presentationController.consentStatus) ? "" : accMode.presentationController.consentStatus + "&consentType=CBP";
                }
                var url = applicationManager.deeplinkSchemaName + "?status=" + status;
                let authMode = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule({
                    "moduleName": "AuthUIModule",
                    "appName": "AuthenticationMA"
                });
                authMode.presentationController.isTPPNavigation = true;
                applicationManager.gblDeepLink = false;
                //kony.application.openURL(url);
                kony.application.openURLAsync({
                    url: url,
                    isSameWindow: true
                });
            } catch (Error) {
                kony.print("Exception While getting exiting the application  : " + Error);
            }
        },
        navigateTotpp: function() {
            const configManager = applicationManager.getConfigurationManager();
            var timer = configManager.getTppNavigationTimer();
            if (timer === "" || kony.sdk.isNullOrUndefined(timer)) timer = 0;
            kony.timer.schedule("timer3", this.onClickContinue, timer, false);
        }
    }
});
define("OpenBankingMA/OpenBankingUIModule/frmAuthConsentAcknowledgementControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** init defined for frmAuthConsentAcknowledgement **/
    AS_Form_f9fea9d0975d41ca9aa74b93e6cc5619: function AS_Form_f9fea9d0975d41ca9aa74b93e6cc5619(eventobject) {
        var self = this;
        this.frmAuthConsentAcknowledgementInit();
    }
});
define("OpenBankingMA/OpenBankingUIModule/frmAuthConsentAcknowledgementController", ["OpenBankingMA/OpenBankingUIModule/userfrmAuthConsentAcknowledgementController", "OpenBankingMA/OpenBankingUIModule/frmAuthConsentAcknowledgementControllerActions"], function() {
    var controller = require("OpenBankingMA/OpenBankingUIModule/userfrmAuthConsentAcknowledgementController");
    var controllerActions = ["OpenBankingMA/OpenBankingUIModule/frmAuthConsentAcknowledgementControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
