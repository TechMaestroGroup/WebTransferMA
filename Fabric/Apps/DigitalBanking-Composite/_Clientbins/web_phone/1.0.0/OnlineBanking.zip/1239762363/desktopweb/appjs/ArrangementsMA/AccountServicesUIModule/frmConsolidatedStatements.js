define("ArrangementsMA/AccountServicesUIModule/frmConsolidatedStatements", function() {
    return function(controller) {
        function addWidgetsfrmConsolidatedStatements() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderPostLogin = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderPostLogin",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderPostLogin.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121dp",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "CopyimgToolTip0i580d9acc07c42": {
                        "src": "golden_card.png"
                    },
                    "customhamburger.imgCollapseAccounts": {
                        "src": "arrow_down.png"
                    },
                    "customhamburger.imgKony": {
                        "src": "kony_logo_white.png"
                    },
                    "customheader": {
                        "zIndex": 1000
                    },
                    "flxHamburger": {
                        "left": "-35%",
                        "width": "35%",
                        "zIndex": 900
                    },
                    "flxTopmenu": {
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": false
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.flxHelp": {
                        "isVisible": false,
                        "right": "5%",
                        "width": "70dp"
                    },
                    "topmenu.lblFeedback": {
                        "isVisible": false,
                        "text": "HELP"
                    },
                    "topmenu.lblHelp": {
                        "centerX": "50%",
                        "isVisible": true,
                        "right": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderPostLogin.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8Border0",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxFeedback = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxFeedback",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxf8f7f8",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedback.setDefaultUnit(kony.flex.DP);
            var flxAccountsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "65dp",
                "id": "flxAccountsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsHeader.setDefaultUnit(kony.flex.DP);
            var lblConsolidatedStatements = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblConsolidatedStatements",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.olb.ViewCombinedStatement\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFilterListBox = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFilterListBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "sknFlxFFFFFFBorderE3E3E3NoRadius",
                "top": "15dp",
                "width": "210dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterListBox.setDefaultUnit(kony.flex.DP);
            var lblSelectedFilter = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.DashboardFilter.allAccounts\")",
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSelectedFilter",
                "isVisible": true,
                "left": "2%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.DashboardFilter.allAccounts\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropDown = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "lblSelectedFilter",
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "4.30%",
                "skin": "sknFlxHover",
                "width": "22dp",
                "zIndex": 10,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDown.setDefaultUnit(kony.flex.DP);
            var lblDropDown = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.profile.Collapse\")",
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "10dp",
                "id": "lblDropDown",
                "isVisible": true,
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": "10dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDown.add(lblDropDown);
            flxFilterListBox.add(lblSelectedFilter, flxDropDown);
            var flxAccountsFilter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAccountsFilter",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "6%",
                "skin": "sknFlxffffff",
                "top": "175dp",
                "width": "250dp",
                "zIndex": 25,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsFilter.setDefaultUnit(kony.flex.DP);
            var flxAllAccounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAllAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "14dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAllAccounts.setDefaultUnit(kony.flex.DP);
            var lblAccounts = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.DashboardFilter.allAccounts\")"
                },
                "id": "lblAccounts",
                "isVisible": true,
                "left": "20px",
                "skin": "sknLbl003e75SSP15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.DashboardFilter.allAccounts\")",
                "top": "0dp",
                "width": "200px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropDownAccounts = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": true,
                        "aria-labelledby": "lblAccounts",
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "22dp",
                "id": "flxDropDownAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "10px",
                "skin": "sknFlxHover",
                "top": "0dp",
                "width": "22dp",
                "zIndex": 10,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDownAccounts.setDefaultUnit(kony.flex.DP);
            var lblDropDownAccounts = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.profile.Collapse\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblDropDownAccounts",
                "isVisible": true,
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "top": "0px",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDownAccounts.add(lblDropDownAccounts);
            flxAllAccounts.add(lblAccounts, flxDropDownAccounts);
            var accountsFilter = new com.InfinityOLB.ArrangementsMA.combinedAccessAccountsFilter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "accountsFilter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ArrangementsMA",
                "overrides": {
                    "combinedAccessAccountsFilter": {
                        "isVisible": true,
                        "left": 0,
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%",
                        "zIndex": 10
                    },
                    "flxCustomFilterWrapper": {
                        "isVisible": false
                    },
                    "flxOrLine": {
                        "isVisible": false
                    },
                    "lblDefaultFiltersHeader": {
                        "isVisible": false
                    },
                    "segDefaultFilters": {
                        "data": [{
                            "lblDelete": "",
                            "lblEdit": "",
                            "lblFilterValue": "personal accounts",
                            "lblRadioButton": "L"
                        }, {
                            "lblDelete": "",
                            "lblEdit": "",
                            "lblFilterValue": "Favourite Accounts",
                            "lblRadioButton": "M"
                        }, {
                            "lblDelete": "",
                            "lblEdit": "",
                            "lblFilterValue": "",
                            "lblRadioButton": ""
                        }, {
                            "lblDelete": "",
                            "lblEdit": "",
                            "lblFilterValue": "",
                            "lblRadioButton": ""
                        }, {
                            "lblDelete": "",
                            "lblEdit": "",
                            "lblFilterValue": "",
                            "lblRadioButton": ""
                        }, {
                            "lblDelete": "",
                            "lblEdit": "",
                            "lblFilterValue": "",
                            "lblRadioButton": ""
                        }, {
                            "lblDelete": "",
                            "lblEdit": "",
                            "lblFilterValue": "",
                            "lblRadioButton": ""
                        }, {
                            "lblDelete": "",
                            "lblEdit": "",
                            "lblFilterValue": "",
                            "lblRadioButton": ""
                        }, {
                            "lblDelete": "",
                            "lblEdit": "",
                            "lblFilterValue": "",
                            "lblRadioButton": ""
                        }, {
                            "lblDelete": "",
                            "lblEdit": "",
                            "lblFilterValue": "",
                            "lblRadioButton": ""
                        }],
                        "left": "0dp",
                        "top": "5dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAccountsFilter.add(flxAllAccounts, accountsFilter);
            flxAccountsHeader.add(lblConsolidatedStatements, flxFilterListBox, flxAccountsFilter);
            var flxFeedbackContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFeedbackContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "4.30%",
                "isModalContainer": false,
                "right": "62dp",
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeedbackContainer.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerX": "50%",
                "clipBounds": true,
                "height": "40px",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                    "tagName": "span"
                },
                "bottom": "8dp",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "40dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "8dp",
                "width": "86.50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblImgCloseDowntimeWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "lblImgCloseDowntimeWarning",
                "isVisible": true,
                "right": "10dp",
                "skin": "sknOlbFonts0273e315px",
                "text": "g",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, lblImgCloseDowntimeWarning);
            var flxRightContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "100dp",
                "id": "flxRightContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "60dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainer.setDefaultUnit(kony.flex.DP);
            var flxFromDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "70dp",
                "id": "flxFromDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "25dp",
                "isModalContainer": false,
                "onTouchEnd": controller.AS_FlexContainer_a88c150d121a4c4d97a841e9c5994b72,
                "onTouchStart": controller.AS_FlexContainer_bb8a4585955648538d4b0f651600fe3e,
                "skin": "slFbox",
                "top": "15dp",
                "width": "215dp",
                "zIndex": 2,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromDate.setDefaultUnit(kony.flex.DP);
            var lblFromDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFromDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.fromDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1200
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var calFromDate = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": [null, null, null],
                "dateFormat": "dd/MM/yyyy",
                "focusSkin": "sknCalTransactionsFocus",
                "height": "40dp",
                "hour": 0,
                "id": "calFromDate",
                "isVisible": true,
                "left": 0,
                "minutes": 0,
                "onTouchStart": controller.AS_Calendar_b31f37f2d1e043459ec67d1ebe3da9a0,
                "placeholder": "Select Date Here",
                "seconds": 0,
                "skin": "sknCalTransactions",
                "top": "8dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [3, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxFromDate.add(lblFromDate, calFromDate);
            var flxToDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70dp",
                "id": "flxToDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "onTouchEnd": controller.AS_FlexContainer_a88c150d121a4c4d97a841e9c5994b72,
                "onTouchStart": controller.AS_FlexContainer_bb8a4585955648538d4b0f651600fe3e,
                "skin": "slFbox",
                "top": "15dp",
                "width": "215dp",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxToDate.setDefaultUnit(kony.flex.DP);
            var lblToDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblToDate",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.toDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1200
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var calToDate = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": [null, null, null],
                "dateFormat": "dd/MM/yyyy",
                "focusSkin": "sknCalTransactionsFocus",
                "height": "40dp",
                "hour": 0,
                "id": "calToDate",
                "isVisible": true,
                "left": "0dp",
                "minutes": 0,
                "onTouchStart": controller.AS_Calendar_b31f37f2d1e043459ec67d1ebe3da9a0,
                "seconds": 0,
                "skin": "sknCalTransactions",
                "top": "8dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 1, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxToDate.add(lblToDate, calToDate);
            flxRightContainer.add(flxFromDate, flxToDate);
            var flxAccountsSegments = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "9dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAccountsSegments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsSegments.setDefaultUnit(kony.flex.DP);
            var segAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "lblAccountTypeHeader": "Personal Bank Accounts",
                            "lblBottomSeperator": "",
                            "lblCheckBox": "D",
                            "lblDropDown": "O",
                            "lblSelectAll": "SelectAll",
                            "lblTopSeperator": ""
                        },
                        [{
                            "lblAccountName": "Checking Account Nickname….2365",
                            "lblAccountType": "Checkings",
                            "lblCheckBox": "D",
                            "lblCheckBoxRight": "D",
                            "lblRightAccountName": "Checking Account Nickname….2365",
                            "lblRightAccountType": "Checkings"
                        }, {
                            "lblAccountName": "Checking Account Nickname….2365",
                            "lblAccountType": "Checkings",
                            "lblCheckBox": "D",
                            "lblCheckBoxRight": "D",
                            "lblRightAccountName": "Checking Account Nickname….2365",
                            "lblRightAccountType": "Checkings"
                        }]
                    ],
                    [{
                            "lblAccountTypeHeader": "Company ABC Accounts",
                            "lblBottomSeperator": "",
                            "lblCheckBox": "D",
                            "lblDropDown": "O",
                            "lblSelectAll": "SelectAll",
                            "lblTopSeperator": ""
                        },
                        [{
                            "lblAccountName": "Checking Account Nickname….2365",
                            "lblAccountType": "Checkings",
                            "lblCheckBox": "D",
                            "lblCheckBoxRight": "D",
                            "lblRightAccountName": "Checking Account Nickname….2365",
                            "lblRightAccountType": "Checkings"
                        }, {
                            "lblAccountName": "Checking Account Nickname….2365",
                            "lblAccountType": "Checkings",
                            "lblCheckBox": "D",
                            "lblCheckBoxRight": "D",
                            "lblRightAccountName": "Checking Account Nickname….2365",
                            "lblRightAccountType": "Checkings"
                        }]
                    ],
                    [{
                            "lblAccountTypeHeader": "Company XYZ Accounts",
                            "lblBottomSeperator": "",
                            "lblCheckBox": "D",
                            "lblDropDown": "O",
                            "lblSelectAll": "SelectAll",
                            "lblTopSeperator": ""
                        },
                        [{
                            "lblAccountName": "Checking Account Nickname….2365",
                            "lblAccountType": "Checkings",
                            "lblCheckBox": "D",
                            "lblCheckBoxRight": "D",
                            "lblRightAccountName": "Checking Account Nickname….2365",
                            "lblRightAccountType": "Checkings"
                        }, {
                            "lblAccountName": "Checking Account Nickname….2365",
                            "lblAccountType": "Checkings",
                            "lblCheckBox": "D",
                            "lblCheckBoxRight": "D",
                            "lblRightAccountName": "Checking Account Nickname….2365",
                            "lblRightAccountType": "Checkings"
                        }, {
                            "lblAccountName": "Checking Account Nickname….2365",
                            "lblAccountType": "Checkings",
                            "lblCheckBox": "D",
                            "lblCheckBoxRight": "D",
                            "lblRightAccountName": "",
                            "lblRightAccountType": ""
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segAccounts",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "right": "0dp",
                "rowSkin": "sknSegDefault",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxAccountsConsolidatedListItem"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxAccountsConsolidatedSectionHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAccountListItemWrapper": "flxAccountListItemWrapper",
                    "flxAccountName": "flxAccountName",
                    "flxAccountsConsolidatedListItem": "flxAccountsConsolidatedListItem",
                    "flxAccountsConsolidatedSectionHeader": "flxAccountsConsolidatedSectionHeader",
                    "flxCheckBox": "flxCheckBox",
                    "flxDropdownTablet": "flxDropdownTablet",
                    "flxHeaderName": "flxHeaderName",
                    "flxHeaderWrapper": "flxHeaderWrapper",
                    "flxLeftAccounts": "flxLeftAccounts",
                    "flxRightAccountName": "flxRightAccountName",
                    "flxRightAccounts": "flxRightAccounts",
                    "flxRightCheckBox": "flxRightCheckBox",
                    "flxSelectAllDropdown": "flxSelectAllDropdown",
                    "flxbottomSpace": "flxbottomSpace",
                    "lblAccountName": "lblAccountName",
                    "lblAccountType": "lblAccountType",
                    "lblAccountTypeHeader": "lblAccountTypeHeader",
                    "lblBottomSeperator": "lblBottomSeperator",
                    "lblCheckBox": "lblCheckBox",
                    "lblCheckBoxRight": "lblCheckBoxRight",
                    "lblDropDown": "lblDropDown",
                    "lblRightAccountName": "lblRightAccountName",
                    "lblRightAccountType": "lblRightAccountType",
                    "lblSelectAll": "lblSelectAll",
                    "lblTopSeperator": "lblTopSeperator"
                },
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTitleSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "8dp",
                "id": "flxTitleSeparator",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxffffff",
                "top": "-8dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTitleSeparator.setDefaultUnit(kony.flex.DP);
            flxTitleSeparator.add();
            flxAccountsSegments.add(segAccounts, flxTitleSeparator);
            flxFeedbackContainer.add(flxDowntimeWarning, flxRightContainer, flxAccountsSegments);
            var flxActions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "right": "6%",
                "skin": "flxActionsnoshadownoborcolor",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActions.setDefaultUnit(kony.flex.DP);
            var btnDownloadStatements = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Continue to generate combined statement"
                },
                "height": "40px",
                "id": "btnDownloadStatements",
                "isVisible": true,
                "onClick": controller.AS_Button_b327ea659ba04b38b7151c4754cbdd87,
                "right": "0dp",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.btnContinue\")",
                "top": "30dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancelStatement = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Cancel generation of combined statement"
                },
                "height": "40px",
                "id": "btnCancelStatement",
                "isVisible": true,
                "onClick": controller.AS_Button_deffb6475d224738b167372143757305,
                "right": "280dp",
                "skin": "sknBtnSecondaryFocusSSP3343a815Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.btnCancel\")",
                "top": "30dp",
                "width": "260dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxActions.add(btnDownloadStatements, btnCancelStatement);
            flxFeedback.add(flxAccountsHeader, flxFeedbackContainer, flxActions);
            flxMainContainer.add(flxFeedback);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": 1000,
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customFooterMaincs = new com.InfinityOLB.Resources.customfooter({
                "centerX": "50%",
                "height": "105dp",
                "id": "customFooterMaincs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": 0,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366px",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooter": {
                        "centerX": "50%",
                        "height": "105dp",
                        "left": "0dp",
                        "right": 0,
                        "top": "0dp",
                        "width": "1366px",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": 0,
                        "top": "26.60%",
                        "width": "1200dp"
                    },
                    "imgFooterIconOne": {
                        "src": "footer_logo_1.png"
                    },
                    "imgFooterIconThree": {
                        "src": "footer_logo_3.png"
                    },
                    "imgFooterIconTwo": {
                        "src": "footer_logo_2.png"
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyright\")",
                        "left": "0%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customFooterMaincs);
            flxFormContent.add(flxMainContainer, flxFooter);
            var flxPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0i94559a2949d45",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1200,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var customPopupcs = new com.InfinityOLB.Resources.CustomPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "customPopupcs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "43%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "50%",
                        "width": "43%"
                    },
                    "btnNo": {
                        "isVisible": true,
                        "left": "5.48%",
                        "right": "viz.val_cleared"
                    },
                    "btnYes": {
                        "right": "4.89%"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfer.QuitTransfer\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"I18n.billPay.QuitTransactionMsg\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(customPopupcs);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var customPopupLogoutcs = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "customPopupLogoutcs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(customPopupLogoutcs);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "145dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "145dp",
                "zIndex": 1000,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxDownladstatementspopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDownladstatementspopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "CopyslFbox0c69b7ae145714d",
                "top": "0%",
                "width": "100%",
                "zIndex": 1200,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownladstatementspopup.setDefaultUnit(kony.flex.DP);
            var flxPopupDownloadStatements = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxPopupDownloadStatements",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "Copysknflxffffff",
                "top": "250dp",
                "width": "45%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupDownloadStatements.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "52px",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox3",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "30px",
                "id": "lblHeader",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.combinedStatements.GenarateStatement\")",
                "top": "11px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClosePopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close This Popup"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "15dp",
                "id": "flxClosePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "15dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClosePopup.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "height": "15dp",
                "id": "imgClose",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "94.71%",
                "onTouchStart": controller.AS_Image_c8fbb9053bcb4c5a8ae803cc949aa7f7,
                "right": "0px",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "top": "0dp",
                "width": "15px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClosePopup.add(imgClose);
            flxHeader.add(lblHeader, flxClosePopup);
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxd8d8d8Opacity60",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            var flxDowntimeWarninginPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarninginPopup",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarninginPopup.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarninginPopup = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarninginPopup",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarninginPopup = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Error Message"
                },
                "centerY": "50%",
                "id": "lblDowntimeWarninginPopup",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "text": "Error Message",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarninginPopup = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "height": "40dp",
                "id": "imgCloseDowntimeWarninginPopup",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarninginPopup.add(imgDowntimeWarninginPopup, lblDowntimeWarninginPopup, imgCloseDowntimeWarninginPopup);
            var flxMiddle = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "148px",
                "id": "flxMiddle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddle.setDefaultUnit(kony.flex.DP);
            var lblPickDateRange = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "30px",
                "id": "lblPickDateRange",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknLblSSP72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.TimePeriod\")",
                "top": "23px",
                "width": "20.90%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelectedDateRange = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "30px",
                "id": "lblSelectedDateRange",
                "isVisible": true,
                "right": "4%",
                "skin": "sknLblSSP72727213px",
                "text": "Time Period:",
                "top": "23px",
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSelectFormat = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "30px",
                "id": "lblSelectFormat",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknLblSSP72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.Loans.selectFormat\")",
                "top": "80px",
                "width": "20.80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperators2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperators2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3.77%",
                "isModalContainer": false,
                "right": "5%",
                "skin": "sknflxd8d8d8Opacity60",
                "top": "70px",
                "width": "92%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperators2.setDefaultUnit(kony.flex.DP);
            flxSeperators2.add();
            var lbxSelectFormat = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxSelectFormat",
                "isVisible": false,
                "masterData": [
                    ["Key319901533", "kony.i18n.getLocalizedString(\"i18N.common.pdf\")"],
                    ["Key952666864", "kony.i18n.getLocalizedString(\"i18N.common.Excel\")"],
                    ["Key2201254308", "kony.i18n.getLocalizedString(\"i18N.common.csv\")"]
                ],
                "right": "4%",
                "selectedKey": "Key319901533",
                "skin": "sknLbx4a4a4a15Px",
                "top": "76px",
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var flxFilterListBoxPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "lblSelectFormat",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFilterListBoxPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20px",
                "skin": "sknBorderE3E3E3",
                "top": "107px",
                "width": "310px",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFilterListBoxPopup.setDefaultUnit(kony.flex.DP);
            var lblSelectedFilterpopup = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblSelectedFilterpopup",
                "isVisible": true,
                "left": "15px",
                "skin": "sknLblSSPSemiBold0e4a7f15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18N.common.pdf\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropDownPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flxDropDownPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "19px",
                "skin": "sknFlxHover",
                "width": "22dp",
                "zIndex": 10,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDownPopup.setDefaultUnit(kony.flex.DP);
            var lblDropDownPopup = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.profile.Collapse\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblDropDownPopup",
                "isVisible": true,
                "skin": "skn0273e315pxolbfonticons",
                "text": "O",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDownPopup.add(lblDropDownPopup);
            flxFilterListBoxPopup.add(lblSelectedFilterpopup, flxDropDownPopup);
            flxMiddle.add(lblPickDateRange, lblSelectedDateRange, lblSelectFormat, flxSeperators2, lbxSelectFormat, flxFilterListBoxPopup);
            var flxSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxd8d8d8Opacity60",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator2.setDefaultUnit(kony.flex.DP);
            flxSeperator2.add();
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "119px",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var flxDefaultFiltersWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDefaultFiltersWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20px",
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "310px",
                "zIndex": 20,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDefaultFiltersWrapper.setDefaultUnit(kony.flex.DP);
            var segFileFilters = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblFilterValue": "kony.i18n.getLocalizedString(\"i18N.common.pdf\")"
                }, {
                    "lblFilterValue": "kony.i18n.getLocalizedString(\"i18N.common.Excel\")"
                }, {
                    "lblFilterValue": "kony.i18n.getLocalizedString(\"i18N.common.csv\")"
                }],
                "groupCells": false,
                "id": "segFileFilters",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxFileFilter"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFileFilter": "flxFileFilter",
                    "lblFilterValue": "lblFilterValue"
                },
                "width": "100%",
                "zIndex": 30,
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDefaultFiltersWrapper.add(segFileFilters);
            var btnDownload = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Create statement"
                },
                "centerY": "50%",
                "height": "40px",
                "id": "btnDownload",
                "isVisible": true,
                "onClick": controller.AS_Button_c49aeb49ac3b4cbcbea92bbafb973cb9,
                "right": "4%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.enrollNow.Create\")",
                "width": "150px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Download"
            });
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Cancel and modify account selection"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "onClick": controller.AS_Button_aa13974666a14aba845b0bdd5a5582a2,
                "right": "304dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px",
                "toolTip": "Cancel"
            });
            flxButtons.add(flxDefaultFiltersWrapper, btnDownload, btnCancel);
            flxPopupDownloadStatements.add(flxHeader, flxSeperator, flxDowntimeWarninginPopup, flxMiddle, flxSeperator2, flxButtons);
            flxDownladstatementspopup.add(flxPopupDownloadStatements);
            var flxGenerateStatementsPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxGenerateStatementsPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": true,
                "skin": "CopyslFbox0c69b7ae145714d",
                "top": "0%",
                "width": "100%",
                "zIndex": 1200,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGenerateStatementsPopup.setDefaultUnit(kony.flex.DP);
            var flxGenerateStatement = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxGenerateStatement",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "Copysknflxffffff",
                "top": "250dp",
                "width": "45%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGenerateStatement.setDefaultUnit(kony.flex.DP);
            var flxHeaderNotification = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52px",
                "id": "flxHeaderNotification",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyCopyslFbox3",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderNotification.setDefaultUnit(kony.flex.DP);
            var lblSystemNotification = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50%",
                "height": "30px",
                "id": "lblSystemNotification",
                "isVisible": true,
                "left": "3.77%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.combinedStatements.systemNotification\")",
                "top": "11px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCloseNotificationPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close This Popup"
                },
                "clipBounds": false,
                "height": "20dp",
                "id": "flxCloseNotificationPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCloseNotificationPopup.setDefaultUnit(kony.flex.DP);
            var imgNotificationClose = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "imgNotificationClose",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "94.71%",
                "onTouchStart": controller.AS_Image_dad257f1c3504ddf853a195260b6e318,
                "right": "11dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "width": "15px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseNotificationPopup.add(imgNotificationClose);
            flxHeaderNotification.add(lblSystemNotification, flxCloseNotificationPopup);
            var flxTopSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxTopSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxd8d8d8Opacity60",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeperator.setDefaultUnit(kony.flex.DP);
            flxTopSeperator.add();
            var flxpopupDowntimeWarninging = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxpopupDowntimeWarninging",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxpopupDowntimeWarninging.setDefaultUnit(kony.flex.DP);
            var imgDowntimePopup = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimePopup",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeErrorMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Error Message"
                },
                "centerY": "50%",
                "id": "lblDowntimeErrorMessage",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "text": "Error Message",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimePopup = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "height": "40dp",
                "id": "imgCloseDowntimePopup",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxpopupDowntimeWarninging.add(imgDowntimePopup, lblDowntimeErrorMessage, imgCloseDowntimePopup);
            var flxPreparingStatement = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "148px",
                "id": "flxPreparingStatement",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPreparingStatement.setDefaultUnit(kony.flex.DP);
            var imgPreparingStatement = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "height": "40dp",
                "id": "imgPreparingStatement",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "20dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPreparingStatementmessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": 50,
                "centerX": "50%",
                "id": "lblPreparingStatementmessage",
                "isVisible": true,
                "skin": "ICSknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.combinedStatements.preparingStatement\")",
                "top": "10dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPreparingStatement.add(imgPreparingStatement, lblPreparingStatementmessage);
            var flxOkay = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "109px",
                "id": "flxOkay",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox3",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOkay.setDefaultUnit(kony.flex.DP);
            var btnOkay = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "Back to statement list"
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "btnOkay",
                "isVisible": true,
                "onClick": controller.AS_Button_ea6036f7f9514380a64426aa4b1ef38a,
                "right": "4%",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.ok\")",
                "width": "210dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px"
            });
            flxOkay.add(btnOkay);
            flxGenerateStatement.add(flxHeaderNotification, flxTopSeperator, flxpopupDowntimeWarninging, flxPreparingStatement, flxOkay);
            flxGenerateStatementsPopup.add(flxGenerateStatement);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeaderPostLogin": {
                        "height": {
                            "type": "string",
                            "value": "51dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "customheader.customhamburger.flxMenuWrapper": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxBottomBlue": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.flxBottomContainer": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHamburger": {
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "Combined Statements",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxContextualMenu": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblFeedback": {
                        "text": "Combined Statements",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFeedback": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "zIndex": 50,
                        "segmentProps": []
                    },
                    "lblConsolidatedStatements": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFilterListBox": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedFilter": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "padding": [1, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "15%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxDropDown": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblDropDown": {
                        "segmentProps": []
                    },
                    "flxAccountsFilter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblAccounts": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "padding": [1, 0, 0, 0],
                        "segmentProps": []
                    },
                    "flxDropDownAccounts": {
                        "segmentProps": []
                    },
                    "accountsFilter": {
                        "segmentProps": [],
                        "instanceId": "accountsFilter"
                    },
                    "flxFeedbackContainer": {
                        "isVisible": true,
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "segmentProps": []
                    },
                    "lblImgCloseDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFromDate": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "calFromDate": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxToDate": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93%"
                        },
                        "segmentProps": []
                    },
                    "calToDate": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxActions": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnDownloadStatements": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.75%"
                        },
                        "segmentProps": []
                    },
                    "btnCancelStatement": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.75%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customFooterMaincs.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customFooterMaincs.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customFooterMaincs": {
                        "segmentProps": []
                    },
                    "customFooterMaincs.flxFooterMenu": {
                        "top": {
                            "type": "string",
                            "value": "40%"
                        },
                        "width": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customFooterMaincs.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customFooterMaincs.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customFooterMaincs.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customFooterMaincs.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customFooterMaincs.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customFooterMaincs.lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "280dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownladstatementspopup": {
                        "segmentProps": []
                    },
                    "flxPopupDownloadStatements": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "string",
                            "value": "93.44%"
                        },
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "imgClose": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "closeicon.png",
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarninginPopup": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxMiddle": {
                        "height": {
                            "type": "string",
                            "value": "165px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblPickDateRange": {
                        "left": {
                            "type": "string",
                            "value": "6.25%"
                        },
                        "skin": "sknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedDateRange": {
                        "left": {
                            "type": "string",
                            "value": "6.25%"
                        },
                        "skin": "sknLblSSP42424215px",
                        "text": "Time Period:",
                        "top": {
                            "type": "string",
                            "value": "45px"
                        },
                        "segmentProps": []
                    },
                    "lblSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "6.25%"
                        },
                        "skin": "sknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "85px"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperators2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lbxSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "6.25%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "Copysknlbxalto13px",
                        "top": {
                            "type": "string",
                            "value": "112px"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.25%"
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBoxPopup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6.25%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknBorderE3E3E3",
                        "top": {
                            "type": "string",
                            "value": "122px"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.20%"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedFilterpopup": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "padding": [1, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": "15%"
                        },
                        "skin": "sknLblSSP42424213px",
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxDropDownPopup": {
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDefaultFiltersWrapper": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "segFileFilters": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnDownload": {
                        "right": {
                            "type": "string",
                            "value": "6.21%"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "54%"
                        },
                        "width": {
                            "type": "string",
                            "value": "40%"
                        },
                        "segmentProps": []
                    },
                    "flxGenerateStatementsPopup": {
                        "segmentProps": []
                    },
                    "flxGenerateStatement": {
                        "height": {
                            "type": "string",
                            "value": "292dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "225dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "299dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseNotificationPopup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "imgNotificationClose": {
                        "height": {
                            "type": "string",
                            "value": "15px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "closeicon.png",
                        "width": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDowntimePopup": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgPreparingStatement": {
                        "src": "inprogress.png",
                        "segmentProps": []
                    },
                    "flxOkay": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "btnOkay": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18px"
                        },
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "",
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "right": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "16%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeedback": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "zIndex": 105,
                        "segmentProps": []
                    },
                    "flxFilterListBox": {
                        "segmentProps": []
                    },
                    "lblSelectedFilter": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsFilter": {
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccounts": {
                        "segmentProps": []
                    },
                    "flxFeedbackContainer": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "calFromDate": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "paddingLocked": false,
                        "segmentProps": []
                    },
                    "flxActions": {
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnDownloadStatements": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelStatement": {
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "customFooterMaincs.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs": {
                        "segmentProps": []
                    },
                    "customFooterMaincs.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.lblCopyright": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxDownladstatementspopup": {
                        "segmentProps": []
                    },
                    "flxPopupDownloadStatements": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "25px"
                        },
                        "width": {
                            "type": "string",
                            "value": "470px"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "left": {
                            "type": "string",
                            "value": "15px"
                        },
                        "top": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "imgClose": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "closeicon.png",
                        "segmentProps": []
                    },
                    "imgCloseDowntimeWarninginPopup": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "lblPickDateRange": {
                        "left": {
                            "type": "string",
                            "value": "15px"
                        },
                        "skin": "sknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "23px"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedDateRange": {
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "skin": "sknLblSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "22px"
                        },
                        "width": {
                            "type": "string",
                            "value": "310px"
                        },
                        "segmentProps": []
                    },
                    "lblSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "15px"
                        },
                        "skin": "sknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "107px"
                        },
                        "segmentProps": []
                    },
                    "flxSeperators2": {
                        "top": {
                            "type": "string",
                            "value": "67px"
                        },
                        "segmentProps": []
                    },
                    "lbxSelectFormat": {
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "skin": "Copysknlbxalto13px",
                        "top": {
                            "type": "string",
                            "value": "107px"
                        },
                        "width": {
                            "type": "string",
                            "value": "310px"
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBoxPopup": {
                        "segmentProps": []
                    },
                    "lblSelectedFilterpopup": {
                        "skin": "sknLblSSP42424213px",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxDefaultFiltersWrapper": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnDownload": {
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "180px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "flxGenerateStatement": {
                        "height": {
                            "type": "string",
                            "value": "291dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "469dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseNotificationPopup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "segmentProps": []
                    },
                    "imgNotificationClose": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "closeicon.png",
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "imgCloseDowntimePopup": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": []
                    },
                    "imgPreparingStatement": {
                        "src": "inprogress.png",
                        "segmentProps": []
                    },
                    "flxOkay": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "btnOkay": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Ok",
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxHeaderPostLogin": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "segmentProps": []
                    },
                    "customheader.lblHeaderMobile": {
                        "text": "Feedback",
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "segmentProps": []
                    },
                    "flxFeedback": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "zIndex": 50,
                        "segmentProps": []
                    },
                    "flxFilterListBox": {
                        "segmentProps": []
                    },
                    "lblSelectedFilter": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsFilter": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccounts": {
                        "segmentProps": []
                    },
                    "flxFeedbackContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "6%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "lblDowntimeWarning": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "lblImgCloseDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFromDate": {
                        "segmentProps": []
                    },
                    "calFromDate": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "paddingLocked": true,
                        "segmentProps": []
                    },
                    "flxToDate": {
                        "segmentProps": []
                    },
                    "calToDate": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "flxActions": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnCancelStatement": {
                        "i18n_text": "i18n.TransfersEur.btnCancel",
                        "text": "Cancel",
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "customFooterMaincs": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.lblCopyright": {
                        "segmentProps": []
                    },
                    "flxPopup": {
                        "segmentProps": []
                    },
                    "flxDownladstatementspopup": {
                        "segmentProps": []
                    },
                    "flxPopupDownloadStatements": {
                        "top": {
                            "type": "string",
                            "value": "240px"
                        },
                        "width": {
                            "type": "string",
                            "value": "470px"
                        },
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "46px"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "15px"
                        },
                        "segmentProps": []
                    },
                    "imgClose": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "closeicon.png",
                        "segmentProps": []
                    },
                    "lblPickDateRange": {
                        "left": {
                            "type": "string",
                            "value": "15px"
                        },
                        "skin": "sknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "22px"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedDateRange": {
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "skin": "sknLblSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "22px"
                        },
                        "width": {
                            "type": "string",
                            "value": "310px"
                        },
                        "segmentProps": []
                    },
                    "lblSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "15px"
                        },
                        "skin": "sknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "107px"
                        },
                        "segmentProps": []
                    },
                    "flxSeperators2": {
                        "top": {
                            "type": "string",
                            "value": "67px"
                        },
                        "segmentProps": []
                    },
                    "lbxSelectFormat": {
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "skin": "Copysknlbxalto13px",
                        "top": {
                            "type": "string",
                            "value": "107px"
                        },
                        "width": {
                            "type": "string",
                            "value": "310px"
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBoxPopup": {
                        "segmentProps": []
                    },
                    "lblSelectedFilterpopup": {
                        "skin": "sknLblSSP42424213px",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "btnDownload": {
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "text": "Create",
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "right": {
                            "type": "string",
                            "value": "180px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "flxGenerateStatementsPopup": {
                        "segmentProps": []
                    },
                    "flxGenerateStatement": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "291dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "239dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "469dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseNotificationPopup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgNotificationClose": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "closeicon.png",
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgPreparingStatement": {
                        "src": "inprogress.png",
                        "segmentProps": []
                    },
                    "lblPreparingStatementmessage": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "btnOkay": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxHeaderPostLogin": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxUserActions": {
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedbackimg": {
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "right": {
                            "type": "string",
                            "value": "83dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.topmenu.lblHelp": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366px"
                        },
                        "segmentProps": []
                    },
                    "flxFeedback": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "1200px"
                        },
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxAccountsHeader": {
                        "zIndex": 50,
                        "segmentProps": []
                    },
                    "lblConsolidatedStatements": {
                        "segmentProps": []
                    },
                    "flxFilterListBox": {
                        "segmentProps": []
                    },
                    "lblSelectedFilter": {
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountsFilter": {
                        "right": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccounts": {
                        "segmentProps": []
                    },
                    "flxFeedbackContainer": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "87.50%"
                        },
                        "segmentProps": []
                    },
                    "imgDowntimeWarning": {
                        "segmentProps": []
                    },
                    "flxRightContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFromDate": {
                        "segmentProps": []
                    },
                    "calFromDate": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "flxToDate": {
                        "segmentProps": []
                    },
                    "calToDate": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "segmentProps": []
                    },
                    "flxActions": {
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "btnDownloadStatements": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancelStatement": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs": {
                        "segmentProps": []
                    },
                    "customFooterMaincs.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "customFooterMaincs.lblCopyright": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "flxPopupDownloadStatements": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "240px"
                        },
                        "width": {
                            "type": "string",
                            "value": "470px"
                        },
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "46px"
                        },
                        "segmentProps": []
                    },
                    "lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "15px"
                        },
                        "top": {
                            "type": "string",
                            "value": "11px"
                        },
                        "segmentProps": []
                    },
                    "imgClose": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "closeicon.png",
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "top": {
                            "type": "string",
                            "value": "1px"
                        },
                        "segmentProps": []
                    },
                    "lblPickDateRange": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "15px"
                        },
                        "skin": "sknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "22px"
                        },
                        "segmentProps": []
                    },
                    "lblSelectedDateRange": {
                        "skin": "sknLblSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "22px"
                        },
                        "width": {
                            "type": "string",
                            "value": "310px"
                        },
                        "segmentProps": []
                    },
                    "lblSelectFormat": {
                        "left": {
                            "type": "string",
                            "value": "15px"
                        },
                        "skin": "sknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "107px"
                        },
                        "segmentProps": []
                    },
                    "flxSeperators2": {
                        "top": {
                            "type": "string",
                            "value": "67px"
                        },
                        "segmentProps": []
                    },
                    "lbxSelectFormat": {
                        "height": {
                            "type": "string",
                            "value": "40px"
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "skin": "Copysknlbxalto13px",
                        "top": {
                            "type": "string",
                            "value": "107px"
                        },
                        "width": {
                            "type": "string",
                            "value": "310px"
                        },
                        "segmentProps": []
                    },
                    "flxFilterListBoxPopup": {
                        "segmentProps": []
                    },
                    "lblSelectedFilterpopup": {
                        "skin": "sknLblSSP42424213px",
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "btnDownload": {
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "text": "Generate",
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxGenerateStatement": {
                        "height": {
                            "type": "string",
                            "value": "291dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "239dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "469dp"
                        },
                        "segmentProps": []
                    },
                    "flxCloseNotificationPopup": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "11dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgNotificationClose": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "closeicon.png",
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "imgPreparingStatement": {
                        "src": "inprogress.png",
                        "segmentProps": []
                    },
                    "btnOkay": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.CopyimgToolTip0i580d9acc07c42": {
                    "src": "golden_card.png"
                },
                "customheader.customhamburger.imgCollapseAccounts": {
                    "src": "arrow_down.png"
                },
                "customheader.customhamburger.imgKony": {
                    "src": "kony_logo_white.png"
                },
                "customheader": {
                    "zIndex": 1000
                },
                "customheader.flxHamburger": {
                    "left": "-35%",
                    "width": "35%",
                    "zIndex": 900
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheader.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "customheader.topmenu.flxHelp": {
                    "right": "5%",
                    "width": "70dp"
                },
                "customheader.topmenu.lblFeedback": {
                    "text": "HELP"
                },
                "customheader.topmenu.lblHelp": {
                    "centerX": "50%",
                    "right": ""
                },
                "accountsFilter": {
                    "left": 0,
                    "right": "",
                    "top": "0dp",
                    "width": "100%",
                    "zIndex": 10
                },
                "accountsFilter.segDefaultFilters": {
                    "data": [{
                        "lblDelete": "",
                        "lblEdit": "",
                        "lblFilterValue": "personal accounts",
                        "lblRadioButton": "L"
                    }, {
                        "lblDelete": "",
                        "lblEdit": "",
                        "lblFilterValue": "Favourite Accounts",
                        "lblRadioButton": "M"
                    }, {
                        "lblDelete": "",
                        "lblEdit": "",
                        "lblFilterValue": "",
                        "lblRadioButton": ""
                    }, {
                        "lblDelete": "",
                        "lblEdit": "",
                        "lblFilterValue": "",
                        "lblRadioButton": ""
                    }, {
                        "lblDelete": "",
                        "lblEdit": "",
                        "lblFilterValue": "",
                        "lblRadioButton": ""
                    }, {
                        "lblDelete": "",
                        "lblEdit": "",
                        "lblFilterValue": "",
                        "lblRadioButton": ""
                    }, {
                        "lblDelete": "",
                        "lblEdit": "",
                        "lblFilterValue": "",
                        "lblRadioButton": ""
                    }, {
                        "lblDelete": "",
                        "lblEdit": "",
                        "lblFilterValue": "",
                        "lblRadioButton": ""
                    }, {
                        "lblDelete": "",
                        "lblEdit": "",
                        "lblFilterValue": "",
                        "lblRadioButton": ""
                    }, {
                        "lblDelete": "",
                        "lblEdit": "",
                        "lblFilterValue": "",
                        "lblRadioButton": ""
                    }],
                    "left": "0dp",
                    "top": "5dp"
                },
                "customFooterMaincs": {
                    "centerX": "50%",
                    "height": "105dp",
                    "left": "0dp",
                    "right": 0,
                    "top": "0dp",
                    "width": "1366px",
                    "zIndex": 2
                },
                "customFooterMaincs.flxFooterMenu": {
                    "centerX": "50%",
                    "left": 0,
                    "top": "26.60%",
                    "width": "1200dp"
                },
                "customFooterMaincs.imgFooterIconOne": {
                    "src": "footer_logo_1.png"
                },
                "customFooterMaincs.imgFooterIconThree": {
                    "src": "footer_logo_3.png"
                },
                "customFooterMaincs.imgFooterIconTwo": {
                    "src": "footer_logo_2.png"
                },
                "customFooterMaincs.lblCopyright": {
                    "centerX": "",
                    "left": "0%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "customPopupcs": {
                    "centerX": "50%",
                    "centerY": "50%",
                    "width": "43%"
                },
                "customPopupcs.btnNo": {
                    "left": "5.48%",
                    "right": ""
                },
                "customPopupcs.btnYes": {
                    "right": "4.89%"
                }
            }
            this.add(flxHeaderPostLogin, flxFormContent, flxPopup, flxLogout, flxLoading, flxDownladstatementspopup, flxGenerateStatementsPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmConsolidatedStatements,
            "enabledForIdleTimeout": true,
            "id": "frmConsolidatedStatements",
            "init": controller.AS_Form_cad29a755ad54f1bb4e686a74f6cccd9,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_f678db6110074ef19e33dc7d5cef0e50,
            "postShow": controller.AS_Form_accf4eda64bd4f20bc046b4aa90e2167,
            "preShow": function(eventobject) {
                controller.AS_Form_d84b2cfd8de24751a9b5502c3eb3dc32(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "title": "Combined Statements",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_aee0f71f77a448518033de9d76dce140,
            "retainScrollPosition": false
        }]
    }
});