define("ArrangementsMA/MortgageServicesUIModule/frmPartialPaymentAcknowledgement", function() {
    return function(controller) {
        function addWidgetsfrmPartialPaymentAcknowledgement() {
            this.setDefaultUnit(kony.flex.DP);
            var confirmPartialRepayment = new com.InfinityOLB.Resources.confirmPartialRepayment({
                "height": "100%",
                "id": "confirmPartialRepayment",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "confirmPartialRepayment",
                "overrides": {
                    "confirmPartialRepayment": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var confirmPartialRepayment_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmPartialPaymentAcknowledgement"] && appConfig.componentMetadata["ResourcesMA"]["frmPartialPaymentAcknowledgement"]["confirmPartialRepayment"]) || {};
            confirmPartialRepayment.serviceParameters = confirmPartialRepayment_data.serviceParameters || {};
            confirmPartialRepayment.customPopupData = confirmPartialRepayment_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            confirmPartialRepayment.dataFormatting = confirmPartialRepayment_data.dataFormatting || {};
            confirmPartialRepayment.dataMapping = confirmPartialRepayment_data.dataMapping || {};
            confirmPartialRepayment.conditionalMappingKey = confirmPartialRepayment_data.conditionalMappingKey || "";
            confirmPartialRepayment.conditionalMapping = confirmPartialRepayment_data.conditionalMapping || {};
            confirmPartialRepayment.pageTitle = confirmPartialRepayment_data.pageTitle || "Partial Repayment - Acknowledgement";
            confirmPartialRepayment.pageTitlei18n = confirmPartialRepayment_data.pageTitlei18n || "i18n.accounts.PartialRepaymentAck";
            confirmPartialRepayment.primaryLinks = confirmPartialRepayment_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            confirmPartialRepayment.flxMainWrapperzIndex = confirmPartialRepayment_data.flxMainWrapperzIndex || 2;
            confirmPartialRepayment.secondaryLinks = confirmPartialRepayment_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            confirmPartialRepayment.supplementaryLinks = confirmPartialRepayment_data.supplementaryLinks || [];
            confirmPartialRepayment.logoConfig = confirmPartialRepayment_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            confirmPartialRepayment.logoutConfig = confirmPartialRepayment_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            confirmPartialRepayment.profileConfig = confirmPartialRepayment_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profilePic",
                    "a11yARIA": {
                        "tabindex": 1
                    }
                },
                "subMenu": [{
                    "title": "profile settings",
                    "toolTip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.ProfileManagement.profilesettings}}"
                    },
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "presentationController": "enterProfileSettings",
                        "moduleName": "SettingsNewUIModule"
                    }
                }]
            };
            confirmPartialRepayment.activeMenuID = confirmPartialRepayment_data.activeMenuID || "";
            confirmPartialRepayment.activeSubMenuID = confirmPartialRepayment_data.activeSubMenuID || "";
            confirmPartialRepayment.backFlag = confirmPartialRepayment_data.backFlag || false;
            confirmPartialRepayment.hamburgerConfig = confirmPartialRepayment_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            confirmPartialRepayment.backProperties = confirmPartialRepayment_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            confirmPartialRepayment.breadCrumbProperties = confirmPartialRepayment_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            confirmPartialRepayment.genricMessage = confirmPartialRepayment_data.genricMessage || {};
            confirmPartialRepayment.sessionTimeOutData = confirmPartialRepayment_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            confirmPartialRepayment.footerProperties = confirmPartialRepayment_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            confirmPartialRepayment.copyRight = confirmPartialRepayment_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxContentMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContentMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentMain.setDefaultUnit(kony.flex.DP);
            var flxRequestDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "70dp",
                "id": "flxRequestDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "30dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestDetails.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgementHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxAcknowledgementHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementHeader.setDefaultUnit(kony.flex.DP);
            var lblAcknowledgement = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblAcknowledgement",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.Acknowledgement\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAckSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxAckSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckSeperator.setDefaultUnit(kony.flex.DP);
            flxAckSeperator.add();
            flxAcknowledgementHeader.add(lblAcknowledgement, flxAckSeperator);
            var imgGreenTick = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "150dp",
                "id": "imgGreenTick",
                "isVisible": true,
                "left": "0",
                "src": "confirmation_tick.png",
                "top": "95dp",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTransactionMsgDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxTransactionMsgDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionMsgDetails.setDefaultUnit(kony.flex.DP);
            var flxTransactionMsg = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxTransactionMsg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionMsg.setDefaultUnit(kony.flex.DP);
            var lblMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMsg",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknlbl424242SSP24px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.transactionSubmitted\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTransactionMsg.add(lblMsg);
            var flxRequestInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxRequestInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestInfo.setDefaultUnit(kony.flex.DP);
            var lblRequestID = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblRequestID",
                "isVisible": true,
                "left": "35%",
                "skin": "sknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.RequestIDWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRequestIDVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblRequestIDVal",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP72727215Px",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblReferenceNumber",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP72727213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.ReferenceNumber:\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumberVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblReferenceNumberVal",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP72727213Px",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRequestInfo.add(lblRequestID, lblRequestIDVal, lblReferenceNumber, lblReferenceNumberVal);
            flxTransactionMsgDetails.add(flxTransactionMsg, flxRequestInfo);
            flxRequestDetails.add(flxAcknowledgementHeader, imgGreenTick, flxTransactionMsgDetails);
            var flxMortgageFacilityDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "240dp",
                "id": "flxMortgageFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityDetails.setDefaultUnit(kony.flex.DP);
            var flxMortgageFacilityHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxMortgageFacilityHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityHeader.setDefaultUnit(kony.flex.DP);
            var lblMortgageFacilityDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblMortgageFacilityDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.displayMortgageFacilityDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            var flxMortgageFacilityContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "190dp",
                "id": "flxMortgageFacilityContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": 50,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityContent.setDefaultUnit(kony.flex.DP);
            var lblFacilityName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFacilityName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.faciltyNameWithColon\")",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityNameVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFacilityNameVal",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoans = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNoOfLoans",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.numberofloansWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNumberOfLoansDummy = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblNumberOfLoansDummy",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Number of loans",
                "top": "70dp",
                "width": "1dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoansVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoOfLoansVal",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBal",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.outstandingBalanceWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBalVal",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€150,054.00",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityAmountDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMaturityAmountDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.amountPaidtoDate\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityAmountDateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblMaturityAmountDateVal",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityContent.add(lblFacilityName, lblFacilityNameVal, lblNoOfLoans, lblNumberOfLoansDummy, lblNoOfLoansVal, lblOutstandingBal, lblOutstandingBalVal, lblMaturityAmountDate, lblMaturityAmountDateVal);
            flxMortgageFacilityHeader.add(lblMortgageFacilityDetails, flxSeperator, flxMortgageFacilityContent);
            flxMortgageFacilityDetails.add(flxMortgageFacilityHeader);
            var flxLoanDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "240dp",
                "id": "flxLoanDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanDetails.setDefaultUnit(kony.flex.DP);
            var flxLoanAccountsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLoanAccountsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": 0,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccountsHeader.setDefaultUnit(kony.flex.DP);
            var lblLoanDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblLoanDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.loans.LoanDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLoanSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxLoanSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanSeperator.setDefaultUnit(kony.flex.DP);
            flxLoanSeperator.add();
            flxLoanAccountsHeader.add(lblLoanDetails, flxLoanSeperator);
            var flxLoanAccountName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxLoanAccountName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFboxBGf8f7f8B0",
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccountName.setDefaultUnit(kony.flex.DP);
            var lblLoanAccountName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "height": "20dp",
                "id": "lblLoanAccountName",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Primary Loan Account Name - 8760",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLoanDetailsSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxLoanDetailsSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "40dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanDetailsSeperator.setDefaultUnit(kony.flex.DP);
            flxLoanDetailsSeperator.add();
            flxLoanAccountName.add(lblLoanAccountName, flxLoanDetailsSeperator);
            var flxLoanDetailsContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoanDetailsContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "90dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanDetailsContent.setDefaultUnit(kony.flex.DP);
            var flxValueType = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxValueType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValueType.setDefaultUnit(kony.flex.DP);
            var lblCurrentVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblCurrentVal",
                "isVisible": true,
                "left": "250dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Current Value",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblSimulatedVal",
                "isVisible": true,
                "left": "580dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Simulated Value",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValueType.add(lblCurrentVal, lblSimulatedVal);
            var flxInstallmentAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxInstallmentAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "45dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInstallmentAmount.setDefaultUnit(kony.flex.DP);
            var lblInstallementAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblInstallementAmount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Installment Amount:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentInstallmentVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblCurrentInstallmentVal",
                "isVisible": true,
                "left": "250dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€3,000",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrentInstallmentValEmpty = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblCurrentInstallmentValEmpty",
                "isVisible": true,
                "left": "250dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "0",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedInstallmentVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblSimulatedInstallmentVal",
                "isVisible": true,
                "left": "580dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€3,000",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedInstallmentValEmpty = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblSimulatedInstallmentValEmpty",
                "isVisible": true,
                "left": "590dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "10dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInstallmentAmount.add(lblInstallementAmount, lblCurrentInstallmentVal, lblCurrentInstallmentValEmpty, lblSimulatedInstallmentVal, lblSimulatedInstallmentValEmpty);
            var flxRepaymentDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxRepaymentDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "80dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRepaymentDate.setDefaultUnit(kony.flex.DP);
            var lblNextRepaymentDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNextRepaymentDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Next Repayment Date:",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepaymentCurrentDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblRepaymentCurrentDate",
                "isVisible": true,
                "left": "250dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/01/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepaymentCurrentDateEmpty = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblRepaymentCurrentDateEmpty",
                "isVisible": true,
                "left": "368dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "10dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepaymentSimulatedDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblRepaymentSimulatedDate",
                "isVisible": true,
                "left": "580dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/01/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepaymentSimulatedDateEmpty = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblRepaymentSimulatedDateEmpty",
                "isVisible": true,
                "left": "590dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "10dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRepaymentDate.add(lblNextRepaymentDate, lblRepaymentCurrentDate, lblRepaymentCurrentDateEmpty, lblRepaymentSimulatedDate, lblRepaymentSimulatedDateEmpty);
            var flxMaturityDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxMaturityDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "110dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMaturityDate.setDefaultUnit(kony.flex.DP);
            var lblMaturityDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblMaturityDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "End Date (Maturity Date):",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityCurrentval = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblMaturityCurrentval",
                "isVisible": true,
                "left": "250dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/01/2031",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturityCurrentvalEmpty = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblMaturityCurrentvalEmpty",
                "isVisible": true,
                "left": "368dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "10dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturitySimulatedVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblMaturitySimulatedVal",
                "isVisible": true,
                "left": "580dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "25/02/2030",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaturitySimulatedValEmpty = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblMaturitySimulatedValEmpty",
                "isVisible": true,
                "left": "590dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "top": "10dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMaturityDate.add(lblMaturityDate, lblMaturityCurrentval, lblMaturityCurrentvalEmpty, lblMaturitySimulatedVal, lblMaturitySimulatedValEmpty);
            var flxValueSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxValueSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValueSeperator.setDefaultUnit(kony.flex.DP);
            flxValueSeperator.add();
            var flxSimulatedValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSimulatedValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulatedValue.setDefaultUnit(kony.flex.DP);
            var lblSimulatedValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblSimulatedValue",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulatedValue.add(lblSimulatedValue);
            var flxSimulatedAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSimulatedAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulatedAmount.setDefaultUnit(kony.flex.DP);
            var lblSimulatedAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedAmount",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedAmountVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedAmountVal",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulatedAmount.add(lblSimulatedAmount, lblSimulatedAmountVal);
            var flxSimulatedDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSimulatedDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulatedDate.setDefaultUnit(kony.flex.DP);
            var lblSimulatedDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedDate",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedDateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedDateVal",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulatedDate.add(lblSimulatedDate, lblSimulatedDateVal);
            var flxSimulatedMaturityDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSimulatedMaturityDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSimulatedMaturityDate.setDefaultUnit(kony.flex.DP);
            var lblSimulatedMaturityDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedMaturityDate",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLblSSP72727215px",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedMaturityDateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSimulatedMaturityDateVal",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSimulatedMaturityDate.add(lblSimulatedMaturityDate, lblSimulatedMaturityDateVal);
            flxLoanDetailsContent.add(flxValueType, flxInstallmentAmount, flxRepaymentDate, flxMaturityDate, flxValueSeperator, flxSimulatedValue, flxSimulatedAmount, flxSimulatedDate, flxSimulatedMaturityDate);
            flxLoanDetails.add(flxLoanAccountsHeader, flxLoanAccountName, flxLoanDetailsContent);
            var flxPaymentDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetails.setDefaultUnit(kony.flex.DP);
            var flxPaymentDetailsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPaymentDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblPaymentDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblPaymentDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.PaymentDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaymentDetailsSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxPaymentDetailsSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsSeperator.setDefaultUnit(kony.flex.DP);
            flxPaymentDetailsSeperator.add();
            flxPaymentDetailsHeader.add(lblPaymentDetails, flxPaymentDetailsSeperator);
            var flxPaymentContentDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentContentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentContentDetails.setDefaultUnit(kony.flex.DP);
            var flxTotalRepaymentAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxTotalRepaymentAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTotalRepaymentAmount.setDefaultUnit(kony.flex.DP);
            var lblTotalRepaymentAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTotalRepaymentAmount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.totalRepaymentWithColon\")",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalRepaymentAmountVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTotalRepaymentAmountVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "€32,000",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTotalRepaymentAmount.add(lblTotalRepaymentAmount, lblTotalRepaymentAmountVal);
            var flxLoanAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxLoanAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccount.setDefaultUnit(kony.flex.DP);
            var lblLoanAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLoanAccount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.LoanAccount\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoanAccountVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLoanAccountVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "************0723",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxShowEyeIconForLoanAcc = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxShowEyeIconForLoanAcc",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "470dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShowEyeIconForLoanAcc.setDefaultUnit(kony.flex.DP);
            var lblShowEyeIconForLoanAcc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblShowEyeIconForLoanAcc",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLblFontIcon",
                "text": "g",
                "top": "3dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxShowEyeIconForLoanAcc.add(lblShowEyeIconForLoanAcc);
            flxLoanAccount.add(lblLoanAccount, lblLoanAccountVal, flxShowEyeIconForLoanAcc);
            var flxCreditValueDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxCreditValueDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreditValueDate.setDefaultUnit(kony.flex.DP);
            var lblCreditValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCreditValue",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.creditValueDateWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCreditValueDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblCreditValueDate",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "07/14/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCreditValueDate.add(lblCreditValue, lblCreditValueDate);
            var flxTransactionFee = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxTransactionFee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionFee.setDefaultUnit(kony.flex.DP);
            var lblTransactionFee = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTransactionFee",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.TransactionfeeWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTransactionFeeVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTransactionFeeVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$5.00",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTransactionFee.add(lblTransactionFee, lblTransactionFeeVal);
            var flxExchangeRate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxExchangeRate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExchangeRate.setDefaultUnit(kony.flex.DP);
            var lblExchangeRate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblExchangeRate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.exchangeRate\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExchangeRateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblExchangeRateVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "1.345",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExchangeRate.add(lblExchangeRate, lblExchangeRateVal);
            var flxAccountHolderName = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxAccountHolderName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountHolderName.setDefaultUnit(kony.flex.DP);
            var lblAccountHolderName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountHolderName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.accountHolderNameWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountHolderNameVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountHolderNameVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Daisy Davis",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountHolderName.add(lblAccountHolderName, lblAccountHolderNameVal);
            var flxAccountNumber = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxAccountNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountNumber.setDefaultUnit(kony.flex.DP);
            var lblAccountNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountNumber",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.accountNumWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountNumberVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "************0723",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxShowEyeIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxShowEyeIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "470dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxShowEyeIcon.setDefaultUnit(kony.flex.DP);
            var lblShowEyeIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "id": "lblShowEyeIcon",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLblFontIcon",
                "text": "g",
                "top": "3dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxShowEyeIcon.add(lblShowEyeIcon);
            flxAccountNumber.add(lblAccountNumber, lblAccountNumberVal, flxShowEyeIcon);
            var flxPayon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxPayon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayon.setDefaultUnit(kony.flex.DP);
            var lblPayon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayon",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.payOnWithColon\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayonDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayonDate",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "07/14/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayon.add(lblPayon, lblPayonDate);
            var flxNotes = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNotes",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNotes.setDefaultUnit(kony.flex.DP);
            var lblNotes = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNotes",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ChequeManagement.Notes\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNotesDesc = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNotesDesc",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "The notes goes here",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNotes.add(lblNotes, lblNotesDesc);
            var flxSupportingDocuments = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSupportingDocuments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocuments.setDefaultUnit(kony.flex.DP);
            var lblSupportingDocuments = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSupportingDocuments",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.supportingDocumentsWithColon\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segSupportingDocs = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgDoc": "",
                    "lblDocName": ""
                }],
                "groupCells": false,
                "id": "segSupportingDocs",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxSupportingDocs"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxContentDocs": "flxContentDocs",
                    "flxGap": "flxGap",
                    "flxImgDoc": "flxImgDoc",
                    "flxSupportingDocs": "flxSupportingDocs",
                    "imgDoc": "imgDoc",
                    "lblDocName": "lblDocName"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSupportingDocuments.add(lblSupportingDocuments, segSupportingDocs);
            flxPaymentContentDetails.add(flxTotalRepaymentAmount, flxLoanAccount, flxCreditValueDate, flxTransactionFee, flxExchangeRate, flxAccountHolderName, flxAccountNumber, flxPayon, flxNotes, flxSupportingDocuments);
            flxPaymentDetails.add(flxPaymentDetailsHeader, flxPaymentContentDetails);
            var flxFacilityOverview = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxFacilityOverview",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": 0,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityOverview.setDefaultUnit(kony.flex.DP);
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "centerY": "50%",
                "height": "100%",
                "id": "btnBack",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknbtnSSPffffff15px0273e3bg",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.CardManagement.BackToFacilityOverview\")",
                "top": "0",
                "width": "250dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(btnBack);
            flxFacilityOverview.add(flxButtons);
            flxContentMain.add(flxRequestDetails, flxMortgageFacilityDetails, flxLoanDetails, flxPaymentDetails, flxFacilityOverview);
            confirmPartialRepayment.flxContentTCCenter.add(flxContentMain);
            var flxDownloadOptions = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0dp",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxDownloadOptions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "top": "18dp",
                "width": "100dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadOptions.setDefaultUnit(kony.flex.DP);
            var flxDownloadServ = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Download partial repayment details"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "25dp",
                "id": "flxDownloadServ",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "width": "40dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadServ.setDefaultUnit(kony.flex.DP);
            var lblDownloadOption = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "label"
                },
                "id": "lblDownloadOption",
                "isVisible": true,
                "left": "0",
                "skin": "ICsknOlbFonts0273e317px",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownloadServ.add(lblDownloadOption);
            var flxPrint = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Print partial repayment details"
                },
                "clipBounds": false,
                "height": "220dp",
                "id": "flxPrint",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrint.setDefaultUnit(kony.flex.DP);
            var imagePrint = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "150dp",
                "id": "imagePrint",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "150dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPrint.add(imagePrint);
            flxDownloadOptions.add(flxDownloadServ, flxPrint);
            confirmPartialRepayment.flxTCButtons.add(flxDownloadOptions);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "confirmPartialRepayment": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxRequestDetails": {
                        "height": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxAcknowledgementHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "imgGreenTick": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "115dp"
                        },
                        "src": "confirmation_tick.png",
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "flxTransactionMsgDetails": {
                        "height": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "flxTransactionMsg": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails"]
                    },
                    "lblMsg": {
                        "left": {
                            "type": "number",
                            "value": "10"
                        },
                        "skin": "ICSknLbl424242SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "228dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxTransactionMsg"]
                    },
                    "flxRequestInfo": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails"]
                    },
                    "lblRequestID": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknSSP72727213Px",
                        "text": "Request ID:",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblRequestIDVal": {
                        "left": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "skin": "sknSSP72727213Px",
                        "text": "45423792753567768",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblReferenceNumber": {
                        "i18n_text": "i18n.accounts.PIReferenceWithColon",
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknSSP72727213Px",
                        "text": "PI Reference :",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblReferenceNumberVal": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "skin": "sknSSP72727213Px",
                        "text": "PI2210913R2W4TF2",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "flxMortgageFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "310dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblMortgageFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "flxSeperator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "flxMortgageFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "Mortgage Facility Account - 1234",
                        "top": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNumberOfLoansDummy": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "3",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityAmountDate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "195dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityAmountDateVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "€50,054.00",
                        "top": {
                            "type": "string",
                            "value": "220dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "flxLoanDetails": {
                        "height": {
                            "type": "string",
                            "value": "525dp"
                        },
                        "skin": "bbSknFlxffffffWithShadow1",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsHeader"]
                    },
                    "lblLoanAccountName": {
                        "text": "Primary Loan Account Name - 8760",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountName"]
                    },
                    "flxLoanDetailsContent": {
                        "height": {
                            "type": "string",
                            "value": "435dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "lblCurrentVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "lblSimulatedVal": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "flxInstallmentAmount": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblInstallementAmount": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblCurrentInstallmentVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblCurrentInstallmentValEmpty": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblSimulatedInstallmentVal": {
                        "isVisible": false,
                        "text": "€3,000",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblSimulatedInstallmentValEmpty": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "flxRepaymentDate": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblNextRepaymentDate": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentCurrentDate": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentCurrentDateEmpty": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentSimulatedDate": {
                        "isVisible": false,
                        "text": "31/01/2022",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentSimulatedDateEmpty": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "flxMaturityDate": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblMaturityDate": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturityCurrentval": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "text": "31/01/2031",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturityCurrentvalEmpty": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturitySimulatedVal": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturitySimulatedValEmpty": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "flxValueSeperator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "skin": "bbSknFlxSeperatore3e3e3",
                        "top": {
                            "type": "string",
                            "value": "214dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedValue": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "235dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "text": "Simulated Value",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedValue"]
                    },
                    "flxSimulatedAmount": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedAmount": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "text": "Installment Amount:",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedAmount"]
                    },
                    "lblSimulatedAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "€3,000",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedAmount"]
                    },
                    "flxSimulatedDate": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "325dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedDate": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "text": "Next Repayment Date:",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedDate"]
                    },
                    "lblSimulatedDateVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "31/01/2022",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedDate"]
                    },
                    "flxSimulatedMaturityDate": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "375dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblSimulatedMaturityDate": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "text": "End Date (Maturity Date):",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedMaturityDate"]
                    },
                    "lblSimulatedMaturityDateVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "31/01/2031",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxSimulatedMaturityDate"]
                    },
                    "flxPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentContentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails"]
                    },
                    "flxTotalRepaymentAmount": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblTotalRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "lblTotalRepaymentAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "flxLoanAccount": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblLoanAccountVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "flxShowEyeIconForLoanAcc": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblShowEyeIconForLoanAcc": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLblFontIcon",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount", "flxShowEyeIconForLoanAcc"]
                    },
                    "flxCreditValueDate": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblCreditValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "lblCreditValueDate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "flxTransactionFee": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblTransactionFee": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "lblTransactionFeeVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "flxExchangeRate": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblExchangeRate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "lblExchangeRateVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "flxAccountHolderName": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountHolderName": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "lblAccountHolderNameVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "flxAccountNumber": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblAccountNumberVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "flxShowEyeIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "125dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblShowEyeIcon": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLblFontIcon",
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber", "flxShowEyeIcon"]
                    },
                    "flxPayon": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblPayon": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxPayon"]
                    },
                    "lblPayonDate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxPayon"]
                    },
                    "flxNotes": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblNotes": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "lblNotesDesc": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "flxSupportingDocuments": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblSupportingDocuments": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "flxFacilityOverview": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "btnBack": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "305dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxFacilityOverview", "flxButtons"]
                    },
                    "flxDownloadOptions": {
                        "top": {
                            "type": "string",
                            "value": "-6dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons"]
                    },
                    "flxDownloadServ": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "lblDownloadOption": {
                        "bottom": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "skin": "ICsknOlbFonts0273e317px",
                        "text": "D",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions", "flxDownloadServ"]
                    },
                    "flxPrint": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "imagePrint": {
                        "bottom": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "print_blue.png",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions", "flxPrint"]
                    }
                },
                "1024": {
                    "flxContentMain": {
                        "width": {
                            "type": "string",
                            "value": "98.80%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter"]
                    },
                    "flxRequestDetails": {
                        "height": {
                            "type": "string",
                            "value": "325dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxAcknowledgementHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "lblAcknowledgement": {
                        "text": "Acknowledgement",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxAcknowledgementHeader"]
                    },
                    "flxAckSeperator": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxAcknowledgementHeader"]
                    },
                    "imgGreenTick": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "confirmation_tick.png",
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "55dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "flxTransactionMsgDetails": {
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "flxTransactionMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails"]
                    },
                    "lblMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknlbl424242SSP24px",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxTransactionMsg"]
                    },
                    "flxRequestInfo": {
                        "height": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails"]
                    },
                    "lblRequestID": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "skin": "sknSSP72727215Px",
                        "text": "Request ID:",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblRequestIDVal": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "48%"
                        },
                        "skin": "sknSSP72727215Px",
                        "text": "45423792753567768",
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "i18n_text": "i18n.ChequeManagement.ReferenceNumber",
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP72727215Px",
                        "text": "Reference Number",
                        "top": {
                            "type": "string",
                            "value": "75dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblReferenceNumberVal": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknlbl424242SSP24px",
                        "text": "PI2210913R2W4TF2",
                        "top": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "flxMortgageFacilityDetails": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblFacilityNameVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "Mortgage Facility Account - 1234",
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNumberOfLoansDummy": {
                        "skin": "ICSknLblSSP72727215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "3",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityAmountDate": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityAmountDateVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "€50,054.00",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblSimulatedVal": {
                        "left": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "lblSimulatedInstallmentVal": {
                        "left": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblSimulatedInstallmentValEmpty": {
                        "left": {
                            "type": "string",
                            "value": "430dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "flxRepaymentDate": {
                        "top": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblRepaymentSimulatedDate": {
                        "left": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentSimulatedDateEmpty": {
                        "left": {
                            "type": "string",
                            "value": "430dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblMaturitySimulatedVal": {
                        "left": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturitySimulatedValEmpty": {
                        "left": {
                            "type": "string",
                            "value": "430dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "flxValueSeperator": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedValue": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedAmount": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedDate": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedMaturityDate": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxPaymentDetailsHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails"]
                    },
                    "flxPaymentContentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails"]
                    },
                    "lblTotalRepaymentAmount": {
                        "text": "Total Repayment Amount:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "lblTotalRepaymentAmountVal": {
                        "text": "€32,000",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "flxLoanAccount": {
                        "isVisible": true,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "flxShowEyeIconForLoanAcc": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "height": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "490dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblShowEyeIconForLoanAcc": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLblFontIcon",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount", "flxShowEyeIconForLoanAcc"]
                    },
                    "lblCreditValue": {
                        "text": "Credit Value Date:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "lblCreditValueDate": {
                        "text": "07/14/2022",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "lblTransactionFee": {
                        "text": "Transaction fee:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "lblTransactionFeeVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "lblExchangeRateVal": {
                        "text": "1.345",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "lblAccountHolderName": {
                        "text": "AccountHolderName:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "lblAccountNumberVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "flxShowEyeIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "height": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "490dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblShowEyeIcon": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLblFontIcon",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber", "flxShowEyeIcon"]
                    },
                    "lblNotesDesc": {
                        "top": {
                            "type": "string",
                            "value": "-17dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "52%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "flxSupportingDocuments": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "btnBack": {
                        "width": {
                            "type": "string",
                            "value": "205dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxFacilityOverview", "flxButtons"]
                    },
                    "flxDownloadOptions": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "9dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-6dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons"]
                    },
                    "flxDownloadServ": {
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "lblDownloadOption": {
                        "bottom": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "ICsknOlbFonts0273e317px",
                        "text": "D",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions", "flxDownloadServ"]
                    },
                    "flxPrint": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "imagePrint": {
                        "bottom": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "src": "print_blue.png",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions", "flxPrint"]
                    }
                },
                "1366": {
                    "confirmPartialRepayment": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxContentMain": {
                        "width": {
                            "type": "string",
                            "value": "101.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter"]
                    },
                    "flxRequestDetails": {
                        "height": {
                            "type": "string",
                            "value": "270px"
                        },
                        "skin": "slFboxshadow1rad4px",
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxAcknowledgementHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "imgGreenTick": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "500px"
                        },
                        "src": "confirmation_tick.png",
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "flxTransactionMsgDetails": {
                        "height": {
                            "type": "string",
                            "value": "68dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "flxTransactionMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "205px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails"]
                    },
                    "lblMsg": {
                        "skin": "ICSknlbl424242SSP24px",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxTransactionMsg"]
                    },
                    "flxRequestInfo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "110px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails"]
                    },
                    "lblRequestID": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "sknSSP72727220Px",
                        "text": "Request ID:",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblRequestIDVal": {
                        "left": {
                            "type": "string",
                            "value": "25%"
                        },
                        "skin": "sknSSP72727220Px",
                        "text": "45423792753567768",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblReferenceNumber": {
                        "i18n_text": "i18n.ChequeManagement.ReferenceNumber:",
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP72727220Px",
                        "text": "Reference Number",
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblReferenceNumberVal": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabel42424224px",
                        "text": "PI2210913R2W4TF2",
                        "top": {
                            "type": "string",
                            "value": "33dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "flxMortgageFacilityDetails": {
                        "skin": "slFboxshadow1rad4px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblMortgageFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "Mortgage Facility Account - 1234 ",
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "text": "No. of Loans:",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNumberOfLoansDummy": {
                        "skin": "ICSknLblSSP72727215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "3",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "text": "Outstanding Balance:",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "€150,054.00",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityAmountDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "text": "Amount Paid to Date:",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityAmountDateVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "€50,054.00",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "flxLoanDetails": {
                        "skin": "slFboxshadow1rad4px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Loan Details",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsHeader"]
                    },
                    "flxLoanAccountName": {
                        "skin": "sknFlxfbfbfb",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "lblLoanAccountName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountName"]
                    },
                    "lblCurrentVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "lblSimulatedVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "lblInstallementAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblCurrentInstallmentVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "text": "€3,000",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblCurrentInstallmentValEmpty": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "flxRepaymentDate": {
                        "top": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblNextRepaymentDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentCurrentDate": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentCurrentDateEmpty": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblMaturityDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturityCurrentval": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturityCurrentvalEmpty": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "flxValueSeperator": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedValue": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedAmount": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedDate": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedMaturityDate": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFboxshadow1rad4px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Payment Details",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentContentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails"]
                    },
                    "lblTotalRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "flxShowEyeIconForLoanAcc": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "height": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "490dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblShowEyeIconForLoanAcc": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "skin": "bbSknLblFontIcon",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount", "flxShowEyeIconForLoanAcc"]
                    },
                    "lblCreditValue": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "lblTransactionFee": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "lblExchangeRate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "lblAccountHolderName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "lblAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "flxShowEyeIcon": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "height": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "490dp"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblShowEyeIcon": {
                        "left": {
                            "type": "string",
                            "value": "7dp"
                        },
                        "skin": "bbSknLblFontIcon",
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber", "flxShowEyeIcon"]
                    },
                    "lblPayon": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxPayon"]
                    },
                    "lblNotes": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "lblNotesDesc": {
                        "top": {
                            "type": "string",
                            "value": "-19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "flxSupportingDocuments": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblSupportingDocuments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "flxDownloadOptions": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "-13dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-6dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons"]
                    },
                    "flxDownloadServ": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "lblDownloadOption": {
                        "bottom": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "skin": "ICsknOlbFonts0273e317px",
                        "text": "D",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions", "flxDownloadServ"]
                    },
                    "flxPrint": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "imagePrint": {
                        "bottom": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "print_blue.png",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions", "flxPrint"]
                    }
                },
                "1380": {
                    "flxRequestDetails": {
                        "height": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "skin": "slFboxshadow1rad4px",
                        "top": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "flxAcknowledgementHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "imgGreenTick": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "500px"
                        },
                        "src": "confirmation_tick.png",
                        "width": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "flxTransactionMsgDetails": {
                        "height": {
                            "type": "string",
                            "value": "68dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails"]
                    },
                    "flxTransactionMsg": {
                        "height": {
                            "type": "string",
                            "value": "38dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "205px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails"]
                    },
                    "lblMsg": {
                        "skin": "ICSknlbl424242SSP24px",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxTransactionMsg"]
                    },
                    "flxRequestInfo": {
                        "height": {
                            "type": "string",
                            "value": "110px"
                        },
                        "left": {
                            "type": "string",
                            "value": "95px"
                        },
                        "top": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails"]
                    },
                    "lblRequestID": {
                        "skin": "sknSSP72727220Px",
                        "text": "Request ID:",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblRequestIDVal": {
                        "left": {
                            "type": "string",
                            "value": "310px"
                        },
                        "skin": "sknSSP72727220Px",
                        "text": "45423792753567768",
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblReferenceNumber": {
                        "i18n_text": "i18n.ChequeManagement.ReferenceNumber:",
                        "left": {
                            "type": "string",
                            "value": "255px"
                        },
                        "skin": "sknSSP72727220Px",
                        "text": "Reference Number:",
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "lblReferenceNumberVal": {
                        "left": {
                            "type": "string",
                            "value": "235dp"
                        },
                        "skin": "sknLabel42424224px",
                        "text": "PI2210913R2W4TF2",
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxRequestDetails", "flxTransactionMsgDetails", "flxRequestInfo"]
                    },
                    "flxMortgageFacilityDetails": {
                        "skin": "slFboxshadow1rad4px",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblMortgageFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "Mortgage Facility Account - 1234",
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNumberOfLoansDummy": {
                        "skin": "ICSknLblSSP72727215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "3",
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityAmountDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "lblMaturityAmountDateVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "text": "€50,054.00",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxMortgageFacilityDetails", "flxMortgageFacilityHeader", "flxMortgageFacilityContent"]
                    },
                    "flxLoanDetails": {
                        "skin": "slFboxshadow1rad4px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountsHeader"]
                    },
                    "flxLoanAccountName": {
                        "skin": "sknFlxfbfbfb",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails"]
                    },
                    "lblLoanAccountName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanAccountName"]
                    },
                    "lblCurrentVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxValueType"]
                    },
                    "lblInstallementAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblCurrentInstallmentVal": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "lblCurrentInstallmentValEmpty": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxInstallmentAmount"]
                    },
                    "flxRepaymentDate": {
                        "top": {
                            "type": "string",
                            "value": "78dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "lblNextRepaymentDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentCurrentDate": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblRepaymentCurrentDateEmpty": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxRepaymentDate"]
                    },
                    "lblMaturityDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturityCurrentval": {
                        "left": {
                            "type": "string",
                            "value": "358dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "lblMaturityCurrentvalEmpty": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent", "flxMaturityDate"]
                    },
                    "flxValueSeperator": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedValue": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedAmount": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedDate": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxSimulatedMaturityDate": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxLoanDetails", "flxLoanDetailsContent"]
                    },
                    "flxPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "slFboxshadow1rad4px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain"]
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentContentDetails": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails"]
                    },
                    "lblTotalRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTotalRepaymentAmount"]
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "flxShowEyeIconForLoanAcc": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount"]
                    },
                    "lblShowEyeIconForLoanAcc": {
                        "skin": "bbSknLblFontIcon",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxLoanAccount", "flxShowEyeIconForLoanAcc"]
                    },
                    "lblCreditValue": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxCreditValueDate"]
                    },
                    "lblTransactionFee": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxTransactionFee"]
                    },
                    "lblExchangeRate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxExchangeRate"]
                    },
                    "lblAccountHolderName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountHolderName"]
                    },
                    "flxAccountNumber": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblAccountNumber": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "flxShowEyeIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber"]
                    },
                    "lblShowEyeIcon": {
                        "skin": "bbSknLblFontIcon",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxAccountNumber", "flxShowEyeIcon"]
                    },
                    "lblPayon": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxPayon"]
                    },
                    "lblNotes": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "lblNotesDesc": {
                        "top": {
                            "type": "string",
                            "value": "-19dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "67%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxNotes"]
                    },
                    "flxSupportingDocuments": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails"]
                    },
                    "lblSupportingDocuments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxContentTCCenter", "flxContentMain", "flxPaymentDetails", "flxPaymentContentDetails", "flxSupportingDocuments"]
                    },
                    "flxDownloadOptions": {
                        "top": {
                            "type": "string",
                            "value": "-6dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons"]
                    },
                    "flxDownloadServ": {
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "lblDownloadOption": {
                        "bottom": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "skin": "ICsknOlbFonts0273e317px",
                        "text": "D",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions", "flxDownloadServ"]
                    },
                    "flxPrint": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions"]
                    },
                    "imagePrint": {
                        "bottom": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "19dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "src": "print_blue.png",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["confirmPartialRepayment", "flxTCButtons", "flxDownloadOptions", "flxPrint"]
                    }
                }
            }
            this.compInstData = {
                "confirmPartialRepayment": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(confirmPartialRepayment);
        };
        return [{
            "addWidgets": addWidgetsfrmPartialPaymentAcknowledgement,
            "enabledForIdleTimeout": true,
            "id": "frmPartialPaymentAcknowledgement",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_a4ba8cef0f824907a9b366abf8e0e22f,
            "preShow": function(eventobject) {
                controller.AS_Form_c317f655167a45899fa8650dd583375e(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "title": "Partial Repayment",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});