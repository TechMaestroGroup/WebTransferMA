define("OpenBankingMA/OpenBankingUIModule/frmConsentVerifyDetails", function() {
    return function(controller) {
        function addWidgetsfrmConsentVerifyDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "64dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxHdr = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "64dp",
                "id": "flxHdr",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "0dp",
                "width": "728dp",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHdr.setDefaultUnit(kony.flex.DP);
            var flxLogo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "42dp",
                "id": "flxLogo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogo.setDefaultUnit(kony.flex.DP);
            var imgLogo = new kony.ui.Image2({
                "height": "42dp",
                "id": "imgLogo",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "0dp",
                "width": "100dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLogo.add(imgLogo);
            flxHdr.add(flxLogo);
            var flxHeaderSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "64dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSeparator.setDefaultUnit(kony.flex.DP);
            flxHeaderSeparator.add();
            flxHeader.add(flxHdr, flxHeaderSeparator);
            var flxContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "0dp",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "top": "64dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "728dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "height": "30dp",
                "id": "lblHeader",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabel42424224pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.CM.verifyDetails\")",
                "top": "20dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxErrorSingle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "48px",
                "id": "flxErrorSingle",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "right": "20dp",
                "skin": "sknFlxffffffBordere3e3e3shadyellow",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorSingle.setDefaultUnit(kony.flex.DP);
            var imgAlert = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgAlert",
                "isVisible": true,
                "left": "25dp",
                "skin": "slImage",
                "src": "warning_yellow.png",
                "top": "10dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError = new kony.ui.Label({
                "height": "35dp",
                "id": "lblError",
                "isVisible": true,
                "left": "10dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "This payment will take your account in to an un arranged overdraft.",
                "textStyle": {},
                "top": "5dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorSingle.add(imgAlert, lblError);
            var flxErrorMultiple = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxErrorMultiple",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffBordere3e3e3shadyellow",
                "top": "20dp",
                "width": "99%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMultiple.setDefaultUnit(kony.flex.DP);
            var flxErrorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxErrorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorHeader.setDefaultUnit(kony.flex.DP);
            var imgAlert1 = new kony.ui.Image2({
                "height": "24dp",
                "id": "imgAlert1",
                "isVisible": true,
                "left": "3%",
                "skin": "slImage",
                "src": "warning_yellow.png",
                "top": "18dp",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorHeader = new kony.ui.Label({
                "id": "lblErrorHeader",
                "isVisible": true,
                "left": "7.50%",
                "skin": "sknLbl000d19SSB16px",
                "text": "Please note the following details",
                "textStyle": {},
                "top": "20dp",
                "width": "92%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorHeader.add(imgAlert1, lblErrorHeader);
            var SegError = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "15dp",
                "data": [{
                    "lblDot": "Label",
                    "lblErrorText": "This payment will take your account in to an un arranged overdraft"
                }, {
                    "lblDot": "Label",
                    "lblErrorText": "This payment will take your account in to an un arranged overdraft"
                }],
                "groupCells": false,
                "id": "SegError",
                "isVisible": true,
                "left": "4.50%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "OpenBankingMA",
                    "friendlyName": "flexWarningMessages"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "5dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flexWarningMessages": "flexWarningMessages",
                    "lblDot": "lblDot",
                    "lblErrorText": "lblErrorText"
                },
                "width": "96.06%",
                "appName": "OpenBankingMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMultiple.add(flxErrorHeader, SegError);
            var flxFutureDate = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "48dp",
                "id": "flxFutureDate",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffBordere3e3e3shad",
                "top": "24dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFutureDate.setDefaultUnit(kony.flex.DP);
            var lblFutureDateInfo = new kony.ui.Label({
                "height": "24dp",
                "id": "lblFutureDateInfo",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknLbl6E7081OlbFonticons20px",
                "text": "K",
                "textStyle": {},
                "top": "12dp",
                "width": "24dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFutContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFutContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFutContainer.setDefaultUnit(kony.flex.DP);
            var flxFutureDateContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFutureDateContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "8dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFutureDateContainer.setDefaultUnit(kony.flex.DP);
            var lblFuturePaymentDate = new kony.ui.Label({
                "id": "lblFuturePaymentDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.futureDatedPayment\")",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFutureDate = new kony.ui.Label({
                "id": "lblFutureDate",
                "isVisible": true,
                "left": "4dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.paymentMadeOn\")",
                "textStyle": {},
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFutureDateContainer.add(lblFuturePaymentDate, lblFutureDate);
            var flxDummy4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "15dp",
                "id": "flxDummy4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "86.50%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy4.setDefaultUnit(kony.flex.DP);
            flxDummy4.add();
            flxFutContainer.add(flxFutureDateContainer, flxDummy4);
            flxFutureDate.add(lblFutureDateInfo, flxFutContainer);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "24dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxPayAmtContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayAmtContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffBordere3e3e3shad",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayAmtContainer.setDefaultUnit(kony.flex.DP);
            var flxPayAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "24dp",
                "isModalContainer": false,
                "right": "24dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "93.50%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayAmount.setDefaultUnit(kony.flex.DP);
            var flxImgAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "48dp",
                "id": "flxImgAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "16dp",
                "width": "48dp",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgAmount.setDefaultUnit(kony.flex.DP);
            var imgAmount = new kony.ui.Image2({
                "height": "100%",
                "id": "imgAmount",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "payment_medium.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgAmount.add(imgAmount);
            var flxAmtContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAmtContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "16dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "4dp",
                "width": "95%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmtContainer.setDefaultUnit(kony.flex.DP);
            var lblEnteredAmt = new kony.ui.Label({
                "id": "lblEnteredAmt",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknLbl424242SSPRegular24px",
                "text": "$5,000.00",
                "textStyle": {},
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTeePee = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxTeePee",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "4dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTeePee.setDefaultUnit(kony.flex.DP);
            var lblTo = new kony.ui.Label({
                "id": "lblTo",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.to\")",
                "textStyle": {},
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTeePee = new kony.ui.Label({
                "id": "lblTeePee",
                "isVisible": false,
                "left": "2dp",
                "skin": "ICSknlbl424242SSP13pxSemibold",
                "text": "TeePee",
                "textStyle": {},
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxAuthInformation = new kony.ui.RichText({
                "id": "rtxAuthInformation",
                "isVisible": true,
                "left": "2dp",
                "linkSkin": "defRichTextLink",
                "skin": "sknRtxSSB000d1915px",
                "text": "<b>TeePee</b>",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEveryMonth = new kony.ui.Label({
                "id": "lblEveryMonth",
                "isVisible": true,
                "left": "3dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.to\")",
                "textStyle": {},
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTeePee.add(lblTo, lblTeePee, rtxAuthInformation, lblEveryMonth);
            var flxDummy3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "16dp",
                "id": "flxDummy3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "-25dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy3.setDefaultUnit(kony.flex.DP);
            flxDummy3.add();
            flxAmtContainer.add(lblEnteredAmt, flxTeePee, flxDummy3);
            flxPayAmount.add(flxImgAmount, flxAmtContainer);
            flxPayAmtContainer.add(flxPayAmount);
            var flxPayDetailsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayDetailsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffBordere3e3e3shad",
                "top": "12dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayDetailsContainer.setDefaultUnit(kony.flex.DP);
            var flxPayContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPayContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "24dp",
                "isModalContainer": false,
                "right": "24dp",
                "skin": "slFbox",
                "top": "24dp",
                "width": "93.50%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayContainer.setDefaultUnit(kony.flex.DP);
            var flxPaymenHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18dp",
                "id": "flxPaymenHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymenHeader.setDefaultUnit(kony.flex.DP);
            var lblPaymentHeader = new kony.ui.Label({
                "id": "lblPaymentHeader",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "sknLbl000d19SSB16px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.paymentAccount\")",
                "textStyle": {},
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymenHeader.add(lblPaymentHeader);
            var flxAccounts = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccounts",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccounts.setDefaultUnit(kony.flex.DP);
            var lblCustomerName = new kony.ui.Label({
                "height": "18dp",
                "id": "lblCustomerName",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "John Smith",
                "textStyle": {},
                "top": "12dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerId = new kony.ui.Label({
                "height": "18dp",
                "id": "lblCustomerId",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "bbSknLbl64727715px",
                "text": "John Smith",
                "textStyle": {},
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "24dp",
                "id": "flxAccAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccAmount.setDefaultUnit(kony.flex.DP);
            var lblAccType = new kony.ui.Label({
                "height": "24dp",
                "id": "lblAccType",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblBgf0eefeB15pxSSR64727711px",
                "text": "Current Account",
                "textStyle": {},
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 1, 2, 1],
                "paddingInPixel": false
            }, {});
            var lblAmount = new kony.ui.Label({
                "bottom": "0dp",
                "id": "lblAmount",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknlbl424242SSP18px",
                "text": "$5,000",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccAmount.add(lblAccType, lblAmount);
            flxAccounts.add(lblCustomerName, lblCustomerId, flxAccAmount);
            var segAccounts = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segAccounts",
                "isVisible": false,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "OpenBankingMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSep14 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSep14",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "16dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSep14.setDefaultUnit(kony.flex.DP);
            flxSep14.add();
            flxPayContainer.add(flxPaymenHeader, flxAccounts, segAccounts, flxSep14);
            var flxSeparatorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparatorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "16dp",
                "width": "93.50%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorHeader.setDefaultUnit(kony.flex.DP);
            flxSeparatorHeader.add();
            var flxFeesAndCharges = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFeesAndCharges",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "24dp",
                "isModalContainer": false,
                "right": "24dp",
                "skin": "slFbox",
                "top": "16dp",
                "width": "93.50%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesAndCharges.setDefaultUnit(kony.flex.DP);
            var lblFeesAndCharges = new kony.ui.Label({
                "height": "18dp",
                "id": "lblFeesAndCharges",
                "isVisible": true,
                "left": "0dp",
                "right": "30dp",
                "skin": "sknLbl000d19SSB16px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.feesandCharges\")",
                "textStyle": {},
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flx2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flx2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "12dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx2.setDefaultUnit(kony.flex.DP);
            var lblAmt = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAmt",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.Amount\")",
                "textStyle": {},
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmtValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAmtValue",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$5,000",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx2.add(lblAmt, lblAmtValue);
            var flx10 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flx10",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "8dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx10.setDefaultUnit(kony.flex.DP);
            var lblExchangeRate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblExchangeRate",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.exchangeRate\")",
                "textStyle": {},
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExchangeRateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblExchangeRateValue",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$5,000",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx10.add(lblExchangeRate, lblExchangeRateValue);
            var flx3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flx3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "8dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx3.setDefaultUnit(kony.flex.DP);
            var lblTransFee = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTransFee",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.transactionFee\")",
                "textStyle": {},
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTransFeeValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTransFeeValue",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$5,00",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx3.add(lblTransFee, lblTransFeeValue);
            var flx4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flx4",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "8dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx4.setDefaultUnit(kony.flex.DP);
            var lblServiceFee = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblServiceFee",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.serviceFeeWithColon\")",
                "textStyle": {},
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblServiceFeeValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblServiceFeeValue",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "$5,00",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx4.add(lblServiceFee, lblServiceFeeValue);
            var flx1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "22dp",
                "id": "flx1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "8dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx1.setDefaultUnit(kony.flex.DP);
            var lblTotalDebit = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTotalDebit",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.totaltoPay\")",
                "textStyle": {},
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalDebitValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblTotalDebitValue",
                "isVisible": true,
                "left": "0",
                "skin": "sknLbl000d19SSPSemiBold18Px",
                "text": "$5,000",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx1.add(lblTotalDebit, lblTotalDebitValue);
            flxFeesAndCharges.add(lblFeesAndCharges, flx2, flx10, flx3, flx4, flx1);
            var flxFeeAndChargesSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxFeeAndChargesSep",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "16dp",
                "width": "93.50%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeeAndChargesSep.setDefaultUnit(kony.flex.DP);
            flxFeeAndChargesSep.add();
            var flxPaymentDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "24dp",
                "isModalContainer": false,
                "right": "24dp",
                "skin": "slFbox",
                "top": "16dp",
                "width": "93.50%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetails.setDefaultUnit(kony.flex.DP);
            var lblPaymentDetailsHdr = new kony.ui.Label({
                "height": "18dp",
                "id": "lblPaymentDetailsHdr",
                "isVisible": true,
                "left": "0dp",
                "right": "30dp",
                "skin": "sknLbl000d19SSB16px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.accdetails.paymentDetails\")",
                "textStyle": {},
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flx6 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flx6",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "12dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx6.setDefaultUnit(kony.flex.DP);
            var lblPayeeAcc = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPayeeAcc",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.payeeAccount\")",
                "textStyle": {},
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayeeAccValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPayeeAccValue",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "DE685001051780001240",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx6.add(lblPayeeAcc, lblPayeeAccValue);
            var flx7 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flx7",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "8dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx7.setDefaultUnit(kony.flex.DP);
            var lblPaymentRef = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPaymentRef",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.reference\")",
                "textStyle": {},
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPaymentRefValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPaymentRefValue",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "X2023-32325234",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx7.add(lblPaymentRef, lblPaymentRefValue);
            var flx5 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flx5",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "8dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx5.setDefaultUnit(kony.flex.DP);
            var flxFrequency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxFrequency",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "0dp",
                "width": "140dp",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency.setDefaultUnit(kony.flex.DP);
            var lblFrequency = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFrequency",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.frequencyColon\")",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFrequency.add(lblFrequency);
            var lblFrequencyValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFrequencyValue",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Once",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx5.add(flxFrequency, lblFrequencyValue);
            var flx8 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flx8",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "8dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx8.setDefaultUnit(kony.flex.DP);
            var lblPaymentDate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPaymentDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.paymentDateWithColon\")",
                "textStyle": {},
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPaymentDateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPaymentDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "10 May 2024",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx8.add(lblPaymentDate, lblPaymentDateValue);
            var flx9 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flx9",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox",
                "top": "8dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flx9.setDefaultUnit(kony.flex.DP);
            var lblCreditDate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCreditDate",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl64727715px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.creditValueDateWithColon\")",
                "textStyle": {},
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCreditDateValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCreditDateValue",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "10 May 2024",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flx9.add(lblCreditDate, lblCreditDateValue);
            flxPaymentDetails.add(lblPaymentDetailsHdr, flx6, flx7, flx5, flx8, flx9);
            var flxPaymentInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "24dp",
                "isModalContainer": false,
                "right": "24dp",
                "skin": "skflxbgf7f8f7border4pxe3e3e3",
                "top": "24dp",
                "width": "93.50%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentInfo.setDefaultUnit(kony.flex.DP);
            var lblPaymentInfo = new kony.ui.Label({
                "height": "24dp",
                "id": "lblPaymentInfo",
                "isVisible": true,
                "left": "8dp",
                "right": "30dp",
                "skin": "sknLbl6E7081OlbFonticons20px",
                "text": "K",
                "textStyle": {},
                "top": "16dp",
                "width": "24dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaymentInfoContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentInfoContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "-21dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentInfoContainer.setDefaultUnit(kony.flex.DP);
            var lblPaymentInfoHdr = new kony.ui.Label({
                "id": "lblPaymentInfoHdr",
                "isVisible": true,
                "left": "0dp",
                "right": "30dp",
                "skin": "ICSknlbl424242SSP13pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.paymentInfo\")",
                "textStyle": {},
                "top": "8dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSinglePaymentInfo = new kony.ui.Label({
                "id": "lblSinglePaymentInfo",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.SinglePaymentInfo\")",
                "textStyle": {},
                "top": "4dp",
                "width": "98.90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRecurringPaymentMsg1 = new kony.ui.Label({
                "id": "lblRecurringPaymentMsg1",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.recurringPaymentMsg1\")",
                "textStyle": {},
                "top": "4dp",
                "width": "98.90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRecurringPaymentMsg2 = new kony.ui.Label({
                "id": "lblRecurringPaymentMsg2",
                "isVisible": false,
                "left": "0dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.recurringPaymentMsg2\")",
                "textStyle": {},
                "top": "4dp",
                "width": "99.11%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDummy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "12dp",
                "id": "flxDummy",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "-25dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy.setDefaultUnit(kony.flex.DP);
            flxDummy.add();
            flxPaymentInfoContainer.add(lblPaymentInfoHdr, lblSinglePaymentInfo, lblRecurringPaymentMsg1, lblRecurringPaymentMsg2, flxDummy);
            flxPaymentInfo.add(lblPaymentInfo, flxPaymentInfoContainer);
            var flxButtons = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "88dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "16dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnApprove = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "SEARCH"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15Px",
                "height": "40dp",
                "id": "btnApprove",
                "isVisible": true,
                "left": "0",
                "right": "24dp",
                "skin": "sknBtnNormalSSPFFFFFF15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.Approve\")",
                "width": "160dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px"
            });
            var btnReject = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "SEARCH"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnffffffBorder0273e31pxRadius2px",
                "height": "40dp",
                "id": "btnReject",
                "isVisible": true,
                "left": "0",
                "right": "16dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18.termsandconditions\")",
                "width": "160dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxButtons.add(btnApprove, btnReject);
            flxPayDetailsContainer.add(flxPayContainer, flxSeparatorHeader, flxFeesAndCharges, flxFeeAndChargesSep, flxPaymentDetails, flxPaymentInfo, flxButtons);
            flxMainContainer.add(flxPayAmtContainer, flxPayDetailsContainer);
            var flxDummy1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "40dp",
                "id": "flxDummy1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "94%",
                "zIndex": 1,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDummy1.setDefaultUnit(kony.flex.DP);
            flxDummy1.add();
            flxFormContent.add(lblHeader, flxErrorSingle, flxErrorMultiple, flxFutureDate, flxMainContainer, flxDummy1);
            flxContent.add(flxFormContent);
            var flxRejectPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxRejectPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000op60",
                "top": "0dp",
                "width": "100%",
                "zIndex": 200,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectPopup.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "268dp",
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffBordere3e3e3shad",
                "width": "500dp",
                "zIndex": 20,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var lblTitle = new kony.ui.Label({
                "height": "24dp",
                "id": "lblTitle",
                "isVisible": true,
                "left": "24dp",
                "skin": "sknLbl000d19SSPSemiBold18Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.reject\")",
                "textStyle": {},
                "top": "20dp",
                "width": "50%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "30dp",
                "top": "0dp",
                "width": "35dp",
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCross.setDefaultUnit(kony.flex.DP);
            var btnClose = new kony.ui.Button({
                "height": "0dp",
                "id": "btnClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "btnClose",
                "top": "0dp",
                "width": "5dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCross.add(btnClose);
            var lblRejectInfo = new kony.ui.Label({
                "id": "lblRejectInfo",
                "isVisible": true,
                "left": "24dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.tppConsent.reject\")",
                "textStyle": {},
                "top": "67dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSep = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSep",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxfafafa",
                "top": "20dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSep.setDefaultUnit(kony.flex.DP);
            flxSep.add();
            var flxRejButtons = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": true,
                "height": "88dp",
                "id": "flxRejButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffB",
                "width": "100%",
                "zIndex": 20,
                "appName": "OpenBankingMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejButtons.setDefaultUnit(kony.flex.DP);
            var btnYes = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "SEARCH"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40dp",
                "id": "btnYes",
                "isVisible": true,
                "right": "24dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.yes\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px"
            });
            var btnNo = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "SEARCH"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnffffffBorder0273e31pxRadius2px",
                "height": "40dp",
                "id": "btnNo",
                "isVisible": true,
                "left": "0%",
                "right": "20dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxRejButtons.add(btnYes, btnNo);
            flxContainer.add(lblTitle, flxCross, lblRejectInfo, flxSep, flxRejButtons);
            flxRejectPopup.add(flxContainer);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeader": {
                        "segmentProps": []
                    },
                    "flxHdr": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxLogo": {
                        "segmentProps": []
                    },
                    "flxHeaderSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFutureDate": {
                        "height": {
                            "type": "string",
                            "value": "68dp"
                        },
                        "segmentProps": []
                    },
                    "flxFutContainer": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "flxFutureDateContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": []
                    },
                    "lblFutureDate": {
                        "i18n_text": "i18n.tppConsent.paymentMadeOn",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxDummy4": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPayAmount": {
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "flxDummy3": {
                        "segmentProps": []
                    },
                    "flxPayDetailsContainer": {
                        "segmentProps": []
                    },
                    "flxPayContainer": {
                        "width": {
                            "type": "string",
                            "value": "86.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSeparatorHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "86.50%"
                        },
                        "segmentProps": []
                    },
                    "lblAmt": {
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "lblExchangeRate": {
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "lblTransFee": {
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "lblServiceFee": {
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "lblTotalDebit": {
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeeAndChargesSep": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "86.50%"
                        },
                        "segmentProps": []
                    },
                    "lblPayeeAcc": {
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentRef": {
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxFrequency": {
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "lblPaymentDate": {
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "lblCreditDate": {
                        "width": {
                            "type": "string",
                            "value": "130dp"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentInfo": {
                        "width": {
                            "type": "string",
                            "value": "86.50%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentInfoContainer": {
                        "width": {
                            "type": "string",
                            "value": "86.50%"
                        },
                        "segmentProps": []
                    },
                    "lblSinglePaymentInfo": {
                        "i18n_text": "i18n.tppConsent.SinglePaymentInfo",
                        "text": "Access will be until 31 jul 2024 (180 days), you can withdraw access any time.Access will be until 31 jul 2024 (180 days), you can withdraw access any time.Access will be until 31 jul 2024 (180 days), you can withdraw access any time.Access will be until 31 jul 2024 (180 days), you can withdraw access any time.Access will be until 31 jul 2024 (180 days), you can withdraw access any time.Access will be until 31 jul 2024 (180 days), you can withdraw access any time.",
                        "segmentProps": []
                    },
                    "lblRecurringPaymentMsg1": {
                        "i18n_text": "i18n.tppConsent.recurringPaymentMsg1",
                        "text": "Access will be until 31 jul 2024 (180 days), you can withdraw access any time.Access will be until 31 jul 2024 (180 days), you can withdraw access any time.Access will be until 31 jul 2024 (180 days), you can withdraw access any time.Access will be until 31 jul 2024 (180 days), you can withdraw access any time.Access will be until 31 jul 2024 (180 days), you can withdraw access any time.Access will be until 31 jul 2024 (180 days), you can withdraw access any time.",
                        "width": {
                            "type": "string",
                            "value": "98.90%"
                        },
                        "segmentProps": []
                    },
                    "lblRecurringPaymentMsg2": {
                        "width": {
                            "type": "string",
                            "value": "98.90%"
                        },
                        "segmentProps": []
                    },
                    "flxDummy": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "144dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "btnApprove": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "72dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.20%"
                        },
                        "segmentProps": []
                    },
                    "btnReject": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "16dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.20%"
                        },
                        "segmentProps": []
                    },
                    "flxDummy1": {
                        "segmentProps": []
                    },
                    "flxRejectPopup": {
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnClose": {
                        "segmentProps": []
                    },
                    "flxRejButtons": {
                        "bottom": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "96dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "btnYes": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "56dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    },
                    "btnNo": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxHdr": {
                        "segmentProps": []
                    },
                    "flxLogo": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "width": {
                            "type": "string",
                            "value": "728dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "flxCross": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnClose": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxLogo": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "btnApprove": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxCross": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnClose": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxLogo": {
                        "segmentProps": []
                    },
                    "lblEnteredAmt": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "reverseLayoutDirection": true,
                        "segmentProps": []
                    },
                    "flxCross": {
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "btnClose": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {}
            this.add(flxHeader, flxContent, flxRejectPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmConsentVerifyDetails,
            "enabledForIdleTimeout": true,
            "id": "frmConsentVerifyDetails",
            "init": controller.AS_Form_fc4c49027a9e4c35a46e8e34fb7a5891,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "title": "Verify Details",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "OpenBankingMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});