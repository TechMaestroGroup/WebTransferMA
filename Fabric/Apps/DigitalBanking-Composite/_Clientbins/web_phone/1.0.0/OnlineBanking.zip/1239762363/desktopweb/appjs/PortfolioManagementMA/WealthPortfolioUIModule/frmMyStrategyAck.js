define("PortfolioManagementMA/WealthPortfolioUIModule/frmMyStrategyAck", function() {
    return function(controller) {
        function addWidgetsfrmMyStrategyAck() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.hamburger.myaccounts\")",
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMainContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxAckHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAckHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6.70%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "88%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckHeader.setDefaultUnit(kony.flex.DP);
            var flxHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeading",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "95%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeading.setDefaultUnit(kony.flex.DP);
            var lblAckHeader = new kony.ui.Label({
                "id": "lblAckHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.myStrategyAcknowledgement\")",
                "top": "25dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeading.add(lblAckHeader);
            var flxButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxButtons",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "5%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var imgDownload = new kony.ui.Image2({
                "height": "19dp",
                "id": "imgDownload",
                "isVisible": true,
                "left": "0dp",
                "src": "download_2x.png",
                "top": "10dp",
                "width": "14dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgPrint = new kony.ui.Image2({
                "height": "18dp",
                "id": "imgPrint",
                "isVisible": true,
                "left": "20dp",
                "src": "print_blue.png",
                "top": "10dp",
                "width": "19dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(imgDownload, imgPrint);
            flxAckHeader.add(flxHeading, flxButtons);
            var flxAckMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAckMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.70%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "88%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckMain.setDefaultUnit(kony.flex.DP);
            var flxAck = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAck",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "16dp",
                "width": "49%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAck.setDefaultUnit(kony.flex.DP);
            var acknowledgmentModify = new com.InfinityOLB.PortfolioManagementMA.acknowledgmentModify({
                "height": "410dp",
                "id": "acknowledgmentModify",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknFlexRoundedBorderFFFFFF3Pxshadowd9d9d9noshadow",
                "top": "0dp",
                "width": "100%",
                "appName": "PortfolioManagementMA",
                "overrides": {
                    "ImgAcknowledged": {
                        "height": "74dp",
                        "src": "success_green.png",
                        "top": "140dp",
                        "width": "74dp"
                    },
                    "acknowledgmentModify": {
                        "centerY": "viz.val_cleared",
                        "height": "410dp",
                        "left": undefined,
                        "top": "0dp"
                    },
                    "btnModifyTransfer": {
                        "isVisible": false
                    },
                    "flxBalance": {
                        "height": "70dp",
                        "isVisible": false
                    },
                    "lblRefrenceNumber": {
                        "isVisible": false
                    },
                    "lblRefrenceNumberValue": {
                        "bottom": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "isVisible": true,
                        "top": "330dp",
                        "width": "100%"
                    },
                    "lblTransactionDate": {
                        "isVisible": false
                    },
                    "lblTransactionMessage": {
                        "top": "80px",
                        "width": "94.40%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAck.add(acknowledgmentModify);
            var flxStrategy = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxStrategy",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "minHeight": "410dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "16dp",
                "width": "49%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStrategy.setDefaultUnit(kony.flex.DP);
            var lblStrategy = new kony.ui.Label({
                "id": "lblStrategy",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabel42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.strategy\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeprator = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSeprator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeprator.setDefaultUnit(kony.flex.DP);
            flxSeprator.add();
            var flxComp = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxComp",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxComp.setDefaultUnit(kony.flex.DP);
            flxComp.add();
            var flxStrategyName = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "30dp",
                "id": "flxStrategyName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "21dp",
                "width": "40%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStrategyName.setDefaultUnit(kony.flex.DP);
            var imgStrategyIcon = new kony.ui.Image2({
                "centerY": "50%",
                "height": "30dp",
                "id": "imgStrategyIcon",
                "isVisible": false,
                "left": "0dp",
                "src": "active_one.png",
                "top": "0",
                "width": "30dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblStrategyName = new kony.ui.Label({
                "height": "28dp",
                "id": "lblStrategyName",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknSSPSemiBold42424220px",
                "text": "Active",
                "top": "1dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStrategyName.add(imgStrategyIcon, lblStrategyName);
            var flxDonutSeg = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxDonutSeg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDonutSeg.setDefaultUnit(kony.flex.DP);
            var flxDonut = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDonut",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "20dp",
                "width": "40%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDonut.setDefaultUnit(kony.flex.DP);
            var wealthDonut = new com.InfinityOLB.PortfolioManagement.wealthDonut({
                "height": "100%",
                "id": "wealthDonut",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA",
                "viewType": "wealthDonut",
                "overrides": {
                    "wealthDonut": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var wealthDonut_data = (appConfig.componentMetadata && appConfig.componentMetadata["PortfolioManagementMA"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmMyStrategyAck"] && appConfig.componentMetadata["PortfolioManagementMA"]["frmMyStrategyAck"]["wealthDonut"]) || {};
            flxDonut.add(wealthDonut);
            var flxSeg = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxSeg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "top": "45dp",
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeg.setDefaultUnit(kony.flex.DP);
            var segStrategyDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblAsset": "",
                    "lblValue": ""
                }],
                "groupCells": false,
                "id": "segStrategyDetails",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "PortfolioManagementMA",
                    "friendlyName": "flxSegMyStrategyOLB"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxAssetDetail": "flxAssetDetail",
                    "flxDot": "flxDot",
                    "flxSegMyStrategyOLB": "flxSegMyStrategyOLB",
                    "lblAsset": "lblAsset",
                    "lblValue": "lblValue"
                },
                "width": "100%",
                "appName": "PortfolioManagementMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeg.add(segStrategyDetails);
            flxDonutSeg.add(flxDonut, flxSeg);
            flxStrategy.add(lblStrategy, flxSeprator, flxComp, flxStrategyName, flxDonutSeg);
            flxAckMain.add(flxAck, flxStrategy);
            var flxButton = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxButton",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "6.70%",
                "isModalContainer": false,
                "top": "0",
                "width": "88%",
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButton.setDefaultUnit(kony.flex.DP);
            var btnReview = new kony.ui.Button({
                "height": "50dp",
                "id": "btnReview",
                "isVisible": true,
                "left": "0",
                "right": "0dp",
                "skin": "sknBtnSSPffffff15pxBg0273e3",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.reviewStrategy\")",
                "top": "0",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnChange = new kony.ui.Button({
                "bottom": "0dp",
                "height": "50dp",
                "id": "btnChange",
                "isVisible": true,
                "left": "0",
                "right": "15dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.changeStrategy\")",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButton.add(btnReview, btnChange);
            flxMain.add(flxAckHeader, flxAckMain, flxButton);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "130dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnFaqs": {
                        "isVisible": true
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    },
                    "btnPrivacy": {
                        "isVisible": true
                    },
                    "btnTermsAndConditions": {
                        "isVisible": true
                    },
                    "customfooter": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "height": "130dp",
                        "width": "1366dp",
                        "zIndex": 2
                    },
                    "flxFooterMenu": {
                        "centerX": "50%",
                        "left": "viz.val_cleared",
                        "width": "1200dp"
                    },
                    "flxVBar2": {
                        "isVisible": true
                    },
                    "flxVBar3": {
                        "isVisible": true
                    },
                    "flxVBar4": {
                        "isVisible": true
                    },
                    "lblCopyright": {
                        "centerX": "viz.val_cleared",
                        "left": "6%",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew, customfooter);
            flxMainContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "PortfolioManagementMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            flxDialogs.add(flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "text": "Accounts",
                        "segmentProps": []
                    },
                    "flxMainContent": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnContactUs": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar1": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxMainContent": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50.00%"
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxAckHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblAckHeader": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxAckMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAck": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgmentModify.ImgAcknowledged": {
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgmentModify": {
                        "height": {
                            "type": "string",
                            "value": "340dp"
                        },
                        "segmentProps": [],
                        "instanceId": "acknowledgmentModify"
                    },
                    "acknowledgmentModify.flxBalance": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "acknowledgmentModify.lblRefrenceNumber": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "acknowledgmentModify.lblRefrenceNumberValue": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "top": {
                            "type": "string",
                            "value": "285dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgmentModify.lblTransactionMessage": {
                        "i18n_text": "i18n.wealth.stratSuccessful",
                        "top": {
                            "type": "string",
                            "value": "84px"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxStrategy": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblStrategy": {
                        "i18n_text": "i18n.wealth.strategy",
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Strategy",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeprator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxComp": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "380dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgStrategyIcon": {
                        "height": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "segmentProps": []
                    },
                    "lblStrategyName": {
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxDonutSeg": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxDonut": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxSeg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "30%"
                        },
                        "segmentProps": []
                    },
                    "flxButton": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "btnReview": {
                        "i18n_text": "i18n.wealth.reviewStrategy",
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "text": "Review Strategy",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "btnChange": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.btnLocateUs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "centerY": {
                            "type": "string",
                            "value": "75%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "centerY": {
                            "type": "string",
                            "value": "40%"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxAckHeader": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "lblAckHeader": {
                        "i18n_text": "i18n.wealth.myStrategyAcknowledgement",
                        "text": "My Strategy - Acknowledgement ",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "imgDownload": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "imgPrint": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAckMain": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "acknowledgmentModify.ImgAcknowledged": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "src": "success_icon.png",
                        "top": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80px"
                        },
                        "segmentProps": []
                    },
                    "acknowledgmentModify": {
                        "segmentProps": [],
                        "instanceId": "acknowledgmentModify"
                    },
                    "acknowledgmentModify.flxBalance": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "acknowledgmentModify.lblRefrenceNumberValue": {
                        "bottom": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "acknowledgmentModify.lblTransactionMessage": {
                        "i18n_text": "i18n.wealth.stratSuccessful",
                        "segmentProps": []
                    },
                    "flxStrategy": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblStrategy": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "i18n_text": "i18n.wealth.strategy",
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "text": "Strategy",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeprator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxComp": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxStrategyName": {
                        "height": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "segmentProps": []
                    },
                    "flxDonutSeg": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "25"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxDonut": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "width": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "wealthDonut": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxSeg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxButton": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "btnReview": {
                        "bottom": {
                            "type": "string",
                            "value": "0"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "i18n_text": "i18n.wealth.reviewStrategy",
                        "text": "Review Strategy",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "btnChange": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "i18n_text": "i18n.wealth.changeStrategy",
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "bottom": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.flxFooterMenu": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "width": {
                            "type": "string",
                            "value": "87%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxAckHeader": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "segmentProps": []
                    },
                    "flxAckMain": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "flxAck": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxStrategy": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblStrategy": {
                        "i18n_text": "i18n.wealth.strategy",
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "text": "Strategy",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeprator": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "1px"
                        },
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "flxComp": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxStrategyName": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "segmentProps": []
                    },
                    "flxDonutSeg": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxDonut": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxSeg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxButton": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "btnReview": {
                        "i18n_text": "i18n.wealth.reviewStrategy",
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "text": "Review Strategy",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    },
                    "btnChange": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "250dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "acknowledgmentModify.ImgAcknowledged": {
                    "height": "74dp",
                    "src": "success_green.png",
                    "top": "140dp",
                    "width": "74dp"
                },
                "acknowledgmentModify": {
                    "centerY": "",
                    "height": "410dp",
                    "left": undefined,
                    "top": "0dp"
                },
                "acknowledgmentModify.flxBalance": {
                    "height": "70dp"
                },
                "acknowledgmentModify.lblRefrenceNumberValue": {
                    "bottom": "",
                    "centerY": "",
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "top": "330dp",
                    "width": "100%"
                },
                "acknowledgmentModify.lblTransactionMessage": {
                    "top": "80px",
                    "width": "94.40%"
                },
                "wealthDonut": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "customfooter": {
                    "centerX": "50%",
                    "centerY": "",
                    "height": "130dp",
                    "width": "1366dp",
                    "zIndex": 2
                },
                "customfooter.flxFooterMenu": {
                    "centerX": "50%",
                    "left": "",
                    "width": "1200dp"
                },
                "customfooter.lblCopyright": {
                    "centerX": "",
                    "left": "6%",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "CustomPopup": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                }
            }
            this.add(flxHeader, flxMainContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmMyStrategyAck,
            "enabledForIdleTimeout": true,
            "id": "frmMyStrategyAck",
            "init": controller.AS_Form_aa849280c4714f4697469bbc75a5748f,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "PortfolioManagementMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});