define("BulkPaymentsMA/BulkPaymentsUIModule/frmBulkPaymentsReview", function() {
    return function(controller) {
        function addWidgetsfrmBulkPaymentsReview() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeaderMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderMain.setDefaultUnit(kony.flex.DP);
            var customheader = new com.InfinityOLB.Resources.customheader({
                "height": "121px",
                "id": "customheader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxSeperatorHor2": {
                        "isVisible": true
                    },
                    "flxUserActions": {
                        "isVisible": false
                    },
                    "headermenu.imgUserReset": {
                        "src": "profileheadernew.png"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    },
                    "segUserActions": {
                        "isVisible": true
                    },
                    "topmenu.flxContextualMenu": {
                        "isVisible": false
                    },
                    "topmenu.lblFeedback": {
                        "text": "Feedback"
                    },
                    "topmenu.lblHelp": {
                        "text": "Help"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderMain.add(customheader);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "Copybbsknf0ed23e6160bbb45",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxMainWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxMainWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 2,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainWrapper.setDefaultUnit(kony.flex.DP);
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "30dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDowntimeWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseDowntimeWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxDowntimeWarning.add(imgDowntimeWarning, lblDowntimeWarning, imgCloseDowntimeWarning);
            var flxOverdraftWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxOverdraftWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverdraftWarning.setDefaultUnit(kony.flex.DP);
            var imgOverDraft = new kony.ui.Image2({
                "centerY": "47%",
                "height": "40dp",
                "id": "imgOverDraft",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOverdraftWarning = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblOverdraftWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.OverDraftWarning\")",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseWarning = new kony.ui.Image2({
                "centerY": "50%",
                "height": "75%",
                "id": "imgCloseWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOverdraftWarning.add(imgOverDraft, lblOverdraftWarning, imgCloseWarning);
            var flxOutageWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxOutageWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "20dp",
                "width": "88%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOutageWarning.setDefaultUnit(kony.flex.DP);
            var imgInfoIconWarning = new kony.ui.Image2({
                "bottom": "10dp",
                "height": "40dp",
                "id": "imgInfoIconWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "10dp",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutageWarning = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblOutageWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.AccountsLanding.Ouronlinebankingapplicationwillbeunavailableon13042017between\")",
                "top": "13dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgCloseOutageWarning = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgCloseOutageWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknImgPointer",
                "src": "icon_close_grey.png",
                "top": "10dp",
                "width": "5%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxOutageWarning.add(imgInfoIconWarning, lblOutageWarning, imgCloseOutageWarning);
            flxMainWrapper.add(flxDowntimeWarning, flxOverdraftWarning, flxOutageWarning);
            var flxskncontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "150px",
                "id": "flxskncontainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxskncontainer.setDefaultUnit(kony.flex.DP);
            var sknleftcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknleftcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "width": "50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknleftcontainer.setDefaultUnit(kony.flex.DP);
            sknleftcontainer.add();
            var sknrightcontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "152dp",
                "id": "sknrightcontainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlexF9F9F9",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            sknrightcontainer.setDefaultUnit(kony.flex.DP);
            sknrightcontainer.add();
            flxskncontainer.add(sknleftcontainer, sknrightcontainer);
            var flxContentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxContentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentContainer.setDefaultUnit(kony.flex.DP);
            var flxContentHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "70dp",
                "id": "flxContentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentHeader.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "2dp",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.bulkPaymentsReview\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgDownloadAch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImgDownloadAch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "90.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "2%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgDownloadAch.setDefaultUnit(kony.flex.DP);
            var imgDownloadAchTransaction = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgDownloadAchTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "bbdownloadicon.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgDownloadAch.add(imgDownloadAchTransaction);
            var flxImgPrintAch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxImgPrintAch",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "93.08%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "3%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgPrintAch.setDefaultUnit(kony.flex.DP);
            var imgPrintAchTransaction = new kony.ui.Image2({
                "centerX": "50%",
                "id": "imgPrintAchTransaction",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "bbprint.png",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgPrintAch.add(imgPrintAchTransaction);
            var flxPrint = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "25dp",
                "id": "flxPrint",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "30dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknflxF4F4F4"
            });
            flxPrint.setDefaultUnit(kony.flex.DP);
            var imgPrint = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25dp",
                "id": "imgPrint",
                "isVisible": false,
                "skin": "slImage",
                "src": "print_blue.png",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Print"
            });
            var lblPrintfontIconConfirm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.accounts.print\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "30dp",
                "id": "lblPrintfontIconConfirm",
                "isVisible": true,
                "skin": "sknPrintFonticon0273e3",
                "text": "p",
                "width": "35px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [13, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPrint.add(imgPrint, lblPrintfontIconConfirm);
            var flxDownload = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "30dp",
                "id": "flxDownload",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5.50%",
                "skin": "slFbox",
                "top": "30dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknflxF4F4F4"
            });
            flxDownload.setDefaultUnit(kony.flex.DP);
            var imgDownload = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.Download\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25dp",
                "id": "imgDownload",
                "isVisible": false,
                "skin": "slImage",
                "src": "download_blue.png",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Print"
            });
            var lblDownloadfontIconConfirm = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.Download\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "25dp",
                "id": "lblDownloadfontIconConfirm",
                "isVisible": true,
                "skin": "sknPrintFonticon0273e3",
                "text": "D",
                "width": "25px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxDownload.add(imgDownload, lblDownloadfontIconConfirm);
            flxContentHeader.add(lblContentHeader, flxImgDownloadAch, flxImgPrintAch, flxPrint, flxDownload);
            var flxDisplayErrorMessage = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "66dp",
                "id": "flxDisplayErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0ja0ebdb1e9dc42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgDisplayError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgDisplayError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDisplayError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblDisplayError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblee0005SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisplayErrorMessage.add(imgDisplayError, lblDisplayError);
            var flxGenericMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "18dp",
                "clipBounds": false,
                "id": "flxGenericMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxGenericMessage.setDefaultUnit(kony.flex.DP);
            var GenericMessageNew = new com.InfinityOLB.Transfers.GenericMessageNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "GenericMessageNew",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "TransfersMA",
                "viewType": "GenericMessageNew",
                "overrides": {
                    "GenericMessageNew": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var GenericMessageNew_data = (appConfig.componentMetadata && appConfig.componentMetadata["TransfersMA"] && appConfig.componentMetadata["TransfersMA"]["frmBulkPaymentsReview"] && appConfig.componentMetadata["TransfersMA"]["frmBulkPaymentsReview"]["GenericMessageNew"]) || {};
            GenericMessageNew.dataMapping = GenericMessageNew_data.dataMapping || {
                "genMsg": "{$.collectionObj.genericMessage}",
                "messageDetails": "{$.collectionObj.message}",
                "successMsg": "{$.collectionObj.genericSuccessMessage}",
                "maxLength": "3",
                "messageType": "{$.collectionObj.messageType}",
                "lblSuccess": "${i18n{i18n.transfers.lblTo}}"
            };
            flxGenericMessage.add(GenericMessageNew);
            var flxAckMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "18dp",
                "clipBounds": false,
                "height": "90dp",
                "id": "flxAckMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckMessage.setDefaultUnit(kony.flex.DP);
            var flxImgContainer = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxImgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "10%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgContainer.setDefaultUnit(kony.flex.DP);
            var imgCheck = new kony.ui.Image2({
                "height": "60dp",
                "id": "imgCheck",
                "isVisible": true,
                "left": "2%",
                "skin": "slImage",
                "src": "success_green_2.png",
                "top": 0,
                "width": "60dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgContainer.add(imgCheck);
            var lblSuccessMessage = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblSuccessMessage",
                "isVisible": true,
                "left": "0%",
                "skin": "bbSknLbl424242SSP20Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.businessEnrollmentSuccessMessage\")",
                "top": 0,
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRightContainerInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxRightContainerInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "30%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainerInfo.setDefaultUnit(kony.flex.DP);
            var lblReferenceHeader = new kony.ui.Label({
                "centerY": "35%",
                "id": "lblReferenceHeader",
                "isVisible": true,
                "left": "332dp",
                "right": "10%",
                "skin": "sknLabelSSP42424217px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.ReferenceNumber\")",
                "top": "33dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumber = new kony.ui.Label({
                "centerY": "65%",
                "id": "lblReferenceNumber",
                "isVisible": true,
                "left": "480dp",
                "right": "10%",
                "skin": "bbSknLbl424242SSP20Px",
                "text": "Label",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightContainerInfo.add(lblReferenceHeader, lblReferenceNumber);
            flxAckMessage.add(flxImgContainer, lblSuccessMessage, flxRightContainerInfo);
            var flxContentDashBoard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContentDashBoard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContentDashBoard.setDefaultUnit(kony.flex.DP);
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.07%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "4dp",
                "width": "90%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var flxTabPaneContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTabPaneContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabPaneContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgementContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "19dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "90dp",
                "id": "flxAcknowledgementContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementContainer.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgement = new com.InfinityOLB.Resources.flxAcknowledgement({
                "centerY": "50%",
                "height": "100%",
                "id": "flxAcknowledgement",
                "isVisible": false,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "ResourcesMA",
                "viewType": "flxAcknowledgement",
                "overrides": {
                    "flxTickImage": {
                        "width": "4.44%"
                    },
                    "rTextSuccess": {
                        "text": "Your transaction has been successfully submitted\nReference Number 45423792753"
                    },
                    "flxAcknowledgement": {
                        "right": "viz.val_cleared",
                        "top": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxAcknowledgement_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmBulkPaymentsReview"] && appConfig.componentMetadata["ResourcesMA"]["frmBulkPaymentsReview"]["flxAcknowledgement"]) || {};
            var flxAcknowledgementNew = new com.InfinityOLB.Resources.flxAcknowledgementNew({
                "height": "100%",
                "id": "flxAcknowledgementNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxAckContainer": {
                        "height": "85dp"
                    },
                    "flxAcknowledgementNew": {
                        "isVisible": true,
                        "left": "0dp",
                        "width": "100%"
                    },
                    "flxImgPrint": {
                        "isVisible": false
                    },
                    "flxImgdownload": {
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "height": "22dp",
                        "isVisible": true,
                        "left": "95%",
                        "width": "22dp"
                    },
                    "imgDownload": {
                        "height": "100%",
                        "imageWhenFailed": "bbcloseicon_1.png",
                        "imageWhileDownloading": "bbcloseicon_1.png",
                        "src": "bbcloseicon_1.png",
                        "width": "100%"
                    },
                    "imgPrint": {
                        "src": "bbprint.png"
                    },
                    "imgTick": {
                        "src": "bulk_billpay_success.png"
                    },
                    "rTextSuccess": {
                        "height": kony.flex.USE_PREFFERED_SIZE,
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.manageUser.UserAddedSuccess\")",
                        "left": "8.80%",
                        "width": "80%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAcknowledgementContainer.add(flxAcknowledgement, flxAcknowledgementNew);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "focusSkin": "sknFlxffffffShadowdddcdc",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblee0005SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(imgError, lblError);
            var flxPaymentReview = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPaymentReview",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentReview.setDefaultUnit(kony.flex.DP);
            var NonEditableBulkPaymentDetails = new com.InfinityOLB.BulkPaymentsMA.NonEditableBulkPaymentDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "NonEditableBulkPaymentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA",
                "overrides": {
                    "NonEditableBulkPaymentDetails": {
                        "isVisible": true,
                        "top": "0dp"
                    },
                    "btnEdit": {
                        "isVisible": true,
                        "width": "45dp"
                    },
                    "flxBtmSeperator": {
                        "top": "15dp",
                        "width": "100%"
                    },
                    "flxTitle": {
                        "top": "-44dp"
                    },
                    "lblACHTitleText": {
                        "centerY": "26dp",
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.PaymentSummary\")"
                    },
                    "segNonEditableDetails": {
                        "data": [{
                            "lblColon": ":",
                            "lblIcon": "",
                            "lblKey": "From Account",
                            "lblValue": "",
                            "lblValueOld": ""
                        }, {
                            "lblColon": ":",
                            "lblIcon": "",
                            "lblKey": "Payment Description",
                            "lblValue": "",
                            "lblValueOld": ""
                        }, {
                            "lblColon": ":",
                            "lblIcon": "",
                            "lblKey": "Payment Date",
                            "lblValue": "",
                            "lblValueOld": ""
                        }, {
                            "lblColon": ":",
                            "lblIcon": "",
                            "lblKey": "Value Date",
                            "lblValue": "",
                            "lblValueOld": ""
                        }, {
                            "lblColon": ":",
                            "lblIcon": "",
                            "lblKey": "Total Amount",
                            "lblValue": "",
                            "lblValueOld": ""
                        }, {
                            "lblColon": ":",
                            "lblIcon": "",
                            "lblKey": "Number of Transactions",
                            "lblValue": "",
                            "lblValueOld": ""
                        }, {
                            "lblColon": ":",
                            "lblIcon": "",
                            "lblKey": "Bulk Payment ID",
                            "lblValue": "",
                            "lblValueOld": ""
                        }, {
                            "lblColon": ":",
                            "lblIcon": "",
                            "lblKey": "Payment File",
                            "lblValue": "",
                            "lblValueOld": ""
                        }],
                        "top": "13dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxEditableDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "600dp",
                "id": "flxEditableDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditableDetails.setDefaultUnit(kony.flex.DP);
            var EditableBulkPaymentDetails = new com.InfinityOLB.BulkPaymentsMA.EditableBulkPaymentDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "EditableBulkPaymentDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA",
                "overrides": {
                    "EditableBulkPaymentDetails": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "isVisible": false,
                        "top": "0dp"
                    },
                    "flxBtmSeperator": {
                        "top": "180dp"
                    },
                    "flxTopSepartor": {
                        "centerX": "50%",
                        "top": "13dp"
                    },
                    "segEditableListBoxDetails": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "data": [{
                            "lblColon": ":",
                            "lblKey": "From Account",
                            "lstFrmAccount": {
                                "masterData": [
                                    ["Key3792415575", "Savings Account Nickname...2365"],
                                    ["Key3338633066", "Value"],
                                    ["Key2518722184", "Value"]
                                ],
                                "selectedKey": "Key3792415575",
                                "selectedKeyValue": ["Key3792415575", "Savings Account Nickname...2365"]
                            }
                        }],
                        "isVisible": true,
                        "top": "20dp"
                    },
                    "segEditableTextBoxDetails": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "data": [{
                            "lblColon": ":",
                            "lblKey": "Description",
                            "txtDescription": {
                                "placeholder": "",
                                "text": "June Salary Payment"
                            }
                        }],
                        "top": "20dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var lblACHTitleText = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblACHTitleText",
                "isVisible": true,
                "left": "1.67%",
                "skin": "bbSknLbl424242SSPS15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.BulkPayments.PaymentSummary\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxTitle",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-45dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTitle.setDefaultUnit(kony.flex.DP);
            var btnEdit = new kony.ui.Button({
                "centerY": "35dp",
                "height": "20dp",
                "id": "btnEdit",
                "isVisible": false,
                "right": "1%",
                "skin": "sknBtn15pxSSp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "top": "40%",
                "width": "100dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTitle.add(btnEdit);
            var flxTopSepartor = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSepartor",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopybbSknFlxSeperatore1",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSepartor.setDefaultUnit(kony.flex.DP);
            flxTopSepartor.add();
            var NonEditableBulkPaymentDetailsEdit = new com.InfinityOLB.BulkPaymentsMA.NonEditableBulkPaymentDetails({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "NonEditableBulkPaymentDetailsEdit",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "top": "8dp",
                "width": "100%",
                "appName": "BulkPaymentsMA",
                "overrides": {
                    "flxBtmSeperator": {
                        "isVisible": false
                    },
                    "flxTitle": {
                        "isVisible": false
                    },
                    "flxTopSepartor": {
                        "isVisible": false
                    },
                    "lblACHTitleText": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxListBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "12%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxListBox",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "15dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxListBox.setDefaultUnit(kony.flex.DP);
            var lblKey = new kony.ui.Label({
                "id": "lblKey",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.fromAccount\")",
                "top": "11dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblColon = new kony.ui.Label({
                "id": "lblColon",
                "isVisible": true,
                "left": "19%",
                "text": ":",
                "top": "11dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lstFrmAccount = new kony.ui.ListBox({
                "id": "lstFrmAccount",
                "isVisible": true,
                "left": "23%",
                "masterData": [
                    ["lb1", "Savings Account Nickname...2365"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "onSelection": controller.AS_ListBox_g36503f916824bd3a115a75e2fc26759,
                "selectedKey": "lb1",
                "skin": "sknLstbxBorder",
                "top": "0",
                "width": "30%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxListBox.add(lblKey, lblColon, lstFrmAccount);
            var lblProcessingDate = new kony.ui.Label({
                "id": "lblProcessingDate",
                "isVisible": true,
                "left": "1.52%",
                "skin": "sknLabelSSP42424215px",
                "text": "ProcessingDate                          :",
                "top": "18dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45dp",
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "24%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-27dp",
                "width": "77%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var flxEffectiveDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxEffectiveDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEffectiveDate.setDefaultUnit(kony.flex.DP);
            var calProcesingDate = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": [null, null, null, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "height": "100%",
                "id": "calProcesingDate",
                "isVisible": true,
                "left": "0dp",
                "placeholder": "dd/mm/yyyy",
                "skin": "sknBBCal42424215px",
                "top": "0dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxEffectiveDate.add(calProcesingDate);
            var lblNotTodayMsg = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNotTodayMsg",
                "isVisible": false,
                "left": "21dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.CannotBeTodaysDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDate.add(flxEffectiveDate, lblNotTodayMsg);
            var lblValueDate = new kony.ui.Label({
                "id": "lblValueDate",
                "isVisible": true,
                "left": "1.52%",
                "skin": "sknLabelSSP42424215px",
                "text": "Value Date                                     :",
                "top": "28dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxValueDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "45dp",
                "id": "flxValueDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "24%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-27dp",
                "width": "77%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValueDate.setDefaultUnit(kony.flex.DP);
            var flxValDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "sknFocusBorder4A90E2",
                "height": "40dp",
                "id": "flxValDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "sknBorderE3E3E3",
                "top": "2dp",
                "width": "350dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValDate.setDefaultUnit(kony.flex.DP);
            var calValueDate = new kony.ui.Calendar({
                "calendarIcon": "calendar.png",
                "dateComponents": [null, null, null, 0, 0, 0],
                "dateFormat": "dd/MM/yyyy",
                "height": "100%",
                "id": "calValueDate",
                "isVisible": true,
                "left": "0dp",
                "placeholder": "dd/mm/yyyy",
                "skin": "sknBBCal42424215px",
                "top": "0dp",
                "viewConfig": {
                    "gridConfig": {
                        "gridCellInactiveDaysSkin": undefined,
                        "gridCellSelectedSkin": undefined,
                        "gridCellSkin": undefined,
                        "gridCellTodaySkin": undefined,
                        "gridCellWeekendSkin": undefined,
                        "gridSkin": undefined,
                        "leftNavigationImage": "arrow_left.png",
                        "rightNavigationImage": "arrow_right.png"
                    }
                },
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 0, 5, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            flxValDate.add(calValueDate);
            var lblNotTodayMsgValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblNotTodayMsgValue",
                "isVisible": false,
                "left": "21dp",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.CannotBeTodaysDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValueDate.add(flxValDate, lblNotTodayMsgValue);
            var flxTextBox = new kony.ui.FlexContainer({
                "centerX": "50%",
                "centerY": "9%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxTextBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "15dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTextBox.setDefaultUnit(kony.flex.DP);
            var lblDescription = new kony.ui.Label({
                "id": "lblDescription",
                "isVisible": true,
                "left": "0%",
                "skin": "sknLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.Accounts.Description\")",
                "top": "11dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblDescColon = new kony.ui.Label({
                "id": "lblDescColon",
                "isVisible": true,
                "left": "19%",
                "text": ":",
                "top": "11dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtDescription = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.City\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "id": "txtDescription",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "23%",
                "secureTextEntry": false,
                "skin": "sknTxtBrodere0e0e0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "30%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxTextBox.add(lblDescription, lblDescColon, txtDescription);
            var flxBtmSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBtmSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "CopybbSknFlxSeperatore1",
                "top": "70dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBtmSeperator.setDefaultUnit(kony.flex.DP);
            flxBtmSeperator.add();
            flxEditableDetails.add(EditableBulkPaymentDetails, lblACHTitleText, flxTitle, flxTopSepartor, NonEditableBulkPaymentDetailsEdit, flxListBox, lblProcessingDate, flxDate, lblValueDate, flxValueDate, flxTextBox, flxBtmSeperator);
            var flxApprovalsHistoryInformation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "clipBounds": true,
                "id": "flxApprovalsHistoryInformation",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalsHistoryInformation.setDefaultUnit(kony.flex.DP);
            var flxApprovalsHistoryErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxApprovalsHistoryErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalsHistoryErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgApprovalHistoryError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgApprovalHistoryError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApprovalHistoryError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblApprovalHistoryError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblee0005SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxErrorSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxErrorSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorSeperator.setDefaultUnit(kony.flex.DP);
            flxErrorSeperator.add();
            flxApprovalsHistoryErrorMessage.add(imgApprovalHistoryError, lblApprovalHistoryError, flxErrorSeperator);
            var flxApprovalHistoryContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalHistoryContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryContent.setDefaultUnit(kony.flex.DP);
            var lblApprovalHistoryInformation = new kony.ui.Label({
                "id": "lblApprovalHistoryInformation",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknLblSSP42424215pxBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.achtransationdetail.ApprovalHistoryInformation\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTopSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "15dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeperator.setDefaultUnit(kony.flex.DP);
            flxTopSeperator.add();
            var flxApprovalStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "25dp",
                "clipBounds": true,
                "id": "flxApprovalStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "8dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalStatus.setDefaultUnit(kony.flex.DP);
            var flxApprovalStatusGroup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalStatusGroup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "60%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalStatusGroup.setDefaultUnit(kony.flex.DP);
            var flxApprovalDetailsStatus = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovalDetailsStatus",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "60%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalDetailsStatus.setDefaultUnit(kony.flex.DP);
            var lblApprovalStatus = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblApprovalStatus",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.ApprovalStatus\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl424242SSP15Px"
            });
            var lblApprovalStatusValue = new kony.ui.Label({
                "centerY": "27dp",
                "id": "lblApprovalStatusValue",
                "isVisible": true,
                "left": "150dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Approved\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl424242SSP15Px"
            });
            flxApprovalDetailsStatus.add(lblApprovalStatus, lblApprovalStatusValue);
            var flxApprovedCountDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApprovedCountDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "60%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovedCountDetails.setDefaultUnit(kony.flex.DP);
            var lblApproveCount = new kony.ui.Label({
                "id": "lblApproveCount",
                "isVisible": true,
                "left": "20dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.approvedWithColon\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblApproveCountVal = new kony.ui.Label({
                "id": "lblApproveCountVal",
                "isVisible": true,
                "left": "185dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "2",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovedCountDetails.add(lblApproveCount, lblApproveCountVal);
            var flxRejectedCountDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRejectedCountDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "60%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRejectedCountDetails.setDefaultUnit(kony.flex.DP);
            var lblRejectCount = new kony.ui.Label({
                "id": "lblRejectCount",
                "isVisible": true,
                "left": 20,
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.rejectedWithColon\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRejectCountVal = new kony.ui.Label({
                "id": "lblRejectCountVal",
                "isVisible": true,
                "left": "190dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRejectedCountDetails.add(lblRejectCount, lblRejectCountVal);
            flxApprovalStatusGroup.add(flxApprovalDetailsStatus, flxApprovedCountDetails, flxRejectedCountDetails);
            var btnPendingAprrovers = new kony.ui.Button({
                "height": "40dp",
                "id": "btnPendingAprrovers",
                "isVisible": true,
                "left": "300dp",
                "skin": "ICSknBtn003e75BGffffff45PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.pendingApprovers\")",
                "top": "10dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalStatus.add(flxApprovalStatusGroup, btnPendingAprrovers);
            var segApprovalDetails = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "groupCells": false,
                "id": "segApprovalDetails",
                "isVisible": true,
                "left": "1dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxApprovalDetailsRowTemplate"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ApprovalRequestMA",
                    "friendlyName": "flxApprovalDetailsACKHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxApprovalDetailsACKHeader": "flxApprovalDetailsACKHeader",
                    "flxApprovalDetailsRowTemplate": "flxApprovalDetailsRowTemplate",
                    "flxNoRecords": "flxNoRecords",
                    "flxTopSeperator": "flxTopSeperator",
                    "flxTopSeperator2": "flxTopSeperator2",
                    "imgFlxTopSeparator": "imgFlxTopSeparator",
                    "imgFlxTopSeparator2": "imgFlxTopSeparator2",
                    "lblAction": "lblAction",
                    "lblActionKey": "lblActionKey",
                    "lblComments": "lblComments",
                    "lblCommentsKey": "lblCommentsKey",
                    "lblDateAndTime": "lblDateAndTime",
                    "lblDateAndTimeKey": "lblDateAndTimeKey",
                    "lblNoRecords": "lblNoRecords",
                    "lblUserID": "lblUserID",
                    "lblUserIDKey": "lblUserIDKey"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApprovalHistoryContent.add(lblApprovalHistoryInformation, flxTopSeperator, flxApprovalStatus, segApprovalDetails);
            flxApprovalsHistoryInformation.add(flxApprovalsHistoryErrorMessage, flxApprovalHistoryContent);
            var flxSearchBar = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": true,
                "id": "flxSearchBar",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchBar.setDefaultUnit(kony.flex.DP);
            var flxTopSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTopSeparator",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "0dp",
                "width": "96.66%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopSeparator.setDefaultUnit(kony.flex.DP);
            var lblTopSeparator = new kony.ui.Label({
                "id": "lblTopSeparator",
                "isVisible": true,
                "left": "1.58%",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Name\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopSeparator.add(lblTopSeparator);
            var flxRecipientTab = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "45dp",
                "id": "flxRecipientTab",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientTab.setDefaultUnit(kony.flex.DP);
            var lblRecordHeader = new kony.ui.Label({
                "id": "lblRecordHeader",
                "isVisible": true,
                "left": "1.66%",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payaperson.RecipientDetails\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bbSknLbl424242SSP15Px"
            });
            var flxAddRecipients = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAddRecipients",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "55%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "32%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRecipients.setDefaultUnit(kony.flex.DP);
            var flxAddExistingRecipients = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAddExistingRecipients",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddExistingRecipients.setDefaultUnit(kony.flex.DP);
            var lblAddExistingRecipients = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddExternalAccount\")"
                },
                "centerY": "50%",
                "id": "lblAddExistingRecipients",
                "isVisible": false,
                "left": "8%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.addExistingRecipients\")",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddExistingRecipients.add(lblAddExistingRecipients);
            var lblActionSeperator = new kony.ui.Label({
                "centerX": "3%",
                "centerY": "50%",
                "height": "25dp",
                "id": "lblActionSeperator",
                "isVisible": false,
                "left": "13%",
                "skin": "sknSeparatore3e3e3",
                "text": "-",
                "width": "1dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddManually = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAddManually",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddManually.setDefaultUnit(kony.flex.DP);
            var lblAddRecipientsManually = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddExternalAccount\")"
                },
                "centerY": "50%",
                "id": "lblAddRecipientsManually",
                "isVisible": true,
                "left": "0%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.manuallyAddedLabel\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddManually.add(lblAddRecipientsManually);
            var flxDropDown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "98%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "13dp",
                "id": "flxDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_gc83d3dd7936434aae07eae80d3bf7c4,
                "skin": "skncursor",
                "width": "13dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDown.setDefaultUnit(kony.flex.DP);
            var imgDropDown = new kony.ui.Label({
                "height": "100%",
                "id": "imgDropDown",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblFontTypeIcon1a98ff12pxOther",
                "text": "O",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDown.add(imgDropDown);
            flxAddRecipients.add(flxAddExistingRecipients, lblActionSeperator, flxAddManually, flxDropDown);
            flxRecipientTab.add(lblRecordHeader, flxAddRecipients);
            var flxHeaderSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxHeaderSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "2dp",
                "width": "94.66%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderSeparator.setDefaultUnit(kony.flex.DP);
            var lblsampleHeaderText = new kony.ui.Label({
                "id": "lblsampleHeaderText",
                "isVisible": true,
                "left": "1.58%",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Name\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderSeparator.add(lblsampleHeaderText);
            var flxSearchRecipients = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "65dp",
                "id": "flxSearchRecipients",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.66%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "12dp",
                "width": "98%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchRecipients.setDefaultUnit(kony.flex.DP);
            var flxSearchRecipientsBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxSearchRecipientsBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "10dp",
                "width": "82%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchRecipientsBox.setDefaultUnit(kony.flex.DP);
            var imgSearchIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgSearchIcon",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "top": "0",
                "width": "17dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSearchBox = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "bbSknTbx949494SSP15pxItalic",
                "height": "100%",
                "id": "tbxSearchBox",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "45dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.billpay.searchForKeywords\")",
                "secureTextEntry": false,
                "skin": "tbxPlaceholderskna0a0a015px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "95%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "tbxPlaceholderskna0a0a015px"
            });
            var imgClearIcon = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgClearIcon",
                "isVisible": false,
                "right": "1%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "top": "0",
                "width": "22dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSearchRecipientsBox.add(imgSearchIcon, tbxSearchBox, imgClearIcon);
            var flxAddPayment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAddPayment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "15%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPayment.setDefaultUnit(kony.flex.DP);
            var lblAddPayment = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.FastTransfers.AddExternalAccount\")"
                },
                "centerY": "50%",
                "id": "lblAddPayment",
                "isVisible": true,
                "left": "18%",
                "skin": "skn3343a8labelSSPRegular",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.manuallyAddedLabel\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddPayment.add(lblAddPayment);
            flxSearchRecipients.add(flxSearchRecipientsBox, flxAddPayment);
            flxSearchBar.add(flxTopSeparator, flxRecipientTab, flxHeaderSeparator, flxSearchRecipients);
            var TabBodyNew1 = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TabBodyNew1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "isVisible": true,
                        "top": "5dp"
                    },
                    "segTemplates": {
                        "bottom": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPaymentReview.add(NonEditableBulkPaymentDetails, flxEditableDetails, flxApprovalsHistoryInformation, flxSearchBar, TabBodyNew1);
            var flxAddRecipientDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "-2dp",
                "clipBounds": true,
                "id": "flxAddRecipientDetails",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRecipientDetails.setDefaultUnit(kony.flex.DP);
            var flxAddRecipientDetailsHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "215dp",
                "id": "flxAddRecipientDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRecipientDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblRecordHeader1 = new kony.ui.Label({
                "id": "lblRecordHeader1",
                "isVisible": true,
                "left": "1.32%",
                "skin": "bblblskn424242Bold",
                "text": "Select Recipients to Add",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "bblblskn424242Bold"
            });
            var flxSeperatorHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperatorHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.32%",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "10dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperatorHeader.setDefaultUnit(kony.flex.DP);
            var lblsampleHeader = new kony.ui.Label({
                "id": "lblsampleHeader",
                "isVisible": true,
                "left": "1.58%",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Name\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeperatorHeader.add(lblsampleHeader);
            var flxAddType2 = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85dp",
                "id": "flxAddType2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddType2.setDefaultUnit(kony.flex.DP);
            var lblAddType2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.SelectRecipientType\")"
                },
                "id": "lblAddType2",
                "isVisible": true,
                "left": "1.76%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.CreatePaymentForBeneficiary\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddType2RadioButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAddType2RadioButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.68%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "45.16%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddType2RadioButtons.setDefaultUnit(kony.flex.DP);
            var flxAddType2Radio1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "45%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAddType2Radio1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxAddType2Radio1.setDefaultUnit(kony.flex.DP);
            var imgAdd21 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgAdd21",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddType2Radio1.add(imgAdd21);
            var lblRadio1Add2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Individual\")"
                },
                "centerY": "43%",
                "id": "lblRadio1Add2",
                "isVisible": true,
                "left": "5dp",
                "right": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.newBeneficiary\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddType2Radio2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "45%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAddType2Radio2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxAddType2Radio2.setDefaultUnit(kony.flex.DP);
            var imgAdd22 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgAdd22",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblFontTypeIcon3343e820pxMOD",
                "text": "M",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddType2Radio2.add(imgAdd22);
            var lblRadio2Add2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblRadio2Add2",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.existingBeneficiary\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddType2RadioButtons.add(flxAddType2Radio1, lblRadio1Add2, flxAddType2Radio2, lblRadio2Add2);
            flxAddType2.add(lblAddType2, flxAddType2RadioButtons);
            var flxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "70dp",
                "id": "flxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.46%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "98%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearch.setDefaultUnit(kony.flex.DP);
            var flxBoxSearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "47.50%",
                "clipBounds": true,
                "height": "50dp",
                "id": "flxBoxSearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "bbSknFlxBordere3e3e3Radius3Px",
                "top": "10dp",
                "width": "99%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBoxSearch.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgSearch",
                "isVisible": true,
                "left": "16dp",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "e",
                "top": "0",
                "width": "17dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "bbSknTbx949494SSP15pxItalic",
                "height": "100%",
                "id": "tbxSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "45dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.SearchPlaceholder\")",
                "secureTextEntry": false,
                "skin": "bbSknTbx949494SSP15pxItalic",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "90%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "placeholderSkin": "bbSknTbx949494SSP15pxItalic"
            });
            var imgClear = new kony.ui.Label({
                "centerY": "50%",
                "height": "22dp",
                "id": "imgClear",
                "isVisible": false,
                "right": "1%",
                "skin": "sknlblSearchfonticon17px0273e3",
                "text": "g",
                "top": "0",
                "width": "22dp",
                "zIndex": 10
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBoxSearch.add(imgSearch, tbxSearch, imgClear);
            var flxViewOnlySeletced = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxViewOnlySeletced",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxViewOnlySeletced.setDefaultUnit(kony.flex.DP);
            var lblViewOnlySelected = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblViewOnlySelected",
                "isVisible": true,
                "left": "85dp",
                "skin": "sknSSP42424215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.bulkwires.viewonlyselected\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "View only selected"
            });
            var flxStatus = new kony.ui.FlexContainer({
                "centerY": "50%",
                "clipBounds": true,
                "height": "40dp",
                "id": "flxStatus",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "70dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "55dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatus.setDefaultUnit(kony.flex.DP);
            var lblStatus1 = new kony.ui.Label({
                "centerX": "50.81%",
                "centerY": "50.00%",
                "height": "100%",
                "id": "lblStatus1",
                "isVisible": true,
                "left": "85dp",
                "right": 0,
                "skin": "sknfonticontoggleON45px",
                "text": "n",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStatus.add(lblStatus1);
            flxViewOnlySeletced.add(lblViewOnlySelected, flxStatus);
            flxSearch.add(flxBoxSearch, flxViewOnlySeletced);
            flxAddRecipientDetailsHeader.add(lblRecordHeader1, flxSeperatorHeader, flxAddType2, flxSearch);
            var flxAddRecipientDetailsErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxAddRecipientDetailsErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRecipientDetailsErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgTemplateRecordsError = new kony.ui.Image2({
                "centerY": "50%",
                "height": "25dp",
                "id": "imgTemplateRecordsError",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTemplateRecordsError = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "50%",
                "id": "lblTemplateRecordsError",
                "isVisible": true,
                "left": "25dp",
                "skin": "sknlblee0005SSPReg15px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTemplateRecordsErrorSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxTemplateRecordsErrorSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "13dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTemplateRecordsErrorSeperator.setDefaultUnit(kony.flex.DP);
            flxTemplateRecordsErrorSeperator.add();
            flxAddRecipientDetailsErrorMessage.add(imgTemplateRecordsError, lblTemplateRecordsError, flxTemplateRecordsErrorSeperator);
            var flxSeperator4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": 0,
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator4.setDefaultUnit(kony.flex.DP);
            var lblSample = new kony.ui.Label({
                "id": "lblSample",
                "isVisible": true,
                "left": "1.58%",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Name\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSeperator4.add(lblSample);
            var flxAddRecipientsContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddRecipientsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRecipientsContainer.setDefaultUnit(kony.flex.DP);
            var TabBodyNew = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TabBodyNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxAddRecipientsContainer.add(TabBodyNew);
            flxAddRecipientDetails.add(flxAddRecipientDetailsHeader, flxAddRecipientDetailsErrorMessage, flxSeperator4, flxAddRecipientsContainer);
            var flxAddRecipientsManually = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddRecipientsManually",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 8,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRecipientsManually.setDefaultUnit(kony.flex.DP);
            var flxAddMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddMain.setDefaultUnit(kony.flex.DP);
            var flxAddManuallyHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxAddManuallyHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddManuallyHeader.setDefaultUnit(kony.flex.DP);
            var lblAddHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "STEP 1 : RECIPIENT DETAILS"
                },
                "centerY": "50%",
                "id": "lblAddHeader",
                "isVisible": true,
                "left": "1.32%",
                "skin": "bblblskn424242Bold",
                "text": "Provide  New Payment Details",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxStep1Seperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxStep1Seperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.32%",
                "isModalContainer": false,
                "right": "1.54%",
                "skin": "sknflxe3e3e3",
                "width": "97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxStep1Seperator.setDefaultUnit(kony.flex.DP);
            flxStep1Seperator.add();
            flxAddManuallyHeader.add(lblAddHeader, flxStep1Seperator);
            var lblInvalidDescription = new kony.ui.Label({
                "height": "17dp",
                "id": "lblInvalidDescription",
                "isVisible": false,
                "left": "1.39%",
                "skin": "ICSknLblErrorNew",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.bulkPayments.invalidDescription\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddType = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85dp",
                "id": "flxAddType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddType.setDefaultUnit(kony.flex.DP);
            var lblAddType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.SelectRecipientType\")"
                },
                "id": "lblAddType",
                "isVisible": true,
                "left": "1.76%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.CreatePaymentForBeneficiary\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddTypeRadioButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAddTypeRadioButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.68%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "45.16%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddTypeRadioButtons.setDefaultUnit(kony.flex.DP);
            var flxAddTypeRadio1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "45%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAddTypeRadio1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxAddTypeRadio1.setDefaultUnit(kony.flex.DP);
            var imgAdd1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgAdd1",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblFontTypeIcon3343e820pxMOD",
                "text": "M",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddTypeRadio1.add(imgAdd1);
            var lblRadioAdd1Opt1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Individual\")"
                },
                "centerY": "43%",
                "id": "lblRadioAdd1Opt1",
                "isVisible": true,
                "left": "5dp",
                "right": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.newBeneficiary\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAddTypeRadio2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "45%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAddTypeRadio2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxAddTypeRadio2.setDefaultUnit(kony.flex.DP);
            var imgAdd2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgAdd2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddTypeRadio2.add(imgAdd2);
            var lblRadioAddOpt2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblRadioAddOpt2",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.existingBeneficiary\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddTypeRadioButtons.add(flxAddTypeRadio1, lblRadioAdd1Opt1, flxAddTypeRadio2, lblRadioAddOpt2);
            flxAddType.add(lblAddType, flxAddTypeRadioButtons);
            var flxBankType = new kony.ui.FlexContainer({
                "bottom": "3dp",
                "clipBounds": true,
                "height": "85dp",
                "id": "flxBankType",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankType.setDefaultUnit(kony.flex.DP);
            var lblType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.SelectRecipientType\")"
                },
                "id": "lblType",
                "isVisible": true,
                "left": "1.76%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.beneficiaryBankAccountisWith\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRecipientTypeRadioButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxRecipientTypeRadioButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.68%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "45.16%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientTypeRadioButtons.setDefaultUnit(kony.flex.DP);
            var flxTypeRadio1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "45%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTypeRadio1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxTypeRadio1.setDefaultUnit(kony.flex.DP);
            var imgTypeRadio1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgTypeRadio1",
                "isVisible": false,
                "skin": "slImage",
                "src": "radiobtn_active_small.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRadioBtnRecipientType1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgRadioBtnRecipientType1",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblFontTypeIcon3343e820pxMOD",
                "text": "M",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTypeRadio1.add(imgTypeRadio1, imgRadioBtnRecipientType1);
            var lblRadioOpt1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Individual\")"
                },
                "centerY": "43%",
                "id": "lblRadioOpt1",
                "isVisible": true,
                "left": "5dp",
                "right": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.infinityBank\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTypeRadio2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "45%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxTypeRadio2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxTypeRadio2.setDefaultUnit(kony.flex.DP);
            var imgTypeRadio2 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgTypeRadio2",
                "isVisible": false,
                "skin": "slImage",
                "src": "icon_radiobtn.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRadioBtnRecipientType2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgRadioBtnRecipientType2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTypeRadio2.add(imgTypeRadio2, imgRadioBtnRecipientType2);
            var lblRadioOpt2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblRadioOpt2",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.externalBank\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRecipientTypeRadioButtons.add(flxTypeRadio1, lblRadioOpt1, flxTypeRadio2, lblRadioOpt2);
            flxBankType.add(lblType, flxRecipientTypeRadioButtons);
            var flxRecipientDetailsInfinity = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRecipientDetailsInfinity",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientDetailsInfinity.setDefaultUnit(kony.flex.DP);
            var lblInvalidIBANInfinity = new kony.ui.Label({
                "id": "lblInvalidIBANInfinity",
                "isVisible": false,
                "left": "1.39%",
                "skin": "sknLabelSSPFF000015Px",
                "text": "label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRecipientAccountNumber = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85dp",
                "id": "flxRecipientAccountNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientAccountNumber.setDefaultUnit(kony.flex.DP);
            var lblRecipientAccountNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblRecipientAccountNumber",
                "isVisible": true,
                "left": "1.39%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.beneficiaryAccNo\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxRecipAccNumber = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxRecipAccNumber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.39%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.EnterBeneficiaryLocalAccountNumberorIBAN\")",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxRecipientAccountNumber.add(lblRecipientAccountNumber, tbxRecipAccNumber);
            flxRecipientDetailsInfinity.add(lblInvalidIBANInfinity, flxRecipientAccountNumber);
            var flxRecipientDetailsExternal = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRecipientDetailsExternal",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientDetailsExternal.setDefaultUnit(kony.flex.DP);
            var flxAccountType = new kony.ui.FlexContainer({
                "bottom": "3dp",
                "clipBounds": true,
                "height": "85dp",
                "id": "flxAccountType",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountType.setDefaultUnit(kony.flex.DP);
            var lblAccountType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.SelectRecipientType\")"
                },
                "id": "lblAccountType",
                "isVisible": true,
                "left": "1.76%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.accountType\")",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountTypeRadioButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAccountTypeRadioButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.68%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "45.16%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountTypeRadioButtons.setDefaultUnit(kony.flex.DP);
            var flxAccTypeRadio1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "45%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAccTypeRadio1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxAccTypeRadio1.setDefaultUnit(kony.flex.DP);
            var imgRadioBtnACCType1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgRadioBtnACCType1",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblFontTypeIcon3343e820pxMOD",
                "text": "M",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccTypeRadio1.add(imgRadioBtnACCType1);
            var lblAccTypeRadio1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Individual\")"
                },
                "centerY": "43%",
                "id": "lblAccTypeRadio1",
                "isVisible": true,
                "left": "5dp",
                "right": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.TransfersEurope.Domestic\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccTypeRadio2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "45%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAccTypeRadio2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxAccTypeRadio2.setDefaultUnit(kony.flex.DP);
            var imgRadioBtnACCType2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgRadioBtnACCType2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccTypeRadio2.add(imgRadioBtnACCType2);
            var lblAccTypeRadio2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblAccTypeRadio2",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.TransfersEurope.International\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountTypeRadioButtons.add(flxAccTypeRadio1, lblAccTypeRadio1, flxAccTypeRadio2, lblAccTypeRadio2);
            flxAccountType.add(lblAccountType, flxAccountTypeRadioButtons);
            var lblInvalidIBAN = new kony.ui.Label({
                "id": "lblInvalidIBAN",
                "isVisible": false,
                "left": "1.39%",
                "skin": "sknLabelSSPFF000015Px",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRecipientAccNumExt = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85dp",
                "id": "flxRecipientAccNumExt",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientAccNumExt.setDefaultUnit(kony.flex.DP);
            var lblRecipientAccountNumberExt = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblRecipientAccountNumberExt",
                "isVisible": true,
                "left": "1.39%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.beneficiaryAccNo\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxRecipAccNumberExt = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxRecipAccNumberExt",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.39%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.EnterBeneficiaryLocalAccountNumberorIBAN\")",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxRecipientAccNumExt.add(lblRecipientAccountNumberExt, tbxRecipAccNumberExt);
            var lblInvalidSwift = new kony.ui.Label({
                "id": "lblInvalidSwift",
                "isVisible": false,
                "left": "1.39%",
                "skin": "sknLabelSSPFF000015Px",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSwift = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85dp",
                "id": "flxSwift",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwift.setDefaultUnit(kony.flex.DP);
            var lblSwift = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblSwift",
                "isVisible": true,
                "left": "1.39%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.SWIFTBIC\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxSwift = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxSwift",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.39%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Enterhere\")",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            var btnLookUp = new kony.ui.Button({
                "focusSkin": "sknbtn0273e315px",
                "id": "btnLookUp",
                "isVisible": false,
                "left": "32%",
                "skin": "sknbtn0273e315px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.LookUp\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknbtn0273e315px",
                "toolTip": "Look Up"
            });
            flxSwift.add(lblSwift, tbxSwift, btnLookUp);
            var flxRecipientBankName = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85dp",
                "id": "flxRecipientBankName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientBankName.setDefaultUnit(kony.flex.DP);
            var lblRecipientBankName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblRecipientBankName",
                "isVisible": true,
                "left": "1.39%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.beneficiaryBankName\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxRecipientBankName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxRecipientBankName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.39%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.payments.enterBeneficiaryBankName\")",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxRecipientBankName.add(lblRecipientBankName, tbxRecipientBankName);
            flxRecipientDetailsExternal.add(flxAccountType, lblInvalidIBAN, flxRecipientAccNumExt, lblInvalidSwift, flxSwift, flxRecipientBankName);
            var flxRecipientDetailsExisting = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxRecipientDetailsExisting",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientDetailsExisting.setDefaultUnit(kony.flex.DP);
            var flxRecipientNameExisting = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxRecipientNameExisting",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "20dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientNameExisting.setDefaultUnit(kony.flex.DP);
            var lblNameKey = new kony.ui.Label({
                "id": "lblNameKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.TransferEurope.beneficairyNameColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblNameValue = new kony.ui.Label({
                "id": "lblNameValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "Micheal Mack",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxRecipientNameExisting.add(lblNameKey, lblNameValue);
            var flxAccountNumberExisting = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxAccountNumberExisting",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountNumberExisting.setDefaultUnit(kony.flex.DP);
            var lblAccountKey = new kony.ui.Label({
                "id": "lblAccountKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.beneficiaryAccIBAN\")",
                "top": "0dp",
                "width": "28%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblAccountValue = new kony.ui.Label({
                "id": "lblAccountValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "2333544488899666",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxAccountNumberExisting.add(lblAccountKey, lblAccountValue);
            var flxBankNameExisting = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxBankNameExisting",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBankNameExisting.setDefaultUnit(kony.flex.DP);
            var lblBankNameKey = new kony.ui.Label({
                "id": "lblBankNameKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "text": "Bank Name:",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblBankNameValue = new kony.ui.Label({
                "id": "lblBankNameValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "Banko Santander",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxBankNameExisting.add(lblBankNameKey, lblBankNameValue);
            var flxSwiftExisting = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxSwiftExisting",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "5dp",
                "width": "96.67%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSwiftExisting.setDefaultUnit(kony.flex.DP);
            var lblSwiftKey = new kony.ui.Label({
                "id": "lblSwiftKey",
                "isVisible": true,
                "left": "1.54%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.swiftOrBicWithColon\")",
                "top": "0dp",
                "width": "18%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            var lblSwiftValue = new kony.ui.Label({
                "id": "lblSwiftValue",
                "isVisible": true,
                "left": "25%",
                "skin": "sknLabelSSP42424215px",
                "text": "44557788963",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLabelSSP42424215px"
            });
            flxSwiftExisting.add(lblSwiftKey, lblSwiftValue);
            flxRecipientDetailsExisting.add(flxRecipientNameExisting, flxAccountNumberExisting, flxBankNameExisting, flxSwiftExisting);
            var flxAmount = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85dp",
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var lblCurrency = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.City\")"
                },
                "id": "lblCurrency",
                "isVisible": true,
                "left": "1.39%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.TransfersEurope.Currency\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbxCurrency = new kony.ui.ListBox({
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxCurrency",
                "isVisible": false,
                "left": "1.39%",
                "masterData": [
                    ["key1", "$"],
                    ["Key2", "Rup"]
                ],
                "selectedKey": "key1",
                "skin": "sknLbxSSP42424215PxBorder727272",
                "top": "40dp",
                "width": "8%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknLbxSSP42424215PxBorder4A90E2",
                "multiSelect": false
            });
            var tbxCurrency = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Zipcode"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxCurrency",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.39%",
                "placeholder": "$",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "8%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            var lblAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Zipcode"
                },
                "id": "lblAmount",
                "isVisible": true,
                "left": "10.50%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.common.Amount\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAmount = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "Zipcode"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxAmount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "10.50%",
                "placeholder": "Enter Amount Here",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "25.80%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxAmount.add(lblCurrency, lbxCurrency, tbxCurrency, lblAmount, tbxAmount);
            var flxRecipientName = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "85dp",
                "id": "flxRecipientName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRecipientName.setDefaultUnit(kony.flex.DP);
            var lblRecipientName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblRecipientName",
                "isVisible": true,
                "left": "1.39%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.common.beneficiary\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxRecipientName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxRecipientName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.39%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.AddExternalAccount.EnterBeneficiaryName\")",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            flxRecipientName.add(lblRecipientName, tbxRecipientName);
            var flxFeesPaid = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "85dp",
                "id": "flxFeesPaid",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesPaid.setDefaultUnit(kony.flex.DP);
            var lblFeesPaidBy = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.SelectRecipientType\")"
                },
                "id": "lblFeesPaidBy",
                "isVisible": true,
                "left": "1.76%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.feesPaidByQuestion\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "17dp",
                "id": "flxInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10.20%",
                "isModalContainer": false,
                "skin": "bbsknCircleD8D8D8",
                "top": "15dp",
                "width": "17dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "height": "100%",
                "id": "imgInfo",
                "isVisible": false,
                "left": "0",
                "skin": "slImage",
                "src": "info_grey_2.png",
                "top": "0",
                "width": "100%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Specify the type of business that you are enrolling into online banking"
            });
            var lblInfo = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "lblInfo",
                "isVisible": true,
                "left": "0",
                "skin": "bbsknlblinfoicon",
                "text": "i",
                "top": "0",
                "width": "15dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfo.add(imgInfo, lblInfo);
            var flxFeesPaidRadioButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxFeesPaidRadioButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.68%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40dp",
                "width": "45.16%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesPaidRadioButtons.setDefaultUnit(kony.flex.DP);
            var flxFeesTypeRadio1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFeesTypeRadio1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxFeesTypeRadio1.setDefaultUnit(kony.flex.DP);
            var imgFees1Type1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgFees1Type1",
                "isVisible": false,
                "skin": "slImage",
                "src": "radiobtn_active_small.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgFees1Type2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgFees1Type2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknLblFontTypeIcon3343e820pxMOD",
                "text": "M",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesTypeRadio1.add(imgFees1Type1, imgFees1Type2);
            var lblFeesOpt1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Individual\")"
                },
                "centerY": "43%",
                "id": "lblFeesOpt1",
                "isVisible": true,
                "left": "5dp",
                "right": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Me\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFeesTypeRadio2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFeesTypeRadio2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxFeesTypeRadio2.setDefaultUnit(kony.flex.DP);
            var imgFees2Type1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgFees2Type1",
                "isVisible": false,
                "skin": "slImage",
                "src": "icon_radiobtn.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgFees2Type2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgFees2Type2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesTypeRadio2.add(imgFees2Type1, imgFees2Type2);
            var lblFeesOpt2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblFeesOpt2",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.Europe.Beneficiary\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFeesTypeRadio3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxFeesTypeRadio3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTopmenu"
            });
            flxFeesTypeRadio3.setDefaultUnit(kony.flex.DP);
            var imgFees3Type1 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "imgFees3Type1",
                "isVisible": false,
                "skin": "slImage",
                "src": "icon_radiobtn.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgFees3Type2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Radio Button"
                },
                "height": "30dp",
                "id": "imgFees3Type2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknC0C0C020pxolbfonticons",
                "text": "L",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesTypeRadio3.add(imgFees3Type1, imgFees3Type2);
            var lblFeesOpt3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.Business\")"
                },
                "centerY": "43%",
                "id": "lblFeesOpt3",
                "isVisible": true,
                "left": "5dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.Europe.Both\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesPaidRadioButtons.add(flxFeesTypeRadio1, lblFeesOpt1, flxFeesTypeRadio2, lblFeesOpt2, flxFeesTypeRadio3, lblFeesOpt3);
            var flxInformationText = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "blur": {
                    "enabled": false,
                    "value": 0
                },
                "clipBounds": false,
                "height": "250dp",
                "id": "flxInformationText",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "10.30%",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "-245dp",
                "width": "390dp",
                "zIndex": 20,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformationText.setDefaultUnit(kony.flex.DP);
            var flxInformation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "35dp",
                "id": "flxInformation",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder3px",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxInformation.setDefaultUnit(kony.flex.DP);
            var lblInformation = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Info\")"
                },
                "centerY": "50%",
                "id": "lblInformation",
                "isVisible": true,
                "left": "4.44%",
                "skin": "sknLblSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.SupportInfo.Title\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "5.55%",
                "skin": "skncursor",
                "top": "5dp",
                "width": "20dp",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "skncursor"
            });
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.close\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "12dp",
                "id": "imgCross",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "0dp",
                "right": "5.05%",
                "skin": "slImage",
                "src": "bbcloseicon.png",
                "top": "0dp",
                "width": "12dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Close"
            });
            flxCross.add(imgCross);
            flxInformation.add(lblInformation, flxCross);
            var flxFeesTypeInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFeesTypeInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeesTypeInfo.setDefaultUnit(kony.flex.DP);
            var RichTextMeInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "This will be used as default account for your transactions. You can also change this default account. "
                },
                "height": "40dp",
                "id": "RichTextMeInfo",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.BulkPayments.infoFeesPaidMe\")",
                "top": "0dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextBenInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "This will be used as default account for your transactions. You can also change this default account. "
                },
                "height": "40dp",
                "id": "RichTextBenInfo",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.BulkPayments.infoFeesPaidBeneficiary\")",
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextSharedInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "This will be used as default account for your transactions. You can also change this default account. "
                },
                "bottom": "0dp",
                "height": "20dp",
                "id": "RichTextSharedInfo",
                "isVisible": true,
                "left": "4.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.BulkPayments.infoFeesPaidShared\")",
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextSharedPayerInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "This will be used as default account for your transactions. You can also change this default account. "
                },
                "bottom": "0dp",
                "height": "20dp",
                "id": "RichTextSharedPayerInfo",
                "isVisible": true,
                "left": "20%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.BulkPayments.infoFeesPaidSharedPayer\")",
                "top": "-2dp",
                "width": "60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var RichTextSharedPayeeInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "This will be used as default account for your transactions. You can also change this default account. "
                },
                "height": "40dp",
                "id": "RichTextSharedPayeeInfo",
                "isVisible": true,
                "left": "17.80%",
                "skin": "sknRtx42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.BulkPayments.infoFeesPaidSharedPayee\")",
                "top": "10dp",
                "width": "78%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFeesTypeInfo.add(RichTextMeInfo, RichTextBenInfo, RichTextSharedInfo, RichTextSharedPayerInfo, RichTextSharedPayeeInfo);
            flxInformationText.add(flxInformation, flxFeesTypeInfo);
            flxFeesPaid.add(lblFeesPaidBy, flxInfo, flxFeesPaidRadioButtons, flxInformationText);
            var flxPaymentRef = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "110dp",
                "id": "flxPaymentRef",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentRef.setDefaultUnit(kony.flex.DP);
            var lblPaymentRef = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "id": "lblPaymentRef",
                "isVisible": true,
                "left": "1.39%",
                "skin": "sknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.PaymentReference\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxPaymentRef = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.AddressLine1\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPaymentRef",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.39%",
                "maxTextLength": 35,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Enterhere\")",
                "secureTextEntry": false,
                "skin": "sknTbxSSPffffff15PxBorder727272opa20",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "35%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off",
                "hoverSkin": "sknSSP42424215PxBorder4A90E2",
                "placeholderSkin": "sknTbxPlaceholdera0a0a0SSPReg15px949494"
            });
            var lblValidDescription = new kony.ui.Label({
                "height": "17dp",
                "id": "lblValidDescription",
                "isVisible": true,
                "left": "1.39%",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.kony.bulkPayments.validDescription\")",
                "top": "87dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentRef.add(lblPaymentRef, tbxPaymentRef, lblValidDescription);
            var flxAddToList = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "80dp",
                "id": "flxAddToList",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddToList.setDefaultUnit(kony.flex.DP);
            var lblSelect = new kony.ui.Label({
                "centerY": "50%",
                "height": "32dp",
                "id": "lblSelect",
                "isVisible": true,
                "left": "1.10%",
                "skin": "skn0273e320pxolbfonticons",
                "text": "D",
                "width": "32dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddToList = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.RecipientAddress\")"
                },
                "centerY": "50%",
                "id": "lblAddToList",
                "isVisible": true,
                "left": "1.54%",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.addBeneficiaryToList\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddToList.add(lblSelect, lblAddToList);
            var flxEndSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "5dp",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEndSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1.10%",
                "isModalContainer": false,
                "right": "1.54%",
                "skin": "sknflxe3e3e3",
                "top": "10dp",
                "width": "96.80%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndSeperator.setDefaultUnit(kony.flex.DP);
            flxEndSeperator.add();
            flxAddMain.add(flxAddManuallyHeader, lblInvalidDescription, flxAddType, flxBankType, flxRecipientDetailsInfinity, flxRecipientDetailsExternal, flxRecipientDetailsExisting, flxAmount, flxRecipientName, flxFeesPaid, flxPaymentRef, flxAddToList, flxEndSeperator);
            flxAddRecipientsManually.add(flxAddMain);
            var CommonFormActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "centerX": "50%",
                "height": "100dp",
                "id": "CommonFormActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "99%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnBack": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "2.54%",
                        "top": "viz.val_cleared",
                        "width": "13%",
                        "zIndex": 3
                    },
                    "btnCancel": {
                        "bottom": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "2.54%",
                        "width": "13%"
                    },
                    "btnNext": {
                        "bottom": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "2.54%",
                        "text": "Next",
                        "width": "13%"
                    },
                    "btnOption": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "2.54%",
                        "top": "viz.val_cleared",
                        "width": "13%",
                        "zIndex": 2
                    },
                    "flxMain": {
                        "centerX": "viz.val_cleared",
                        "centerY": "40%",
                        "height": "100%",
                        "isVisible": true,
                        "left": "0dp",
                        "reverseLayoutDirection": true,
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%",
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "formActionsNew": {
                        "centerX": "50%",
                        "height": "100dp",
                        "top": "10dp",
                        "width": "99%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMainContainer.add(flxErrorMessage, flxPaymentReview, flxAddRecipientDetails, flxAddRecipientsManually, CommonFormActionsNew);
            var PaginationContainer = new com.InfinityOLB.Resources.Pagination.PaginationContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "PaginationContainer",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "PaginationContainer": {
                        "isVisible": false,
                        "top": "0dp"
                    },
                    "flxPaginationLast": {
                        "isVisible": false
                    },
                    "flxPaginationNext": {
                        "right": "-0.50%"
                    },
                    "imgPaginationLast": {
                        "src": "pagination_last_active.png"
                    },
                    "imgPaginationNext": {
                        "src": "pagination_next_active.png"
                    },
                    "imgPaginationPrevious": {
                        "src": "pagination_back_inactive.png"
                    },
                    "lblPagination": {
                        "left": "1.50%",
                        "right": "1.50%",
                        "text": "1-03 of 03 Records"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "111dp",
                "id": "formActionsNew",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxMain": {
                        "height": "100%"
                    },
                    "formActionsNew": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var CommonFormActionsExt = new com.InfinityOLB.Resources.formActionsNew({
                "centerX": "50%",
                "height": "100dp",
                "id": "CommonFormActionsExt",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnBack": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "height": "40dp",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "2.54%",
                        "top": "viz.val_cleared",
                        "width": "13%",
                        "zIndex": 3
                    },
                    "btnCancel": {
                        "bottom": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "2.54%",
                        "width": "13%"
                    },
                    "btnNext": {
                        "bottom": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "right": "0%",
                        "text": "Next",
                        "width": "13%"
                    },
                    "btnOption": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "height": "40dp",
                        "isVisible": false,
                        "left": "viz.val_cleared",
                        "right": "2.54%",
                        "top": "viz.val_cleared",
                        "width": "13%",
                        "zIndex": 2
                    },
                    "flxMain": {
                        "centerX": "viz.val_cleared",
                        "centerY": "40%",
                        "height": "100%",
                        "isVisible": true,
                        "left": "0dp",
                        "reverseLayoutDirection": true,
                        "right": "viz.val_cleared",
                        "top": "0dp",
                        "width": "100%",
                        "layoutType": kony.flex.FLOW_HORIZONTAL
                    },
                    "formActionsNew": {
                        "centerX": "50%",
                        "height": "100dp",
                        "isVisible": false,
                        "top": "10dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTabPaneContainer.add(flxAcknowledgementContainer, flxMainContainer, PaginationContainer, formActionsNew, CommonFormActionsExt);
            flxDashboard.add(flxTabPaneContainer);
            flxContentDashBoard.add(flxDashboard);
            var flxTerms = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "10dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxTerms",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "87.85%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTerms.setDefaultUnit(kony.flex.DP);
            var lblTitleTerms = new kony.ui.Label({
                "id": "lblTitleTerms",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.TnC\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var browserTnC = new kony.ui.Browser({
                "bottom": "10dp",
                "detectTelNumber": true,
                "enableZoom": false,
                "id": "browserTnC",
                "isVisible": true,
                "left": "20dp",
                "setAsContent": false,
                "requestURLConfig": {
                    "URL": "richtextViewer.html",
                    "requestMethod": constants.BROWSER_REQUEST_METHOD_GET
                },
                "top": "10dp",
                "width": "95%",
                "zIndex": 1
            }, {}, {});
            flxTerms.add(lblTitleTerms, browserTnC);
            flxContentContainer.add(flxContentHeader, flxDisplayErrorMessage, flxGenericMessage, flxAckMessage, flxContentDashBoard, flxTerms);
            flxMain.add(flxMainWrapper, flxskncontainer, flxContentContainer);
            var flxFooter = new kony.ui.FlexContainer({
                "bottom": "0dp",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "btnContactUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.contactUs\")"
                    },
                    "btnLocateUs": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.locateUs\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "800dp",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5001,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1000px",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "CopysknFlx0e638206384ce42",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxPopupConfirmation = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxPopupConfirmation",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupConfirmation.setDefaultUnit(kony.flex.DP);
            var flxPopupNew = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "flxPopupNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxComments": {
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "imgClose": {
                        "src": "bbcloseicon.png"
                    },
                    "lblCommnets": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.myRequests.comments\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopupConfirmation.add(flxPopupNew);
            var flxLookupPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLookupPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookupPopup.setDefaultUnit(kony.flex.DP);
            var flxLookup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "600dp",
                "id": "flxLookup",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "10%",
                "isModalContainer": false,
                "skin": "bbSKnFlxf1ab15",
                "top": "10dp",
                "width": "50%",
                "zIndex": 10020,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookup.setDefaultUnit(kony.flex.DP);
            var flxSearchHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxSearchHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchHeading.setDefaultUnit(kony.flex.DP);
            var lblSearchHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.swift/BicSearch\")"
                },
                "id": "lblSearchHeading",
                "isVisible": true,
                "left": "3%",
                "skin": "bblblskn424242Bold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.SWIFTBICSearch\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxCrossLookup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxCrossLookup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "top": "10dp",
                "width": "30dp",
                "zIndex": 5,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "skncursor"
            });
            flxCrossLookup.setDefaultUnit(kony.flex.DP);
            var lblcross = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.payments.quitBillPay\")"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "20dp",
                "id": "lblcross",
                "isVisible": true,
                "skin": "sknOlbFonts0273e317px",
                "text": "g",
                "width": "20dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCrossLookup.add(lblcross);
            flxSearchHeading.add(lblSearchHeading, flxCrossLookup);
            var lblseparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "lblseparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "sknFlxd3d3d3",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            lblseparator.setDefaultUnit(kony.flex.DP);
            lblseparator.add();
            var lblSwiftText = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "To find your SWIFT code, please enter bank details t"
                },
                "id": "lblSwiftText",
                "isVisible": true,
                "left": "3%",
                "skin": "sknBBSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.TofindyourSWIFTcodepleaseenterbankdetailsthenhitSearch\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var lblBankNameLookup = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.transfers.bankName\")"
                },
                "id": "lblBankNameLookup",
                "isVisible": true,
                "left": "3%",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.bankName\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtBankName = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.StopPayments.Optional\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "txtBankName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3%",
                "maxTextLength": 150,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.AccountsAggregation.EnterBankName\")",
                "secureTextEntry": false,
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "10dp",
                "width": "94%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var flxCityCountry = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxCityCountry",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCityCountry.setDefaultUnit(kony.flex.DP);
            var lblCity1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.City\")"
                },
                "id": "lblCity1",
                "isVisible": true,
                "left": "0%",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.City\")",
                "top": "10px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtCity1 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.StopPayments.Optional\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": "10dp",
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "txtCity1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "maxTextLength": 150,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.EnterCityName\")",
                "secureTextEntry": false,
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "35dp",
                "width": "48%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblCountry1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Country\")"
                },
                "id": "lblCountry1",
                "isVisible": true,
                "left": "52%",
                "skin": "sknSSP72727215Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Country\")",
                "top": "10px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtCountry1 = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.StopPayments.Optional\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "bottom": "10dp",
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "txtCountry1",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "52%",
                "maxTextLength": 150,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.EnterCountryName\")",
                "secureTextEntry": false,
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "35dp",
                "width": "48%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxCityCountry.add(lblCity1, txtCity1, lblCountry1, txtCountry1);
            var flxSearchButtons = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxSearchButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchButtons.setDefaultUnit(kony.flex.DP);
            var btnClearSearchBic = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "btnClearSearchBic",
                "isVisible": true,
                "left": "0",
                "skin": "slButtonGlossBlue",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.clear\")",
                "top": "0",
                "width": "300dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Clear Selection"
            });
            var btnSearch = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")"
                },
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40dp",
                "id": "btnSearch",
                "isVisible": true,
                "right": "3.77%",
                "skin": "sknbtnSSPffffff15px0273e3bg",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Search\")",
                "top": "20dp",
                "width": "18.99%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px",
                "toolTip": "Search"
            });
            flxSearchButtons.add(btnClearSearchBic, btnSearch);
            var flxLookupSegmentHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "42dp",
                "id": "flxLookupSegmentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "0%",
                "skin": "sknBBFlexBGf9f9f9",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookupSegmentHeader.setDefaultUnit(kony.flex.DP);
            var lblSwiftCode = new kony.ui.Label({
                "id": "lblSwiftCode",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.BICSWIFT\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBank = new kony.ui.Label({
                "id": "lblBank",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.bankName\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCountryName = new kony.ui.Label({
                "id": "lblCountryName",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.Country\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCityName = new kony.ui.Label({
                "id": "lblCityName",
                "isVisible": true,
                "left": "0",
                "skin": "slLabel",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.City\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLookupSegmentHeader.add(lblSwiftCode, lblBank, lblCountryName, lblCityName);
            var flxLookupSegmentDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "35%",
                "id": "flxLookupSegmentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLookupSegmentDetails.setDefaultUnit(kony.flex.DP);
            var segResults = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "data": [{
                    "lblBankValue": "Bank Name",
                    "lblCityNameValue": "City Name",
                    "lblCountryNameValue": "Country Name",
                    "lblSelectSwift": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.selectSwift\")",
                    "lblSwiftCodeValue": "Swift Code"
                }],
                "groupCells": false,
                "height": "90%",
                "id": "segResults",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "TransfersMA",
                    "friendlyName": "flxResults"
                }),
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": true,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxResults": "flxResults",
                    "lblBankValue": "lblBankValue",
                    "lblCityNameValue": "lblCityNameValue",
                    "lblCountryNameValue": "lblCountryNameValue",
                    "lblSelectSwift": "lblSelectSwift",
                    "lblSwiftCodeValue": "lblSwiftCodeValue"
                },
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoResults = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxNoResults",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoResults.setDefaultUnit(kony.flex.DP);
            var lblNoResults = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblNoResults",
                "isVisible": true,
                "left": "0",
                "skin": "sknBBLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TransfersEur.noResults\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoResults.add(lblNoResults);
            flxLookupSegmentDetails.add(segResults, flxNoResults);
            flxLookup.add(flxSearchHeading, lblseparator, lblSwiftText, lblBankNameLookup, txtBankName, flxCityCountry, flxSearchButtons, flxLookupSegmentHeader, flxLookupSegmentDetails);
            flxLookupPopup.add(flxLookup);
            var flxOverlay = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxOverlay",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Opacity40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOverlay.setDefaultUnit(kony.flex.DP);
            flxOverlay.add();
            var flxPendingApprovers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50.04%",
                "clipBounds": true,
                "height": "700dp",
                "id": "flxPendingApprovers",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "ICsknFlxffffff",
                "width": "50%",
                "zIndex": 7000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApprovers.setDefaultUnit(kony.flex.DP);
            var flxPendingApproversDetails = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxPendingApproversDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApproversDetails.setDefaultUnit(kony.flex.DP);
            var flxPendingApproversHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxPendingApproversHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPendingApproversHeader.setDefaultUnit(kony.flex.DP);
            var lblApprovalDetails = new kony.ui.Label({
                "id": "lblApprovalDetails",
                "isVisible": true,
                "left": "23dp",
                "skin": "sknLblSSP42424215pxBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendinApprovers.PendingApprovalDetails\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgPopupclose = new kony.ui.Image2({
                "height": "30dp",
                "id": "imgPopupclose",
                "isVisible": true,
                "right": "10dp",
                "skin": "slImage",
                "src": "closeicon.png",
                "top": "15dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPendingApproversHeader.add(lblApprovalDetails, imgPopupclose);
            var flxSeparator = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxGroupDetails = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "78%",
                "horizontalScrollIndicator": true,
                "id": "flxGroupDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupDetails.setDefaultUnit(kony.flex.DP);
            var flxApprovalLimitHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxApprovalLimitHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxShadow4645454Bg",
                "top": "3dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalLimitHeader.setDefaultUnit(kony.flex.DP);
            var flxPerTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPerTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "190dp",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPerTransaction.setDefaultUnit(kony.flex.DP);
            var lblPerTransaction = new kony.ui.Label({
                "id": "lblPerTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendingApprovers.PerTransactionApprovals\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPerTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxPerTransactionSelected",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "36dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPerTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxPerTransactionSelected.add();
            flxPerTransaction.add(lblPerTransaction, flxPerTransactionSelected);
            var flxDailyTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDailyTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "240dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "125dp",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyTransaction.setDefaultUnit(kony.flex.DP);
            var lblDailyTransaction = new kony.ui.Label({
                "id": "lblDailyTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.dailyTransaction\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDailyTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxDailyTransactionSelected",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "36dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDailyTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxDailyTransactionSelected.add();
            flxDailyTransaction.add(lblDailyTransaction, flxDailyTransactionSelected);
            var flxWeekelyTransaction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWeekelyTransaction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "395dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "145dp",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeekelyTransaction.setDefaultUnit(kony.flex.DP);
            var lblWeekelyTransaction = new kony.ui.Label({
                "id": "lblWeekelyTransaction",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP42424215pxBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.weeklyTransaction\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxWeeklyTransactionSelected = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "3dp",
                "id": "flxWeeklyTransactionSelected",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknBorder003e75",
                "top": "30dp",
                "width": "97%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWeeklyTransactionSelected.setDefaultUnit(kony.flex.DP);
            flxWeeklyTransactionSelected.add();
            flxWeekelyTransaction.add(lblWeekelyTransaction, flxWeeklyTransactionSelected);
            flxApprovalLimitHeader.add(flxPerTransaction, flxDailyTransaction, flxWeekelyTransaction);
            var flxNoteMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNoteMessage",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoteMessage.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgInfoIcon",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBulkInfo = new kony.ui.Label({
                "id": "lblBulkInfo",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.bulkNoteMessage\")",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoteMessage.add(imgInfoIcon, lblBulkInfo);
            var flxApproverList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxApproverList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApproverList.setDefaultUnit(kony.flex.DP);
            flxApproverList.add();
            flxGroupDetails.add(flxApprovalLimitHeader, flxNoteMessage, flxApproverList);
            var flxNoPendingData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "470dp",
                "id": "flxNoPendingData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoPendingData.setDefaultUnit(kony.flex.DP);
            var flxBulkInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBulkInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBulkInfo.setDefaultUnit(kony.flex.DP);
            var imgInfoIcon2 = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgInfoIcon2",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoPendingApprovals = new kony.ui.Label({
                "id": "lblNoPendingApprovals",
                "isVisible": true,
                "left": "20dp",
                "skin": "ICSknLbl42424215PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.pendingApprovers.noPendingApprovals\")",
                "top": "0dp",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBulkInfo.add(imgInfoIcon2, lblNoPendingApprovals);
            flxNoPendingData.add(flxBulkInfo);
            var flxPopupBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "15%",
                "id": "flxPopupBottom",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "100%",
                "zIndex": 500,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupBottom.setDefaultUnit(kony.flex.DP);
            var flxBottomSeparator = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "1dp",
                "id": "flxBottomSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottomSeparator.setDefaultUnit(kony.flex.DP);
            flxBottomSeparator.add();
            var btnClose = new kony.ui.Button({
                "bottom": "30dp",
                "height": "50dp",
                "id": "btnClose",
                "isVisible": true,
                "right": "20dp",
                "skin": "ICSknBtn003e75BGffffff45PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.close\")",
                "top": "30dp",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPopupBottom.add(flxBottomSeparator, btnClose);
            flxPendingApproversDetails.add(flxPendingApproversHeader, flxSeparator, flxGroupDetails, flxNoPendingData, flxPopupBottom);
            flxPendingApprovers.add(flxPendingApproversDetails);
            var flxDialogs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "ICSknFlx000000BG",
                "top": 0,
                "width": "100%",
                "zIndex": 5000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxCancelPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCancelPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 15000,
                "appName": "BulkPaymentsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancelPopup.setDefaultUnit(kony.flex.DP);
            var PopupHeaderUM = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "PopupHeaderUM",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxCancelPopup.add(PopupHeaderUM);
            flxDialogs.add(flxCancelPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheader.flxHeaderMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.flxSeperatorHor2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.flxTopmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.imgKony": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxFeedback": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxHelp": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxMenusMain": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheader.topmenu.flxaccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "lblPrintfontIconConfirm": {
                        "segmentProps": []
                    },
                    "lblDownloadfontIconConfirm": {
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgPrint": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxImgdownload": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.flxTickImage": {
                        "width": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknFlxffffffShadowdddcdc",
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDate": {
                        "segmentProps": []
                    },
                    "flxValueDate": {
                        "segmentProps": []
                    },
                    "flxApprovalHistoryContent": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "sknlblSSP42424213pxBold",
                        "hoverSkin": "sknlblSSP42424213pxBold",
                        "segmentProps": []
                    },
                    "lblApprovalStatus": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "segmentProps": []
                    },
                    "flxAddRecipients": {
                        "left": {
                            "type": "string",
                            "value": "37%"
                        },
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": []
                    },
                    "flxDropDown": {
                        "centerX": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxAddType2": {
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "lblAddType2": {
                        "top": {
                            "type": "string",
                            "value": "102dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddType2RadioButtons": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "lblRadio1Add2": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "flxAddType2Radio2": {
                        "segmentProps": []
                    },
                    "lblRadio2Add2": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipientsManually": {
                        "top": {
                            "type": "string",
                            "value": "0px"
                        },
                        "segmentProps": []
                    },
                    "lblAddHeader": {
                        "segmentProps": []
                    },
                    "flxStep1Seperator": {
                        "segmentProps": []
                    },
                    "flxAddType": {
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "lblAddType": {
                        "top": {
                            "type": "string",
                            "value": "102dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddTypeRadioButtons": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAddTypeRadio1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblRadioAdd1Opt1": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblRadioAddOpt2": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "flxBankType": {
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "lblType": {
                        "top": {
                            "type": "string",
                            "value": "102dp"
                        },
                        "segmentProps": []
                    },
                    "flxRecipientTypeRadioButtons": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxTypeRadio1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblRadioOpt1": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblRadioOpt2": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblInvalidIBANInfinity": {
                        "segmentProps": []
                    },
                    "flxRecipientAccountNumber": {
                        "height": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientAccountNumber": {
                        "segmentProps": []
                    },
                    "tbxRecipAccNumber": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccountType": {
                        "top": {
                            "type": "string",
                            "value": "102dp"
                        },
                        "segmentProps": []
                    },
                    "flxAccountTypeRadioButtons": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "flxAccTypeRadio1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblAccTypeRadio1": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblAccTypeRadio2": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblInvalidIBAN": {
                        "segmentProps": []
                    },
                    "flxRecipientAccNumExt": {
                        "height": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientAccountNumberExt": {
                        "segmentProps": []
                    },
                    "tbxRecipAccNumberExt": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblInvalidSwift": {
                        "segmentProps": []
                    },
                    "flxSwift": {
                        "height": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "tbxSwift": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxRecipientBankName": {
                        "height": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientBankName": {
                        "segmentProps": []
                    },
                    "tbxRecipientBankName": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrency": {
                        "segmentProps": []
                    },
                    "tbxCurrency": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxRecipientName": {
                        "height": {
                            "type": "string",
                            "value": "135dp"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientName": {
                        "segmentProps": []
                    },
                    "tbxRecipientName": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeesPaid": {
                        "height": {
                            "type": "string",
                            "value": "170dp"
                        },
                        "segmentProps": []
                    },
                    "lblFeesPaidBy": {
                        "top": {
                            "type": "string",
                            "value": "102dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "segmentProps": []
                    },
                    "flxFeesPaidRadioButtons": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeesTypeRadio1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblFeesOpt1": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblFeesOpt2": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "lblFeesOpt3": {
                        "centerY": {
                            "type": "string",
                            "value": "41%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentRef": {
                        "segmentProps": []
                    },
                    "lblPaymentRef": {
                        "segmentProps": []
                    },
                    "tbxPaymentRef": {
                        "right": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddToList": {
                        "segmentProps": []
                    },
                    "lblAddToList": {
                        "segmentProps": []
                    },
                    "flxEndSeperator": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnBack": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnNext": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Next",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnOption": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Option",
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnBack": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnNext": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Next",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnOption": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Option",
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt": {
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "customfooter.btnFaqs": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnPrivacy": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.btnTermsAndConditions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar3": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.flxVBar4": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "text": "© Copyright Infinity Retail Banking. All rights reserved.",
                        "segmentProps": []
                    },
                    "customfooter": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPopupNew.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxPopupNew.flxPlaceHolder": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLookup": {
                        "segmentProps": []
                    },
                    "lblSearchHeading": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftText": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblBankNameLookup": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "txtBankName": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxCityCountry": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "lblCity1": {
                        "segmentProps": []
                    },
                    "txtCity1": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblCountry1": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "segmentProps": []
                    },
                    "txtCountry1": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchButtons": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "btnClearSearchBic": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknbtnSSPffffff15px0273e3bg",
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "skin": "sknbtnSSPffffff15px0273e3bg",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45.16%"
                        },
                        "hoverSkin": "sknbtnSSPffffff15px0273e3bg",
                        "segmentProps": []
                    },
                    "btnSearch": {
                        "centerY": {
                            "type": "string",
                            "value": "66.67%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "3.23%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45.16%"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftCode": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblBank": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCountryName": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCityName": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxLookupSegmentDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "segResults": {
                        "data": [{
                            "lblBankValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Bank Name"
                            },
                            "lblCityNameValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "City Name"
                            },
                            "lblCountryNameValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Country Name"
                            },
                            "lblSelectSwift": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "i18nkey": "i18n.TransfersEur.selectSwift",
                                "text": "Select Swift"
                            },
                            "lblSwiftCodeValue": {
                                "@class": "com.viz.ide.model.segment.SimpleTextSegmentData",
                                "text": "Swift Code"
                            }
                        }],
                        "rowTemplate": kony.mvc.resolveNameFromContext({
                            "appName": "TransfersMA",
                            "friendlyName": "flxResultsMobile"
                        }),
                        "sectionHeaderTemplate": "",
                        "widgetDataMap": {
                            "flxCity": "flxCity",
                            "flxResultsMobile": "flxResultsMobile",
                            "lblBankValue": "lblBankValue",
                            "lblCityNameValue": "lblCityNameValue",
                            "lblCountryNameValue": "lblCountryNameValue",
                            "lblSelectSwift": "lblSelectSwift",
                            "lblSwiftCodeValue": "lblSwiftCodeValue"
                        },
                        "segmentProps": ["rowTemplate", "sectionHeaderTemplate", "widgetDataMap", "data"],
                        "appName": "TransfersMA"
                    },
                    "flxNoResults": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblNoResults": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "customheader": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOverdraftWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxOutageWarning": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "lblPrintfontIconConfirm": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "height": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "isVisible": false,
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxGenericMessage": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAckMessage": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknLabelSSP42424217px",
                        "text": "23467686990",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "skin": "slFbox",
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.rTextSuccess": {
                        "left": {
                            "type": "string",
                            "value": "12%"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "focusSkin": "sknFlxffffffShadowdddcdc",
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxDate": {
                        "segmentProps": []
                    },
                    "calProcesingDate": {
                        "padding": [5, 0, 5, 0],
                        "segmentProps": []
                    },
                    "flxValueDate": {
                        "segmentProps": []
                    },
                    "calValueDate": {
                        "padding": [5, 0, 5, 0],
                        "segmentProps": []
                    },
                    "flxTextBox": {
                        "height": {
                            "type": "string",
                            "value": "106px"
                        },
                        "segmentProps": []
                    },
                    "txtDescription": {
                        "Default": {
                            "contentAlignment": 1
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "height": {
                            "type": "string",
                            "value": "106px"
                        },
                        "text": "Savings Account Nickname...2365",
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "flxTopSeperator": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.67%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalDetailsStatus": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatus": {
                        "left": {
                            "type": "string",
                            "value": "4.10%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "left": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "lblApproveCount": {
                        "left": {
                            "type": "string",
                            "value": "18dp"
                        },
                        "segmentProps": []
                    },
                    "lblApproveCountVal": {
                        "left": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "btnPendingAprrovers": {
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "35dp"
                        },
                        "segmentProps": []
                    },
                    "segApprovalDetails": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTopSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "width": {
                            "type": "string",
                            "value": "94.66%"
                        },
                        "segmentProps": []
                    },
                    "lblRecordHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipients": {
                        "left": {
                            "type": "string",
                            "value": "51%"
                        },
                        "width": {
                            "type": "string",
                            "value": "33%"
                        },
                        "segmentProps": []
                    },
                    "flxHeaderSeparator": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "segmentProps": []
                    },
                    "flxSearchRecipientsBox": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "lblAddPayment": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "lblRecordHeader1": {
                        "segmentProps": []
                    },
                    "flxSeperatorHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddType2": {
                        "height": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddType2RadioButtons": {
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "flxViewOnlySeletced": {
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "36%"
                        },
                        "segmentProps": []
                    },
                    "lblViewOnlySelected": {
                        "height": {
                            "type": "string",
                            "value": "60px"
                        },
                        "left": {
                            "type": "string",
                            "value": "20%"
                        },
                        "right": {
                            "type": "string",
                            "value": "10%"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "45%"
                        },
                        "segmentProps": []
                    },
                    "flxStatus": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "10%"
                        },
                        "width": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "lblStatus1": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "n",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipientDetailsErrorMessage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "2.60%"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxSeperator4": {
                        "centerX": {
                            "type": "string",
                            "value": "49.89%"
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipientsManually": {
                        "segmentProps": []
                    },
                    "lblAddHeader": {
                        "segmentProps": []
                    },
                    "flxAddType": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "3dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddTypeRadioButtons": {
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "flxBankType": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientAccountNumber": {
                        "segmentProps": []
                    },
                    "tbxRecipAccNumber": {
                        "width": {
                            "type": "string",
                            "value": "44.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountType": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientAccountNumberExt": {
                        "segmentProps": []
                    },
                    "tbxRecipAccNumberExt": {
                        "width": {
                            "type": "string",
                            "value": "44.50%"
                        },
                        "segmentProps": []
                    },
                    "tbxSwift": {
                        "width": {
                            "type": "string",
                            "value": "44.50%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientBankName": {
                        "segmentProps": []
                    },
                    "tbxRecipientBankName": {
                        "width": {
                            "type": "string",
                            "value": "44.50%"
                        },
                        "segmentProps": []
                    },
                    "lblNameValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountKey": {
                        "width": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "lblAccountValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblBankNameValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftValue": {
                        "left": {
                            "type": "string",
                            "value": "38%"
                        },
                        "segmentProps": []
                    },
                    "lblCurrency": {
                        "segmentProps": []
                    },
                    "lbxCurrency": {
                        "width": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "tbxCurrency": {
                        "width": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "left": {
                            "type": "string",
                            "value": "14%"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "width": {
                            "type": "string",
                            "value": "32%"
                        },
                        "segmentProps": []
                    },
                    "lblRecipientName": {
                        "segmentProps": []
                    },
                    "tbxRecipientName": {
                        "width": {
                            "type": "string",
                            "value": "44.50%"
                        },
                        "segmentProps": []
                    },
                    "flxFeesPaid": {
                        "height": {
                            "type": "string",
                            "value": "85dp"
                        },
                        "segmentProps": []
                    },
                    "flxInfo": {
                        "left": {
                            "type": "string",
                            "value": "15%"
                        },
                        "segmentProps": []
                    },
                    "flxFeesPaidRadioButtons": {
                        "isVisible": true,
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "flxFeesTypeRadio2": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxFeesTypeRadio3": {
                        "left": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxInformationText": {
                        "left": {
                            "type": "string",
                            "value": "15.30%"
                        },
                        "segmentProps": []
                    },
                    "RichTextSharedPayeeInfo": {
                        "segmentProps": []
                    },
                    "flxPaymentRef": {
                        "segmentProps": []
                    },
                    "lblPaymentRef": {
                        "segmentProps": []
                    },
                    "tbxPaymentRef": {
                        "width": {
                            "type": "string",
                            "value": "44.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAddToList": {
                        "segmentProps": []
                    },
                    "lblSelect": {
                        "centerX": {
                            "type": "string",
                            "value": "2.80%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "56%"
                        },
                        "segmentProps": []
                    },
                    "lblAddToList": {
                        "centerY": {
                            "type": "string",
                            "value": "56%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnBack": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnCancel": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnNext": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnOption": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.flxMain": {
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnBack": {
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnCancel": {
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnNext": {
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.btnOption": {
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.flxMain": {
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblTitleTerms": {
                        "left": {
                            "type": "string",
                            "value": "27px"
                        },
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconOne": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconThree": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter.imgFooterIconTwo": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customfooter": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxLookup": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblSearchHeading": {
                        "segmentProps": []
                    },
                    "lblSwiftText": {
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "txtBankName": {
                        "segmentProps": []
                    },
                    "txtCity1": {
                        "segmentProps": []
                    },
                    "txtCountry1": {
                        "segmentProps": []
                    },
                    "flxSearchButtons": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "btnClearSearchBic": {
                        "focusSkin": "sknbtnSSPffffff15px0273e3bg",
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "45%"
                        },
                        "skin": "sknbtnSSPffffff15px0273e3bg",
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "hoverSkin": "sknbtnSSPffffff15px0273e3bg",
                        "segmentProps": []
                    },
                    "btnSearch": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "lblSwiftCode": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblBank": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCountryName": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCityName": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxLookupSegmentDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxNoResults": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxOverlay": {
                        "segmentProps": []
                    },
                    "flxPendingApprovers": {
                        "width": {
                            "type": "string",
                            "value": "60%"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalDetails": {
                        "segmentProps": []
                    },
                    "imgPopupclose": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxPerTransaction": {
                        "width": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "flxDailyTransaction": {
                        "left": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": []
                    },
                    "flxWeekelyTransaction": {
                        "segmentProps": []
                    },
                    "lblBulkInfo": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "lblNoPendingApprovals": {
                        "width": {
                            "type": "string",
                            "value": "85%"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "height": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxGenericMessage": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxAckMessage": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "23467686990",
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "skin": "sknFlxffffffShadowdddcdc",
                        "zIndex": 1,
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "flxErrorMessage": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "calProcesingDate": {
                        "padding": [6, 0, 5, 0],
                        "segmentProps": []
                    },
                    "calValueDate": {
                        "padding": [6, 0, 5, 0],
                        "segmentProps": []
                    },
                    "txtDescription": {
                        "text": "Savings Account Nickname...2365",
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "CopyslFbox0j0ebf902d97643",
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96.60%"
                        },
                        "segmentProps": []
                    },
                    "flxApprovalHistoryContent": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "segmentProps": []
                    },
                    "flxRecipientTab": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "lblRecordHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipients": {
                        "left": {
                            "type": "string",
                            "value": "65.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAddPayment": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "segmentProps": []
                    },
                    "lblAddPayment": {
                        "centerX": {
                            "type": "string",
                            "value": "65%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "TabBodyNew1.segTemplates": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxViewOnlySeletced": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "lblViewOnlySelected": {
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxStatus": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblStatus1": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "text": "n",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipientDetailsErrorMessage": {
                        "layoutType": kony.flex.FREE_FORM,
                        "skin": "CopyslFbox0j0ebf902d97643",
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "96.60%"
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipientsManually": {
                        "segmentProps": []
                    },
                    "flxAddToList": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnOption": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.flxMain": {
                        "segmentProps": []
                    },
                    "PaginationContainer": {
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "instanceId": "PaginationContainer"
                    },
                    "CommonFormActionsExt.btnOption": {
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.flxMain": {
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "customfooter": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxPopupNew.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxLookup": {
                        "segmentProps": []
                    },
                    "flxSearchHeading": {
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": []
                    },
                    "lblSearchHeading": {
                        "segmentProps": []
                    },
                    "lblseparator": {
                        "segmentProps": []
                    },
                    "lblSwiftText": {
                        "segmentProps": []
                    },
                    "txtBankName": {
                        "segmentProps": []
                    },
                    "txtCity1": {
                        "segmentProps": []
                    },
                    "txtCountry1": {
                        "segmentProps": []
                    },
                    "flxSearchButtons": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnClearSearchBic": {
                        "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknbtnSSPffffff15px0273e3bg",
                        "text": "Clear",
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "19%"
                        },
                        "hoverSkin": "sknBtnNormalSSPFFFFFFHover15Px",
                        "segmentProps": []
                    },
                    "btnSearch": {
                        "left": {
                            "type": "string",
                            "value": "7%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxLookupSegmentHeader": {
                        "segmentProps": []
                    },
                    "lblSwiftCode": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblBank": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCountryName": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCityName": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxLookupSegmentDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "segResults": {
                        "segmentProps": []
                    },
                    "flxNoResults": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "isVisible": false,
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblNoResults": {
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheader": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentContainer": {
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "flxContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": []
                    },
                    "flxDownload": {
                        "height": {
                            "type": "string",
                            "value": "26dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "4%"
                        },
                        "top": {
                            "type": "string",
                            "value": "31dp"
                        },
                        "segmentProps": []
                    },
                    "flxDisplayErrorMessage": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "66dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.85%"
                        },
                        "segmentProps": []
                    },
                    "imgDisplayError": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxGenericMessage": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxAckMessage": {
                        "isVisible": false,
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxImgContainer": {
                        "segmentProps": []
                    },
                    "imgCheck": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "src": "success_green_2.png",
                        "segmentProps": []
                    },
                    "lblSuccessMessage": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl424242SSP20Px",
                        "text": "43331575819",
                        "segmentProps": []
                    },
                    "flxDashboard": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxTabPaneContainer": {
                        "isVisible": true,
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxAcknowledgementContainer": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew": {
                        "segmentProps": []
                    },
                    "flxAcknowledgementNew.imgTick": {
                        "src": "success_green.png",
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "focusSkin": "sknFlxffffffShadowdddcdc",
                        "segmentProps": []
                    },
                    "NonEditableBulkPaymentDetails.flxTitle": {
                        "top": "-43dp",
                        "segmentProps": []
                    },
                    "flxDate": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxEffectiveDate": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "calProcesingDate": {
                        "padding": [6, 0, 5, 0],
                        "skin": "sknBBCal42424215px",
                        "segmentProps": []
                    },
                    "flxValueDate": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "flxValDate": {
                        "zIndex": 2,
                        "segmentProps": []
                    },
                    "calValueDate": {
                        "padding": [6, 0, 5, 0],
                        "skin": "sknBBCal42424215px",
                        "segmentProps": []
                    },
                    "txtDescription": {
                        "text": "Savings Account Nickname...2365",
                        "segmentProps": []
                    },
                    "flxApprovalsHistoryErrorMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryError": {
                        "centerX": {
                            "type": "string",
                            "value": "7%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblApprovalHistoryInformation": {
                        "segmentProps": []
                    },
                    "lblApprovalStatusValue": {
                        "segmentProps": []
                    },
                    "btnPendingAprrovers": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblRecordHeader": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblAddPayment": {
                        "left": {
                            "type": "string",
                            "value": "18%"
                        },
                        "segmentProps": []
                    },
                    "TabBodyNew1.segTemplates": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxViewOnlySeletced": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblViewOnlySelected": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80px"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "skin": "sknSSP42424215Px",
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxStatus": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "lblStatus1": {
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipientDetailsErrorMessage": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblTemplateRecordsError": {
                        "segmentProps": []
                    },
                    "flxTemplateRecordsErrorSeperator": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxAddRecipientsManually": {
                        "segmentProps": []
                    },
                    "lblInvalidIBANInfinity": {
                        "segmentProps": []
                    },
                    "lblInvalidIBAN": {
                        "segmentProps": []
                    },
                    "lblInvalidSwift": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.btnOption": {
                        "segmentProps": []
                    },
                    "CommonFormActionsNew.flxMain": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "PaginationContainer": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "instanceId": "PaginationContainer"
                    },
                    "CommonFormActionsExt.btnOption": {
                        "segmentProps": []
                    },
                    "CommonFormActionsExt.flxMain": {
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxTerms": {
                        "segmentProps": []
                    },
                    "browserTnC": {
                        "segmentProps": []
                    },
                    "flxLoading": {
                        "segmentProps": []
                    },
                    "flxPopupConfirmation": {
                        "segmentProps": []
                    },
                    "flxPopupNew.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxLookup": {
                        "segmentProps": []
                    },
                    "lblSearchHeading": {
                        "segmentProps": []
                    },
                    "lblseparator": {
                        "segmentProps": []
                    },
                    "lblSwiftText": {
                        "segmentProps": []
                    },
                    "txtBankName": {
                        "segmentProps": []
                    },
                    "txtCity1": {
                        "segmentProps": []
                    },
                    "txtCountry1": {
                        "segmentProps": []
                    },
                    "flxSearchButtons": {
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "segmentProps": []
                    },
                    "btnClearSearchBic": {
                        "focusSkin": "sknbtnSSPffffff15px0273e3bg",
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknbtnSSPffffff15px0273e3bg",
                        "text": "Clear",
                        "top": {
                            "type": "number",
                            "value": "20"
                        },
                        "width": {
                            "type": "string",
                            "value": "19%"
                        },
                        "hoverSkin": "sknbtnSSPffffff15px0273e3bg",
                        "segmentProps": []
                    },
                    "btnSearch": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "right": {
                            "type": "string",
                            "value": "3%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxLookupSegmentHeader": {
                        "segmentProps": []
                    },
                    "lblSwiftCode": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblBank": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCountryName": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "lblCityName": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "skin": "sknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "flxLookupSegmentDetails": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "flxNoResults": {
                        "isVisible": false,
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "flxPendingApprovers": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICsknFlxffffff",
                        "segmentProps": []
                    },
                    "flxSeparator": {
                        "skin": "ICSknflxe3e3e3",
                        "segmentProps": []
                    },
                    "flxNoteMessage": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon": {
                        "segmentProps": []
                    },
                    "lblBulkInfo": {
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxApproverList": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxBulkInfo": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": []
                    },
                    "imgInfoIcon2": {
                        "segmentProps": []
                    },
                    "lblNoPendingApprovals": {
                        "right": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "segmentProps": []
                    },
                    "flxBottomSeparator": {
                        "segmentProps": []
                    },
                    "btnClose": {
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "flxCancelPopup": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheader.headermenu.imgUserReset": {
                    "src": "profileheadernew.png"
                },
                "customheader.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheader.topmenu.lblFeedback": {
                    "text": "Feedback"
                },
                "customheader.topmenu.lblHelp": {
                    "text": "Help"
                },
                "GenericMessageNew": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "flxAcknowledgement": {
                    "successImgWidth": "4.44%",
                    "successMsg": "Your transaction has been successfully submitted\nReference Number 45423792753",
                    "right": "",
                    "top": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": ""
                },
                "flxAcknowledgementNew.flxAckContainer": {
                    "height": "85dp"
                },
                "flxAcknowledgementNew": {
                    "left": "0dp",
                    "width": "100%"
                },
                "flxAcknowledgementNew.flxImgdownload": {
                    "centerX": "",
                    "centerY": "50%",
                    "height": "22dp",
                    "left": "95%",
                    "width": "22dp"
                },
                "flxAcknowledgementNew.imgDownload": {
                    "height": "100%",
                    "src": "bbcloseicon_1.png",
                    "width": "100%"
                },
                "flxAcknowledgementNew.imgPrint": {
                    "src": "bbprint.png"
                },
                "flxAcknowledgementNew.imgTick": {
                    "src": "bulk_billpay_success.png"
                },
                "flxAcknowledgementNew.rTextSuccess": {
                    "height": kony.flex.USE_PREFFERED_SIZE,
                    "left": "8.80%",
                    "width": "80%"
                },
                "NonEditableBulkPaymentDetails": {
                    "top": "0dp"
                },
                "NonEditableBulkPaymentDetails.btnEdit": {
                    "width": "45dp"
                },
                "NonEditableBulkPaymentDetails.flxBtmSeperator": {
                    "top": "15dp",
                    "width": "100%"
                },
                "NonEditableBulkPaymentDetails.flxTitle": {
                    "top": "-44dp"
                },
                "NonEditableBulkPaymentDetails.lblACHTitleText": {
                    "centerY": "26dp"
                },
                "NonEditableBulkPaymentDetails.segNonEditableDetails": {
                    "data": [{
                        "lblColon": ":",
                        "lblIcon": "",
                        "lblKey": "From Account",
                        "lblValue": "",
                        "lblValueOld": ""
                    }, {
                        "lblColon": ":",
                        "lblIcon": "",
                        "lblKey": "Payment Description",
                        "lblValue": "",
                        "lblValueOld": ""
                    }, {
                        "lblColon": ":",
                        "lblIcon": "",
                        "lblKey": "Payment Date",
                        "lblValue": "",
                        "lblValueOld": ""
                    }, {
                        "lblColon": ":",
                        "lblIcon": "",
                        "lblKey": "Value Date",
                        "lblValue": "",
                        "lblValueOld": ""
                    }, {
                        "lblColon": ":",
                        "lblIcon": "",
                        "lblKey": "Total Amount",
                        "lblValue": "",
                        "lblValueOld": ""
                    }, {
                        "lblColon": ":",
                        "lblIcon": "",
                        "lblKey": "Number of Transactions",
                        "lblValue": "",
                        "lblValueOld": ""
                    }, {
                        "lblColon": ":",
                        "lblIcon": "",
                        "lblKey": "Bulk Payment ID",
                        "lblValue": "",
                        "lblValueOld": ""
                    }, {
                        "lblColon": ":",
                        "lblIcon": "",
                        "lblKey": "Payment File",
                        "lblValue": "",
                        "lblValueOld": ""
                    }],
                    "top": "13dp"
                },
                "EditableBulkPaymentDetails": {
                    "top": "0dp"
                },
                "EditableBulkPaymentDetails.flxBtmSeperator": {
                    "top": "180dp"
                },
                "EditableBulkPaymentDetails.flxTopSepartor": {
                    "centerX": "50%",
                    "top": "13dp"
                },
                "EditableBulkPaymentDetails.segEditableListBoxDetails": {
                    "data": [{
                        "lblColon": ":",
                        "lblKey": "From Account",
                        "lstFrmAccount": {
                            "masterData": [
                                ["Key3792415575", "Savings Account Nickname...2365"],
                                ["Key3338633066", "Value"],
                                ["Key2518722184", "Value"]
                            ],
                            "selectedKey": "Key3792415575",
                            "selectedKeyValue": ["Key3792415575", "Savings Account Nickname...2365"]
                        }
                    }],
                    "top": "20dp"
                },
                "EditableBulkPaymentDetails.segEditableTextBoxDetails": {
                    "data": [{
                        "lblColon": ":",
                        "lblKey": "Description",
                        "txtDescription": {
                            "placeholder": "",
                            "text": "June Salary Payment"
                        }
                    }],
                    "top": "20dp"
                },
                "TabBodyNew1": {
                    "top": "5dp"
                },
                "TabBodyNew1.segTemplates": {
                    "bottom": ""
                },
                "CommonFormActionsNew.btnBack": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "50%",
                    "height": "40dp",
                    "left": "",
                    "right": "2.54%",
                    "top": "",
                    "width": "13%",
                    "zIndex": 3
                },
                "CommonFormActionsNew.btnCancel": {
                    "bottom": "",
                    "height": "40dp",
                    "left": "",
                    "right": "2.54%",
                    "width": "13%"
                },
                "CommonFormActionsNew.btnNext": {
                    "bottom": "",
                    "height": "40dp",
                    "left": "",
                    "right": "2.54%",
                    "text": "Next",
                    "width": "13%"
                },
                "CommonFormActionsNew.btnOption": {
                    "bottom": "",
                    "centerX": "",
                    "height": "40dp",
                    "left": "",
                    "right": "2.54%",
                    "top": "",
                    "width": "13%",
                    "zIndex": 2
                },
                "CommonFormActionsNew.flxMain": {
                    "centerX": "",
                    "centerY": "40%",
                    "height": "100%",
                    "left": "0dp",
                    "reverseLayoutDirection": true,
                    "right": "",
                    "top": "0dp",
                    "width": "100%",
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "CommonFormActionsNew": {
                    "centerX": "50%",
                    "height": "100dp",
                    "top": "10dp",
                    "width": "99%"
                },
                "PaginationContainer": {
                    "top": "0dp"
                },
                "PaginationContainer.flxPaginationNext": {
                    "right": "-0.50%"
                },
                "PaginationContainer.imgPaginationLast": {
                    "src": "pagination_last_active.png"
                },
                "PaginationContainer.imgPaginationNext": {
                    "src": "pagination_next_active.png"
                },
                "PaginationContainer.imgPaginationPrevious": {
                    "src": "pagination_back_inactive.png"
                },
                "PaginationContainer.lblPagination": {
                    "left": "1.50%",
                    "right": "1.50%",
                    "text": "1-03 of 03 Records"
                },
                "formActionsNew.flxMain": {
                    "height": "100%"
                },
                "CommonFormActionsExt.btnBack": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "50%",
                    "height": "40dp",
                    "left": "",
                    "right": "2.54%",
                    "top": "",
                    "width": "13%",
                    "zIndex": 3
                },
                "CommonFormActionsExt.btnCancel": {
                    "bottom": "",
                    "height": "40dp",
                    "left": "",
                    "right": "2.54%",
                    "width": "13%"
                },
                "CommonFormActionsExt.btnNext": {
                    "bottom": "",
                    "height": "40dp",
                    "left": "",
                    "right": "0%",
                    "text": "Next",
                    "width": "13%"
                },
                "CommonFormActionsExt.btnOption": {
                    "bottom": "",
                    "centerX": "",
                    "height": "40dp",
                    "left": "",
                    "right": "2.54%",
                    "top": "",
                    "width": "13%",
                    "zIndex": 2
                },
                "CommonFormActionsExt.flxMain": {
                    "centerX": "",
                    "centerY": "40%",
                    "height": "100%",
                    "left": "0dp",
                    "reverseLayoutDirection": true,
                    "right": "",
                    "top": "0dp",
                    "width": "100%",
                    "layoutType": kony.flex.FLOW_HORIZONTAL
                },
                "CommonFormActionsExt": {
                    "centerX": "50%",
                    "height": "100dp",
                    "top": "10dp",
                    "width": "100%"
                },
                "flxPopupNew.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "flxPopupNew.imgClose": {
                    "src": "bbcloseicon.png"
                }
            }
            this.add(flxHeaderMain, flxFormContent, flxLogout, flxLoading, flxPopupConfirmation, flxLookupPopup, flxOverlay, flxPendingApprovers, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmBulkPaymentsReview,
            "enabledForIdleTimeout": true,
            "id": "frmBulkPaymentsReview",
            "init": controller.AS_Form_d73a055aaedf48e6907a1a372f42e78d,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "onTouchEnd": controller.AS_Form_c27f34c779fe4459a0570f2e7167b0ae,
            "postShow": controller.AS_Form_gf55215895974e91987f0dbb71552dbe,
            "preShow": function(eventobject) {
                controller.AS_Form_i5e7f04ab3f74cfebc1f92cd9cf46ac5(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "BulkPaymentsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_a0745c8d7fb84daabe97fc2da77944f6,
            "retainScrollPosition": true
        }]
    }
});