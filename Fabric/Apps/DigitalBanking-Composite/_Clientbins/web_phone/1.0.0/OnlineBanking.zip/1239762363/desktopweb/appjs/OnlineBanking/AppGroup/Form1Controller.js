define("OnlineBanking/AppGroup/userForm1Controller", {
    //Type your controller code here
    //dummy commit 
});
define("OnlineBanking/AppGroup/Form1ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("OnlineBanking/AppGroup/Form1Controller", ["OnlineBanking/AppGroup/userForm1Controller", "OnlineBanking/AppGroup/Form1ControllerActions"], function() {
    var controller = require("OnlineBanking/AppGroup/userForm1Controller");
    var controllerActions = ["OnlineBanking/AppGroup/Form1ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
