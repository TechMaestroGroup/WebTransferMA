define("ArrangementsMA/MortgageServicesUIModule/frmPrintPartialRepaymentAcknowledge", function() {
    return function(controller) {
        function addWidgetsfrmPrintPartialRepaymentAcknowledge() {
            this.setDefaultUnit(kony.flex.DP);
            var flxPrintAcknowledge = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPrintAcknowledge",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffnoborderThree",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrintAcknowledge.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "70px",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxHeader",
                "top": "70dp",
                "width": "97%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var imgKony = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "Header Kony Logo"
                },
                "height": "31dp",
                "id": "imgKony",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "6%",
                "skin": "slImage",
                "src": "kony_logo.png",
                "top": "18px",
                "width": "102dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblKonyBank = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "My Checking Account ….XXXX3254"
                },
                "centerY": "50%",
                "id": "lblKonyBank",
                "isVisible": true,
                "right": "6.66%",
                "skin": "sknlbl424242bold17px",
                "text": "My Checking Account ….XXXX3254",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeader.add(imgKony, lblKonyBank);
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.common.back\")"
                },
                "focusSkin": "slButtonGlossRed",
                "id": "btnBack",
                "isVisible": false,
                "left": "6.07%",
                "skin": "Copysknbtnffffff",
                "text": "< Back",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back"
            });
            var lblMyLoanAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "My Checking Account ….XXXX3254"
                },
                "id": "lblMyLoanAccount",
                "isVisible": true,
                "left": "1%",
                "skin": "sknlbl424242bold17px",
                "text": "My Checking Account ….XXXX3254",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAcknowledgementDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxAcknowledgementDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0",
                "width": "97%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementDetails.setDefaultUnit(kony.flex.DP);
            var flxAckHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxAckHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckHeader.setDefaultUnit(kony.flex.DP);
            var lblAcknowledgement = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAcknowledgement",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.Acknowledgement\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            flxAckHeader.add(lblAcknowledgement, flxSeparator);
            var flxRequestDetails = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "270dp",
                "id": "flxRequestDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRequestDetails.setDefaultUnit(kony.flex.DP);
            var flxMsg = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMsg",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "32dp",
                "width": "78%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMsg.setDefaultUnit(kony.flex.DP);
            var lblMsg = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblMsg",
                "isVisible": true,
                "left": 0,
                "skin": "ICSknlbl424242SSP24px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.transactionSubmitted\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMsg.add(lblMsg);
            var imgGreenTick = new kony.ui.Image2({
                "centerX": "50%",
                "height": "70dp",
                "id": "imgGreenTick",
                "isVisible": true,
                "left": "0",
                "src": "confirmation_tick.png",
                "top": "109dp",
                "width": "70dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceID = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblReferenceID",
                "isVisible": true,
                "left": "0",
                "skin": "sknSSP72727220Px",
                "text": "Request ID :",
                "top": "192dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceValue = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblReferenceValue",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabel42424224px",
                "text": "45423792753",
                "top": 214,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumber = new kony.ui.Label({
                "id": "lblReferenceNumber",
                "isVisible": true,
                "left": "0",
                "text": "Refrence Number :",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblReferenceNumberVal = new kony.ui.Label({
                "id": "lblReferenceNumberVal",
                "isVisible": true,
                "left": "0",
                "text": "PI2210913R2W4TF2",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRequestDetails.add(flxMsg, imgGreenTick, lblReferenceID, lblReferenceValue, lblReferenceNumber, lblReferenceNumberVal);
            flxAcknowledgementDetails.add(flxAckHeader, flxRequestDetails);
            var flxMortgageFacilityDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxMortgageFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0",
                "width": "97%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMortgageFacilityDetails.setDefaultUnit(kony.flex.DP);
            var flxFacilityDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0ba61b247ab7b42",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityDetails.setDefaultUnit(kony.flex.DP);
            var flxFacilityHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxFacilityHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityHeader.setDefaultUnit(kony.flex.DP);
            var lblMortgageDetails = new kony.ui.Label({
                "id": "lblMortgageDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": " Mortgage Facility Details",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "48dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator2.setDefaultUnit(kony.flex.DP);
            flxSeparator2.add();
            flxFacilityHeader.add(lblMortgageDetails, flxSeparator2);
            var flxFacilityContent = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "270dp",
                "id": "flxFacilityContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": 50,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityContent.setDefaultUnit(kony.flex.DP);
            var lblFacilityName = new kony.ui.Label({
                "id": "lblFacilityName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": " Facility Name :",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityNameVal = new kony.ui.Label({
                "id": "lblFacilityNameVal",
                "isVisible": true,
                "left": "333dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Mortgage Facility Account - 1234",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoans = new kony.ui.Label({
                "id": "lblNoOfLoans",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "No. of Loans :",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoansVal = new kony.ui.Label({
                "id": "lblNoOfLoansVal",
                "isVisible": true,
                "left": "333dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "3",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalance = new kony.ui.Label({
                "id": "lblOutstandingBalance",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Outstanding Balance :",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalanceVal = new kony.ui.Label({
                "id": "lblOutstandingBalanceVal",
                "isVisible": true,
                "left": "333dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€150,054.00",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmount = new kony.ui.Label({
                "id": "lblAmount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Amount Paid to Date :",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountVal = new kony.ui.Label({
                "id": "lblAmountVal",
                "isVisible": true,
                "left": "333dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€50,054.00",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFacilityContent.add(lblFacilityName, lblFacilityNameVal, lblNoOfLoans, lblNoOfLoansVal, lblOutstandingBalance, lblOutstandingBalanceVal, lblAmount, lblAmountVal);
            flxFacilityDetails.add(flxFacilityHeader, flxFacilityContent);
            flxMortgageFacilityDetails.add(flxFacilityDetails);
            var flxDisclaimer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDisclaimer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "sknFlxf7f7f7Border9797971pxRadius3px",
                "top": "5dp",
                "width": "97%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDisclaimer.setDefaultUnit(kony.flex.DP);
            var rtxDisclaimer = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": " <p style=\"line-height:200%;\"><b>Disclaimer:</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes.</style></p>"
                },
                "bottom": "2dp",
                "id": "rtxDisclaimer",
                "isVisible": true,
                "left": "1%",
                "skin": "sknRtxSSP72727213px",
                "text": " <p style=\"line-height:200%;\"><b>Disclaimer:</b>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes,  Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes.</style></p>",
                "top": "10px",
                "width": "94.60%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDisclaimer.add(rtxDisclaimer);
            var btnBackBottom = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.Back\")"
                },
                "focusSkin": "slButtonGlossRed",
                "height": "50px",
                "id": "btnBackBottom",
                "isVisible": false,
                "left": "79dp",
                "skin": "sknbtnbck3343a8SSPffffff15pxradius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.BACK\")",
                "top": "40dp",
                "width": "14.60%",
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Back"
            });
            var flxLoanDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxLoanDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0",
                "width": "97%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanDetails.setDefaultUnit(kony.flex.DP);
            var flxLoanFacilityDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxLoanFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0ba61b247ab7b42",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanFacilityDetails.setDefaultUnit(kony.flex.DP);
            var flxLoanHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxLoanHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanHeader.setDefaultUnit(kony.flex.DP);
            var lblLoanDetails = new kony.ui.Label({
                "id": "lblLoanDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": " Mortgage Facility Details",
                "top": "14dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLoanSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxLoanSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "48dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanSeparator.setDefaultUnit(kony.flex.DP);
            flxLoanSeparator.add();
            flxLoanHeader.add(lblLoanDetails, flxLoanSeparator);
            var flxLoanAccountName = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLoanAccountName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccountName.setDefaultUnit(kony.flex.DP);
            var lblLoanAccountName = new kony.ui.Label({
                "id": "lblLoanAccountName",
                "isVisible": true,
                "left": "0",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLoanAccountSeperator = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxLoanAccountSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccountSeperator.setDefaultUnit(kony.flex.DP);
            flxLoanAccountSeperator.add();
            flxLoanAccountName.add(lblLoanAccountName, flxLoanAccountSeperator);
            var flxLoanFacilityContent = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "270dp",
                "id": "flxLoanFacilityContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": 50,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanFacilityContent.setDefaultUnit(kony.flex.DP);
            var lblCurrentValue = new kony.ui.Label({
                "id": "lblCurrentValue",
                "isVisible": true,
                "left": "330dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Current Value",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedValue = new kony.ui.Label({
                "id": "lblSimulatedValue",
                "isVisible": true,
                "left": "572dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Simulated Value",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInstallmentAmount = new kony.ui.Label({
                "id": "lblInstallmentAmount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.numberofloansWithColon\")",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcurrInstallmentAmount = new kony.ui.Label({
                "id": "lblcurrInstallmentAmount",
                "isVisible": true,
                "left": "330dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€3,000",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblsimInstallmentAmount = new kony.ui.Label({
                "id": "lblsimInstallmentAmount",
                "isVisible": true,
                "left": "572dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "€3,000",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepaymentDate = new kony.ui.Label({
                "id": "lblRepaymentDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Next Repayment Date :",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcurrRepaymentDate = new kony.ui.Label({
                "id": "lblcurrRepaymentDate",
                "isVisible": true,
                "left": "330dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/01/2022",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblsimRepaymentDate = new kony.ui.Label({
                "id": "lblsimRepaymentDate",
                "isVisible": true,
                "left": "572dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/01/2022",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEndDate = new kony.ui.Label({
                "id": "lblEndDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "End Date (Maturity Date) :",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblcurrEndDate = new kony.ui.Label({
                "id": "lblcurrEndDate",
                "isVisible": true,
                "left": "330dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/01/2031",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblsimEndDate = new kony.ui.Label({
                "id": "lblsimEndDate",
                "isVisible": true,
                "left": "572dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "25/02/2030",
                "top": 140,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoanFacilityContent.add(lblCurrentValue, lblSimulatedValue, lblInstallmentAmount, lblcurrInstallmentAmount, lblsimInstallmentAmount, lblRepaymentDate, lblcurrRepaymentDate, lblsimRepaymentDate, lblEndDate, lblcurrEndDate, lblsimEndDate);
            flxLoanFacilityDetails.add(flxLoanHeader, flxLoanAccountName, flxLoanFacilityContent);
            flxLoanDetails.add(flxLoanFacilityDetails);
            var flxPaymentDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxffffffWithShadow1",
                "top": "0",
                "width": "97%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetails.setDefaultUnit(kony.flex.DP);
            var flxPaymentDetailsHeader = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPaymentDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "CopyslFbox0ba61b247ab7b42",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblPaymentDetails = new kony.ui.Label({
                "id": "lblPaymentDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Payment Details",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPaymentSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxPaymentSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentSeperator.setDefaultUnit(kony.flex.DP);
            flxPaymentSeperator.add();
            flxPaymentDetailsHeader.add(lblPaymentDetails, flxPaymentSeperator);
            var flxPaymentDetailsContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentDetailsContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "60dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsContent.setDefaultUnit(kony.flex.DP);
            var flxRepaymentAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxRepaymentAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRepaymentAmount.setDefaultUnit(kony.flex.DP);
            var lblRepaymentAmount = new kony.ui.Label({
                "id": "lblRepaymentAmount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Total Repayment Amount :",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepaymentAmountVal = new kony.ui.Label({
                "id": "lblRepaymentAmountVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "€32,000",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRepaymentAmount.add(lblRepaymentAmount, lblRepaymentAmountVal);
            var flxLoanAccount = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "30dp",
                "id": "flxLoanAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanAccount.setDefaultUnit(kony.flex.DP);
            var lblLoanAccount = new kony.ui.Label({
                "id": "lblLoanAccount",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.LoanAccount\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoanAccountVal = new kony.ui.Label({
                "id": "lblLoanAccountVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "************0723",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLoanAccount.add(lblLoanAccount, lblLoanAccountVal);
            var flxCredDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxCredDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCredDate.setDefaultUnit(kony.flex.DP);
            var lblCredDate = new kony.ui.Label({
                "id": "lblCredDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Credit Value Date : ",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCredDateVal = new kony.ui.Label({
                "id": "lblCredDateVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "07/14/2022",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCredDate.add(lblCredDate, lblCredDateVal);
            var flxTransactionFee = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTransactionFee",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTransactionFee.setDefaultUnit(kony.flex.DP);
            var lblTransactionFee = new kony.ui.Label({
                "id": "lblTransactionFee",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Transaction Fee :",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTransactionFeeVal = new kony.ui.Label({
                "id": "lblTransactionFeeVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$5.00",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTransactionFee.add(lblTransactionFee, lblTransactionFeeVal);
            var flxExchangeRate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxExchangeRate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxExchangeRate.setDefaultUnit(kony.flex.DP);
            var lblExchangeRate = new kony.ui.Label({
                "id": "lblExchangeRate",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Exchange Rate :",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblExchangeRateVal = new kony.ui.Label({
                "id": "lblExchangeRateVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "1.345",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxExchangeRate.add(lblExchangeRate, lblExchangeRateVal);
            var flxAccountHolder = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAccountHolder",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountHolder.setDefaultUnit(kony.flex.DP);
            var lblAccountHolder = new kony.ui.Label({
                "id": "lblAccountHolder",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Account Holder Name :",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountHolderVal = new kony.ui.Label({
                "id": "lblAccountHolderVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "Daisy Davis",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountHolder.add(lblAccountHolder, lblAccountHolderVal);
            var flxAccountNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxAccountNumber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountNumber.setDefaultUnit(kony.flex.DP);
            var lblAccountNumber = new kony.ui.Label({
                "id": "lblAccountNumber",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Account Number :",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountNumberVal = new kony.ui.Label({
                "id": "lblAccountNumberVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "************4556",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountNumber.add(lblAccountNumber, lblAccountNumberVal);
            var flxPayOn = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPayOn",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayOn.setDefaultUnit(kony.flex.DP);
            var lblPayOn = new kony.ui.Label({
                "id": "lblPayOn",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Pay On :",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPayOnVal = new kony.ui.Label({
                "id": "lblPayOnVal",
                "isVisible": true,
                "left": "358dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "07/14/2022",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayOn.add(lblPayOn, lblPayOnVal);
            var flxNotes = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNotes",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNotes.setDefaultUnit(kony.flex.DP);
            var lblNotes = new kony.ui.Label({
                "id": "lblNotes",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Notes :",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNotesDesc = new kony.ui.Label({
                "id": "lblNotesDesc",
                "isVisible": true,
                "left": 358,
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "The notes goes here",
                "top": "-19dp",
                "width": "67%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNotes.add(lblNotes, lblNotesDesc);
            var flxSupportingDocs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSupportingDocs",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "12dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSupportingDocs.setDefaultUnit(kony.flex.DP);
            var lblSuppDocs = new kony.ui.Label({
                "id": "lblSuppDocs",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727215px",
                "text": "Supporting Documents :",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segSupportingDocs = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgDoc": "",
                    "lblDocName": ""
                }],
                "groupCells": false,
                "id": "segSupportingDocs",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxSupportingDocs"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxContentDocs": "flxContentDocs",
                    "flxGap": "flxGap",
                    "flxImgDoc": "flxImgDoc",
                    "flxSupportingDocs": "flxSupportingDocs",
                    "imgDoc": "imgDoc",
                    "lblDocName": "lblDocName"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSupportingDocs.add(lblSuppDocs, segSupportingDocs);
            flxPaymentDetailsContent.add(flxRepaymentAmount, flxLoanAccount, flxCredDate, flxTransactionFee, flxExchangeRate, flxAccountHolder, flxAccountNumber, flxPayOn, flxNotes, flxSupportingDocs);
            flxPaymentDetails.add(flxPaymentDetailsHeader, flxPaymentDetailsContent);
            var flxBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "30dp",
                "clipBounds": true,
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "zIndex": 3,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var lblCopyRight = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Kony Bank Pvt. Ltd. Copyright 2017. All rightes reserved."
                },
                "id": "lblCopyRight",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.footer.copyrightTab1\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Page 1 of 1"
                },
                "id": "lblPage",
                "isVisible": false,
                "right": "0%",
                "skin": "sknlbl424242bold15px",
                "text": "Page 1 of 1",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 3
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBottom.add(lblCopyRight, lblPage);
            flxPrintAcknowledge.add(flxHeader, btnBack, lblMyLoanAccount, flxAcknowledgementDetails, flxMortgageFacilityDetails, flxDisclaimer, btnBackBottom, flxLoanDetails, flxPaymentDetails, flxBottom);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxPrintAcknowledge": {
                        "segmentProps": []
                    },
                    "flxLoanAccount": {
                        "height": {
                            "type": "string",
                            "value": "45dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblLoanAccountVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": []
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxPrintAcknowledge": {
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "lblMyLoanAccount": {
                        "text": "",
                        "segmentProps": []
                    },
                    "flxAcknowledgementDetails": {
                        "height": {
                            "type": "string",
                            "value": "320dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "number",
                            "value": "30"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxRequestDetails": {
                        "height": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": []
                    },
                    "lblMsg": {
                        "segmentProps": []
                    },
                    "imgGreenTick": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "270"
                        },
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceID": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "308dp"
                        },
                        "skin": "sknSSP72727220Px",
                        "text": "45423792753567768",
                        "top": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "skin": "sknSSP72727220Px",
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumberVal": {
                        "left": {
                            "type": "string",
                            "value": "363dp"
                        },
                        "skin": "sknSSP72727220Px",
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "number",
                            "value": "30"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxLoanDetails": {
                        "height": {
                            "type": "string",
                            "value": "290dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "number",
                            "value": "30"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxLoanFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "290dp"
                        },
                        "segmentProps": []
                    },
                    "lblLoanDetails": {
                        "text": "Loan Details",
                        "segmentProps": []
                    },
                    "flxLoanAccountName": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblLoanAccountName": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Primary Loan Account Name - 8760",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoanAccountSeperator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "skin": "bbSknFlxSeperatore3e3e3",
                        "top": {
                            "type": "number",
                            "value": "40"
                        },
                        "segmentProps": []
                    },
                    "flxLoanFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "top": {
                            "type": "number",
                            "value": "90"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "number",
                            "value": "30"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxLoanAccount": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "46%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxPrintAcknowledge": {
                        "segmentProps": []
                    },
                    "flxHeader": {
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "lblKonyBank": {
                        "right": {
                            "type": "string",
                            "value": "16.66%"
                        },
                        "segmentProps": []
                    },
                    "lblMyLoanAccount": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "text": "",
                        "segmentProps": []
                    },
                    "flxAcknowledgementDetails": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgement": {
                        "i18n_text": "i18n.konybb.common.Acknowledgement",
                        "text": "Acknowledgement",
                        "segmentProps": []
                    },
                    "flxRequestDetails": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": []
                    },
                    "flxMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "lblMsg": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "imgGreenTick": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "58dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "28dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceID": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "67dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceValue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "252dp"
                        },
                        "skin": "sknSSP72727220Px",
                        "text": "45423792753567768",
                        "top": {
                            "type": "string",
                            "value": "67dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumber": {
                        "left": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "skin": "sknSSP72727220Px",
                        "top": {
                            "type": "string",
                            "value": "67dp"
                        },
                        "segmentProps": []
                    },
                    "lblReferenceNumberVal": {
                        "left": {
                            "type": "string",
                            "value": "860dp"
                        },
                        "skin": "sknSSP72727220Px",
                        "text": "PI2210913R2W4TF2",
                        "top": {
                            "type": "string",
                            "value": "67dp"
                        },
                        "segmentProps": []
                    },
                    "flxMortgageFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "segmentProps": []
                    },
                    "lblMortgageDetails": {
                        "segmentProps": []
                    },
                    "flxFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": []
                    },
                    "lblFacilityName": {
                        "segmentProps": []
                    },
                    "lblNoOfLoans": {
                        "segmentProps": []
                    },
                    "lblOutstandingBalance": {
                        "segmentProps": []
                    },
                    "lblAmount": {
                        "segmentProps": []
                    },
                    "flxDisclaimer": {
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxLoanDetails": {
                        "height": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxLoanFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "270dp"
                        },
                        "segmentProps": []
                    },
                    "lblLoanDetails": {
                        "text": "Loan Details",
                        "segmentProps": []
                    },
                    "flxLoanAccountName": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "skin": "slFboxBGf8f7f8B0",
                        "top": {
                            "type": "number",
                            "value": "50"
                        },
                        "segmentProps": []
                    },
                    "lblLoanAccountName": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl424242SSP15Px",
                        "text": "Primary Loan Account Name - 8760",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxLoanAccountSeperator": {
                        "height": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "skin": "bbSknFlxSeperatore3e3e3",
                        "top": {
                            "type": "number",
                            "value": "40"
                        },
                        "segmentProps": []
                    },
                    "flxLoanFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "lblCurrentValue": {
                        "segmentProps": []
                    },
                    "lblInstallmentAmount": {
                        "i18n_text": "i18n.mortgageAccount.NewRepaymentAccountHolderNameWithColon",
                        "segmentProps": []
                    },
                    "lblsimInstallmentAmount": {
                        "segmentProps": []
                    },
                    "lblcurrRepaymentDate": {
                        "segmentProps": []
                    },
                    "flxPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "1%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDetailsHeader": {
                        "segmentProps": []
                    },
                    "flxLoanAccount": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": []
                    },
                    "segSupportingDocs": {
                        "left": {
                            "type": "string",
                            "value": "345dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "-10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "flxBottom": {
                        "width": {
                            "type": "string",
                            "value": "83%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {}
            this.add(flxPrintAcknowledge);
        };
        return [{
            "addWidgets": addWidgetsfrmPrintPartialRepaymentAcknowledge,
            "enabledForIdleTimeout": false,
            "id": "frmPrintPartialRepaymentAcknowledge",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_cdb75ea6f172421f9a9aaa462c26eeb6,
            "preShow": function(eventobject) {
                controller.AS_Form_fc372f4985ca4a829704083f1030d34f(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});