define("ApprovalMatrixMA/SettingsNewApprovalUIModule/frmEditApprovalsMatrixLimits", function() {
    return function(controller) {
        function addWidgetsfrmEditApprovalsMatrixLimits() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "imgUser": {
                        "src": "profile_header.png"
                    },
                    "lblHeaderMobile": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var lblApprovalMatrixHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "Foreign Exchange"
                },
                "centerX": "50%",
                "id": "lblApprovalMatrixHeader",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "text": "Approval Matrix -  Customer Level Edit ",
                "top": "0dp",
                "width": "88%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxDowntimeWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "height": "60dp",
                "id": "flxDowntimeWarning",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3.60%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "20dp",
                "width": "92.80%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.setDefaultUnit(kony.flex.DP);
            var imgDowntimeWarning = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "47%",
                "height": "40dp",
                "id": "imgDowntimeWarning",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "40dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var rtxDowntimeWarning = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "There is some error in the server.</br>\nWe could not complete your request of adding the account."
                },
                "centerY": "50%",
                "id": "rtxDowntimeWarning",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRtxSSPFF000015Px",
                "text": "There is some error in the server.</br>\nWe could not complete your request of adding the account.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDowntimeWarning.add(imgDowntimeWarning, rtxDowntimeWarning);
            var flxContractContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "80px",
                "id": "flxContractContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "23dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContractContainer.setDefaultUnit(kony.flex.DP);
            var flxAccountsName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountsName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountsName.setDefaultUnit(kony.flex.DP);
            var lblAccountNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.approvalMatrix.account\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountHeaderValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccountHeaderValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Checking Account….6737",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountsName.add(lblAccountNameHeader, lblAccountHeaderValue);
            var flxCustomerName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerName.setDefaultUnit(kony.flex.DP);
            var lblCustomerNameHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerNameHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.18n.approvalMatrix.customer\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerHeaderValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerHeaderValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos UK",
                "width": "75%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerName.add(lblCustomerNameHeader, lblCustomerHeaderValue);
            var flxCustomerID = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxCustomerID",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "16%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCustomerID.setDefaultUnit(kony.flex.DP);
            var lblCustomerIDHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Customer ID :",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCustomerIDValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCustomerIDValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "34256452388",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCustomerID.add(lblCustomerIDHeader, lblCustomerIDValue);
            var flxContract = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxContract",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "1.50%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "25%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContract.setDefaultUnit(kony.flex.DP);
            var lblContractHeader = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractHeader",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Contract :",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblContractValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblContractValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "sknlbl424242SSP15pxSemibold",
                "text": "Temenos Corp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContract.add(lblContractHeader, lblContractValue);
            flxContractContainer.add(flxAccountsName, flxCustomerName, flxCustomerID, flxContract);
            var flxMatrixSegmentWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMatrixSegmentWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "83px",
                "isModalContainer": false,
                "right": "83px",
                "skin": "sknFlxffffffShadowdddcdc3pxradius",
                "top": "30dp",
                "width": "88%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMatrixSegmentWrapper.setDefaultUnit(kony.flex.DP);
            var flxFeatureActionHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "49dp",
                "id": "flxFeatureActionHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFeatureActionHeader.setDefaultUnit(kony.flex.DP);
            var lblFeatureActionHeader = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblFeatureActionHeader",
                "isVisible": true,
                "left": "20px",
                "skin": "sknLblSSP46464615pxbold",
                "text": "Per Transaction Limits - Transfer to Own Account Within the  Financial Institution",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxPopupIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "55%",
                "clipBounds": true,
                "height": "16dp",
                "id": "flxPopupIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "12dp",
                "width": "16dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopupIcon.setDefaultUnit(kony.flex.DP);
            var imgIcon = new kony.ui.Image2({
                "height": "16dp",
                "id": "imgIcon",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "0dp",
                "width": "16dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPopupIcon.add(imgIcon);
            var flxMaxLimitContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxMaxLimitContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "54dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMaxLimitContainer.setDefaultUnit(kony.flex.DP);
            var lblMaxLimitTitle = new kony.ui.Label({
                "height": "100%",
                "id": "lblMaxLimitTitle",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblSSP46464615pxbold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvalMatrix.limitRange\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblMaxLimitValue = new kony.ui.Label({
                "height": "100%",
                "id": "lblMaxLimitValue",
                "isVisible": true,
                "left": "10dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMaxLimitContainer.add(lblMaxLimitTitle, lblMaxLimitValue);
            flxFeatureActionHeader.add(lblFeatureActionHeader, flxPopupIcon, flxMaxLimitContainer);
            var lblHeadingSeperator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblHeadingSeperator",
                "isVisible": true,
                "left": "0",
                "skin": "sknSeparatore3e3e3",
                "text": "-",
                "top": "0dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImportantInfo = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "120dp",
                "id": "flxImportantInfo",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "10dp",
                "width": "96%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImportantInfo.setDefaultUnit(kony.flex.DP);
            var flxImportantHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxImportantHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImportantHeader.setDefaultUnit(kony.flex.DP);
            var imgimportant = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.NAO.Info\")"
                },
                "height": "20dp",
                "id": "imgimportant",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "4%",
                "skin": "slImage",
                "src": "info.png",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblImportant = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.login.PasswordRules\")"
                },
                "centerY": "50%",
                "id": "lblImportant",
                "isVisible": true,
                "left": "2.30%",
                "skin": "sknLblSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userManagement.imprtntInfo\")",
                "top": "4dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImportantHeader.add(imgimportant, lblImportant);
            var rtxImportantInfo = new kony.ui.RichText({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.CardManagement.RichText\")"
                },
                "bottom": "10dp",
                "id": "rtxImportantInfo",
                "isVisible": true,
                "left": "5%",
                "linkSkin": "defRichTextLink",
                "skin": "sknRtxSSP72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.approvalMatix.importantPoints\")",
                "top": "10dp",
                "width": "83%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImportantInfo.add(flxImportantHeader, rtxImportantInfo);
            var lblImportantInfoSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblImportantInfoSeparator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknSeparatore3e3e3",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxErrorMessage = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "66dp",
                "id": "flxErrorMessage",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorMessage.setDefaultUnit(kony.flex.DP);
            var imgError = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "25dp",
                "id": "imgError",
                "isVisible": true,
                "left": "20dp",
                "skin": "slImage",
                "src": "error_yellow_2.png",
                "top": "5dp",
                "width": "25dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblError",
                "isVisible": true,
                "left": "9dp",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.createUser.ErrorMessage\")",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorMessage.add(imgError, lblError);
            var lblErrorSeparator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblErrorSeparator",
                "isVisible": false,
                "left": "0dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxTabNewHolder = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTabNewHolder",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTabNewHolder.setDefaultUnit(kony.flex.DP);
            var TabBodyNew = new com.InfinityOLB.Resources.TabBodyNew({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "TabBodyNew",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0px",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "TabBodyNew": {
                        "left": "0dp",
                        "top": "0px",
                        "width": "100%"
                    },
                    "segTemplates": {
                        "left": "0dp",
                        "top": "-40px"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxTabNewHolder.add(TabBodyNew);
            var flxAddRowContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "80dp",
                "id": "flxAddRowContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRowContainer.setDefaultUnit(kony.flex.DP);
            var btnAddAnotherRow = new kony.ui.Button({
                "centerY": "50%",
                "height": "30dp",
                "id": "btnAddAnotherRow",
                "isVisible": true,
                "left": "20px",
                "skin": "bbSknBtnFont455574SSP15Px",
                "text": "+ Add New Approval Limit",
                "top": "0",
                "width": "170dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddRowContainer.add(btnAddAnotherRow);
            var lblActionsHeadingSeperator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblActionsHeadingSeperator",
                "isVisible": true,
                "left": "0",
                "skin": "sknSeparatore3e3e3",
                "text": "-",
                "top": "0px",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEditActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxEditActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 20,
                "width": "100%",
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditActions.setDefaultUnit(kony.flex.DP);
            var EditActions = new com.InfinityOLB.Resources.formActionsNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "height": "100%",
                "id": "EditActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "bottom": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "190dp",
                        "top": "0dp",
                        "width": "150px"
                    },
                    "btnNext": {
                        "bottom": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "viz.val_cleared",
                        "right": "20px",
                        "text": "Save",
                        "top": "0dp",
                        "width": "150px"
                    },
                    "flxButtons": {
                        "centerY": "viz.val_cleared",
                        "top": "20dp"
                    },
                    "flxMain": {
                        "bottom": "0dp",
                        "height": "100%",
                        "top": "0dp"
                    },
                    "formActionsNew": {
                        "bottom": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "50%",
                        "height": "100%",
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEditActions.add(EditActions);
            flxMatrixSegmentWrapper.add(flxFeatureActionHeader, lblHeadingSeperator, flxImportantInfo, lblImportantInfoSeparator, flxErrorMessage, lblErrorSeparator, flxTabNewHolder, flxAddRowContainer, lblActionsHeadingSeperator, flxEditActions);
            flxContent.add(lblApprovalMatrixHeader, flxDowntimeWarning, flxContractContainer, flxMatrixSegmentWrapper);
            flxMain.add(flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "1400dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "103%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "centerX": "50%",
                        "width": "103%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxApprovalMatrixPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "60%",
                "clipBounds": true,
                "height": "100%",
                "id": "flxApprovalMatrixPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflx000000op50",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1002,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxApprovalMatrixPopup.setDefaultUnit(kony.flex.DP);
            var flxSegmentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "45%",
                "clipBounds": true,
                "height": "470px",
                "id": "flxSegmentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "65%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSegmentContainer.setDefaultUnit(kony.flex.DP);
            var lblHeader = new kony.ui.Label({
                "height": "18px",
                "id": "lblHeader",
                "isVisible": true,
                "left": "26dp",
                "skin": "bbSknLbl455574Lato15Px",
                "text": "Label",
                "top": "15dp",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxCross = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCross",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20px",
                "skin": "slFbox",
                "top": "13dp",
                "width": "20dp",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCross.setDefaultUnit(kony.flex.DP);
            var imgCross = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgCross",
                "isVisible": true,
                "left": "0",
                "skin": "sknImgPointer5vs",
                "src": "bbcloseicon.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCross.add(imgCross);
            var lblSeperator = new kony.ui.Label({
                "height": "1dp",
                "id": "lblSeperator",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblC4C4C4Seperator",
                "text": "a",
                "top": "50dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segData = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "100dp",
                "groupCells": false,
                "height": "320dp",
                "id": "segData",
                "isVisible": true,
                "left": "0dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "55dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxActions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "clipBounds": true,
                "height": "90dp",
                "id": "flxActions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "zIndex": 1,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxActions.setDefaultUnit(kony.flex.DP);
            var formActionsNew = new com.InfinityOLB.Resources.formActionsNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0dp",
                "height": "80dp",
                "id": "formActionsNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "overrides": {
                    "btnCancel": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.no\")",
                        "left": "140px",
                        "width": "150px"
                    },
                    "btnNext": {
                        "left": "321px",
                        "right": "34px",
                        "text": "Save",
                        "width": "140px"
                    },
                    "formActionsNew": {
                        "bottom": "0dp",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "height": "80dp",
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxActions.add(formActionsNew);
            flxSegmentContainer.add(lblHeader, flxCross, lblSeperator, segData, flxActions);
            flxApprovalMatrixPopup.add(flxSegmentContainer);
            var InfoIconPopups = new com.InfinityOLB.BillPay.InfoIcon.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "InfoIconPopups",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "270dp",
                "zIndex": 1,
                "appName": "BillPayMA",
                "overrides": {
                    "AllForms": {
                        "width": "270dp",
                        "zIndex": 1
                    },
                    "imgCross": {
                        "src": "bbcloseicon.png"
                    },
                    "imgToolTip": {
                        "src": "tool_tip.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxConfirmPopup = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxConfirmPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 100000000,
                "appName": "ApprovalMatrixMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmPopup.setDefaultUnit(kony.flex.DP);
            var confirmpopup = new com.InfinityOLB.Resources.flxPopupNew({
                "height": "100%",
                "id": "confirmpopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "bbSknFlx000000Opacity45Px",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "flxActionLevel": {
                        "isVisible": false
                    },
                    "flxComments": {
                        "isVisible": true,
                        "layoutType": kony.flex.FLOW_VERTICAL
                    },
                    "flxPlaceHolder": {
                        "isVisible": false
                    },
                    "flxPopupContainer": {
                        "left": "viz.val_cleared",
                        "right": "viz.val_cleared"
                    },
                    "flxSeperatorBottom": {
                        "top": "35dp"
                    },
                    "formActionsNew": {
                        "top": "0dp"
                    },
                    "formActionsNew.btnCancel": {
                        "text": "No",
                        "top": "viz.val_cleared"
                    },
                    "formActionsNew.btnNext": {
                        "height": "40dp",
                        "text": "Save",
                        "top": "viz.val_cleared"
                    },
                    "imgClose": {
                        "src": "closeicon_1.png"
                    },
                    "lblCommnets": {
                        "text": "Comments"
                    },
                    "lblHeader": {
                        "left": "30dp",
                        "text": "Popup Header"
                    },
                    "lblPopupMsg": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "text": "The changes will apply to all accounts of the customer, do you want to save?",
                        "top": "22dp",
                        "width": "70%"
                    },
                    "trComments": {
                        "right": "viz.val_cleared",
                        "top": "12dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxConfirmPopup.add(confirmpopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "segmentProps": []
                    },
                    "lblApprovalMatrixHeader": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "segmentProps": []
                    },
                    "confirmpopup.flxComments": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPlaceHolder": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPopupContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "160dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "lblApprovalMatrixHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "flxMatrixSegmentWrapper": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxImportantInfo": {
                        "height": {
                            "type": "string",
                            "value": "108px"
                        },
                        "segmentProps": []
                    },
                    "flxImportantHeader": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "imgimportant": {
                        "left": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "lblImportant": {
                        "left": {
                            "type": "string",
                            "value": "10px"
                        },
                        "segmentProps": []
                    },
                    "rtxImportantInfo": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "4px"
                        },
                        "segmentProps": []
                    },
                    "EditActions.btnCancel": {
                        "text": "Cancel",
                        "segmentProps": []
                    },
                    "EditActions.btnNext": {
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "width": {
                            "type": "string",
                            "value": "115%"
                        },
                        "segmentProps": []
                    },
                    "flxSegmentContainer": {
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "formActionsNew.btnCancel": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "segmentProps": []
                    },
                    "formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmPopup": {
                        "segmentProps": []
                    },
                    "confirmpopup.flxComments": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "65.10%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "text": "Create Rule",
                        "segmentProps": []
                    },
                    "confirmpopup.lblPopupMsg": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "4%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "lblApprovalMatrixHeader": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "flxDowntimeWarning": {
                        "left": {
                            "type": "string",
                            "value": "6.08%"
                        },
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxContractContainer": {
                        "width": {
                            "type": "string",
                            "value": "88%"
                        },
                        "segmentProps": []
                    },
                    "flxMatrixSegmentWrapper": {
                        "segmentProps": []
                    },
                    "flxImportantHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "imgimportant": {
                        "left": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "lblImportant": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "rtxImportantInfo": {
                        "left": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "segmentProps": []
                    },
                    "EditActions.btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "EditActions.flxButtons": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0"
                        },
                        "segmentProps": []
                    },
                    "EditActions": {
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "width": {
                            "type": "string",
                            "value": "104%"
                        },
                        "segmentProps": []
                    },
                    "flxSegmentContainer": {
                        "width": {
                            "type": "string",
                            "value": "36.60%"
                        },
                        "segmentProps": []
                    },
                    "formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "120px"
                        },
                        "width": {
                            "type": "string",
                            "value": "150px"
                        },
                        "segmentProps": []
                    },
                    "formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxConfirmPopup": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "confirmpopup.flxActionLevel": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "confirmpopup.flxComments": {
                        "isVisible": false,
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": []
                    },
                    "confirmpopup.flxPopupContainer": {
                        "width": {
                            "type": "string",
                            "value": "42%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.flxSeperatorBottom": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.formActionsNew.btnNext": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.imgClose": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblCommnets": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.lblHeader": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Create Rule",
                        "segmentProps": []
                    },
                    "confirmpopup.lblPopupMsg": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "This is an Account level Feature Action. The changes made will apply to only this account associated with the customer .",
                        "top": {
                            "type": "string",
                            "value": "22dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "confirmpopup.trComments": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "42dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "92%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "customheadernew.imgUser": {
                    "src": "profile_header.png"
                },
                "TabBodyNew": {
                    "left": "0dp",
                    "top": "0px",
                    "width": "100%"
                },
                "TabBodyNew.segTemplates": {
                    "left": "0dp",
                    "top": "-40px"
                },
                "EditActions.btnCancel": {
                    "bottom": "",
                    "centerY": "",
                    "left": "",
                    "right": "190dp",
                    "top": "0dp",
                    "width": "150px"
                },
                "EditActions.btnNext": {
                    "bottom": "",
                    "centerY": "",
                    "left": "",
                    "right": "20px",
                    "text": "Save",
                    "top": "0dp",
                    "width": "150px"
                },
                "EditActions.flxButtons": {
                    "centerY": "",
                    "top": "20dp"
                },
                "EditActions.flxMain": {
                    "bottom": "0dp",
                    "height": "100%",
                    "top": "0dp"
                },
                "EditActions": {
                    "bottom": "",
                    "centerX": "",
                    "centerY": "50%",
                    "height": "100%",
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%"
                },
                "customfooternew": {
                    "centerX": "50%",
                    "width": "103%"
                },
                "formActionsNew.btnCancel": {
                    "left": "140px",
                    "width": "150px"
                },
                "formActionsNew.btnNext": {
                    "left": "321px",
                    "right": "34px",
                    "text": "Save",
                    "width": "140px"
                },
                "formActionsNew": {
                    "bottom": "0dp",
                    "centerX": "",
                    "centerY": "",
                    "height": "80dp",
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%"
                },
                "InfoIconPopups": {
                    "width": "270dp",
                    "zIndex": 1
                },
                "InfoIconPopups.imgCross": {
                    "src": "bbcloseicon.png"
                },
                "InfoIconPopups.imgToolTip": {
                    "src": "tool_tip.png"
                },
                "confirmpopup.flxComments": {
                    "layoutType": kony.flex.FLOW_VERTICAL
                },
                "confirmpopup.flxPopupContainer": {
                    "left": "",
                    "right": ""
                },
                "confirmpopup.flxSeperatorBottom": {
                    "top": "35dp"
                },
                "confirmpopup.formActionsNew": {
                    "top": "0dp"
                },
                "confirmpopup.formActionsNew.btnCancel": {
                    "text": "No",
                    "top": ""
                },
                "confirmpopup.formActionsNew.btnNext": {
                    "height": "40dp",
                    "text": "Save",
                    "top": ""
                },
                "confirmpopup.imgClose": {
                    "src": "closeicon_1.png"
                },
                "confirmpopup.lblCommnets": {
                    "text": "Comments"
                },
                "confirmpopup.lblHeader": {
                    "left": "30dp",
                    "text": "Popup Header"
                },
                "confirmpopup.lblPopupMsg": {
                    "centerX": "",
                    "centerY": "",
                    "text": "The changes will apply to all accounts of the customer, do you want to save?",
                    "top": "22dp",
                    "width": "70%"
                },
                "confirmpopup.trComments": {
                    "right": "",
                    "top": "12dp"
                }
            }
            this.add(flxHeader, flxFormContent, flxApprovalMatrixPopup, InfoIconPopups, flxConfirmPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmEditApprovalsMatrixLimits,
            "enabledForIdleTimeout": true,
            "id": "frmEditApprovalsMatrixLimits",
            "init": controller.AS_Form_ef67f38961974a36a1861b0c88759204,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_i617b7fc1df94c819ecf1c69767e6129,
            "preShow": function(eventobject) {
                controller.AS_Form_c02dfa489c93448dab39eaffbe2c9920(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "ApprovalMatrixMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_ec921cf649634f60adbe39cd459046f9,
            "retainScrollPosition": false
        }]
    }
});