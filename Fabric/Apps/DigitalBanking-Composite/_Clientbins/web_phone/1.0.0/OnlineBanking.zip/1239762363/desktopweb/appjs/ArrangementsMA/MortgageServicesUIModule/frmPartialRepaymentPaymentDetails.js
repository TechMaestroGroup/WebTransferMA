define("ArrangementsMA/MortgageServicesUIModule/frmPartialRepaymentPaymentDetails", function() {
    return function(controller) {
        function addWidgetsfrmPartialRepaymentPaymentDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var formTemplate12 = new com.InfinityOLB.Resources.formTemplate12({
                "height": "100%",
                "id": "formTemplate12",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ResourcesMA",
                "viewType": "formTemplate12",
                "overrides": {
                    "formTemplate12": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var formTemplate12_data = (appConfig.componentMetadata && appConfig.componentMetadata["ResourcesMA"] && appConfig.componentMetadata["ResourcesMA"]["frmPartialRepaymentPaymentDetails"] && appConfig.componentMetadata["ResourcesMA"]["frmPartialRepaymentPaymentDetails"]["formTemplate12"]) || {};
            formTemplate12.serviceParameters = formTemplate12_data.serviceParameters || {};
            formTemplate12.customPopupData = formTemplate12_data.customPopupData || {
                "lblPopupMessage": "${i18n{i18n.common.LogoutMsg}}",
                "lblHeading": "${i18n{i18n.login.signOut}}",
                "btnNo": "${i18n{i18n.common.no}}",
                "btnYes": {
                    "btnYesValue": "$${i18n{i18n.common.yes}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                }
            };
            formTemplate12.dataFormatting = formTemplate12_data.dataFormatting || {};
            formTemplate12.dataMapping = formTemplate12_data.dataMapping || {};
            formTemplate12.conditionalMappingKey = formTemplate12_data.conditionalMappingKey || "";
            formTemplate12.conditionalMapping = formTemplate12_data.conditionalMapping || {};
            formTemplate12.pageTitle = formTemplate12_data.pageTitle || "Partial Repayment";
            formTemplate12.pageTitlei18n = formTemplate12_data.pageTitlei18n || "i18n.accounts.PartialRepayment";
            formTemplate12.primaryLinks = formTemplate12_data.primaryLinks || [{
                "title": "${i18n{i18n.topmenu.accounts}}",
                "toolTip": "${i18n{i18n.topmenu.accounts}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.topmenu.accounts}}"
                },
                "callToAction": {
                    "microApp": "HomepageMA",
                    "presentationControllerMethod": "showAccountsDashboard",
                    "moduleName": "AccountsUIModule"
                }
            }, {
                "id": "TRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "tooltip": "${i18n{i18n.billPay.BillPayMakeTransfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.billPay.BillPayMakeTransfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.hamburger.transferHistory}}",
                    "tooltip": "${i18n{i18n.hamburger.transferHistory}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transferHistory}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "recent"
                        }
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.hamburger.externalAccounts}}",
                    "tooltip": "${i18n{i18n.hamburger.externalAccounts}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.externalAccounts}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "externalAccounts"
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addInternalAccounts"
                        }
                    }
                }, {
                    "id": "Add Non Kony Accounts",
                    "title": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "tooltip": "${i18n{i18n.hamburger.addNonKonyAccount}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.addNonKonyAccount}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "initialView": "addExternalAccounts"
                        }
                    }
                }]
            }, {
                "id": "FASTTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.hamburger.transfers}}",
                "toolTip": "${i18n{i18n.hamburger.transfers}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.hamburger.transfers}}"
                },
                "visibleInMAs": ["REGIONALTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "P2P", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Transfer Money",
                    "title": "${i18n{i18n.hamburger.transfer}}",
                    "tooltip": "${i18n{i18n.hamburger.transfer}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.hamburger.transfer}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE", "P2P_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen"
                    }
                }, {
                    "id": "Transfer history",
                    "title": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "tooltip": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.Transfers.TRANSFERACTIVITIES}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "P2P_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "getPastPayments"
                    }
                }, {
                    "id": "External Accounts",
                    "title": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.ManageRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.ManageRecipient}}"
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTRA_BANK_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW_RECEPIENT", "P2P_VIEW_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showManageRecipients": true
                        }
                    }
                }, {
                    "id": "Add Infinity Accounts",
                    "title": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "tooltip": "${i18n{i18n.PayAPerson.AddRecipient}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.PayAPerson.AddRecipient}}"
                    },
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "INTRA_BANK_FUND_TRANSFER_CREATE_RECEPIENT", "INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE_RECEPIENT", "P2P_CREATE_RECEPIENT"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferFastUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "showRecipientGateway": true
                        }
                    }
                }]
            }, {
                "id": "EUROTRANSFERS",
                "fontIcon": "t",
                "title": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "toolTip": "${i18n{i18n.TransfersEur.PaymentsAndTransfers}}",
                "accessibilityConfig": {
                    "a11yHidden": true,
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "visibleInMAs": ["REGIONALTRANSFER", "UNIFIEDTRANSFER"],
                "featureAndPermissions": [{
                    "atLeastOneFeature": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER", "INTER_BANK_ACCOUNT_FUND_TRANSFER", "INTRA_BANK_FUND_TRANSFER", "TRANSFER_BETWEEN_OWN_ACCOUNT"]
                }],
                "subMenu": [{
                    "id": "Make a Payment",
                    "title": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "tooltip": "${i18n{i18n.TransfersEur.MakePayment}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_CREATE", "INTER_BANK_ACCOUNT_FUND_TRANSFER_CREATE", "INTRA_BANK_FUND_TRANSFER_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePayment"
                        }
                    }
                }, {
                    "id": "Transfer Between Accounts",
                    "title": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "tooltip": "${i18n{i18n.TransfersEur.TransferBetweenAccounts}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["TRANSFER_BETWEEN_OWN_ACCOUNT_CREATE"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "TransferEurUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "MakePaymentOwnAccounts"
                        }
                    }
                }, {
                    "id": "Manage Beneficiaries",
                    "title": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "ManageBeneficiaries"
                        }
                    }
                }, {
                    "id": "Manage Payments",
                    "title": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "tooltip": "${i18n{i18n.TransfersEur.ManageTransactions}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["UNIFIEDTRANSFER"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["INTERNATIONAL_ACCOUNT_FUND_TRANSFER_VIEW", "INTER_BANK_ACCOUNT_FUND_TRANSFER_VIEW", "INTRA_BANK_FUND_TRANSFER_VIEW", "TRANSFER_BETWEEN_OWN_ACCOUNT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "ManageActivitiesUIModule",
                        "presentationControllerMethod": "showTransferScreen",
                        "params": {
                            "context": "PastPayments"
                        }
                    }
                }, {
                    "id": "Pay Multiple Beneficiaries",
                    "title": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "tooltip": "${i18n{i18n.Transfers.PayMultipleBeneficiaries}}",
                    "accessibilityConfig": {
                        "a11yARIA": {
                            "tabindex": -1
                        }
                    },
                    "visibleInMAs": ["REGIONALTRANSFER"],
                    "callToAction": {
                        "microApp": "TransfersMA",
                        "moduleName": "PayMultipleBeneficiariesUIModule",
                        "presentationControllerMethod": "showPayMultipleBeneficiaries",
                        "params": {
                            "showManageBeneficiaries": true
                        }
                    }
                }]
            }];
            formTemplate12.flxMainWrapperzIndex = formTemplate12_data.flxMainWrapperzIndex || 2;
            formTemplate12.secondaryLinks = formTemplate12_data.secondaryLinks || [{
                "fontIcon": ")",
                "title": "${i18n{i18n.Alerts.Notifications}}",
                "toolTip": "${i18n{i18n.Alerts.Notifications}}",
                "notificationCount": 1,
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.Alerts.Notifications}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule",
                    "param": {
                        "show": "Messages"
                    }
                }
            }, {
                "fontIcon": "m",
                "title": "${i18n{i18n.AlertsAndMessages.Message}}",
                "toolTip": "${i18n{i18n.AlertsAndMessages.Message}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.AlertsAndMessages.Message}}"
                },
                "callToAction": {
                    "microApp": "SecureMessageMA",
                    "presentationControllerMethod": "showAlertsPage",
                    "moduleName": "AlertsMsgsUIModule"
                }
            }];
            formTemplate12.supplementaryLinks = formTemplate12_data.supplementaryLinks || [];
            formTemplate12.pageTitleVisibility = formTemplate12_data.pageTitleVisibility || true;
            formTemplate12.logoConfig = formTemplate12_data.logoConfig || {
                "loggedIn": {
                    "toolTip": "${i18n{kony.mb.MM.Dashboard}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{kony.mb.MM.Dashboard}}"
                    },
                    "callToAction": {
                        "microApp": "HomepageMA",
                        "presentationControllerMethod": "showAccountsDashboard",
                        "moduleName": "AccountsUIModule"
                    }
                },
                "loggedOut": {
                    "toolTip": "${i18n{i18n.common.login}}",
                    "accessibilityConfig": {
                        "a11yLabel": "${i18n{i18n.common.login}}"
                    },
                    "callToAction": {
                        "microApp": "AuthenticationMA",
                        "presentationControllerMethod": "showLoginScreen",
                        "moduleName": "AuthUIModule"
                    }
                }
            };
            formTemplate12.accountText = formTemplate12_data.accountText || "";
            formTemplate12.logoutConfig = formTemplate12_data.logoutConfig || {
                "title": "l",
                "toolTip": "${i18n{i18n.common.logout}}",
                "accessibilityConfig": {
                    "a11yLabel": "${i18n{i18n.common.logout}}"
                },
                "callToAction": {
                    "microApp": "AuthenticationMA",
                    "presentationControllerMethod": "doLogout",
                    "moduleName": "AuthUIModule",
                    "param": {
                        "action": "Logout"
                    }
                }
            };
            formTemplate12.profileConfig = formTemplate12_data.profileConfig || {
                "image": "profile_header.png",
                "profileImage": "",
                "profileUsername": "",
                "profileEmail": "",
                "toolTip": "profilePic",
                "accessibilityConfig": {
                    "a11yLabel": "profile",
                    "a11yARIA": {
                        "aria-expanded": false,
                        "tabindex": 0,
                        "role": "button"
                    }
                },
                "subMenu": [{
                    "id": "Profile Settings",
                    "title": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.profilesettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PROFILE_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "profileSettings"
                    }
                }, {
                    "id": "Security Settings",
                    "title": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.SecuritySettings}}",
                    "visibleInMAs": ["MANAGEPROFILE"],
                    "callToAction": {
                        "microApp": "ManageProfileMA",
                        "moduleName": "SettingsNewUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "securityQuestions"
                    }
                }, {
                    "id": "Account Settings",
                    "title": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "tooltip": "${i18n{i18n.Accounts.ContextualActions.updateSettingAndPreferences}}",
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ACCOUNT_SETTINGS_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ManageArrangementsMA",
                        "moduleName": "ManageArrangementsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "accountSettings"
                    }
                }, {
                    "id": "Approval Matrix",
                    "title": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "tooltip": "${i18n{i18n.Settings.ApprovalMatrix.approvalMatrix}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["APPROVALMATRIX"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["APPROVAL_MATRIX_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ApprovalMatrixMA",
                        "moduleName": "SettingsNewApprovalUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "approvalMatrix"
                    }
                }, {
                    "id": "Alert Settings",
                    "title": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Alerts}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["ALERTSETTINGS"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["ALERT_MANAGEMENT"]
                    }],
                    "callToAction": {
                        "microApp": "AlertSettingsMA",
                        "moduleName": "SettingsNewAlertsUIModule",
                        "presentationControllerMethod": "enterProfileSettings",
                        "params": "alertSettings"
                    }
                }, {
                    "id": "Consent Management",
                    "title": "${i18n{i18n.ProfileManagement.Consent}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.Consent}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["CDP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "CDPConsentUIModule",
                        "presentationControllerMethod": "showConsentManagement"
                    }
                }, {
                    "id": "Manage Account Access",
                    "title": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "tooltip": "${i18n{i18n.ProfileManagement.ManageAccountAccess}}",
                    "breakpoints": [1024, 1366, 1380],
                    "visibleInMAs": ["CONSENTMANAGEMENT"],
                    "featureAndPermissions": [{
                        "atLeastOneReqPermissions": ["PSD2_TPP_CONSENT_VIEW"]
                    }],
                    "callToAction": {
                        "microApp": "ConsentMgmtMA",
                        "moduleName": "PSD2ConsentUIModule",
                        "presentationControllerMethod": "showManageAccountAccess"
                    }
                }]
            };
            formTemplate12.activeMenuID = formTemplate12_data.activeMenuID || "";
            formTemplate12.activeSubMenuID = formTemplate12_data.activeSubMenuID || "";
            formTemplate12.backFlag = formTemplate12_data.backFlag || false;
            formTemplate12.hamburgerConfig = formTemplate12_data.hamburgerConfig || "HamburgerConfigWCAG.js";
            formTemplate12.backProperties = formTemplate12_data.backProperties || [{
                "btnBack": "${i18n{i18n.CardManagement.Back}}",
                "callToAction": {
                    "appName": "ResourcesMA",
                    "form": "frmStyleGuide",
                    "module": "",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.breadCrumbProperties = formTemplate12_data.breadCrumbProperties || [{
                "btnFirstLevel": "${CNTX.btnFirstLevel}",
                "btnFirstLevela11yLabel": "${CNTX.btnFirstLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnSecondLevel": "${CNTX.btnSecondLevel}",
                "btnSecondLevela11yLabel": "${CNTX.btnSecondLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }, {
                "btnThirdLevel": "${CNTX.btnThirdLevel}",
                "btnThirdLevela11yLabel": "${CNTX.btnThirdLevela11yLabel}",
                "callToAction": {
                    "appName": "ArrangementsMA",
                    "form": "frmAccountsDetails",
                    "module": "AccountsUIModule",
                    "presentationControllerMethod": "",
                    "params": []
                }
            }];
            formTemplate12.genricMessage = formTemplate12_data.genricMessage || {};
            formTemplate12.sessionTimeOutData = formTemplate12_data.sessionTimeOutData || {
                "lblPopupMessage": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessagea11yLabel": "${i18n{i18n.login.idleWarning}}",
                "lblPopupMessage2": "${i18n{i18n.login.signOutMin}}",
                "lblPopupMessage2a11yLabel": "${i18n{i18n.login.signOutMin}}",
                "lblHeading": "${i18n{i18n.login.idleSession}}",
                "lblHeadinga11yLabel": "${i18n{i18n.login.idleSession}}",
                "btnYes": "${i18n{i18n.login.idleExtend}}",
                "btnYesa11yLabel": "${i18n{i18n.login.idleExtend}}",
                "btnNo": {
                    "btnNoValue": "${i18n{i18n.login.signOut}}",
                    "btnNoa11yLabel": "${i18n{i18n.login.signOut}}",
                    "callToAction": {
                        "appName": "AuthenticationMA",
                        "form": "",
                        "module": "AuthUIModule",
                        "presentationControllerMethod": "doLogout",
                        "params": {
                            "action": "Logout"
                        }
                    }
                },
                "timer": "${CNTX.timer}"
            };
            formTemplate12.footerProperties = formTemplate12_data.footerProperties || [{
                "title": "${i18n{i18n.footer.locateUs}}",
                "a11yLabel": "${i18n{i18n.footer.locateUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "LocateUsUIModule",
                    "presentationControllerMethod": "showLocateUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.contactUs}}",
                "a11yLabel": "${i18n{i18n.footer.contactUs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showContactUsPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.privacy}}",
                "a11yLabel": "${i18n{i18n.footer.privacy}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "a11yLabel": "${i18n{i18n.ProfileManagement.TermsAndConditions}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showPrivacyPolicyPage",
                    "params": []
                }
            }, {
                "title": "${i18n{i18n.footer.faqs}}",
                "a11yLabel": "${i18n{i18n.footer.faqs}}",
                "callToAction": {
                    "appName": "AboutUsMA",
                    "form": "",
                    "module": "InformationContentUIModule",
                    "presentationControllerMethod": "showFAQs",
                    "params": []
                }
            }];
            formTemplate12.copyRight = formTemplate12_data.copyRight || {
                "title": "${i18n{i18n.footer.copyright}}"
            };
            var flxMainContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var lblError = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblError",
                "isVisible": true,
                "left": "0",
                "skin": "sknlblErrorEE0005SSP15px",
                "text": "Label",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError.add(lblError);
            var flxErrorContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "87dp",
                "id": "flxErrorContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorContainer.setDefaultUnit(kony.flex.DP);
            var flxErrorImage = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxErrorImage",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "top": "20dp",
                "width": "40dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorImage.setDefaultUnit(kony.flex.DP);
            var ErrorImg = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "40dp",
                "id": "ErrorImg",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "error_cross_1x.png",
                "top": "0",
                "width": "40dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorImage.add(ErrorImg);
            var lblErrorMsg = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblErrorMsg",
                "isVisible": true,
                "left": "75dp",
                "text": "We couldn't complete the payment",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblErrorMsg1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "10dp",
                "id": "lblErrorMsg1",
                "isVisible": true,
                "left": "75dp",
                "skin": "sknSSP72727213Px",
                "text": "Your account has insufficient Balance. Try again with another account",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxErrorClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxErrorClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "20dp",
                "top": "15dp",
                "width": "30dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxErrorClose.setDefaultUnit(kony.flex.DP);
            var lblErrorClose = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblErrorClose",
                "isVisible": true,
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxErrorClose.add(lblErrorClose);
            flxErrorContainer.add(flxErrorImage, lblErrorMsg, lblErrorMsg1, flxErrorClose);
            var flxFacilityDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "id": "flxFacilityDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityDetails.setDefaultUnit(kony.flex.DP);
            var flxFacilityHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "id": "flxFacilityHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityHeader.setDefaultUnit(kony.flex.DP);
            var lblFacilityDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblFacilityDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.displayMortgageFacilityDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 30,
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            var flxFacilityContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "id": "flxFacilityContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "50",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFacilityContent.setDefaultUnit(kony.flex.DP);
            var lblFacilityName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFacilityName",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.faciltyNameWithColon\")",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFacilityNameVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFacilityNameVal",
                "isVisible": true,
                "left": "255dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "Mortgage Facility Account - 1234 ",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoans = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoOfLoans",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.NoOfLoansWithColon\")",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNoOfLoansVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNoOfLoansVal",
                "isVisible": true,
                "left": "255dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "2",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBal",
                "isVisible": true,
                "left": "55%",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.outstandingBalanceWithColon\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOutstandingBalVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOutstandingBalVal",
                "isVisible": true,
                "left": "75%",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "$38,000.00",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountPaidToDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAmountPaidToDate",
                "isVisible": true,
                "left": "55%",
                "skin": "ICSknLblSSP72727213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.amountPaidtoDate\")",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAmountPaidToDateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAmountPaidToDateVal",
                "isVisible": true,
                "left": "75%",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "$3255.00",
                "top": "60dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFacilityContent.add(lblFacilityName, lblFacilityNameVal, lblNoOfLoans, lblNoOfLoansVal, lblOutstandingBal, lblOutstandingBalVal, lblAmountPaidToDate, lblAmountPaidToDateVal);
            flxFacilityHeader.add(lblFacilityDetails, flxSeparator, flxFacilityContent);
            flxFacilityDetails.add(flxFacilityHeader);
            var flxPrimaryLoanDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "235dp",
                "id": "flxPrimaryLoanDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryLoanDetails.setDefaultUnit(kony.flex.DP);
            var flxPrimaryLoanHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPrimaryLoanHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryLoanHeader.setDefaultUnit(kony.flex.DP);
            var lblPrimaryLoanDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblPrimaryLoanDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.mb.loans.LoanDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "49dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator1.setDefaultUnit(kony.flex.DP);
            flxSeparator1.add();
            var flxPrimaryLoanAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxPrimaryLoanAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxfbfbfb",
                "top": 50,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPrimaryLoanAccount.setDefaultUnit(kony.flex.DP);
            var lblPrimaryLoanAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h3"
                },
                "id": "lblPrimaryLoanAccount",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "Primary Loan Account Name-8760",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparatorLine = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparatorLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "38dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparatorLine.setDefaultUnit(kony.flex.DP);
            flxSeparatorLine.add();
            flxPrimaryLoanAccount.add(lblPrimaryLoanAccount, flxSeparatorLine);
            var flxLoanDetailsContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "120dp",
                "id": "flxLoanDetailsContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": 90,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoanDetailsContent.setDefaultUnit(kony.flex.DP);
            var flxValues = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxValues",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxValues.setDefaultUnit(kony.flex.DP);
            var lblCurrentValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "25dp",
                "id": "lblCurrentValue",
                "isVisible": true,
                "left": "240dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.CurrentValue\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSimulatedValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "25dp",
                "id": "lblSimulatedValue",
                "isVisible": true,
                "left": "500dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.SimulatedValue\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxValues.add(lblCurrentValue, lblSimulatedValue);
            var lblInstalAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblInstalAmount",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbsknA0A0A015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.installmentAmountWithcolon\")",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInstalAmountVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblInstalAmountVal",
                "isVisible": true,
                "left": "240dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$3000",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInstalAmountValAccessibility = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblInstalAmountValAccessibility",
                "isVisible": true,
                "left": "265dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$3000",
                "top": "55dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInstalAmountVal1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblInstalAmountVal1",
                "isVisible": true,
                "left": "500dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$3000",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInstalAmountVal1Accessibility = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblInstalAmountVal1Accessibility",
                "isVisible": true,
                "left": "65%",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "$3000",
                "top": "55dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNextRepayDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNextRepayDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbsknA0A0A015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.nextRepaymentDateWithColon\")",
                "top": "80dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepayDateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblRepayDateVal",
                "isVisible": true,
                "left": "240dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "31/11/2011",
                "top": "80dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepayDateValAccessibility = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblRepayDateValAccessibility",
                "isVisible": true,
                "left": "265dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/11/2011",
                "top": "90dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepayDateVal1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblRepayDateVal1",
                "isVisible": true,
                "left": "500dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/11/2011",
                "top": "80dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRepayDateVal1Accessibility = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblRepayDateVal1Accessibility",
                "isVisible": true,
                "left": "65%",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/11/2011",
                "top": "90dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEndDate = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblEndDate",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbsknA0A0A015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.endDateWithColon\")",
                "top": "115dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEndDateVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblEndDateVal",
                "isVisible": true,
                "left": "240dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "31/11/2011",
                "top": "115dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEndDateValAccessibility = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblEndDateValAccessibility",
                "isVisible": true,
                "left": "265dp",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/11/2011",
                "top": "125dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEndDateVal1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblEndDateVal1",
                "isVisible": true,
                "left": "500dp",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "31/11/2011",
                "top": "115dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEndDateVal1Accessibility = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "0dp",
                "id": "lblEndDateVal1Accessibility",
                "isVisible": true,
                "left": "65%",
                "skin": "ICSknBBLabelSSP42424215px",
                "text": "31/11/2011",
                "top": "125dp",
                "width": "0dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInstalAmount1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblInstalAmount1",
                "isVisible": false,
                "left": "30dp",
                "skin": "ICSknLblSSP72727213px",
                "text": "Installment Amount :",
                "top": "45dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNextRepayDate1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblNextRepayDate1",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727213px",
                "text": "Next Repaymnet Date :",
                "top": "80dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEndDate1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblEndDate1",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknLblSSP72727213px",
                "text": "End Date (Maturity Date) :",
                "top": "115dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator5 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator5",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "199dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator5.setDefaultUnit(kony.flex.DP);
            flxSeparator5.add();
            flxLoanDetailsContent.add(flxValues, lblInstalAmount, lblInstalAmountVal, lblInstalAmountValAccessibility, lblInstalAmountVal1, lblInstalAmountVal1Accessibility, lblNextRepayDate, lblRepayDateVal, lblRepayDateValAccessibility, lblRepayDateVal1, lblRepayDateVal1Accessibility, lblEndDate, lblEndDateVal, lblEndDateValAccessibility, lblEndDateVal1, lblEndDateVal1Accessibility, lblInstalAmount1, lblNextRepayDate1, lblEndDate1, flxSeparator5);
            flxPrimaryLoanHeader.add(lblPrimaryLoanDetails, flxSeparator1, flxPrimaryLoanAccount, flxLoanDetailsContent);
            flxPrimaryLoanDetails.add(flxPrimaryLoanHeader);
            var flxPaymentDetailsContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentDetailsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowdddcdc",
                "top": "20dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsContainer.setDefaultUnit(kony.flex.DP);
            var flxPaymentDetailsHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPaymentDetailsHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsHeader.setDefaultUnit(kony.flex.DP);
            var lblPaymentDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "id": "lblPaymentDetails",
                "isVisible": true,
                "left": "30dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.TradeFinance.PaymentDetails\")",
                "top": "19dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblSeparator1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "bottom": 0,
                "height": "1dp",
                "id": "lblSeparator1",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsHeader.add(lblPaymentDetails, lblSeparator1);
            var flxPaymentDetailsContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentDetailsContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "50dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsContent.setDefaultUnit(kony.flex.DP);
            var flxPaymentDetailsContainer1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentDetailsContainer1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsContainer1.setDefaultUnit(kony.flex.DP);
            var lblTotalRepaymentAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTotalRepaymentAmount",
                "isVisible": true,
                "left": "30dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.totalRepaymentWithColon\")",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblTotalRepaymentAmountVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblTotalRepaymentAmountVal",
                "isVisible": true,
                "left": "65dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Label",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoanAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLoanAccount",
                "isVisible": true,
                "left": "-260dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.LoanAccount\")",
                "top": "40dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLoanAccountVal = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblLoanAccountVal",
                "isVisible": true,
                "left": "140dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "**********8244",
                "top": "40dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblShowIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblShowIcon",
                "isVisible": true,
                "left": "380dp",
                "skin": "bbSknLblFontIcon",
                "text": "h",
                "top": "43dp",
                "width": "20dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsContainer1.add(lblTotalRepaymentAmount, lblTotalRepaymentAmountVal, lblLoanAccount, lblLoanAccountVal, lblShowIcon);
            var flxPaymentDetailsContainer2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "30dp",
                "id": "flxPaymentDetailsContainer2",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "30dp",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsContainer2.setDefaultUnit(kony.flex.DP);
            var lblSelectAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSelectAccount",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.SelectAccount\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAccountGrouping = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblSelectAccount",
                        "role": "radiogroup",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountGrouping",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountGrouping.setDefaultUnit(kony.flex.DP);
            var imgRad = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-checked": "true",
                        "aria-labelledby": "lblOwnAccount",
                        "role": "radio",
                        "tabindex": 0
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "imgRad",
                "isVisible": true,
                "left": "130dp",
                "skin": "sknRadioselectedFonticon",
                "text": "M",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOwnAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblOwnAccount",
                "isVisible": true,
                "left": "6dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.OwnAccount\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgRad1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblAccountOtherBank",
                        "role": "radio",
                        "tabindex": 0
                    },
                    "tagName": "span"
                },
                "id": "imgRad1",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknRadioselectedFonticon",
                "text": "L",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccountOtherBank = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAccountOtherBank",
                "isVisible": true,
                "left": "6dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.AccountWithOtherBank\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccountGrouping.add(imgRad, lblOwnAccount, imgRad1, lblAccountOtherBank);
            flxPaymentDetailsContainer2.add(lblSelectAccount, flxAccountGrouping);
            var flxPaymentDetailsContainer3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPaymentDetailsContainer3",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "30dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDetailsContainer3.setDefaultUnit(kony.flex.DP);
            var lblFromAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFromAccount",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.FromAccount\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFromAccount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "40dp",
                "id": "flxFromAccount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "slFboxmb",
                "top": "8dp",
                "width": "560dp",
                "zIndex": 5,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromAccount.setDefaultUnit(kony.flex.DP);
            var tbxFromAccount = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "both",
                        "aria-labelledby": "lblFromAccount",
                        "role": "textbox",
                        "tabindex": 0
                    },
                    "a11yLabel": "From account. Click to select an account."
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "100%",
                "id": "tbxFromAccount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.accounts.SearchByAccountNumberOrIBAN\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            var lblAccountBalance = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblAccountBalance",
                "isVisible": true,
                "right": "15dp",
                "skin": "bbSknLbl727272SSP15Px",
                "text": "$5000.00",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromAccount.add(tbxFromAccount, lblAccountBalance);
            var flxSegAccountsContainer = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "220dp",
                "horizontalScrollIndicator": true,
                "id": "flxSegAccountsContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknFlx464545Rds3Px",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "51%",
                "zIndex": 5
            }, {
                "paddingInPixel": false
            }, {});
            flxSegAccountsContainer.setDefaultUnit(kony.flex.DP);
            var segAccounts = new kony.ui.SegmentedUI2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Primary Loan-8760"
                        },
                        [{}]
                    ],
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "Secondary Loan -1211"
                        },
                        [{}]
                    ],
                    [{
                            "imgDropDown": "",
                            "lblSeparator": "",
                            "lblTopSeparator": "",
                            "lblTransactionHeader": "New Loan -1234"
                        },
                        [{}]
                    ]
                ],
                "groupCells": false,
                "id": "segAccounts",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxAccountsListCustomView"
                }),
                "sectionHeaderTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ACHMA",
                    "friendlyName": "flxTransfersFromListHeader"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "1dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxNoResult = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNoResult",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "1dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoResult.setDefaultUnit(kony.flex.DP);
            var lblNoResult = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblNoResult",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.maps.NoResultsFound\")",
                "top": "100dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoResult.add(lblNoResult);
            flxSegAccountsContainer.add(segAccounts, flxNoResult);
            var lblPayOn = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPayOn",
                "isVisible": true,
                "left": "0",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.payOnWithColon\")",
                "top": "28dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var CalPayOn = new kony.ui.Calendar({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPayOn",
                        "tabindex": 0
                    }
                },
                "calendarIcon": "calendar_2.png",
                "dateComponents": [null, null, null],
                "dateFormat": "MM/dd/yyyy",
                "height": "40dp",
                "hour": 0,
                "id": "CalPayOn",
                "isVisible": true,
                "left": "0",
                "minutes": 0,
                "placeholder": "Enter Text Here",
                "seconds": 0,
                "skin": "sknCalNormal",
                "top": "8dp",
                "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
                "width": "25%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "noOfMonths": 1
            });
            var flxSeperator1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeperator1",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "right": "30dp",
                "skin": "bbSknFlxSeperatore3e3e3",
                "top": "15dp",
                "width": "94%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator1.setDefaultUnit(kony.flex.DP);
            flxSeperator1.add();
            var lblNote = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNote",
                "isVisible": true,
                "left": "0dp",
                "skin": "bbSknLbl727272SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.NoteOptional\")",
                "top": "15dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxNote = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-labelledby": "lblNote",
                        "tabindex": 0
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "tbxNote",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "maxTextLength": 140,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.accounts.EnterNotes\")",
                "secureTextEntry": false,
                "skin": "ICSknTxtE3E3E3Border1px424242SSPRegular15px",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "8dp",
                "width": "51%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxPaymentDetailsContainer3.add(lblFromAccount, flxFromAccount, flxSegAccountsContainer, lblPayOn, CalPayOn, flxSeperator1, lblNote, tbxNote);
            var flxDocumentContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDocumentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDocumentContainer.setDefaultUnit(kony.flex.DP);
            var flxSuppDocContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxSuppDocContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuppDocContainer.setDefaultUnit(kony.flex.DP);
            var lblSupportingDocuments = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSupportingDocuments",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknlbl424242SSP15pxSemibold",
                "text": "Supporting Documents (Optional)",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgSupportInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Read more information about attaching supporting documents"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxImgSupportInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10dp",
                "isModalContainer": false,
                "right": "0",
                "skin": "sknFlxffffffShadowd464545",
                "top": "10dp",
                "width": "20dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImgSupportInfo.setDefaultUnit(kony.flex.DP);
            var imgSuppInfoIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "a11yLabel": "Read more information about Supporting Documents"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "15dp",
                "id": "imgSuppInfoIcon",
                "isVisible": true,
                "left": "0dp",
                "src": "info_grey.png",
                "top": "0dp",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgSupportInfo.add(imgSuppInfoIcon);
            flxSuppDocContainer.add(lblSupportingDocuments, flxImgSupportInfo);
            var flxSuppDocInfo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "dialog",
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "85dp",
                "id": "flxSuppDocInfo",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "250dp",
                "isModalContainer": false,
                "skin": "sknFlxffffffShadowd464545",
                "top": "0dp",
                "width": "300dp",
                "zIndex": 10,
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuppDocInfo.setDefaultUnit(kony.flex.DP);
            var lblAttachmentRules = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAttachmentRules",
                "isVisible": true,
                "left": 5,
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.UnifiedTransfer.attachmentRules\")",
                "top": "5dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxClose = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Close this information pop-up"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknFlxffffffShadowd464545",
                "top": "0",
                "width": "25dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxClose.setDefaultUnit(kony.flex.DP);
            var lblClose = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "label"
                },
                "id": "lblClose",
                "isVisible": true,
                "right": "11dp",
                "skin": "sknOLBFonts003e7512px",
                "text": "g",
                "top": 15,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(lblClose);
            var lblSuppDocInfo = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "height": "55dp",
                "id": "lblSuppDocInfo",
                "isVisible": true,
                "left": 5,
                "skin": "ICSknBBLabelSSP42424213px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.LargeAttachmentRules\")",
                "top": 25,
                "width": "280dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSuppDocInfo.add(lblAttachmentRules, flxClose, lblSuppDocInfo);
            var uploadFiles3 = new com.InfinityOLB.ArrangementsMA.uploadFiles3({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "uploadFiles3",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "35dp",
                "width": "100%",
                "appName": "ArrangementsMA",
                "viewType": "uploadFiles3",
                "overrides": {
                    "uploadFiles3": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "height": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var uploadFiles3_data = (appConfig.componentMetadata && appConfig.componentMetadata["ArrangementsMA"] && appConfig.componentMetadata["ArrangementsMA"]["frmPartialRepaymentPaymentDetails"] && appConfig.componentMetadata["ArrangementsMA"]["frmPartialRepaymentPaymentDetails"]["uploadFiles3"]) || {};
            uploadFiles3.inErrorState = uploadFiles3_data.inErrorState || false;
            uploadFiles3.maxFilesCount = uploadFiles3_data.maxFilesCount || 5;
            uploadFiles3.aaa = uploadFiles3_data.aaa || true;
            flxDocumentContainer.add(flxSuppDocContainer, flxSuppDocInfo, uploadFiles3);
            var lblSeparator2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "height": "1dp",
                "id": "lblSeparator2",
                "isVisible": true,
                "left": "0dp",
                "right": "0dp",
                "skin": "sknSeparatore3e3e3",
                "text": "Label",
                "top": "10dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "80dp",
                "id": "flxButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFboxffffff",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Continue to Confirmation"
                },
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "text": "Continue",
                "top": "20dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Back to partial repayment simulation"
                },
                "height": "40dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "text": "Back",
                "top": "20dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Cancel partial repayment"
                },
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "360dp",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "text": "Cancel",
                "top": "20dp",
                "width": "150dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(btnContinue, btnBack, btnCancel);
            flxPaymentDetailsContent.add(flxPaymentDetailsContainer1, flxPaymentDetailsContainer2, flxPaymentDetailsContainer3, flxDocumentContainer, lblSeparator2, flxButtons);
            flxPaymentDetailsContainer.add(flxPaymentDetailsHeader, flxPaymentDetailsContent);
            flxMainContent.add(flxError, flxErrorContainer, flxFacilityDetails, flxPrimaryLoanDetails, flxPaymentDetailsContainer);
            formTemplate12.flxContentTCCenter.add(flxMainContent);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "formTemplate12": {
                        "breadCrumbBackFlag": false,
                        "flag": false,
                        "segmentProps": []
                    },
                    "flxError": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "lblError": {
                        "top": {
                            "type": "string",
                            "value": "-12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "80%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxError"]
                    },
                    "flxErrorContainer": {
                        "height": {
                            "type": "string",
                            "value": "100px"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxErrorImage": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxErrorContainer"]
                    },
                    "lblErrorMsg": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "56dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "width": {
                            "type": "string",
                            "value": "76%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxErrorContainer"]
                    },
                    "lblErrorMsg1": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "57dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxErrorContainer"]
                    },
                    "lblErrorClose": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxErrorContainer", "flxErrorClose"]
                    },
                    "flxFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "285dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxFacilityHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails"]
                    },
                    "lblFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "49dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "235dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDate": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "165dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDateVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "185dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "flxPrimaryLoanDetails": {
                        "height": {
                            "type": "string",
                            "value": "475dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxPrimaryLoanHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails"]
                    },
                    "lblPrimaryLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "flxSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "lblPrimaryLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxPrimaryLoanAccount"]
                    },
                    "flxSeparatorLine": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxPrimaryLoanAccount"]
                    },
                    "flxLoanDetailsContent": {
                        "height": {
                            "type": "string",
                            "value": "390dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "lblCurrentValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent", "flxValues"]
                    },
                    "lblSimulatedValue": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "210dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent", "flxValues"]
                    },
                    "lblInstalAmount": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "65dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal1": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal1Accessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblNextRepayDate": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "95dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "115dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal1": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "305dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal1Accessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDate": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "145dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "165dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal1": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "top": {
                            "type": "string",
                            "value": "350dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal1Accessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmount1": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "240dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblNextRepayDate1": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "285dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDate1": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "330dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "flxSeparator5": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "text": "Payment Details",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsHeader"]
                    },
                    "lblSeparator1": {
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentDetailsContainer1": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblTotalRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Total Repayment Amount :",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblTotalRepaymentAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "text": "$32000",
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Loan Account :",
                        "top": {
                            "type": "string",
                            "value": "14dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblLoanAccountVal": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "top": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblShowIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "flxPaymentDetailsContainer2": {
                        "height": {
                            "type": "string",
                            "value": "90dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblSelectAccount": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Select Account :",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2"]
                    },
                    "imgRad": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "lblOwnAccount": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Own Account",
                        "top": {
                            "type": "string",
                            "value": "-23dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "imgRad1": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "lblAccountOtherBank": {
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Account With Other Bank",
                        "top": {
                            "type": "string",
                            "value": "-20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "flxPaymentDetailsContainer3": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblFromAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxFromAccount": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "zIndex": 6,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "tbxFromAccount": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "86%"
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxFromAccount"]
                    },
                    "lblAccountBalance": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxFromAccount"]
                    },
                    "flxSegAccountsContainer": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "zIndex": 6,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxNoResult": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxSegAccountsContainer"]
                    },
                    "lblNoResult": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxSegAccountsContainer", "flxNoResult"]
                    },
                    "lblPayOn": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Pay On :",
                        "top": {
                            "type": "string",
                            "value": "43dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "CalPayOn": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "padding": [5, 0, 1, 0],
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxSeperator1": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "lblNote": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "tbxNote": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxSuppDocContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer"]
                    },
                    "lblSupportingDocuments": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocContainer"]
                    },
                    "imgSuppInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocContainer", "flxImgSupportInfo"]
                    },
                    "flxSuppDocInfo": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer"]
                    },
                    "lblAttachmentRules": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "flxClose": {
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "lblClose": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo", "flxClose"]
                    },
                    "uploadFiles3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer"]
                    },
                    "lblSeparator2": {
                        "isVisible": true,
                        "text": "",
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "layoutType": kony.flex.FREE_FORM,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "reverseLayoutDirection": true,
                        "skin": "slFboxffffff",
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "bottom": {
                            "type": "number",
                            "value": "140"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "Continue",
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "bottom": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "formTemplate12": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContent": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    },
                    "flxError": {
                        "top": {
                            "type": "number",
                            "value": "0"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "lblError": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxError"]
                    },
                    "flxErrorContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxErrorImage": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxErrorContainer"]
                    },
                    "ErrorImg": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxErrorContainer", "flxErrorImage"]
                    },
                    "lblErrorMsg": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxErrorContainer"]
                    },
                    "lblErrorMsg1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxErrorContainer"]
                    },
                    "lblErrorClose": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxErrorContainer", "flxErrorClose"]
                    },
                    "flxFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "230dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxFacilityHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails"]
                    },
                    "lblFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "180dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "left": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Outstanding Balance :",
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDate": {
                        "left": {
                            "type": "string",
                            "value": "23dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDateVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "140dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "flxPrimaryLoanDetails": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxPrimaryLoanHeader": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails"]
                    },
                    "lblPrimaryLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "flxSeparator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "flxPrimaryLoanAccount": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "lblPrimaryLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxPrimaryLoanAccount"]
                    },
                    "flxSeparatorLine": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxPrimaryLoanAccount"]
                    },
                    "flxLoanDetailsContent": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "flxValues": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblCurrentValue": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent", "flxValues"]
                    },
                    "lblSimulatedValue": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent", "flxValues"]
                    },
                    "lblInstalAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal1": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal1Accessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblNextRepayDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal1Accessibility": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateValAccessibility": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal1Accessibility": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmount1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblNextRepayDate1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDate1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "flxSeparator5": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "flxPaymentDetailsContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxPaymentDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer"]
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Payment Details",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsHeader"]
                    },
                    "lblSeparator1": {
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentDetailsContent": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer"]
                    },
                    "flxPaymentDetailsContainer1": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblTotalRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Total Repayment Amount :",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblTotalRepaymentAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "text": "$3200",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Loan Account :",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblLoanAccountVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "flxPaymentDetailsContainer2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblSelectAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Select Account :",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2"]
                    },
                    "imgRad": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "lblOwnAccount": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "skin": "ICSknLblSSP72727215px",
                        "text": "Own Account ",
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "imgRad1": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "aria-checked": "false",
                                "aria-labelledby": "lblAccountOtherBank",
                                "role": "radio",
                                "tabindex": 0
                            },
                            "tagName": "span"
                        },
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "lblAccountOtherBank": {
                        "skin": "ICSknLblSSP72727215px",
                        "text": "Account With Other Bank",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "flxPaymentDetailsContainer3": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblFromAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxFromAccount": {
                        "accessibilityConfig": {
                            "a11yARIA": {
                                "aria-expanded": "false",
                                "tabindex": -1
                            }
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "tbxFromAccount": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "90%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "98%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxFromAccount"]
                    },
                    "lblAccountBalance": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxFromAccount"]
                    },
                    "flxSegAccountsContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "segAccounts": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxSegAccountsContainer"]
                    },
                    "flxNoResult": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxSegAccountsContainer"]
                    },
                    "lblNoResult": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxSegAccountsContainer", "flxNoResult"]
                    },
                    "lblPayOn": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Pay On :",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "CalPayOn": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "padding": [2, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "47%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxSeperator1": {
                        "isVisible": true,
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "lblNote": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "tbxNote": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "padding": [2, 0, 0, 0],
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "94%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxDocumentContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "flxSuppDocContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer"]
                    },
                    "lblSupportingDocuments": {
                        "skin": "bbSknLbl42424215pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocContainer"]
                    },
                    "flxImgSupportInfo": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocContainer"]
                    },
                    "imgSuppInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocContainer", "flxImgSupportInfo"]
                    },
                    "flxSuppDocInfo": {
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer"]
                    },
                    "lblAttachmentRules": {
                        "i18n_text": "i18n.UnifiedTransfer.attachmentRules",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "flxClose": {
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "lblClose": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo", "flxClose"]
                    },
                    "lblSuppDocInfo": {
                        "i18n_text": "i18n.accounts.LargeAttachmentRules",
                        "isVisible": true,
                        "skin": "ICSknBBLabelSSP42424213px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "uploadFiles3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer"]
                    },
                    "lblSeparator2": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "bottom": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "formTemplate12": {
                        "backProperties": "{}",
                        "segmentProps": []
                    },
                    "flxMainContent": {
                        "width": {
                            "type": "string",
                            "value": "101.30%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter"]
                    },
                    "flxFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxFacilityHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails"]
                    },
                    "lblFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDate": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDateVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "flxPrimaryLoanDetails": {
                        "height": {
                            "type": "string",
                            "value": "245dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "lblPrimaryLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "flxPrimaryLoanAccount": {
                        "skin": "sknFlxfbfbfb",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "lblPrimaryLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxPrimaryLoanAccount"]
                    },
                    "lblCurrentValue": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent", "flxValues"]
                    },
                    "lblSimulatedValue": {
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent", "flxValues"]
                    },
                    "lblInstalAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal1": {
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal1Accessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblNextRepayDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal1": {
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal1Accessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal1": {
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal1Accessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmount1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblNextRepayDate1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDate1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "flxSeparator5": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "flxPaymentDetailsContainer": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxPaymentDetailsHeader": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer"]
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Payment Details",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsHeader"]
                    },
                    "lblSeparator1": {
                        "skin": "sknSeparatore3e3e3",
                        "text": "",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentDetailsContent": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer"]
                    },
                    "flxPaymentDetailsContainer1": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblTotalRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Total Repayment Amount :",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblTotalRepaymentAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "text": "$25000.00",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Loan Account :",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblLoanAccountVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblShowIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "flxPaymentDetailsContainer2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblSelectAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Select Account :",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2"]
                    },
                    "imgRad": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "lblOwnAccount": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Own Account",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "imgRad1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "lblAccountOtherBank": {
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Account With Other Bank",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "flxPaymentDetailsContainer3": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblFromAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxFromAccount": {
                        "height": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "567dp"
                        },
                        "zIndex": 6,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "tbxFromAccount": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "placeholder": "Search by account number or IBAN",
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxFromAccount"]
                    },
                    "lblAccountBalance": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxFromAccount"]
                    },
                    "flxSegAccountsContainer": {
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "skin": "ICSknFlx464545Rds3Px",
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "zIndex": 6,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "segAccounts": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxSegAccountsContainer"]
                    },
                    "flxNoResult": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxSegAccountsContainer"]
                    },
                    "lblNoResult": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxSegAccountsContainer", "flxNoResult"]
                    },
                    "lblPayOn": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Pay On :",
                        "top": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "CalPayOn": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "padding": [1, 0, 0, 0],
                        "skin": "sknCalNormal",
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxSeperator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "lblNote": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "tbxNote": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "padding": [1, 0, 0, 0],
                        "placeholder": "Enter notes",
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxDocumentContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblSupportingDocuments": {
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocContainer"]
                    },
                    "imgSuppInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocContainer", "flxImgSupportInfo"]
                    },
                    "flxSuppDocInfo": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "24dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer"]
                    },
                    "lblAttachmentRules": {
                        "skin": "bbSknLbl424242SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "flxClose": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "lblClose": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "height": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknOLBFonts003e7512px",
                        "top": {
                            "type": "number",
                            "value": "5"
                        },
                        "width": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo", "flxClose"]
                    },
                    "lblSuppDocInfo": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "ICSknBBLabelSSP42424213px",
                        "zIndex": 1,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "uploadFiles3": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer"]
                    },
                    "lblSeparator2": {
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxFacilityDetails": {
                        "height": {
                            "type": "string",
                            "value": "155dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxFacilityHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails"]
                    },
                    "lblFacilityDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxSeparator": {
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "right": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "flxFacilityContent": {
                        "height": {
                            "type": "string",
                            "value": "105dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader"]
                    },
                    "lblFacilityName": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblFacilityNameVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoans": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblNoOfLoansVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBal": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblOutstandingBalVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDate": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "lblAmountPaidToDateVal": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxFacilityDetails", "flxFacilityHeader", "flxFacilityContent"]
                    },
                    "flxPrimaryLoanDetails": {
                        "height": {
                            "type": "string",
                            "value": "245dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "lblPrimaryLoanDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "flxPrimaryLoanAccount": {
                        "skin": "sknFlxfbfbfb",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader"]
                    },
                    "lblPrimaryLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxPrimaryLoanAccount"]
                    },
                    "lblCurrentValue": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent", "flxValues"]
                    },
                    "lblSimulatedValue": {
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent", "flxValues"]
                    },
                    "lblInstalAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal1": {
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmountVal1Accessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblNextRepayDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal1": {
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblRepayDateVal1Accessibility": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDate": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateValAccessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal1": {
                        "left": {
                            "type": "string",
                            "value": "55%"
                        },
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDateVal1Accessibility": {
                        "skin": "ICSknBBLabelSSP42424215px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblInstalAmount1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblNextRepayDate1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "lblEndDate1": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "flxSeparator5": {
                        "isVisible": false,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPrimaryLoanDetails", "flxPrimaryLoanHeader", "flxLoanDetailsContent"]
                    },
                    "flxPaymentDetailsContainer": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent"]
                    },
                    "flxPaymentDetailsHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "number",
                            "value": "0"
                        },
                        "skin": "s1bb24340a974e98987aa24654a27407",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer"]
                    },
                    "lblPaymentDetails": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "text": "Payment Details ",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsHeader"]
                    },
                    "lblSeparator1": {
                        "skin": "sknSeparatore3e3e3",
                        "text": "Label",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsHeader"]
                    },
                    "flxPaymentDetailsContainer1": {
                        "layoutType": kony.flex.FREE_FORM,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblTotalRepaymentAmount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Total Repayment Amount:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblTotalRepaymentAmountVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "text": "$112.00",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblLoanAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Loan Account:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblLoanAccountVal": {
                        "left": {
                            "type": "string",
                            "value": "255dp"
                        },
                        "skin": "ICSknlbl424242SSP15pxSemibold",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "lblShowIcon": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "text": "h",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer1"]
                    },
                    "flxPaymentDetailsContainer2": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblSelectAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Select Account:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2"]
                    },
                    "imgRad": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "lblOwnAccount": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Own Account",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "imgRad1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "lblAccountOtherBank": {
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Account With Other Bank",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer2", "flxAccountGrouping"]
                    },
                    "flxPaymentDetailsContainer3": {
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent"]
                    },
                    "lblFromAccount": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxFromAccount": {
                        "height": {
                            "type": "string",
                            "value": "47dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "567dp"
                        },
                        "zIndex": 6,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "tbxFromAccount": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "40dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxFromAccount"]
                    },
                    "lblAccountBalance": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxFromAccount"]
                    },
                    "flxSegAccountsContainer": {
                        "left": {
                            "type": "string",
                            "value": "21dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "zIndex": 6,
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxNoResult": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxSegAccountsContainer"]
                    },
                    "lblNoResult": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3", "flxSegAccountsContainer", "flxNoResult"]
                    },
                    "lblPayOn": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "text": "Pay On:",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "CalPayOn": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "padding": [1, 0, 0, 0],
                        "skin": "sknCalNormal",
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "flxSeperator1": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "lblNote": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "skin": "bbSknLbl727272SSP15Px",
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "tbxNote": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "padding": [1, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "560dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxPaymentDetailsContainer3"]
                    },
                    "lblSupportingDocuments": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocContainer"]
                    },
                    "imgSuppInfoIcon": {
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocContainer", "flxImgSupportInfo"]
                    },
                    "flxSuppDocInfo": {
                        "height": {
                            "type": "string",
                            "value": "100dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "260dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer"]
                    },
                    "flxClose": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "25dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "lblClose": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo", "flxClose"]
                    },
                    "lblSuppDocInfo": {
                        "height": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": [],
                        "parentWgtAccessPath": ["formTemplate12", "flxContentTCCenter", "flxMainContent", "flxPaymentDetailsContainer", "flxPaymentDetailsContent", "flxDocumentContainer", "flxSuppDocInfo"]
                    },
                    "lblSeparator2": {
                        "skin": "sknSeparatore3e3e3",
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "right": {
                            "type": "string",
                            "value": "190dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "btnCancel": {
                        "right": {
                            "type": "string",
                            "value": "360dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "formTemplate12": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "formTemplate12.flxContentTCCenter.flxMainContent.flxPaymentDetailsContainer.flxPaymentDetailsContent.flxDocumentContainer.uploadFiles3": {
                    "right": "",
                    "bottom": "",
                    "height": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                }
            }
            this.add(formTemplate12);
        };
        return [{
            "addWidgets": addWidgetsfrmPartialRepaymentPaymentDetails,
            "enabledForIdleTimeout": false,
            "id": "frmPartialRepaymentPaymentDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_bce93c3c54e34c4896d7fab186ceeddd,
            "preShow": function(eventobject) {
                controller.AS_Form_e6d0a167d8eb490e85aec94b32fd5d4d(eventobject);
                kony.visualizer.syncComponentInstanceDataCache(eventobject);
            },
            "skin": "slForm",
            "title": "Partial Repayment",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});