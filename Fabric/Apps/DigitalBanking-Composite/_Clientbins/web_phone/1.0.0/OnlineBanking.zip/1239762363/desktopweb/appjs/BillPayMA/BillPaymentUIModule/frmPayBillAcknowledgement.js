define("BillPayMA/BillPaymentUIModule/frmPayBillAcknowledgement", function() {
    return function(controller) {
        function addWidgetsfrmPayBillAcknowledgement() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxAckHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "60dp",
                "id": "flxAckHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAckHeader.setDefaultUnit(kony.flex.DP);
            var lblBillPayAcknowledgement = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblBillPayAcknowledgement",
                "isVisible": true,
                "left": "86dp",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.AcknowledgementBillPay\")",
                "top": "30dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxPrint = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "button",
                        "tabindex": 0
                    },
                    "a11yLabel": "Print details of this transaction"
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxPrint",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "6.14%",
                "skin": "slFbox",
                "top": "30dp",
                "width": "30dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknflxFFFFFnobg"
            });
            flxPrint.setDefaultUnit(kony.flex.DP);
            var lblPrintfontIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "height": "30dp",
                "id": "lblPrintfontIcon",
                "isVisible": true,
                "skin": "sknPrintFonticon0273e3",
                "text": "p",
                "width": "30px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Print"
            });
            flxPrint.add(lblPrintfontIcon);
            flxAckHeader.add(lblBillPayAcknowledgement, flxPrint);
            var flxAcknowledgement = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAcknowledgement",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgement.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "1366dp",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxSuccess = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxSuccess",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "83dp",
                "minHeight": "406dp",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "590px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSuccess.setDefaultUnit(kony.flex.DP);
            var flxAcknowledgementHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxAcknowledgementHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30px",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "530px",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAcknowledgementHeader.setDefaultUnit(kony.flex.DP);
            var lblAcknowledgementHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Acknowledgement",
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblAcknowledgementHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.common.Acknowledgement\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator9 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxSeparator9",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknflxe5e5e5Op60",
                "top": "48px",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator9.setDefaultUnit(kony.flex.DP);
            flxSeparator9.add();
            flxAcknowledgementHeader.add(lblAcknowledgementHeader, flxSeparator9);
            var lblSuccessMessage = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblSuccessMessage",
                "isVisible": true,
                "skin": "sknLblSSP42424224px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.AcknowledgementMessage\")",
                "top": "30px",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 2],
                "paddingInPixel": false
            }, {});
            var ImgAcknowledged = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerX": "50%",
                "height": "69px",
                "id": "ImgAcknowledged",
                "isVisible": true,
                "skin": "slImage",
                "src": "success_green.png",
                "top": "10dp",
                "width": "69px",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblRefrenceNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Reference Number",
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblRefrenceNumber",
                "isVisible": true,
                "skin": "sknlbl424242SSPReg17px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.RefrenceNumber\")",
                "top": "21dp",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 1],
                "paddingInPixel": false
            }, {});
            var lblRefrenceNumberValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "id": "lblRefrenceNumberValue",
                "isVisible": true,
                "skin": "sknSSPLight42424228px",
                "text": "FT84743321023",
                "top": "0dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [2, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            var flxAvailableBalance = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "30dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "81dp",
                "id": "flxAvailableBalance",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "30dp",
                "isModalContainer": false,
                "skin": "sknFlxF7F7F7op100border5px",
                "top": "22dp",
                "width": "90%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAvailableBalance.setDefaultUnit(kony.flex.DP);
            var lblAvailableBalance = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Now your Available Balance in",
                    "tagName": "span"
                },
                "id": "lblAvailableBalance",
                "isVisible": true,
                "left": "2.20%",
                "skin": "sknSSP42424217Pxop70",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.PayAPerson.NowyouravailableBalancein\")",
                "top": "19dp",
                "width": "55%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSavings = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxSavings",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "43dp",
                "width": "50%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSavings.setDefaultUnit(kony.flex.DP);
            var flxSavingsIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxSavingsIcon",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "2%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "20dp",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSavingsIcon.setDefaultUnit(kony.flex.DP);
            var lblSavingsIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "100%",
                "id": "lblSavingsIcon",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblOLBFontIconsvs",
                "text": "s",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSavingsIcon.add(lblSavingsIcon);
            var lblSavingsAccount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblSavingsAccount",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl424242SSP15Px",
                "text": "My Savings Account",
                "top": "0dp",
                "width": "70%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSavings.add(flxSavingsIcon, lblSavingsAccount);
            var lblBalanceValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblBalanceValue",
                "isVisible": true,
                "left": "50%",
                "skin": "sknSSPLight42424228px",
                "text": "$2,348.00",
                "width": "50%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxAvailableBalance.add(lblAvailableBalance, flxSavings, lblBalanceValue);
            flxSuccess.add(flxAcknowledgementHeader, lblSuccessMessage, ImgAcknowledged, lblRefrenceNumber, lblRefrenceNumberValue, flxAvailableBalance);
            var flxBillPayDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "id": "flxBillPayDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "minHeight": "406dp",
                "isModalContainer": false,
                "right": "6%",
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "43.27%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBillPayDetails.setDefaultUnit(kony.flex.DP);
            var flxYourTransactionDetails = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxYourTransactionDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxYourTransactionDetails.setDefaultUnit(kony.flex.DP);
            var lblHeadingDetails = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yLabel": "Verify Payee Information",
                    "tagName": "h2"
                },
                "centerY": "50%",
                "id": "lblHeadingDetails",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.YourTransactionDetails\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxSeparator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "48dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            flxYourTransactionDetails.add(lblHeadingDetails, flxSeparator);
            var flxFrom = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFrom",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrom.setDefaultUnit(kony.flex.DP);
            var flxFromKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFromKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromKey.setDefaultUnit(kony.flex.DP);
            var lblFromKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFromKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblFrom\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromKey.add(lblFromKey, lblColon);
            var flxFromValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFromValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "22.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromValue.setDefaultUnit(kony.flex.DP);
            var flxFromIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxFromIcon",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "2%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "20dp",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFromIcon.setDefaultUnit(kony.flex.DP);
            var lblFromIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "100%",
                "id": "lblFromIcon",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblOLBFontIconsvs",
                "text": "s",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromIcon.add(lblFromIcon);
            var lblFromValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFromValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFromValue.add(flxFromIcon, lblFromValue);
            flxFrom.add(flxFromKey, flxFromValue);
            var flxTo = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxTo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxTo.setDefaultUnit(kony.flex.DP);
            var flxToKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxToKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxToKey.setDefaultUnit(kony.flex.DP);
            var lblToKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblToKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblTo\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon1 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon1",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxToKey.add(lblToKey, lblColon1);
            var flxToValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxToValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "22.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxToValue.setDefaultUnit(kony.flex.DP);
            var flxToIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxToIcon",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "right": "2%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "20dp",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxToIcon.setDefaultUnit(kony.flex.DP);
            var lblToIcon = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerX": "50%",
                "height": "100%",
                "id": "lblToIcon",
                "isVisible": true,
                "left": "0",
                "skin": "sknLblOLBFontIconsvs",
                "text": "s",
                "top": "0",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxToIcon.add(lblToIcon);
            var lblToValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblToValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxToValue.add(flxToIcon, lblToValue);
            flxTo.add(flxToKey, flxToValue);
            var flxAmount = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var flxAmountKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAmountKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountKey.setDefaultUnit(kony.flex.DP);
            var lblAmountKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAmountKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblAmount\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon2 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon2",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmountKey.add(lblAmountKey, lblColon2);
            var flxAmountValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAmountValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "22.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountValue.setDefaultUnit(kony.flex.DP);
            var lblAmountValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblAmountValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmountValue.add(lblAmountValue);
            flxAmount.add(flxAmountKey, flxAmountValue);
            var flxFrequency = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFrequency",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequency.setDefaultUnit(kony.flex.DP);
            var flxFrequencyKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFrequencyKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequencyKey.setDefaultUnit(kony.flex.DP);
            var lblFrequencyKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFrequencyKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.lblFrequency\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon5 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon5",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFrequencyKey.add(lblFrequencyKey, lblColon5);
            var flxFrequencyValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxFrequencyValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "22.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFrequencyValue.setDefaultUnit(kony.flex.DP);
            var lblFrequencyValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblFrequencyValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFrequencyValue.add(lblFrequencyValue);
            flxFrequency.add(flxFrequencyKey, flxFrequencyValue);
            var flxPaymentDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPaymentDate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDate.setDefaultUnit(kony.flex.DP);
            var flxPaymentDateKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPaymentDateKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDateKey.setDefaultUnit(kony.flex.DP);
            var lblPaymentDateKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPaymentDateKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PaymentDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon3",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentDateKey.add(lblPaymentDateKey, lblColon3);
            var flxPaymentDateValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPaymentDateValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "22.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPaymentDateValue.setDefaultUnit(kony.flex.DP);
            var lblPaymentDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPaymentDateValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPaymentDateValue.add(lblPaymentDateValue);
            flxPaymentDate.add(flxPaymentDateKey, flxPaymentDateValue);
            var flxEndDate = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEndDate",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndDate.setDefaultUnit(kony.flex.DP);
            var flxEndDateKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEndDateKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndDateKey.setDefaultUnit(kony.flex.DP);
            var lblEndDateKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEndDateKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.PaymentDate\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon7 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon7",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEndDateKey.add(lblEndDateKey, lblColon7);
            var flxEndDateValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxEndDateValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "22.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEndDateValue.setDefaultUnit(kony.flex.DP);
            var lblEndDateValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblEndDateValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEndDateValue.add(lblEndDateValue);
            flxEndDate.add(flxEndDateKey, flxEndDateValue);
            var flxDeliverBy = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDeliverBy",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeliverBy.setDefaultUnit(kony.flex.DP);
            var flxDeliverByKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDeliverByKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeliverByKey.setDefaultUnit(kony.flex.DP);
            var lblDeliverByKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblDeliverByKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.DeliverBy\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon4",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeliverByKey.add(lblDeliverByKey, lblColon4);
            var flxDeliverByValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxDeliverByValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "22.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDeliverByValue.setDefaultUnit(kony.flex.DP);
            var lblDeliverByValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblDeliverByValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDeliverByValue.add(lblDeliverByValue);
            flxDeliverBy.add(flxDeliverByKey, flxDeliverByValue);
            var flxNotes = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNotes",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNotes.setDefaultUnit(kony.flex.DP);
            var flxNotesKey = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNotesKey",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "18.50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNotesKey.setDefaultUnit(kony.flex.DP);
            var lblNotesKey = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNotesKey",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.accounts.Note\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblColon6 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "id": "lblColon6",
                "isVisible": true,
                "left": "2dp",
                "skin": "sknlbla0a0a015px",
                "text": ":",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNotesKey.add(lblNotesKey, lblColon6);
            var flxNotesValue = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxNotesValue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "22.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxNotesValue.setDefaultUnit(kony.flex.DP);
            var lblNotesValue = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblNotesValue",
                "isVisible": true,
                "left": "0dp",
                "skin": "slLabel0d8a72616b3cc47",
                "text": "Label",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNotesValue.add(lblNotesValue);
            flxNotes.add(flxNotesKey, flxNotesValue);
            flxBillPayDetails.add(flxYourTransactionDetails, flxFrom, flxTo, flxAmount, flxFrequency, flxPaymentDate, flxEndDate, flxDeliverBy, flxNotes);
            flxMainContainer.add(flxSuccess, flxBillPayDetails);
            var flxButtons = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxButtons",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxButtons.setDefaultUnit(kony.flex.DP);
            var btnViewPaymentActivity = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40px",
                "id": "btnViewPaymentActivity",
                "isVisible": true,
                "left": "950px",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.ViewPaymentActivity\")",
                "top": "20dp",
                "width": "250px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnMakeAnotherPayment = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": 0
                    }
                },
                "focusSkin": "sknBtnNormalSSPFFFFFF15PxFocus",
                "height": "40px",
                "id": "btnMakeAnotherPayment",
                "isVisible": true,
                "left": "680px",
                "skin": "sknbtnSSPffffff0278ee15pxbr3px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.MakeAnotherPayment\")",
                "top": "20dp",
                "width": "250px",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButtons.add(btnViewPaymentActivity, btnMakeAnotherPayment);
            flxAcknowledgement.add(flxMainContainer, flxButtons);
            flxMain.add(flxAckHeader, flxAcknowledgement);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "800dp",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopup);
            var flxDelete = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "800dp",
                "id": "flxDelete",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "BillPayMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDelete.setDefaultUnit(kony.flex.DP);
            var deletePopup = new com.InfinityOLB.Resources.CustomPopup({
                "height": "268px",
                "id": "deletePopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDelete.add(deletePopup);
            flxDialogs.add(flxLogout, flxDelete);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "customheadernew.lblHeaderMobile": {
                        "i18n_text": "i18n.transfers.Acknowledgement",
                        "text": "",
                        "segmentProps": []
                    },
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "flxAckHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblBillPayAcknowledgement": {
                        "height": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "isVisible": false,
                        "left": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblPrintfontIcon": {
                        "segmentProps": []
                    },
                    "flxAcknowledgement": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSuccess": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "430dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementHeader": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgementHeader": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "lblRefrenceNumber": {
                        "padding": [2, 0, 2, 0],
                        "segmentProps": []
                    },
                    "flxAvailableBalance": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknflxBordere3e3e3",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblSavingsAccount": {
                        "text": "My Savings Account",
                        "segmentProps": []
                    },
                    "flxBillPayDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "563dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxYourTransactionDetails": {
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "lblHeadingDetails": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "segmentProps": []
                    },
                    "flxFromKey": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblColon": {
                        "segmentProps": []
                    },
                    "flxFromValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxToKey": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblColon1": {
                        "segmentProps": []
                    },
                    "flxToValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountKey": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblColon2": {
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxFrequencyKey": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblColon5": {
                        "segmentProps": []
                    },
                    "flxFrequencyValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDateKey": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblColon3": {
                        "segmentProps": []
                    },
                    "flxPaymentDateValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxEndDateKey": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblColon7": {
                        "segmentProps": []
                    },
                    "flxEndDateValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxDeliverByKey": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblColon4": {
                        "segmentProps": []
                    },
                    "flxDeliverByValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxNotesKey": {
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblColon6": {
                        "segmentProps": []
                    },
                    "flxNotesValue": {
                        "left": {
                            "type": "string",
                            "value": "3%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "btnViewPaymentActivity": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "btnMakeAnotherPayment": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "segmentProps": []
                    },
                    "deletePopup.flxSeperator2": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "268px"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "300dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "lblBillPayAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblPrintfontIcon": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSuccess": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "418dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgementHeader": {
                        "segmentProps": []
                    },
                    "flxAvailableBalance": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "skin": "sknflxBordere3e3e3",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblSavingsAccount": {
                        "text": "My Savings Account",
                        "segmentProps": []
                    },
                    "flxBillPayDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": "480dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "lblHeadingDetails": {
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "segmentProps": []
                    },
                    "flxFromValue": {
                        "segmentProps": []
                    },
                    "flxTo": {
                        "segmentProps": []
                    },
                    "flxToValue": {
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "segmentProps": []
                    },
                    "flxFrequency": {
                        "segmentProps": []
                    },
                    "flxFrequencyValue": {
                        "segmentProps": []
                    },
                    "flxPaymentDate": {
                        "segmentProps": []
                    },
                    "flxPaymentDateValue": {
                        "segmentProps": []
                    },
                    "flxEndDate": {
                        "segmentProps": []
                    },
                    "flxEndDateValue": {
                        "segmentProps": []
                    },
                    "flxDeliverBy": {
                        "segmentProps": []
                    },
                    "flxDeliverByValue": {
                        "segmentProps": []
                    },
                    "flxNotes": {
                        "segmentProps": []
                    },
                    "flxNotesValue": {
                        "segmentProps": []
                    },
                    "btnViewPaymentActivity": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "btnMakeAnotherPayment": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "27%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "22%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "130%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "height": {
                            "type": "string",
                            "value": "130%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "lblBillPayAcknowledgement": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "flxPrint": {
                        "segmentProps": []
                    },
                    "lblPrintfontIcon": {
                        "segmentProps": []
                    },
                    "flxMainContainer": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSuccess": {
                        "height": {
                            "type": "string",
                            "value": "430dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "6%"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "43.27%"
                        },
                        "segmentProps": []
                    },
                    "flxAcknowledgementHeader": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgementHeader": {
                        "segmentProps": []
                    },
                    "flxAvailableBalance": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "32dp"
                        },
                        "skin": "sknflxBordere3e3e3",
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "flxBillPayDetails": {
                        "height": {
                            "type": "string",
                            "value": "430dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxYourTransactionDetails": {
                        "left": {
                            "type": "string",
                            "value": "5%"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "lblHeadingDetails": {
                        "segmentProps": []
                    },
                    "flxFrom": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxFromKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon": {
                        "segmentProps": []
                    },
                    "flxFromValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxTo": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxToKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon1": {
                        "segmentProps": []
                    },
                    "flxToValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxAmount": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon2": {
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxFrequency": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxFrequencyKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon5": {
                        "segmentProps": []
                    },
                    "flxFrequencyValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDate": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDateKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon3": {
                        "segmentProps": []
                    },
                    "flxPaymentDateValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxEndDate": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxEndDateKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon7": {
                        "segmentProps": []
                    },
                    "flxEndDateValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxDeliverBy": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxDeliverByKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon4": {
                        "segmentProps": []
                    },
                    "flxDeliverByValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxNotes": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxNotesKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon6": {
                        "segmentProps": []
                    },
                    "flxNotesValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxButtons": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnViewPaymentActivity": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.14%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "16.84%"
                        },
                        "segmentProps": []
                    },
                    "btnMakeAnotherPayment": {
                        "left": {
                            "type": "string",
                            "value": "58.60%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "16.84%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CustomPopup": {
                        "width": {
                            "type": "string",
                            "value": "44.30%"
                        },
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "isVisible": false,
                        "segmentProps": []
                    }
                },
                "1380": {
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "120dp"
                        },
                        "segmentProps": []
                    },
                    "flxMain": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "1366dp"
                        },
                        "segmentProps": []
                    },
                    "lblBillPayAcknowledgement": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "segmentProps": []
                    },
                    "flxSuccess": {
                        "height": {
                            "type": "string",
                            "value": "418dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "43.27%"
                        },
                        "segmentProps": []
                    },
                    "lblAcknowledgementHeader": {
                        "segmentProps": []
                    },
                    "flxAvailableBalance": {
                        "skin": "sknflxBordere3e3e3",
                        "segmentProps": []
                    },
                    "flxBillPayDetails": {
                        "height": {
                            "type": "string",
                            "value": "418dp"
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "43.27%"
                        },
                        "segmentProps": []
                    },
                    "lblHeadingDetails": {
                        "segmentProps": []
                    },
                    "flxFromKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon": {
                        "segmentProps": []
                    },
                    "flxFromValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxToKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon1": {
                        "segmentProps": []
                    },
                    "flxToValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon2": {
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxFrequencyKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon5": {
                        "segmentProps": []
                    },
                    "flxFrequencyValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxPaymentDateKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon3": {
                        "segmentProps": []
                    },
                    "flxPaymentDateValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxEndDateKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon7": {
                        "segmentProps": []
                    },
                    "flxEndDateValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxDeliverByKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon4": {
                        "segmentProps": []
                    },
                    "flxDeliverByValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "flxNotesKey": {
                        "width": {
                            "type": "string",
                            "value": "28%"
                        },
                        "segmentProps": []
                    },
                    "lblColon6": {
                        "segmentProps": []
                    },
                    "flxNotesValue": {
                        "left": {
                            "type": "string",
                            "value": "35%"
                        },
                        "segmentProps": []
                    },
                    "btnViewPaymentActivity": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "6.14%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "16.84%"
                        },
                        "segmentProps": []
                    },
                    "btnMakeAnotherPayment": {
                        "left": {
                            "type": "string",
                            "value": "58.60%"
                        },
                        "top": {
                            "type": "string",
                            "value": "30px"
                        },
                        "width": {
                            "type": "string",
                            "value": "16.84%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "zIndex": 1000,
                        "segmentProps": []
                    },
                    "flxDelete": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "deletePopup": {
                        "height": {
                            "type": "string",
                            "value": "268dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {}
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmPayBillAcknowledgement,
            "enabledForIdleTimeout": true,
            "id": "frmPayBillAcknowledgement",
            "init": controller.AS_Form_c72bacea8b604203bcd0fba4f38216c5,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "title": "Bill pay Acknowledgement",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "BillPayMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});