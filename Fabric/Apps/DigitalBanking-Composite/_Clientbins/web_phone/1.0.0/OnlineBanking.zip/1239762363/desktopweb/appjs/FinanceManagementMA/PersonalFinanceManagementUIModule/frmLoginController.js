define("FinanceManagementMA/PersonalFinanceManagementUIModule/userfrmLoginController", {
    //Type your controller code here 
});
define("FinanceManagementMA/PersonalFinanceManagementUIModule/frmLoginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnLogin **/
    AS_Button_df6b3e8f0700458cb2a61fd66b22bbd1: function AS_Button_df6b3e8f0700458cb2a61fd66b22bbd1(eventobject) {
        var self = this; 
        var self = this;  
        kony.application.showLoadingScreen("", "Authenticating the user");  
        var authParams = {  
            "UserName": "1166317776",
               "Password": "Kony@1234",
               "loginOptions": {    
                "isOfflineEnabled": false   
            }  
        };  
        authClient = KNYMobileFabric.getIdentityService("DbxUserLogin");  
        authClient.login(authParams, successCallback, errorCallback);  
        function successCallback(resSuccess) {  
            kony.application.dismissLoadingScreen();   
            kony.print(resSuccess);  
            //     var pfmModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("PersonalFinanceManagementUIModule");
            //      pfmModule.presentationController.navigateToPFMModule();
            // new kony.mvc.Navigation({
            //                 "appName": "PfmMA",
            //                 "friendlyName": "frmPersonalFinanceManagement"
            //             }).navigate();
            var pfmMAname = "FinanceManagementMA"; 
            var pfmModule = kony.mvc.MDAApplication.getSharedInstance().moduleManager.getModule({
                "moduleName": "PersonalFinanceManagementUIModule",
                "appName": pfmMAname
            }); 
            pfmModule.presentationController.initPFMForm();
            // ntf.navigate();  
             
        }  
        function errorCallback(resError) {   
            kony.application.dismissLoadingScreen();   
            kony.print(resError);   
            alert("login is not working...");  
        }
    }
});
define("FinanceManagementMA/PersonalFinanceManagementUIModule/frmLoginController", ["FinanceManagementMA/PersonalFinanceManagementUIModule/userfrmLoginController", "FinanceManagementMA/PersonalFinanceManagementUIModule/frmLoginControllerActions"], function() {
    var controller = require("FinanceManagementMA/PersonalFinanceManagementUIModule/userfrmLoginController");
    var controllerActions = ["FinanceManagementMA/PersonalFinanceManagementUIModule/frmLoginControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
