define("PortfolioManagementMA/WealthPortfolioUIModule/userfrmRiskAppetiteController", {
    frmPreShow: function() {
        this.view.formTemplate12.flxContentTCCenter.skin = "sknFlxffffffShadowdddcdc";
        this.view.formTemplate12.pageTitlei18n = "i18n.wealth.suitabilityProfile";
        this.view.formTemplate12.onError = function(errorObject) {};
        let reqParam = {
            "portfolioId": applicationManager.getModulesPresentationController("WealthPortfolioUIModule").getPortfolioId(),
            "portfolioServiceType": "Advisory"
        };
        let serviceParams = {
            "ObjectName": "Strategies",
            "ServiceName": "PortfolioServicing",
            "OperationName1": "getStrategyQuestions",
            "OperationName2": "submitStrategyQuestionnaire",
            "OperationName3": "getMyStrategy"
        }
        this.view.formTemplate12.flxContentTCCenter.suitabilityRiskAppetite.setContext(reqParam, serviceParams);
    }
});
define("PortfolioManagementMA/WealthPortfolioUIModule/frmRiskAppetiteControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** preShow defined for frmRiskAppetite **/
    AS_Form_e474c9d657b44736ad76a250f39c0dfe: function AS_Form_e474c9d657b44736ad76a250f39c0dfe(eventobject) {
        var self = this;
        this.frmPreShow();
    }
});
define("PortfolioManagementMA/WealthPortfolioUIModule/frmRiskAppetiteController", ["PortfolioManagementMA/WealthPortfolioUIModule/userfrmRiskAppetiteController", "PortfolioManagementMA/WealthPortfolioUIModule/frmRiskAppetiteControllerActions"], function() {
    var controller = require("PortfolioManagementMA/WealthPortfolioUIModule/userfrmRiskAppetiteController");
    var controllerActions = ["PortfolioManagementMA/WealthPortfolioUIModule/frmRiskAppetiteControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
