define("ArrangementsMA/AccountsUIModule/frmUpcomingTransactionsPrint", function() {
    return function(controller) {
        function addWidgetsfrmUpcomingTransactionsPrint() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "1250dp",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "top": "15dp",
                "width": "98%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "58dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var flxHeaderContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxHeaderContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderContent.setDefaultUnit(kony.flex.DP);
            var imgLogo = new kony.ui.Image2({
                "id": "imgLogo",
                "imageWhenFailed": "print_logo.png",
                "imageWhileDownloading": "print_logo.png",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "print_logo.png",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblHeader = new kony.ui.Label({
                "id": "lblHeader",
                "isVisible": true,
                "right": "10.50%",
                "skin": "sknLbl000000185PercentBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.accountStatement\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderContent.add(imgLogo, lblHeader);
            var flxSeparator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0",
                "clipBounds": false,
                "height": "1dp",
                "id": "flxSeparator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "ICSknFlxeE3E3E3bg",
                "top": "5dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeparator.setDefaultUnit(kony.flex.DP);
            flxSeparator.add();
            flxHeader.add(flxHeaderContent, flxSeparator);
            var flxAccountDetailsContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAccountDetailsContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountDetailsContent.setDefaultUnit(kony.flex.DP);
            var flxAccNameAndPhoneNoContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAccNameAndPhoneNoContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "5dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccNameAndPhoneNoContent.setDefaultUnit(kony.flex.DP);
            var flxAccName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAccName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccName.setDefaultUnit(kony.flex.DP);
            var lblAccName = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccName",
                "isVisible": true,
                "skin": "sknLabelSSP42424217pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.accountName\")",
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccNameValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccNameValue",
                "isVisible": true,
                "left": "11dp",
                "skin": "ICSknLbl42424218PX",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccName.add(lblAccName, lblAccNameValue);
            var flxPhoneNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxPhoneNumber",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumber.setDefaultUnit(kony.flex.DP);
            var lblPhoneNumber = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPhoneNumber",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabelSSP42424217pxSemiBold",
                "text": "Label",
                "width": "80dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblPhoneNumberValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPhoneNumberValue",
                "isVisible": true,
                "left": "11dp",
                "skin": "ICSknLbl42424218PX",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhoneNumber.add(lblPhoneNumber, lblPhoneNumberValue);
            flxAccNameAndPhoneNoContent.add(flxAccName, flxPhoneNumber);
            var flxAccNumberAndEmailContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAccNumberAndEmailContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "5dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccNumberAndEmailContent.setDefaultUnit(kony.flex.DP);
            var flxAccNumber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxAccNumber",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccNumber.setDefaultUnit(kony.flex.DP);
            var lblAccNumber = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccNumber",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabelSSP42424217pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.accountNumber\")",
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAccNumberValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAccNumberValue",
                "isVisible": true,
                "left": "11dp",
                "skin": "ICSknLbl42424218PX",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAccNumber.add(lblAccNumber, lblAccNumberValue);
            var flxEmail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxEmail",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0",
                "width": "50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEmail.setDefaultUnit(kony.flex.DP);
            var lblEmail = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblEmail",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabelSSP42424217pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.LoginMFA.EmailID\")",
                "width": "80dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblEmailValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblEmailValue",
                "isVisible": true,
                "left": "11dp",
                "skin": "ICSknLbl42424218PX",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEmail.add(lblEmail, lblEmailValue);
            flxAccNumberAndEmailContent.add(flxAccNumber, flxEmail);
            var flxBranchAndAddressContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "52dp",
                "id": "flxBranchAndAddressContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "5dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBranchAndAddressContent.setDefaultUnit(kony.flex.DP);
            var flxBranchCurrencyContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxBranchCurrencyContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBranchCurrencyContent.setDefaultUnit(kony.flex.DP);
            var flxBranch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxBranch",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBranch.setDefaultUnit(kony.flex.DP);
            var lblBranch = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblBranch",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabelSSP42424217pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.branchwithcolon\")",
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblBranchValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblBranchValue",
                "isVisible": true,
                "left": "11dp",
                "skin": "ICSknLbl42424218PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.nA\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBranch.add(lblBranch, lblBranchValue);
            var flxCurrency = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxCurrency",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "5dp",
                "width": "50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCurrency.setDefaultUnit(kony.flex.DP);
            var lblCurrency = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCurrency",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabelSSP42424217pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"kony.i18n.verifyDetails.currency\")",
                "width": "140dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblCurrencyValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCurrencyValue",
                "isVisible": true,
                "left": "11dp",
                "skin": "ICSknLbl42424218PX",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCurrency.add(lblCurrency, lblCurrencyValue);
            flxBranchCurrencyContent.add(flxBranch, flxCurrency);
            var flxAddress = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAddress",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "0dp",
                "width": "50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddress.setDefaultUnit(kony.flex.DP);
            var lblAddress = new kony.ui.Label({
                "id": "lblAddress",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabelSSP42424217pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.payments.addressWithColon\")",
                "top": "0dp",
                "width": "80dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAddressValue = new kony.ui.Label({
                "id": "lblAddressValue",
                "isVisible": true,
                "left": "11dp",
                "skin": "ICSknLbl42424218PX",
                "text": "Label",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddress.add(lblAddress, lblAddressValue);
            flxBranchAndAddressContent.add(flxBranchCurrencyContent, flxAddress);
            flxAccountDetailsContent.add(flxAccNameAndPhoneNoContent, flxAccNumberAndEmailContent, flxBranchAndAddressContent);
            var flxUpcomingTransactionsDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "55dp",
                "id": "flxUpcomingTransactionsDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpcomingTransactionsDetails.setDefaultUnit(kony.flex.DP);
            var lblUpcomingTransactions = new kony.ui.Label({
                "id": "lblUpcomingTransactions",
                "isVisible": true,
                "left": "0",
                "skin": "sknLbl000000171PocentBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.upComingTransactions\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUpcomingDateRange = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20dp",
                "id": "flxUpcomingDateRange",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpcomingDateRange.setDefaultUnit(kony.flex.DP);
            var lblDateRange = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDateRange",
                "isVisible": true,
                "left": "0",
                "skin": "sknLabelSSP42424217pxSemiBold",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.serviceRequests.DateRange\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDateRangeValue = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDateRangeValue",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLbl42424218PX",
                "text": "Label",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUpcomingDateRange.add(lblDateRange, lblDateRangeValue);
            flxUpcomingTransactionsDetails.add(lblUpcomingTransactions, flxUpcomingDateRange);
            var flxUpcomingTransactionsListing = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUpcomingTransactionsListing",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpcomingTransactionsListing.setDefaultUnit(kony.flex.DP);
            var flxLisingHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxLisingHeader",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxBg293276",
                "top": "0dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLisingHeader.setDefaultUnit(kony.flex.DP);
            var flxDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "12.50%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDate.setDefaultUnit(kony.flex.DP);
            var lbldate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lbldate",
                "isVisible": true,
                "left": "5dp",
                "skin": "ICSknLblffffff18PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.konybb.Common.Date\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDate.add(lbldate);
            var flxPayeeName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPayeeName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "10dp",
                "isModalContainer": false,
                "top": "0dp",
                "width": "40%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPayeeName.setDefaultUnit(kony.flex.DP);
            var lblPayeeName = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPayeeName",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblffffff18PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.StopCheckPayments.PayeeName\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPayeeName.add(lblPayeeName);
            var flxType = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxType",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "top": "0dp",
                "width": "21%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxType.setDefaultUnit(kony.flex.DP);
            var lblType = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblType",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblffffff18PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.Type\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxType.add(lblType);
            var flxAmount = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAmount",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5%",
                "isModalContainer": false,
                "top": "0dp",
                "width": "28%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmount.setDefaultUnit(kony.flex.DP);
            var lblAmount = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblAmount",
                "isVisible": true,
                "left": "0dp",
                "skin": "ICSknLblffffff18PX",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.wealth.amount\")",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAmount.add(lblAmount);
            flxLisingHeader.add(flxDate, flxPayeeName, flxType, flxAmount);
            var flxLisingContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLisingContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "top": "15dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLisingContent.setDefaultUnit(kony.flex.DP);
            var segUpcomingTransactions = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblAmount": "",
                    "lblBalance": "",
                    "lblCategory": "",
                    "lblDate": "",
                    "lblDescription": "",
                    "lblSeparator": "",
                    "lblType": ""
                }],
                "groupCells": false,
                "id": "segUpcomingTransactions",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknSegScrollHide",
                "rowTemplate": kony.mvc.resolveNameFromContext({
                    "appName": "ArrangementsMA",
                    "friendlyName": "flxPrintTransaction"
                }),
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxPrintTransaction": "flxPrintTransaction",
                    "lblAmount": "lblAmount",
                    "lblBalance": "lblBalance",
                    "lblCategory": "lblCategory",
                    "lblDate": "lblDate",
                    "lblDescription": "lblDescription",
                    "lblSeparator": "lblSeparator",
                    "lblType": "lblType"
                },
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLisingContent.add(segUpcomingTransactions);
            flxUpcomingTransactionsListing.add(flxLisingHeader, flxLisingContent);
            var flxFooterContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFooterContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "top": "10dp",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterContent.setDefaultUnit(kony.flex.DP);
            var lblNote = new kony.ui.Label({
                "bottom": "10dp",
                "id": "lblNote",
                "isVisible": true,
                "left": "0",
                "skin": "ICSknBBLabelSSP42424213px",
                "text": "Note:",
                "top": "0dp",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxBg293276",
                "top": "0",
                "width": "100%",
                "appName": "ArrangementsMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var lblFooterMailId = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFooterMailId",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknLblffffffSSPR11px",
                "text": "info@temenos.com",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFooterPhoneNumber = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblFooterPhoneNumber",
                "isVisible": true,
                "skin": "sknLblffffffSSPR11px",
                "text": "Phone Number: +1 xxx xxxx",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblFooterWebsite = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblFooterWebsite",
                "isVisible": true,
                "right": "13%",
                "skin": "sknLblffffffSSPR11px",
                "text": "www.temenos.com",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFooter.add(lblFooterMailId, lblFooterPhoneNumber, lblFooterWebsite);
            flxFooterContent.add(lblNote, flxFooter);
            flxMain.add(flxHeader, flxAccountDetailsContent, flxUpcomingTransactionsDetails, flxUpcomingTransactionsListing, flxFooterContent);
            flxMainContainer.add(flxMain);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "1024": {
                    "lblHeader": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {}
            this.add(flxMainContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmUpcomingTransactionsPrint,
            "enabledForIdleTimeout": false,
            "id": "frmUpcomingTransactionsPrint",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [1024, 1366],
            "appName": "ArrangementsMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});