define("ManageProfileMA/SettingsNewUIModule/frmSettingsEditPhoneNumber", function() {
    return function(controller) {
        function addWidgetsfrmSettingsEditPhoneNumber() {
            this.setDefaultUnit(kony.flex.DP);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": false,
                "height": "120dp",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheadernew": {
                        "centerX": "viz.val_cleared",
                        "width": "100%"
                    },
                    "flxActionsMenu": {
                        "top": "0dp"
                    },
                    "imgKony": {
                        "src": "kony_logo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgMenu": {
                        "src": "menu_icon.png"
                    },
                    "imgNotifications": {
                        "src": "notification_flag.png"
                    },
                    "lblHeaderMobile": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.profilesettings\")",
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxMain = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "main",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h1"
                },
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "3.25%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Settingscapson\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxSettingsContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxSettingsContainer",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "3.25%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "93.50%",
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxSettingsContainer.setDefaultUnit(kony.flex.DP);
            var flxMenuItemMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxMenuItemMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknFlxf6f6f6",
                "top": "-1dp",
                "width": "101%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMenuItemMobile.setDefaultUnit(kony.flex.DP);
            var lblAccountSettingsMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "centerY": "50%",
                "id": "lblAccountSettingsMobile",
                "isVisible": true,
                "left": "20.56%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Accounts.ContextualActions.updateSettingAndPreferences\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Account Settings"
            });
            var flxAccountSettingsCollapseMobile = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-expanded": false,
                        "aria-labelledby": "lblAccountSettingsMobile",
                        "role": "button"
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxAccountSettingsCollapseMobile",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "skncursor",
                "top": "0dp",
                "width": "8.36%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAccountSettingsCollapseMobile.setDefaultUnit(kony.flex.DP);
            var lblCollapseMobile = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "15dp",
                "id": "lblCollapseMobile",
                "isVisible": true,
                "left": "0%",
                "skin": "sknOlbFontsIcons0273e3",
                "text": "P",
                "width": "15dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Profile Settings"
            });
            flxAccountSettingsCollapseMobile.add(lblCollapseMobile);
            flxMenuItemMobile.add(lblAccountSettingsMobile, flxAccountSettingsCollapseMobile);
            var flxLeft = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3dp",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder0b7491d9b1d7c4e",
                "top": "-1dp",
                "width": "23.70%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var profileMenu = new com.InfinityOLB.Resources.profileMenu({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "profileMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "ResourcesMA",
                "overrides": {
                    "flxProfileMenu": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLeft.add(profileMenu);
            var flxRight = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "695px",
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "24%",
                "isModalContainer": false,
                "skin": "CopysknFlxffffffBorder0b7491d9b1d7c4e",
                "top": "0dp",
                "width": "76.08%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "bottom": "0px",
                "clipBounds": true,
                "height": "100%",
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.23%",
                "isModalContainer": false,
                "skin": "sknFlxffffffBorder0",
                "top": "0dp",
                "width": "95.62%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxEditPhoneNumbersWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxEditPhoneNumbersWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditPhoneNumbersWrapper.setDefaultUnit(kony.flex.DP);
            var flxEditPhoneNumberHeading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50px",
                "id": "flxEditPhoneNumberHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxffffff3pxe3e3e3bordermod",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditPhoneNumberHeading.setDefaultUnit(kony.flex.DP);
            var flxEditPhoneNumberSeperator = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "1px",
                "clipBounds": true,
                "height": "1dp",
                "id": "flxEditPhoneNumberSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditPhoneNumberSeperator.setDefaultUnit(kony.flex.DP);
            flxEditPhoneNumberSeperator.add();
            var lblEditPhoneNumberHeading = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "h2"
                },
                "centerY": "50.67%",
                "id": "lblEditPhoneNumberHeading",
                "isVisible": true,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.EditPhoneNumber\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDelete = new kony.ui.Button({
                "centerY": "50%",
                "id": "btnDelete",
                "isVisible": true,
                "onClick": controller.AS_Button_a9834b6892cc45faa2fbee76734ad9a0,
                "right": "0dp",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.deleteExternalAccount\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknbtn3343a813pxnobghover"
            });
            var btnEdit = new kony.ui.Button({
                "centerY": "50%",
                "id": "btnEdit",
                "isVisible": true,
                "onClick": controller.AS_Button_a9834b6892cc45faa2fbee76734ad9a0,
                "right": "7%",
                "skin": "sknBtnSSP0273e313Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.Edit\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknbtn3343a813pxnobghover"
            });
            flxEditPhoneNumberHeading.add(flxEditPhoneNumberSeperator, lblEditPhoneNumberHeading, btnDelete, btnEdit);
            var flxEditPhoneNumberContainer = new kony.ui.FlexScrollContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "91%",
                "horizontalScrollIndicator": true,
                "id": "flxEditPhoneNumberContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditPhoneNumberContainer.setDefaultUnit(kony.flex.DP);
            var flxEditPhoneNumberContent = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "id": "flxEditPhoneNumberContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "minHeight": "525dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0fd0ec3c44e314c",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditPhoneNumberContent.setDefaultUnit(kony.flex.DP);
            var flxError = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "alert",
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "52dp",
                "id": "flxError",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.29%",
                "isModalContainer": false,
                "skin": "sknrounded",
                "top": "10dp",
                "width": "85%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var CopyimgError0e5915ab907ef4c = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "30dp",
                "id": "CopyimgError0e5915ab907ef4c",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "10px",
                "skin": "slImage",
                "src": "error_yellow.png",
                "width": "8.54%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblError = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblError",
                "isVisible": true,
                "left": "70dp",
                "skin": "sknlblff000015px",
                "text": "Page level/transaction level errors appear here.",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxError.add(CopyimgError0e5915ab907ef4c, lblError);
            var flxPhoneNumber = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "130dp",
                "id": "flxPhoneNumber",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhoneNumber.setDefaultUnit(kony.flex.DP);
            var flxContainer1 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxContainer1",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "minHeight": "70dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer1.setDefaultUnit(kony.flex.DP);
            var flxAddPhoneNumberTypeContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddPhoneNumberTypeContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 2,
                        "1380": 2
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPhoneNumberTypeContainer.setDefaultUnit(kony.flex.DP);
            var lblPhoneNumberType = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPhoneNumberType",
                "isVisible": true,
                "left": "10%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Type\")",
                "top": "35px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddPhoneNumberTypeContainer.add(lblPhoneNumberType);
            var flxAddPhoneNumberType2Container = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxAddPhoneNumberType2Container",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "24%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddPhoneNumberType2Container.setDefaultUnit(kony.flex.DP);
            var lbxPhoneNumberType = new kony.ui.ListBox({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-labelledby": "lblPhoneNumberType"
                    }
                },
                "focusSkin": "sknLbxBorder003e751px",
                "height": "40dp",
                "id": "lbxPhoneNumberType",
                "isVisible": true,
                "left": "0%",
                "masterData": [
                    ["key1", "Mobile"],
                    ["key2", "Home"],
                    ["key3", "Work"]
                ],
                "selectedKey": "key1",
                "skin": "sknlbxalto42424215pxBordere3e3e32pxRadius",
                "top": "25dp",
                "width": "43.81%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [2, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxAddPhoneNumberType2Container.add(lbxPhoneNumberType);
            flxContainer1.add(flxAddPhoneNumberTypeContainer, flxAddPhoneNumberType2Container);
            var flxContainer2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxContainer2",
                "isVisible": true,
                "layoutType": kony.flex.RESPONSIVE_GRID,
                "left": "0dp",
                "minHeight": "50dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 12,
                        "1366": 12
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContainer2.setDefaultUnit(kony.flex.DP);
            var flxPhoneNumberEntryContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxPhoneNumberEntryContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "minHeight": "40dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "24%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0,
                        "1380": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 3,
                        "1366": 2,
                        "1380": 2
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumberEntryContainer.setDefaultUnit(kony.flex.DP);
            var lblPhoneNumber = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPhoneNumber",
                "isVisible": true,
                "left": "10%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PhoneNumber\")",
                "top": "27px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPhoneNumberEntryContainer.add(lblPhoneNumber);
            var flxPhoneNumberEntry2Container = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxPhoneNumberEntry2Container",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "24%",
                "minHeight": "40dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 12,
                        "1024": 8,
                        "1366": 9
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPhoneNumberEntry2Container.setDefaultUnit(kony.flex.DP);
            var flxEditPhoneNumberCountryCode = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxEditPhoneNumberCountryCode",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "43.80%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditPhoneNumberCountryCode.setDefaultUnit(kony.flex.DP);
            var tbxEditPhoneNumberCountryCode = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-required": true
                    },
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.Profile.code\")"
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxEditPhoneNumberCountryCode",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.Profile.code\")",
                "secureTextEntry": false,
                "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "23%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "tel-country-code"
            });
            var tbxPhoneNumber = new kony.ui.TextBox2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-autocomplete": "none",
                        "aria-labelledby": "lblPhoneNumber",
                        "aria-required": true
                    }
                },
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxPhoneNumber",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "18dp",
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.PhoneNumbers\")",
                "secureTextEntry": false,
                "skin": "skntbxffffffBordere3e3e3SSP15px424242",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0px",
                "width": "72%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": true
            }, {
                "autoCorrect": false,
                "autoComplete": "tel-national"
            });
            flxEditPhoneNumberCountryCode.add(tbxEditPhoneNumberCountryCode, tbxPhoneNumber);
            flxPhoneNumberEntry2Container.add(flxEditPhoneNumberCountryCode);
            flxContainer2.add(flxPhoneNumberEntryContainer, flxPhoneNumberEntry2Container);
            flxPhoneNumber.add(flxContainer1, flxContainer2);
            var flxEditPhoneNumberSeperator2 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxEditPhoneNumberSeperator2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "15dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditPhoneNumberSeperator2.setDefaultUnit(kony.flex.DP);
            flxEditPhoneNumberSeperator2.add();
            var flxOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxOptions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.29%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "95.18%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOptions.setDefaultUnit(kony.flex.DP);
            var lblPleaseChoose = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "id": "lblPleaseChoose",
                "isVisible": false,
                "left": "0%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.pleasechoosewhatservice\")",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxOption3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "25dp",
                "id": "flxOption3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "17dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOption3.setDefaultUnit(kony.flex.DP);
            var flxCheckBox3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "30dp",
                "id": "flxCheckBox3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "width": "25dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxCheckBox3.setDefaultUnit(kony.flex.DP);
            var imgCheckBox3 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "20dp",
                "id": "imgCheckBox3",
                "isVisible": false,
                "left": "0%",
                "skin": "slImage",
                "src": "checked_box.png",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "checkbox"
            });
            var lblCheckBox3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblCheckBox3",
                "isVisible": true,
                "skin": "sknlblDelete20px",
                "text": "C",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox3.add(imgCheckBox3, lblCheckBox3);
            var lblOption3 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblOption3",
                "isVisible": true,
                "left": "3.61%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManageemnt.Makemyprimaryphonenumber\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOption3.add(flxCheckBox3, lblOption3);
            var flxWarning = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": true,
                "height": "60dp",
                "id": "flxWarning",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "10dp",
                "width": "95%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var CopyimgWarning0d045e22dc1104f = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "role": "presentation",
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "centerY": "50%",
                "height": "40dp",
                "id": "CopyimgWarning0d045e22dc1104f",
                "imageWhileDownloading": "img_transparent.png",
                "isVisible": true,
                "left": "16dp",
                "skin": "slImage",
                "src": "info_blue.png",
                "width": "3.30%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblWarning",
                "isVisible": true,
                "left": "25dp",
                "skin": "sknSSPregular42424213Px",
                "text": "Another primary number exists and by selecting this one it will replace the previously added number.",
                "width": "80%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarning.add(CopyimgWarning0d045e22dc1104f, lblWarning);
            var flxOption4 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30px",
                "id": "flxOption4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "17dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxOption4.setDefaultUnit(kony.flex.DP);
            var flxCheckBox4 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "30dp",
                "id": "flxCheckBox4",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "skncursor",
                "top": 0,
                "width": "25dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknHoverTakeSurvey"
            });
            flxCheckBox4.setDefaultUnit(kony.flex.DP);
            var imgCheckBox4 = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "20dp",
                "id": "imgCheckBox4",
                "isVisible": false,
                "left": "0%",
                "skin": "slImage",
                "src": "checked_box.png",
                "top": 0,
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "toolTip": "Select Online Security and Text Alerts"
            });
            var lblCheckBox4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true,
                    "tagName": "span"
                },
                "centerX": "50%",
                "centerY": "50%",
                "id": "lblCheckBox4",
                "isVisible": true,
                "skin": "sknlblDelete20px",
                "text": "C",
                "width": "22dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCheckBox4.add(imgCheckBox4, lblCheckBox4);
            var lblOption4 = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "centerY": "50%",
                "id": "lblOption4",
                "isVisible": true,
                "left": "3.61%",
                "skin": "slLabel0d8a72616b3cc47",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.alertSettings.markAlertComm\")",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblOption4Description = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "tagName": "span"
                },
                "bottom": "60dp",
                "id": "lblOption4Description",
                "isVisible": false,
                "left": "3.61%",
                "skin": "sknSSPregular42424213Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.ThisNumberWillbe\")",
                "top": "32dp",
                "width": "67.10%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var ImgTextMessageInfo = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "15dp",
                "id": "ImgTextMessageInfo",
                "isVisible": false,
                "left": "36.06%",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "3dp",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxImgInfoIcon = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "aria-label": "Information",
                        "role": "button",
                        "tabindex": 0
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxImgInfoIcon",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "36%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "20dp",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknhoverlocateus"
            });
            flxImgInfoIcon.setDefaultUnit(kony.flex.DP);
            var ImgInfoIcon = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "15dp",
                "id": "ImgInfoIcon",
                "isVisible": true,
                "left": "0%",
                "skin": "slImage",
                "src": "info_grey.png",
                "top": "3dp",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImgInfoIcon.add(ImgInfoIcon);
            var AllForms = new com.InfinityOLB.PortfolioManagementMA.AllForms({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "AllForms",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "23%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "270dp",
                "zIndex": 20,
                "appName": "PortfolioManagementMA",
                "overrides": {
                    "AllForms": {
                        "isVisible": false,
                        "left": "23%",
                        "top": "25dp",
                        "width": "270dp",
                        "zIndex": 20
                    },
                    "RichTextInfo": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.viewDetailsinfo\")",
                        "width": "83%"
                    },
                    "imgToolTip": {
                        "left": "39%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxOption4.add(flxCheckBox4, lblOption4, lblOption4Description, ImgTextMessageInfo, flxImgInfoIcon, AllForms);
            flxOptions.add(lblPleaseChoose, flxOption3, flxWarning, flxOption4);
            flxEditPhoneNumberContent.add(flxError, flxPhoneNumber, flxEditPhoneNumberSeperator2, flxOptions);
            var flxEditPhoneNumberButtons = new kony.ui.FlexContainer({
                "bottom": 0,
                "clipBounds": true,
                "height": "80px",
                "id": "flxEditPhoneNumberButtons",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0fd0ec3c44e314c",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditPhoneNumberButtons.setDefaultUnit(kony.flex.DP);
            var flxEditPhoneNumberSeperator3 = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1px",
                "id": "flxEditPhoneNumberSeperator3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxEditPhoneNumberSeperator3.setDefaultUnit(kony.flex.DP);
            flxEditPhoneNumberSeperator3.add();
            var btnEditPhoneNumberSave = new kony.ui.Button({
                "bottom": "20dp",
                "height": "40dp",
                "id": "btnEditPhoneNumberSave",
                "isVisible": true,
                "right": "20dp",
                "skin": "sknBtn0273e3Border0273e3pxOp100Radius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.Save\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtn3343a8Border3343a82pxRadius2pxhover"
            });
            var btnEditPhoneNumberCancel = new kony.ui.Button({
                "bottom": "20dp",
                "height": "40dp",
                "id": "btnEditPhoneNumberCancel",
                "isVisible": true,
                "right": "190dp",
                "skin": "sknBtnffffffBorder0273e315pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "width": "150dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxEditPhoneNumberButtons.add(flxEditPhoneNumberSeperator3, btnEditPhoneNumberSave, btnEditPhoneNumberCancel);
            flxEditPhoneNumberContainer.add(flxEditPhoneNumberContent, flxEditPhoneNumberButtons);
            flxEditPhoneNumbersWrapper.add(flxEditPhoneNumberHeading, flxEditPhoneNumberContainer);
            flxContainer.add(flxEditPhoneNumbersWrapper);
            flxRight.add(flxContainer);
            flxSettingsContainer.add(flxMenuItemMobile, flxLeft, flxRight);
            flxContent.add(flxSettingsContainer);
            flxMain.add(lblContentHeader, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooternew = new com.InfinityOLB.Resources.customfooternew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooternew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "customfooternew": {
                        "left": "0dp",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooternew);
            flxFormContent.add(flxHeader, flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxPopup = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "140%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Opacity40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1200,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "250dp",
                "width": "43%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "top": "250dp",
                        "width": "43%"
                    },
                    "btnNo": {
                        "left": "5.48%",
                        "right": "viz.val_cleared"
                    },
                    "btnYes": {
                        "right": "4.89%"
                    },
                    "flxCross": {
                        "height": "30dp",
                        "right": "16dp",
                        "width": "30dp",
                        "zIndex": 5
                    },
                    "imgCross": {
                        "centerX": "52%",
                        "height": "15dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfer.QuitTransfer\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"I18n.billPay.QuitTransactionMsg\")",
                        "width": "80%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    }
                },
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "ManageProfileMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxLogout = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "ICSknScrlFlx000000OP40",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1000
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CopyCustomPopup0da94f13237d34a = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "centerY": "50%",
                "height": "268px",
                "id": "CopyCustomPopup0da94f13237d34a",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "width": "500px",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "isVisible": true
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CopyCustomPopup0da94f13237d34a);
            flxDialogs.add(flxPopup, flxLoading, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "lblContentHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxSettingsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "skin": "slFbox",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "isVisible": true,
                        "skin": "sknFlxffffffShadowPlain",
                        "zIndex": 400,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "4.40%"
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "skin": "sknSSP4176a413px",
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "flxAccountSettingsCollapseMobile": {
                        "zIndex": 100,
                        "segmentProps": []
                    },
                    "lblCollapseMobile": {
                        "text": "O",
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "profileMenu.flxProfileMenu": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "flxRight": {
                        "height": {
                            "type": "string",
                            "value": "630dp"
                        },
                        "skin": "slFbox",
                        "segmentProps": []
                    },
                    "flxContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "600dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "right": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "skin": "ICSknFlxffffffShadowdddcdc3",
                        "top": {
                            "type": "string",
                            "value": "12dp"
                        },
                        "width": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxEditPhoneNumbersWrapper": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblEditPhoneNumberHeading": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "segmentProps": []
                    },
                    "flxEditPhoneNumberContainer": {
                        "height": {
                            "type": "string",
                            "value": "550dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxEditPhoneNumberContent": {
                        "height": {
                            "type": "string",
                            "value": "420dp"
                        },
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "minHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxPhoneNumber": {
                        "height": {
                            "type": "string",
                            "value": "200dp"
                        },
                        "segmentProps": []
                    },
                    "flxContainer1": {
                        "minHeight": {
                            "type": "string",
                            "value": "70dp"
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumberType": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "25px"
                        },
                        "segmentProps": []
                    },
                    "lbxPhoneNumberType": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "96%"
                        },
                        "segmentProps": []
                    },
                    "lblPhoneNumber": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20px"
                        },
                        "segmentProps": []
                    },
                    "flxEditPhoneNumberCountryCode": {
                        "left": {
                            "type": "string",
                            "value": "2%"
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "tbxEditPhoneNumberCountryCode": {
                        "padding": [15, 0, 0, 0],
                        "segmentProps": []
                    },
                    "tbxPhoneNumber": {
                        "padding": [15, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "73%"
                        },
                        "segmentProps": []
                    },
                    "flxEditPhoneNumberSeperator2": {
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblPleaseChoose": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxOption3": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblOption3": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopyimgWarning0d045e22dc1104f": {
                        "src": "error_yellow.png",
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "segmentProps": []
                    },
                    "flxOption4": {
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "lblOption4": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "lblOption4Description": {
                        "segmentProps": []
                    },
                    "flxImgInfoIcon": {
                        "segmentProps": []
                    },
                    "flxEditPhoneNumberButtons": {
                        "bottom": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "height": {
                            "type": "string",
                            "value": "130px"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "maxWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnEditPhoneNumberSave": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "btnEditPhoneNumberCancel": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "0%"
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxDialogs": {
                        "segmentProps": []
                    },
                    "CopyCustomPopup0da94f13237d34a": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxAccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxContextualMenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxLogoAndActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuLeft": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxSeparatorNew": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "padding": [0, 0, 2, 0],
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSettingsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxEditPhoneNumberContainer": {
                        "height": {
                            "type": "string",
                            "value": "650dp"
                        },
                        "segmentProps": []
                    },
                    "flxEditPhoneNumberCountryCode": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "width": {
                            "type": "string",
                            "value": "55%"
                        },
                        "segmentProps": []
                    },
                    "tbxEditPhoneNumberCountryCode": {
                        "padding": [10, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "25%"
                        },
                        "segmentProps": []
                    },
                    "tbxPhoneNumber": {
                        "padding": [10, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "65%"
                        },
                        "segmentProps": []
                    },
                    "lblOption3": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopyimgWarning0d045e22dc1104f": {
                        "src": "error_yellow.png",
                        "segmentProps": []
                    },
                    "lblOption4": {
                        "left": {
                            "type": "string",
                            "value": "10%"
                        },
                        "segmentProps": []
                    },
                    "flxLogout": {
                        "segmentProps": []
                    },
                    "CopyCustomPopup0da94f13237d34a": {
                        "width": {
                            "type": "string",
                            "value": "75%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheadernew.flxActionsMenu": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuLeft": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuRight": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "ref",
                            "value": kony.flex.USE_PREFFERED_SIZE
                        },
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "padding": [0, 0, 2, 0],
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSettingsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "87.86%"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblAccountSettingsMobile": {
                        "text": "ACCOUNT SETTINGS",
                        "segmentProps": []
                    },
                    "flxEditPhoneNumberContainer": {
                        "segmentProps": []
                    },
                    "CopyimgError0e5915ab907ef4c": {
                        "width": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "segmentProps": []
                    },
                    "lblError": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "tbxEditPhoneNumberCountryCode": {
                        "padding": [15, 0, 0, 0],
                        "segmentProps": []
                    },
                    "tbxPhoneNumber": {
                        "left": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "padding": [15, 0, 0, 0],
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopyimgWarning0d045e22dc1104f": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "src": "error_yellow.png",
                        "width": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    },
                    "customfooternew": {
                        "segmentProps": []
                    }
                },
                "1380": {
                    "customheadernew.flxActionsMenu": {
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "padding": [0, 0, 2, 0],
                        "top": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "bottom": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxSettingsContainer": {
                        "bottom": {
                            "type": "string",
                            "value": ""
                        },
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1202dp"
                        },
                        "segmentProps": []
                    },
                    "flxMenuItemMobile": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "maxHeight": {
                            "type": "string",
                            "value": "700dp"
                        },
                        "segmentProps": []
                    },
                    "CopyimgError0e5915ab907ef4c": {
                        "width": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "segmentProps": []
                    },
                    "lblError": {
                        "left": {
                            "type": "string",
                            "value": "60dp"
                        },
                        "segmentProps": []
                    },
                    "tbxEditPhoneNumberCountryCode": {
                        "padding": [15, 0, 0, 0],
                        "segmentProps": []
                    },
                    "tbxPhoneNumber": {
                        "left": {
                            "type": "string",
                            "value": "17dp"
                        },
                        "padding": [15, 0, 0, 0],
                        "text": "",
                        "width": {
                            "type": "string",
                            "value": "71%"
                        },
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "CopyimgWarning0d045e22dc1104f": {
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "src": "error_yellow.png",
                        "width": {
                            "type": "string",
                            "value": "6.50%"
                        },
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "left": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew": {
                    "centerX": "",
                    "width": "100%"
                },
                "customheadernew.flxActionsMenu": {
                    "top": "0dp"
                },
                "customheadernew.imgKony": {
                    "src": "kony_logo.png"
                },
                "customheadernew.imgLogout": {
                    "src": "logout.png"
                },
                "customheadernew.imgMenu": {
                    "src": "menu_icon.png"
                },
                "customheadernew.imgNotifications": {
                    "src": "notification_flag.png"
                },
                "AllForms": {
                    "left": "23%",
                    "top": "25dp",
                    "width": "270dp",
                    "zIndex": 20
                },
                "AllForms.RichTextInfo": {
                    "width": "83%"
                },
                "AllForms.imgToolTip": {
                    "left": "39%"
                },
                "customfooternew": {
                    "left": "0dp",
                    "top": "0dp"
                },
                "CustomPopup": {
                    "centerX": "50%",
                    "centerY": "",
                    "top": "250dp",
                    "width": "43%"
                },
                "CustomPopup.btnNo": {
                    "left": "5.48%",
                    "right": ""
                },
                "CustomPopup.btnYes": {
                    "right": "4.89%"
                },
                "CustomPopup.flxCross": {
                    "height": "30dp",
                    "right": "16dp",
                    "width": "30dp",
                    "zIndex": 5
                },
                "CustomPopup.imgCross": {
                    "centerX": "52%",
                    "height": "15dp"
                },
                "CustomPopup.lblPopupMessage": {
                    "width": "80%"
                }
            }
            this.add(flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmSettingsEditPhoneNumber,
            "enabledForIdleTimeout": true,
            "id": "frmSettingsEditPhoneNumber",
            "init": controller.AS_Form_de8f2bb893c1478caa4afc644c5216a8,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "i18n_title": "kony.i18n.getLocalizedString(\"i18n.ProfileManagement.EditPhoneNumber\")",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "ManageProfileMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});