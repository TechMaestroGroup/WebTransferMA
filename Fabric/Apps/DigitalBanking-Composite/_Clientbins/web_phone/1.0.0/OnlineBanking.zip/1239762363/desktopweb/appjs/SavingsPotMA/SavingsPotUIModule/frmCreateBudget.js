define("SavingsPotMA/SavingsPotUIModule/frmCreateBudget", function() {
    return function(controller) {
        function addWidgetsfrmCreateBudget() {
            this.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var customheadernew = new com.InfinityOLB.Resources.customheadernew({
                "height": "121px",
                "id": "customheadernew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "ResourcesMA",
                "overrides": {
                    "customheadernew": {
                        "centerX": "viz.val_cleared",
                        "width": "100%"
                    },
                    "lblHeaderMobile": {
                        "isVisible": true
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(customheadernew);
            var flxFormContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": 0,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxFormContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "120dp",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "paddingInPixel": false
            }, {});
            flxFormContent.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var lblContentHeader = new kony.ui.Label({
                "id": "lblContentHeader",
                "isVisible": true,
                "left": "3.25%",
                "skin": "sknlblUserName",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.lblTitleCreateBudget\")",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxContent.setDefaultUnit(kony.flex.DP);
            var flxBudgetDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "clipBounds": false,
                "id": "flxBudgetDetails",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3.25%",
                "isModalContainer": false,
                "skin": "slfBoxffffffB1R5",
                "top": "0dp",
                "width": "93.50%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBudgetDetails.setDefaultUnit(kony.flex.DP);
            var flxError = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxError",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "19dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxError.setDefaultUnit(kony.flex.DP);
            var lblError = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.accounts.swiftCode\")"
                },
                "id": "lblError",
                "isVisible": true,
                "left": "2.20%",
                "skin": "sknlblff000015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.sameBudgetNameError\")",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 2, 0],
                "paddingInPixel": false
            }, {});
            flxError.add(lblError);
            var flxWarning = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxWarning",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.30%",
                "isModalContainer": false,
                "skin": "sknFlxffffffborderradE3E3E3",
                "top": "30dp",
                "width": "95.40%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxWarning.setDefaultUnit(kony.flex.DP);
            var lblAlertsWarningImageNew = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"kony.mb.NAO.Info\")"
                },
                "bottom": "20dp",
                "height": "34dp",
                "id": "lblAlertsWarningImageNew",
                "isVisible": true,
                "left": "15dp",
                "skin": "sknlbl4a90e230OLBFontIconsPx",
                "text": "K",
                "top": "20dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWarning = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.WireTransfer.PleaseActivateWireTransferToSendMoney\")"
                },
                "bottom": "20dp",
                "id": "lblWarning",
                "isVisible": true,
                "left": "20dp",
                "minHeight": "34dp",
                "skin": "bbSknLbl424242SSP15Px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.budgetInfo\")",
                "top": "20dp",
                "width": "85%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxWarning.add(lblAlertsWarningImageNew, lblWarning);
            var flxBdgtNameAndCharCnt = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": true,
                "id": "flxBdgtNameAndCharCnt",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.30%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45.34%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBdgtNameAndCharCnt.setDefaultUnit(kony.flex.DP);
            var lblBudgetName = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.LoanPayoffAmount\")"
                },
                "height": "18px",
                "id": "lblBudgetName",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.budgetName\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblNameCharCount = new kony.ui.Label({
                "height": "18px",
                "id": "lblNameCharCount",
                "isVisible": true,
                "left": "90%",
                "right": "2dp",
                "skin": "sknlbla0a0a015px",
                "text": "15/30",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBdgtNameAndCharCnt.add(lblBudgetName, lblNameCharCount);
            var flxBudgetNameTxt = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxBudgetNameTxt",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.20%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "5dp",
                "width": "40%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxBudgetNameTxt.setDefaultUnit(kony.flex.DP);
            var tbxbudgetName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "sknTbxBorder0036751px",
                "height": "40dp",
                "id": "tbxbudgetName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "2.30%",
                "maxTextLength": 30,
                "placeholder": "Budget Name",
                "secureTextEntry": false,
                "skin": "sknTxtBrodere0e0e0",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "5dp",
                "width": "45.34%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxBudgetNameTxt.add(tbxbudgetName);
            var lblBudgetAmount = new kony.ui.Label({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.PayDueAmount.LoanPayoffAmount\")"
                },
                "height": "18px",
                "id": "lblBudgetAmount",
                "isVisible": true,
                "left": "2.30%",
                "skin": "sknlbla0a0a015px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.savingsPot.budgetAmount\")",
                "top": "20dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAmountValue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "40dp",
                "id": "flxAmountValue",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "2.20%",
                "isModalContainer": false,
                "skin": "skne3e3e3br3pxradius",
                "top": "5dp",
                "width": "40%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxAmountValue.setDefaultUnit(kony.flex.DP);
            var lblCurrency = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblCurrency",
                "isVisible": true,
                "left": "13dp",
                "skin": "bbSknLbl424242SSP15Px",
                "text": "$",
                "top": 20,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var tbxAmount = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "id": "tbxAmount",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "maxTextLength": 16,
                "i18n_placeholder": "kony.i18n.getLocalizedString(\"i18n.transfers.lblAmount\")",
                "secureTextEntry": false,
                "skin": "skntbxSSP42424215pxnoborder",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": 20,
                "width": "50%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "autoComplete": "off"
            });
            flxAmountValue.add(lblCurrency, tbxAmount);
            var flxSeperator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "1dp",
                "id": "flxSeperator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2.30%",
                "isModalContainer": false,
                "skin": "sknflxe9ebee",
                "top": "30dp",
                "width": "95.40%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeperator.setDefaultUnit(kony.flex.DP);
            flxSeperator.add();
            var flxSubmitBtnWrapper = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100dp",
                "id": "flxSubmitBtnWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "reverseLayoutDirection": false,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 5,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubmitBtnWrapper.setDefaultUnit(kony.flex.DP);
            var btnContinue = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.Yes\")"
                },
                "centerX": "92%",
                "centerY": "50%",
                "focusSkin": "sknBtnFocusSSPFFFFFF15Px0273e3",
                "height": "40dp",
                "id": "btnContinue",
                "isVisible": true,
                "skin": "sknBtnNormalSSPFFFFFF4vs",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.userManagement.Continue\")",
                "top": "0dp",
                "width": "15%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnHoverSSPFFFFFF15Px",
                "toolTip": "Continue"
            });
            var btnBack = new kony.ui.Button({
                "accessibilityConfig": {
                    "a11yLabel": "kony.i18n.getLocalizedString(\"i18n.SignatoryMatrix.No\")"
                },
                "centerY": "50%",
                "focusSkin": "sknBtnSecondaryFocusSSP4A90E215Px",
                "height": "40dp",
                "id": "btnBack",
                "isVisible": true,
                "right": "17%",
                "skin": "sknBtnffffffBorder0273e31pxRadius2px",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfers.Cancel\")",
                "top": "0dp",
                "width": "15%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "hoverSkin": "sknBtnffffffBorder3343a81pxRadius2px"
            });
            flxSubmitBtnWrapper.add(btnContinue, btnBack);
            flxBudgetDetails.add(flxError, flxWarning, flxBdgtNameAndCharCnt, flxBudgetNameTxt, lblBudgetAmount, flxAmountValue, flxSeperator, flxSubmitBtnWrapper);
            flxContent.add(flxBudgetDetails);
            flxMain.add(lblContentHeader, flxContent);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "150dp",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var customfooter = new com.InfinityOLB.Resources.customfooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "150dp",
                "id": "customfooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "ResourcesMA",
                "overrides": {
                    "lblCopyright": {
                        "left": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(customfooter);
            flxFormContent.add(flxMain, flxFooter);
            var flxDialogs = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flxDialogs",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxDialogs.setDefaultUnit(kony.flex.DP);
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "140%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlx000000Opacity40",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1200,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var CustomPopup = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50%",
                "height": "268px",
                "id": "CustomPopup",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "250dp",
                "width": "43%",
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50%",
                        "centerY": "viz.val_cleared",
                        "top": "250dp",
                        "width": "43%"
                    },
                    "btnNo": {
                        "left": "5.48%",
                        "right": "viz.val_cleared"
                    },
                    "btnYes": {
                        "right": "4.89%"
                    },
                    "flxCross": {
                        "height": "30dp",
                        "right": "16dp",
                        "width": "30dp",
                        "zIndex": 5
                    },
                    "imgCross": {
                        "centerX": "52%",
                        "height": "15dp"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.transfer.QuitTransfer\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"I18n.billPay.QuitTransactionMsg\")",
                        "width": "80%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(CustomPopup);
            var flxLoading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLoading",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0px",
                "isModalContainer": false,
                "skin": "sknChangeLangBlueGradient",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoading.setDefaultUnit(kony.flex.DP);
            var flxLoadingWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "150dp",
                "id": "flxLoadingWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "top": "250dp",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoadingWrapper.setDefaultUnit(kony.flex.DP);
            var flxImageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "150dp",
                "id": "flxImageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox0h9a2ed84d2df4f",
                "width": "150dp",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxImageContainer.setDefaultUnit(kony.flex.DP);
            var imgLoading = new kony.ui.Image2({
                "accessibilityConfig": {
                    "a11yARIA": {
                        "tabindex": -1
                    },
                    "a11yHidden": true
                },
                "height": "100%",
                "id": "imgLoading",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "loading.gif",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxImageContainer.add(imgLoading);
            flxLoadingWrapper.add(flxImageContainer);
            flxLoading.add(flxLoadingWrapper);
            var flxLogout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-100%",
                "isModalContainer": false,
                "skin": "sknBackground000000Op35",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1000,
                "appName": "SavingsPotMA"
            }, {
                "paddingInPixel": false
            }, {});
            flxLogout.setDefaultUnit(kony.flex.DP);
            var CustomPopupLogout = new com.InfinityOLB.Resources.CustomPopup({
                "centerX": "50.00%",
                "height": "268px",
                "id": "CustomPopupLogout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknBGFFFFFBdrRadius4PxShadow303030",
                "top": "300dp",
                "width": "44.30%",
                "zIndex": 1100,
                "appName": "ResourcesMA",
                "overrides": {
                    "CustomPopup": {
                        "centerX": "50.00%",
                        "centerY": "viz.val_cleared",
                        "top": "300dp",
                        "width": "44.30%",
                        "zIndex": 1100
                    },
                    "imgCross": {
                        "height": "15dp",
                        "src": "bbcloseicon.png"
                    },
                    "lblHeading": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.billPay.QuitBillPay\")"
                    },
                    "lblPopupMessage": {
                        "i18n_text": "kony.i18n.getLocalizedString(\"i18n.Transfers.Areyousureyouwanttocancelthistransaction\")"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxLogout.add(CustomPopupLogout);
            flxDialogs.add(flxPopup, flxLoading, flxLogout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1380,
                "640": {
                    "flxFormContent": {
                        "top": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxBudgetDetails": {
                        "left": {
                            "type": "string",
                            "value": "4.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "91%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "flxWarning": {
                        "layoutType": kony.flex.FLOW_HORIZONTAL,
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.40%"
                        },
                        "segmentProps": []
                    },
                    "lblAlertsWarningImageNew": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "bottom": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "top": {
                            "type": "string",
                            "value": "15dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": []
                    },
                    "flxBdgtNameAndCharCnt": {
                        "width": {
                            "type": "string",
                            "value": "95.40%"
                        },
                        "segmentProps": []
                    },
                    "lblNameCharCount": {
                        "left": {
                            "type": "string",
                            "value": "82%"
                        },
                        "segmentProps": []
                    },
                    "flxBudgetNameTxt": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.40%"
                        },
                        "segmentProps": []
                    },
                    "tbxbudgetName": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "skin": "skntbxSSP42424215pxnoborder",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.40%"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "width": {
                            "type": "string",
                            "value": "96.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSeperator": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxSubmitBtnWrapper": {
                        "height": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.40%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.40%"
                        },
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxHeader": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew": {
                        "height": {
                            "type": "string",
                            "value": "50px"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxAccounts": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxContextualMenu": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxLogoAndActions": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuContainer": {
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuLeft": {
                        "left": {
                            "type": "string",
                            "value": "10dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuRight": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMyBills": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxSeparatorNew": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxSeperator1": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.flxTransfersAndPay": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "customheadernew.lblHeaderMobile": {
                        "isVisible": true,
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxBudgetDetails": {
                        "left": {
                            "type": "string",
                            "value": "2.50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "95%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxBdgtNameAndCharCnt": {
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "lblNameCharCount": {
                        "left": {
                            "type": "string",
                            "value": "90%"
                        },
                        "right": {
                            "type": "string",
                            "value": "2dp"
                        },
                        "text": "15/30",
                        "segmentProps": []
                    },
                    "flxBudgetNameTxt": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "tbxbudgetName": {
                        "left": {
                            "type": "string",
                            "value": "8dp"
                        },
                        "padding": [1, 0, 0, 0],
                        "skin": "skntbxSSP42424215pxnoborder",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "70%"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "width": {
                            "type": "string",
                            "value": "97%"
                        },
                        "segmentProps": []
                    },
                    "flxSubmitBtnWrapper": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.40%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": "90%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "right": {
                            "type": "string",
                            "value": "23.50%"
                        },
                        "width": {
                            "type": "string",
                            "value": "20%"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "8.07%"
                        },
                        "segmentProps": []
                    }
                },
                "1366": {
                    "customheadernew.flxActionsMenu": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxLogoAndActionsWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuLeft": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuRight": {
                        "right": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.flxMenuWrapper": {
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "customheadernew.imgKony": {
                        "left": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "lblContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.80%"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "segmentProps": []
                    },
                    "flxBudgetDetails": {
                        "left": {
                            "type": "string",
                            "value": "6.07%"
                        },
                        "right": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "87.80%"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxBudgetNameTxt": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45.34%"
                        },
                        "segmentProps": []
                    },
                    "tbxbudgetName": {
                        "left": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "skin": "skntbxSSP42424215pxnoborder",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98.54%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45.34%"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "padding": [1, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "96.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSubmitBtnWrapper": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.40%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "centerY": {
                            "type": "string",
                            "value": "50%"
                        },
                        "right": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "171dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "8.07%"
                        },
                        "segmentProps": []
                    }
                },
                "1380": {
                    "lblContentHeader": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "height": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxContent": {
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "20dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxBudgetDetails": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "80dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "1200dp"
                        },
                        "segmentProps": []
                    },
                    "flxError": {
                        "isVisible": false,
                        "segmentProps": []
                    },
                    "lblWarning": {
                        "width": {
                            "type": "string",
                            "value": "90%"
                        },
                        "segmentProps": []
                    },
                    "flxBudgetNameTxt": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45.34%"
                        },
                        "segmentProps": []
                    },
                    "tbxbudgetName": {
                        "left": {
                            "type": "string",
                            "value": "6dp"
                        },
                        "placeholderSkin": "",
                        "skin": "skntbxSSP42424215pxnoborder",
                        "text": "",
                        "top": {
                            "type": "string",
                            "value": "0dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "98.50%"
                        },
                        "segmentProps": []
                    },
                    "flxAmountValue": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "45.34%"
                        },
                        "segmentProps": []
                    },
                    "tbxAmount": {
                        "padding": [1, 0, 0, 0],
                        "width": {
                            "type": "string",
                            "value": "96.50%"
                        },
                        "segmentProps": []
                    },
                    "flxSubmitBtnWrapper": {
                        "left": {
                            "type": "string",
                            "value": "2.30%"
                        },
                        "width": {
                            "type": "string",
                            "value": "95.40%"
                        },
                        "segmentProps": []
                    },
                    "btnContinue": {
                        "centerX": {
                            "type": "string",
                            "value": ""
                        },
                        "right": {
                            "type": "string",
                            "value": "1dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "btnBack": {
                        "right": {
                            "type": "string",
                            "value": "171dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "150dp"
                        },
                        "segmentProps": []
                    },
                    "flxFooter": {
                        "accessibilityConfig": {},
                        "segmentProps": []
                    },
                    "customfooter.lblCopyright": {
                        "left": {
                            "type": "string",
                            "value": "8.07%"
                        },
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "customheadernew": {
                    "centerX": "",
                    "width": "100%"
                },
                "customfooter.lblCopyright": {
                    "left": ""
                },
                "CustomPopup": {
                    "centerX": "50%",
                    "centerY": "",
                    "top": "250dp",
                    "width": "43%"
                },
                "CustomPopup.btnNo": {
                    "left": "5.48%",
                    "right": ""
                },
                "CustomPopup.btnYes": {
                    "right": "4.89%"
                },
                "CustomPopup.flxCross": {
                    "height": "30dp",
                    "right": "16dp",
                    "width": "30dp",
                    "zIndex": 5
                },
                "CustomPopup.imgCross": {
                    "centerX": "52%",
                    "height": "15dp"
                },
                "CustomPopup.lblPopupMessage": {
                    "width": "80%"
                },
                "CustomPopupLogout": {
                    "centerX": "50.00%",
                    "centerY": "",
                    "top": "300dp",
                    "width": "44.30%",
                    "zIndex": 1100
                },
                "CustomPopupLogout.imgCross": {
                    "height": "15dp",
                    "src": "bbcloseicon.png"
                }
            }
            this.add(flxHeader, flxFormContent, flxDialogs);
        };
        return [{
            "addWidgets": addWidgetsfrmCreateBudget,
            "enabledForIdleTimeout": true,
            "id": "frmCreateBudget",
            "init": controller.AS_Form_bbc4a6cc0dbc43e0803fb9954875683d,
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFrmf8f7f8",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366, 1380],
            "appName": "SavingsPotMA"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});